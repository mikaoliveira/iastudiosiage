# @siage/siage-ui

Biblioteca privada de componentes Angular do SIAGE.

Os componentes encapsulam o Angular Material por **composição**: a aplicação
consumidora usa apenas a API pública desta biblioteca (`<s-button>`,
`<s-autocomplete>`...), nunca `matButton`, `mat-form-field` ou `mat-autocomplete`
diretamente.

- Angular 20 · Angular Material 20 · Angular CDK 20
- Componentes standalone, `OnPush`, compatíveis com aplicações zoneless
- Prefixo `s-` para todos os componentes públicos
- **Escopo web.** O mobile do SIAGE é Flutter e usa outra biblioteca; as regras
  de mobile continuam descritas no guia de design, mas os componentes daqui não
  as implementam

---

## Instalação

> O quadro **Instalação** que o Gitea mostra acima desta página está incompleto:
> ele traz apenas a linha do registry. Falta a linha de autenticação — sem ela o
> `npm install` falha com `E401 Incorrect or missing password`. Use o `.npmrc`
> abaixo, com as **duas** linhas.

### 1. `.npmrc` da aplicação

```ini
@siage:registry=http://seepb.qa/api/packages/SEEPB-DesignSystem/npm/
//seepb.qa/api/packages/SEEPB-DesignSystem/npm/:_authToken=${GITEA_NPM_TOKEN}
```

`GITEA_NPM_TOKEN` é um token do Gitea com escopo **`package` -> `read:package`**
(um token só com escopo de repositório não autentica no registry npm). Gere em
http://seepb.qa/user/settings/applications e exporte antes de instalar:

```powershell
$env:GITEA_NPM_TOKEN = 'seu-token'
```

Você também pode colar o token literal no lugar de `${GITEA_NPM_TOKEN}` — desde
que o `.npmrc` esteja no `.gitignore`.

### 2. Instalar

```bash
npm install @siage/siage-ui
```

O `^20` que o npm grava é seguro: dentro da mesma major nada é removido nem muda
de comportamento — o que for substituído ganha `@deprecated` e só sai na major
seguinte, junto com o Angular. As versões publicadas e o que ficou descontinuado
estão no `CHANGELOG.md`.

**Só isso.** Angular Material, CDK e os demais pacotes do Angular são
`peerDependencies` e o npm 7+ os instala sozinho, uma única vez, no topo do
`node_modules` — sem segunda cópia do Angular no bundle. Confira depois com:

```bash
npm ls @angular/material @angular/cdk
```

Com **pnpm** ou **yarn clássico**, que não instalam peers automaticamente,
adicione-os na mão:

```bash
npm install @angular/material@^20.2.0 @angular/cdk@^20.2.0
```

### 3. Tema e fontes

O tema do design system vem dentro da biblioteca — veja [Tema (design system
SIAGE)](#tema-design-system-siage). Aplique o mixin (uma linha em
`src/styles.scss`) e carregue as fontes no `index.html`. A aplicação não monta
tema de Material por conta própria.

### 4. Providers da aplicação

Nada disso é obrigatório para começar — cada linha destrava um recurso, e o
`app.config.ts` fica assim:

```ts
import { ApplicationConfig } from '@angular/core';
import {
  provideSiageAutocompleteSource,
  provideSiageDateAdapter,
  provideSiageLoadingDelay,
  provideSiageValidationMessages,
} from '@siage/siage-ui';

export const appConfig: ApplicationConfig = {
  providers: [
    // Sem isto, <s-datepicker> lança erro em tempo de execução.
    provideSiageDateAdapter(),

    // Necessário só para url="..." no <s-autocomplete>, <s-multiselect> e <s-chips>.
    provideSiageAutocompleteSource(SiageAutocompleteSource),

    // Opcionais: só se quiser mudar os padrões.
    provideSiageValidationMessages({ required: 'Preencha este campo.' }),
    provideSiageLoadingDelay(1500),
  ],
};
```

| Provider                           | Quando é preciso                                        | Sem ele                   |
| ---------------------------------- | ------------------------------------------------------- | ------------------------- |
| `provideSiageDateAdapter()`        | ao usar `<s-datepicker>`                                | erro em tempo de execução |
| `provideSiageAutocompleteSource()` | ao usar `url` no autocomplete, multiselect ou etiquetas | erro ao buscar            |
| `provideSiageValidationMessages()` | para trocar as frases de validação                      | usa as frases padrão      |
| `provideSiageLoadingDelay()`       | para mudar o limiar do esqueleto                        | 3 segundos                |

### 5. Usar

```ts
import { SFieldComponent, SInputComponent } from '@siage/siage-ui';
```

```html
<s-field label="Nome" required>
  <s-input formControlName="nome" />
</s-field>
```

Os componentes são standalone: importe só os que a tela usa, no array `imports`
do próprio componente.

---

## Tema (design system SIAGE)

O tema vem **dentro da biblioteca**: cores, tipografia, espacamento, raio e
elevacao sao transcritos do _Guia de Design SIAGE_ em
`styles/_tokens.scss` e publicados junto com o pacote. A aplicacao nao redefine
nada — quando o guia muda, sai uma versao nova da lib e todos os sistemas
herdam.

### Aplicando

Em `src/styles.scss` da aplicacao:

```scss
@use '@siage/siage-ui/styles/theme' as siage;

html {
  @include siage.theme();
}
```

Sem SCSS, aponte o CSS ja compilado no `angular.json`:

```json
"styles": [
  "node_modules/@siage/siage-ui/styles/theme.css",
  "src/styles.css"
]
```

Aplique no `html`, nao num seletor interno: o painel do `<s-autocomplete>` e
qualquer menu, dialog ou tooltip do Material sao renderizados em overlay no
`<body>`, fora da arvore do componente. Um tema escopado deixaria esses
elementos sem identidade.

### Fontes

O guia define tres familias, que a aplicacao carrega no `index.html` (um pacote
npm nao consegue inserir `<link>` sozinho):

```html
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link
  href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&family=Roboto:wght@400;500;700&family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=swap"
  rel="stylesheet"
/>
```

- **Poppins** — conteudo estrutural (titulos, secoes);
- **Roboto** — conteudo operacional (textos, formularios, tabelas, botoes);
- **Material Symbols Rounded** — unica biblioteca de icones do sistema. Sem ela,
  o botao de limpar do autocomplete aparece como o texto `close`.

### Tema escuro

Os dois temas sao obrigatorios no guia e ja saem no mesmo CSS. O escuro entra:

- automaticamente, pela preferencia do sistema operacional;
- explicitamente, com `data-theme="dark"` no elemento raiz;
- `data-theme="light"` forca o claro mesmo com o SO em escuro.

```html
<html data-theme="dark"></html>
```

### Tokens disponiveis

Todos os tokens do guia viram CSS custom properties e podem ser usados nas telas
da aplicacao:

| Grupo       | Tokens                                                                                    |
| ----------- | ----------------------------------------------------------------------------------------- |
| Cor         | `--primary`, `--secondary`, `--success`, `--warning`, `--info`, `--destructive`           |
| Superficie  | `--background`, `--card`, `--border`, `--card-border`, `--surface-table-head`             |
| Texto       | `--text-primary`, `--text-secondary`, `--on-filled`, `--*-on-surface`                     |
| Estado      | `--primary-hover`, `--destructive-hover`, `--success-hover`, `--focus-ring`               |
| Tipografia  | `--font-display`, `--font-ui`, `--font-icon`, `--text-h1` a `--text-h6`, `--text-body`... |
| Espacamento | `--space-4` a `--space-64`                                                                |
| Raio        | `--radius-control` (8px), `--radius-container` (12px), `--radius-full`                    |
| Elevacao    | `--elevation-1` a `--elevation-3` (no tema escuro, todas `none`)                          |
| Tint        | `--tint-subtle`, `--tint-container`, `--tint-strong`                                      |
| Marca       | `--brand-navy`, `--brand-pink`, ... — **somente logotipo, nunca na interface**            |

Os mesmos valores alimentam os tokens de sistema do Angular Material
(`--mat-sys-*`), entao qualquer componente Material usado pela aplicacao ja sai
com a identidade correta.

### Escopando um trecho em tema fixo

```scss
@use '@siage/siage-ui/styles/theme' as siage;

.previa-escura {
  @include siage.tokens(dark);
}
```

---

## Versionamento

O major da biblioteca acompanha o major do Angular:

| `@siage/siage-ui` | Angular |
| ----------------- | ------- |
| `20.x`            | 20      |
| `21.x`            | 21      |
| `22.x`            | 22      |

- **major** — atualização do Angular, e a única hora em que algo é removido
- **minor** — novos componentes, inputs e outputs retrocompatíveis, e o aviso
  `@deprecated` do que for substituído
- **patch** — correções

**Atualizar dentro da mesma major nunca quebra o sistema.** Nada que já existe é
removido, renomeado ou muda de comportamento numa minor ou num patch. O que for
substituído continua funcionando, marcado como `@deprecated` e listado na seção
`Descontinuado` do `CHANGELOG.md`, e só sai na major seguinte.

Versão inicial: **20.0.0**.

### Tags

Publicação é por tag, e cada prefixo publica uma coisa:

```
v20.2.0   -> publica o pacote @siage/siage-ui@20.2.0   (publicar-lib.yml)
s20.2.0   -> atualiza a página do Storybook            (publicar-storybook.yml)
```

**A tag `v` é a versão.** O workflow grava o número da tag no `package.json`
antes do build, então não há commit de "subir versão" antes de marcar. A trava
é a **major**: ela acompanha o Angular e a branch (`v20`, `v21`), e uma tag
cuja major diverge da do `package.json` falha antes de publicar — é o que
impede sair uma `21.0.0` com código Angular 20.

O Storybook tem tag própria para que corrigir uma story não exija versão nova
do pacote.

---

## Componentes

| Componente              | Base no Material    | Papel                                    |
| ----------------------- | ------------------- | ---------------------------------------- |
| `<s-icon>`              | `mat-icon`          | Glifo do Material Symbols Rounded        |
| `<s-button>`            | `matButton`         | Ação, em seis variantes semânticas       |
| `<s-icon-button>`       | `matIconButton`     | Ação sem rótulo visível                  |
| `<s-card>`              | —                   | Superfície de conteúdo                   |
| `<s-badge>`             | —                   | Rótulo curto de estado                   |
| `[sTooltip]`            | `matTooltip`        | Ajuda de apoio no hover e no foco        |
| `<s-field>`             | —                   | Envelope: rótulo, ajuda e faixa de erro  |
| `<s-input>`             | —                   | Campo de linha única, também de busca    |
| `<s-textarea>`          | —                   | Campo de texto longo                     |
| `<s-select>`            | `mat-select`        | Escolha em domínio fechado               |
| `<s-multiselect>`       | `mat-select`        | Escolha múltipla                         |
| `<s-autocomplete>`      | `mat-autocomplete`  | Busca tipada, com `options` ou por `url` |
| `<s-datepicker>`        | `matDatepicker`     | Data em `dd/MM/yyyy`                     |
| `<s-checkbox>`          | —                   | Caixa de seleção em formulário salvo     |
| `<s-switch>`            | —                   | Alternância com efeito imediato          |
| `<s-table>`             | —                   | Listagem, com os quatro estados          |
| `<s-filter-card>`       | —                   | Filtros acima da listagem                |
| `<s-pagination>`        | —                   | Rodapé da tabela                         |
| `<s-record-count>`      | —                   | Contagem do resultado atual              |
| `<s-empty-state>`       | —                   | Vazio, erro e sem permissão              |
| `<s-skeleton>`          | —                   | Carregando, no formato do conteúdo       |
| `<s-alert>`             | —                   | Aviso que permanece na página            |
| `SToastService`         | `MatSnackBar`       | Avisos em pilha, canto superior direito  |
| `SModalService`         | `MatDialog`         | Confirmação numa linha                   |
| `<s-page-header>`       | —                   | Trilha, título, descrição e ação         |
| `<s-top-bar>`           | —                   | Barra superior de 64px                   |
| `<s-sidebar>`           | —                   | Menu lateral de 256px                    |
| `<s-chips>`             | `mat-autocomplete`  | Seleção múltipla que vira etiquetas      |
| `<s-file-upload>`       | —                   | Escolha de arquivo, com validação        |
| `<s-radio-group>`       | `mat-radio-group`   | Escolha única entre poucas opções        |
| `<s-selection-buttons>` | `mat-button-toggle` | Escolha em botões                        |
| `<s-tabs>`              | —                   | Navegação por abas                       |
| `<s-stat-card>`         | —                   | Número grande com o que significa        |
| `<s-theme-toggle>`      | —                   | Alterna claro e escuro                   |
| `<s-crud-list>`         | —                   | Tela de listagem inteira (entry `/crud`) |
| `injectCrudList()`      | —                   | Estado e comportamento do CRUD           |

Cada um tem página própria no Storybook, com a tabela de API completa e os
parâmetros editáveis. O que segue é o resumo.

### Núcleo

#### `<s-icon>`

Glifo do **Material Symbols Rounded**, a única biblioteca de ícones do SIAGE.
Os tamanhos são fixos por contexto, não por preferência.

```html
<s-icon name="search" size="sm" />
```

| Input        | Tipo           | Padrão        | Descrição                                                               |
| ------------ | -------------- | ------------- | ----------------------------------------------------------------------- |
| `name`       | `string`       | — (requerido) | Nome do glifo, ex. `search`, `delete`, `chevron_right`                  |
| `size`       | `number`       | `20`          | 20 controle · 24 navegação · 16 badge e ajuda · 48+ vazio               |
| `iconFilled` | `boolean`      | `false`       | Preenche o glifo (eixo FILL) — no guia, só o item ativo da navegação    |
| `variant`    | `SIconVariant` | `'default'`   | Cor do papel no glifo (`text-*`)                                        |
| `filled`     | `boolean`      | `false`       | Fundo de container da `variant` (`bg-*-container`); sem `variant`, nada |
| `color`      | `string`       | herda         | Cor explícita; por padrão acompanha o texto ao redor                    |
| `label`      | `string`       | `''`          | Torna o ícone anunciável (`role="img"` + `aria-label`)                  |

O ícone é decorativo por padrão. Informe `label` só quando o glifo for o único
conteúdo com significado.

#### `<s-button>`

```html
<s-button variant="primary" icon="add">Nova Jornada</s-button>
```

| Input         | Tipo                              | Padrão      | Descrição                                    |
| ------------- | --------------------------------- | ----------- | -------------------------------------------- |
| `variant`     | `SButtonVariant`                  | `'primary'` | Papel da ação na tela                        |
| `outlined`    | `boolean`                         | `false`     | Troca o preenchimento por contorno na cor    |
| `fullWidth`   | `boolean`                         | `false`     | Largura total e a altura maior do guia       |
| `loading`     | `boolean`                         | `false`     | Glifo de progresso; bloqueia o clique        |
| `loadingText` | `string \| undefined`             | `undefined` | Texto no lugar do rótulo durante `loading`   |
| `disabled`    | `boolean`                         | `false`     | Ação indisponível                            |
| `icon`        | `string`                          | `''`        | Glifo de 20px à esquerda                     |
| `iconRight`   | `string`                          | `''`        | Glifo de 20px à direita (`link_2` em `link`) |
| `type`        | `'button' \| 'submit' \| 'reset'` | `'button'`  | Atributo do botão nativo                     |

Variantes: `primary` (a única ação principal da tela), `secondary` (apoio ao
lado da principal, e a ação neutra em grupo quando contornada, como
Limpar/Buscar), `success`, `warning` e `info` (ações de tom semântico),
`ghost` (ação discreta em linha de tabela), `destructive` (remove ou desfaz,
sempre nomeada) e `link` (navegação com aparência de texto).

Alturas, todas vindas de token: 40px normalmente e 48px em largura total —
menos em `link`, que não é um controle e não tem altura fixa.

`link` é sublinhado o tempo todo, não só no hover, e já traz o glifo `link_2`
à direita: sem moldura e sem fundo, sublinhado e glifo são os únicos sinais de
que aquele texto é clicável. `iconRight` substitui o glifo — use `open_in_new`
no que abre em outra aba. No hover o que muda é a cor.

`outlined` vale para as variantes preenchidas; em `ghost` e `link` é ignorado,
porque não haveria estado novo para produzir. Esta combinação não está no guia
— existe para cobrir os botões contornados que o Professores já usa, e
reaproveita as opacidades que o guia já fixou.

Em `loading` o botão **continua habilitado e focável** e anuncia `aria-busy`,
mas deixa de responder ao clique. Desabilitar faria o controle sumir da
navegação por teclado no meio da ação.

Com `loadingText` (padrão `undefined`), o rótulo é trocado por ele enquanto
`loading` for `true` e a troca é anunciada (`aria-live="polite"`), sem perder o
foco. Para travar os demais botões da barra de ações, ligue o `[disabled]` de
cada um ao mesmo estado de salvamento da tela.

#### `<s-icon-button>`

```html
<s-icon-button icon="delete" label="Excluir jornada" variant="ghost" />
```

| Input        | Tipo             | Padrão        | Descrição                          |
| ------------ | ---------------- | ------------- | ---------------------------------- |
| `icon`       | `string`         | — (requerido) | Nome do glifo                      |
| `label`      | `string`         | — (requerido) | Vira `aria-label` e `title`        |
| `variant`    | `SButtonVariant` | `'ghost'`     | As mesmas do `<s-button>`          |
| `outlined`   | `boolean`        | `false`       | Contorno no lugar do preenchimento |
| `size`       | `SIconSize`      | `'md'`        | `xs` `sm` `md` `lg`                |
| `iconFilled` | `boolean`        | `false`       | Preenche o glifo (eixo FILL)       |
| `disabled`   | `boolean`        | `false`       | Desabilita o botão                 |

`label` é obrigatório: sem texto visível, é a única coisa que identifica a ação
para quem usa leitor de tela. Escreva o texto que o botão mostraria se tivesse
rótulo — nunca o nome do glifo.

O botão só-ícone é **redondo** (`--radius-full`), e é a única forma da
biblioteca que não usa o raio de controle: é o que separa a ação isolada do
campo e do botão com texto que dividem a mesma linha. O guia desenha esse botão
com o raio dos demais controles — a divergência é deliberada.

A área clicável acompanha o glifo: `xs` dá 32px, `md` os 40px que o guia fixa
para ação isolada, e `lg` chega a 64px.

`variant` tem as mesmas variantes do `<s-button>`, e o padrão `ghost` é quase
sempre o certo: glifo neutro no ocioso, cor só no hover. As preenchidas são para
o botão que é a ação da tela, não item de lista — numa coluna de ações, um botão
preenchido por linha compete com o dado.

#### `<s-card>`

```html
<s-card [padding]="16" [elevation]="1">…</s-card>
```

| Input       | Tipo                        | Padrão | Descrição                                                |
| ----------- | --------------------------- | ------ | -------------------------------------------------------- |
| `padding`   | `0 \| 12 \| 16 \| 24 \| 32` | `16`   | Espaçamento interno, em passos da escala; `0` com seções |
| `elevation` | `0 \| 1 \| 2 \| 3`          | `1`    | Nível de sombra; `0` apoia só na borda                   |

Os valores são listas fechadas de propósito: aceitar CSS livre abriria a porta
para `13px`, que é o que a escala de 4px existe para evitar.

No tema escuro a sombra desaparece — lá a hierarquia vem da borda. Isso já está
resolvido nos tokens `--elevation-*`, sem condicional no componente.

Com seções, o espaçamento é delas, e o card zera o próprio sem precisar de
`[padding]="0"`:

```html
<s-card>
  <header sCardHeader>
    <h2 sCardTitle>Jornadas pendentes</h2>
    <s-badge tone="warning">3</s-badge>
  </header>
  <div sCardContent>…</div>
  <footer sCardFooter>
    <s-button variant="primary">Aprovar</s-button>
  </footer>
</s-card>
```

| Diretiva       | Papel                                                                  |
| -------------- | ---------------------------------------------------------------------- |
| `sCardHeader`  | Linha do título; o que vier depois do `sCardTitle` vai para a direita  |
| `sCardTitle`   | Título (`<h2>`, `<h3>`…): tipografia de card e o espaço livre da linha |
| `sCardContent` | Corpo                                                                  |
| `sCardFooter`  | Ações, à direita, sempre por último                                    |

Entre duas seções o espaço é de um passo (16px), e não a soma dos dois.

#### `<s-badge>`

```html
<s-badge tone="success" icon="check">Aprovado</s-badge>
```

| Input      | Tipo         | Padrão      | Descrição                                                                   |
| ---------- | ------------ | ----------- | --------------------------------------------------------------------------- |
| `tone`     | `SBadgeTone` | `'default'` | Tom do rótulo                                                               |
| `icon`     | `string`     | `''`        | Glifo opcional à esquerda                                                   |
| `iconSize` | `number`     | `16`        | Tamanho do glifo                                                            |
| `wrap`     | `boolean`    | `false`     | Quebra o rótulo em várias linhas em área estreita (24px vira altura mínima) |

Tons: `default`, `success`, `warning`, `destructive` e `info` são semânticos
(fundo tintado em 12% do token, texto na variante `on-surface`); `secondary` usa
a cor neutra em força total; `outline` não tem fundo.

O guia chama o tom informativo de `type`; aqui ele se chama `info`, igual ao
token que pinta. É a única divergência de nome com a documentação, e existe
porque `type` colide com o vocabulário de atributo nativo.

O badge não é interativo. Se precisar de clique, o componente certo é o botão.

#### `[sTooltip]`

```html
<s-icon name="info" size="xs" sTooltip="Aguardando aprovação da regional." />
```

| Input              | Tipo                | Padrão        | Descrição                                  |
| ------------------ | ------------------- | ------------- | ------------------------------------------ |
| `sTooltip`         | `string`            | — (requerido) | Texto exibido, uma a duas linhas           |
| `sTooltipPosition` | `'top' \| 'bottom'` | `'top'`       | Posição em relação ao elemento             |
| `sTooltipDisabled` | `boolean`           | `false`       | Desliga sem remover a diretiva             |
| `sTooltipDelay`    | `number`            | `400`         | Atraso do hover; a faixa do guia é 300–500 |

É ajuda de apoio, nunca instrução obrigatória: se a informação for necessária
para concluir a tarefa, ela pertence ao rótulo ou ao texto de ajuda do campo.

Só existem duas posições. O Material aceita seis; as laterais ficam de fora
porque competem com o conteúdo da linha em tabela.

### Formulários

Todos os controles desta seção implementam `ControlValueAccessor` e funcionam
com as duas APIs de formulário do Angular:

```html
<s-input formControlName="nome" />
<s-input [formControl]="nome" />
<s-input [(ngModel)]="nome" [ngModelOptions]="{ standalone: true }" />
```

Um teste de contrato (`core/control.spec.ts`) percorre os oito controles nos dois
sentidos — modelo para tela e tela para modelo — em cada uma das APIs.

Com exceção de `<s-checkbox>` e `<s-switch>`, que trazem o próprio rótulo ao
lado, os controles vão **dentro de um `<s-field>`** — é ele que fornece rótulo,
obrigatoriedade, ajuda e faixa de erro, e que amarra `for`, `aria-required`,
`aria-invalid` e `aria-describedby` sem a aplicação ligar nada à mão.

#### `<s-field>`

```html
<s-field label="Nome da Jornada de Trabalho" required [error]="erro()">
  <s-input placeholder="Buscar por nome" formControlName="nome" />
</s-field>
```

| Input       | Tipo      | Padrão  | Descrição                                           |
| ----------- | --------- | ------- | --------------------------------------------------- |
| `label`     | `string`  | `''`    | Sempre visível, à esquerda, com altura mínima fixa  |
| `required`  | `boolean` | `false` | Obrigatório recebe asterisco; opcional não recebe   |
| `help`      | `string`  | `''`    | Texto do ícone "i" de 16px — apoio não essencial    |
| `error`     | `string`  | `''`    | Mensagem de erro; a faixa existe mesmo quando vazia |
| `controlId` | `string`  | gerado  | Informe só para reaproveitar um id que já existe    |

| `control` | `AbstractControl` | detectado | Só se o controle não estiver projetado aqui |
| `showErrorsWhen` | `'touched' \| 'dirty' \| 'always'` | `'touched'` | Quando a mensagem aparece |

A faixa de erro é sempre renderizada. É o detalhe que faz a validação não mudar
a altura do formulário — sem ela, a tela salta quando a primeira mensagem
aparece.

##### Mensagens automáticas

O campo lê os validadores do próprio controle. Isto basta:

```html
<s-field label="Nome" required>
  <s-input formControlName="nome" />
</s-field>
```

Com `Validators.required` e `Validators.minLength(5)` no controle, a faixa mostra
"Campo obrigatório." e depois "Informe pelo menos 5 caracteres." — sem a tela
escrever ternário nenhum. O `error` continua existindo e **vence** a mensagem
automática, para o caso de um erro que só o servidor conhece.

A mensagem aparece quando o campo é tocado, que é o momento em que o guia manda
validar: acusar "campo obrigatório" antes de a pessoa chegar no campo é cobrar
por algo que ela ainda ia fazer.

Para que "campo obrigatório" seja a **mesma frase** nas 87 telas do Professores,
registre as mensagens uma vez:

```ts
// app.config.ts
import { provideSiageValidationMessages } from '@siage/siage-ui';

providers: [
  provideSiageValidationMessages({
    required: 'Preencha este campo.',
    cpfInvalido: 'CPF inválido.',
  }),
];
```

O que você informa é mesclado com os padrões — só o que aparecer ali é trocado.
A biblioteca já cobre `required`, `email`, `min`, `max`, `minlength`,
`maxlength`, `pattern` e os erros do datepicker.

#### `<s-input>`

```html
<s-input icon="search" placeholder="Buscar por nome" formControlName="nome" />
```

| Input          | Tipo             | Padrão   | Descrição                                       |
| -------------- | ---------------- | -------- | ----------------------------------------------- |
| `type`         | `SInputType`     | `'text'` | text, email, tel, password, number, search, url |
| `placeholder`  | `string`         | `''`     | Nunca substitui o rótulo                        |
| `icon`         | `string`         | `''`     | Glifo de 20px à esquerda                        |
| `invalid`      | `boolean`        | `false`  | Borda em `--destructive`                        |
| `readOnly`     | `boolean`        | `false`  | Fundo neutro, sem moldura                       |
| `disabled`     | `boolean`        | `false`  | Ação indisponível                               |
| `maxlength`    | `number \| null` | `null`   | Limite de caracteres                            |
| `autocomplete` | `string`         | `'off'`  | Valor de `autocomplete` do navegador            |

`readOnly` **não** é `disabled`: somente-leitura mostra o dado em fundo neutro,
sem moldura e sem aparência de bloqueado — nem sequer renderiza um `<input>`.

Estados da superfície, iguais em todos os campos: ocioso com borda `--border` a
45% sobre `--background`; hover com borda cheia sobre `--card`; focado com borda
`--primary` de **2px** — o único lugar do sistema onde a espessura muda por
estado, e por isso o padding cai de 16px para 15px, para nada saltar.

#### `<s-textarea>`

| Input         | Tipo             | Padrão  | Descrição                 |
| ------------- | ---------------- | ------- | ------------------------- |
| `placeholder` | `string`         | `''`    | Nunca substitui o rótulo  |
| `invalid`     | `boolean`        | `false` | Borda em `--destructive`  |
| `readOnly`    | `boolean`        | `false` | Fundo neutro, sem moldura |
| `disabled`    | `boolean`        | `false` | Ação indisponível         |
| `maxlength`   | `number \| null` | `null`  | Limite de caracteres      |

#### `<s-select>`

```html
<s-field label="Status">
  <s-select [options]="status" placeholder="Todos" formControlName="status" />
</s-field>
```

| Input         | Tipo                      | Padrão    | Descrição                          |
| ------------- | ------------------------- | --------- | ---------------------------------- |
| `options`     | `SOption<T>[]`            | `[]`      | Opções do painel                   |
| `placeholder` | `string`                  | `''`      | Exibido enquanto nada é escolhido  |
| `invalid`     | `boolean`                 | `false`   | Borda em `--destructive`           |
| `disabled`    | `boolean`                 | `false`   | Ação indisponível                  |
| `compareWith` | `(a: T, b: T) => boolean` | igualdade | Necessário quando o valor é objeto |

Envolve o `mat-select` **sem** `mat-form-field`: o `mat-select` injeta o campo do
Material como opcional, então ficamos com o painel em overlay, a navegação por
teclado e a semântica de combobox, e a superfície segue a regra do guia em vez
do rótulo flutuante.

Nunca use um campo de texto genérico no lugar de uma escolha. Em card de filtros
a opção padrão é sempre `"Todos"`.

#### `<s-multiselect>`

| Input          | Tipo                      | Padrão           | Descrição                                 |
| -------------- | ------------------------- | ---------------- | ----------------------------------------- |
| `options`      | `SOption<T>[]`            | `[]`             | Opções do painel; ignorado com `url`      |
| `url`          | `string`                  | `''`             | Consulta via `SAutocompleteSource`        |
| `params`       | `Record<string, unknown>` | `{}`             | Filtros enviados junto da busca           |
| `minLength`    | `number`                  | `0`              | Caracteres mínimos; `0` consulta ao abrir |
| `debounceTime` | `number`                  | `300`            | Espera entre digitação e consulta, ms     |
| `filterable`   | `boolean`                 | `true`           | Busca no painel; sempre visível com `url` |
| `maxLabels`    | `number`                  | `2`              | Rótulos no gatilho antes da contagem      |
| `itemsLabel`   | `string`                  | `'selecionados'` | Substantivo da contagem, no plural        |

Mais os mesmos `placeholder`, `invalid`, `disabled` e `compareWith` do
`<s-select>`.

Como no Professores e no Educacional, quem decide de onde vem a lista é o `url`:
sem ele, a lista é `options` e a busca filtra por ela; com ele, abrir o painel já
consulta e cada digitação consulta de novo a mesma `SAutocompleteSource` do
`<s-autocomplete>`. O que já está marcado continua marcado quando a busca atual
não o traz, e o `resolve` da fonte dá o rótulo dos ids que chegam preenchidos.

**Não está no guia.** Entrou porque o Professores usa seleção múltipla em 14
lugares. Segue a anatomia do campo à risca: fechado, não deve se distinguir de um
`<s-select>`.

#### `<s-datepicker>`

```html
<s-field label="Data da aula" required>
  <s-datepicker formControlName="data" [max]="hoje" />
</s-field>

<!-- Período: uma ou duas datas; o valor é SDateRange ({ start, end }). -->
<s-field label="Período">
  <s-datepicker formControlName="periodo" range />
</s-field>
```

| Input         | Tipo           | Padrão         | Descrição                              |
| ------------- | -------------- | -------------- | -------------------------------------- |
| `range`       | `boolean`      | `false`        | Vira período: aceita uma ou duas datas |
| `requireEnd`  | `boolean`      | `false`        | Com `range`, exige as duas datas       |
| `placeholder` | `string`       | `'dd/mm/aaaa'` | Texto de exemplo                       |
| `min`         | `Date \| null` | `null`         | Primeira data selecionável             |
| `max`         | `Date \| null` | `null`         | Última data selecionável               |
| `invalid`     | `boolean`      | `false`        | Borda em `--destructive`               |
| `pickerOnly`  | `boolean`      | `false`        | Impede a digitação                     |
| `openOnClick` | `boolean`      | `true`         | Abre o calendário ao clicar no campo   |
| `disabled`    | `boolean`      | `false`        | Ação indisponível                      |

Com `range`, só o início é um período válido ("a partir de") e o campo mostra só
a data, sem o "a" pendurado. Com `requireEnd`, o período sem fim fica inválido
com o erro `sDateRangeIncomplete`, que o `<s-field>` mostra como "Informe a data
final do período.". Sem nenhuma das datas o valor é `null`, então
`Validators.required` funciona como num campo comum.

**Requer registrar o adaptador de data uma vez na aplicação:**

```ts
// app.config.ts
import { provideSiageDateAdapter } from '@siage/siage-ui';

export const appConfig: ApplicationConfig = {
  providers: [provideSiageDateAdapter()],
};
```

Sem ele o Material lança erro em tempo de execução pedindo um `DateAdapter`. O
adaptador nativo do Material delega a leitura de texto ao `Date.parse` do
navegador, que interpreta `03/04/2026` como **4 de março** — ordem americana.
Numa folha de ponto isso é um erro silencioso e caro, então o
`provideSiageDateAdapter()` instala um adaptador que lê e escreve `dd/MM/yyyy` e
recusa datas que não existem, como `31/02`.

**Não está no guia**, que não define calendário. Segue a anatomia do campo e o
ícone de controle de 20px.

#### `<s-checkbox>`

```html
<s-checkbox label="Considerar apenas jornadas ativas" formControlName="apenasAtivas" />
```

| Input       | Tipo      | Padrão  | Descrição                                   |
| ----------- | --------- | ------- | ------------------------------------------- |
| `label`     | `string`  | `''`    | Parte da área de clique                     |
| `ariaLabel` | `string`  | `''`    | Nome para leitor de tela sem rótulo visível |
| `disabled`  | `boolean` | `false` | Opacidade 40% no conjunto                   |

Caixa de 20px com check de 16px. Não usa `<s-field>`: o rótulo é dele. Sem
`label` (a caixa de seleção de uma linha de tabela, por exemplo), passe
`ariaLabel`: é ele que diz ao leitor de tela o que a caixa marca.

#### `<s-switch>`

| Input       | Tipo      | Padrão  | Descrição                              |
| ----------- | --------- | ------- | -------------------------------------- |
| `label`     | `string`  | `''`    | Rótulo opcional à direita              |
| `ariaLabel` | `string`  | `''`    | Descrição quando não há rótulo visível |
| `disabled`  | `boolean` | `false` | Opacidade 40% no conjunto              |

Trilha de 44×24. Use `<s-switch>` para estado que aplica na hora e
`<s-checkbox>` dentro de formulário que é salvo — a escolha informa ao usuário se
a mudança já valeu.

#### `<s-autocomplete>`

Autocomplete tipado com suporte a Reactive Forms. Mesma superfície dos demais
campos, dentro de um `<s-field>`.

```html
<s-field label="Cidade" required>
  <s-autocomplete
    placeholder="Digite uma cidade"
    [options]="cidades"
    formControlName="cidadeId"
    (search)="buscar($event)"
    (selectionChange)="aoSelecionar($event)"
  />
</s-field>
```

##### Buscando pela API com `url`

A biblioteca **não faz HTTP**. Para que o template fique igual ao do Professores
(`url` + `params`), a aplicação implementa o contrato e registra uma vez:

```ts
// autocomplete.source.ts, na aplicação
@Injectable({ providedIn: 'root' })
export class SiageAutocompleteSource extends SAutocompleteSource {
  private readonly api = inject(ApiService);

  search({ url, term, params }: SAutocompleteQuery): Observable<SAutocompleteOption[]> {
    const busca = new URLSearchParams({ ...params, termo: term } as Record<string, string>);
    return this.api
      .get(`Autocomplete/${url}?${busca}`)
      .pipe(map((r) => r.body.data.map((i) => ({ label: i.descricao, value: i.id }))));
  }
}

// app.config.ts
providers: [provideSiageAutocompleteSource(SiageAutocompleteSource)];
```

E aí, em qualquer tela:

```html
<s-field label="Cidade">
  <s-autocomplete url="cidades" [params]="{ ufId: uf() }" formControlName="cidadeId" />
</s-field>
```

| Input          | Tipo                      | Padrão | Descrição                             |
| -------------- | ------------------------- | ------ | ------------------------------------- |
| `url`          | `string`                  | `''`   | Recurso a consultar; vazio desliga    |
| `params`       | `Record<string, unknown>` | `{}`   | Filtros enviados junto da busca       |
| `minLength`    | `number`                  | `1`    | Caracteres mínimos antes de consultar |
| `debounceTime` | `number`                  | `300`  | Espera entre digitação e consulta, ms |

É o `url` que decide quem filtra, como no autocomplete do Professores e do
Educacional: sem ele, o componente filtra `options` pelo texto digitado
(ignorando acento e caixa); com ele, quem decide o que casa é a API. O `search`
continua sendo emitido nos dois modos, e respeita o mesmo `debounceTime`. Quem
faz a própria busca não deveria receber um evento por tecla enquanto quem usa
`url` recebe um a cada 300ms. Consultas são canceladas a cada nova
digitação, e uma que falhe não deixa o campo preso em "carregando".

Para telas de edição, implemente também o `resolve` — ele é opcional:

```ts
resolve({ url, value }: SAutocompleteLookup): Observable<SAutocompleteOption | null> {
  return this.api
    .get(`Autocomplete/${url}/${value}`)
    .pipe(map((r) => ({ label: r.body.data.descricao, value })));
}
```

Sem ele, um valor que já vem do formulário fica sem rótulo até alguém digitar —
o componente não tem como saber o texto de um id que nenhuma busca trouxe. Com
ele, o campo se preenche sozinho ao abrir a tela.

> **Descontinuado:** o input `label`. Ele ainda funciona **fora** de um
> `<s-field>`, para não quebrar telas existentes; dentro de um, o rótulo do
> campo prevalece e o `label` é ignorado, para não duplicar. Migre envolvendo o
> componente com `<s-field label="...">`.

##### Inputs

| Input           | Tipo                                | Padrão                          | Descrição                                              |
| --------------- | ----------------------------------- | ------------------------------- | ------------------------------------------------------ |
| `label`         | `string`                            | `''`                            | Rótulo do campo                                        |
| `placeholder`   | `string`                            | `''`                            | Placeholder do input                                   |
| `options`       | `readonly SAutocompleteOption<T>[]` | `[]`                            | Opções exibidas no painel                              |
| `required`      | `boolean`                           | `false`                         | Marca o campo como obrigatório                         |
| `disabled`      | `boolean`                           | `false`                         | Desabilita o campo                                     |
| `loading`       | `boolean`                           | `false`                         | Exibe spinner e mensagem de carregamento               |
| `noResultsText` | `string`                            | `'Nenhum resultado encontrado'` | Mensagem quando não há opções                          |
| `loadingText`   | `string`                            | `'Carregando...'`               | Mensagem exibida no painel enquanto `loading` é `true` |

##### Outputs

| Output            | Tipo                             | Quando                                                   |
| ----------------- | -------------------------------- | -------------------------------------------------------- |
| `search`          | `string`                         | A cada digitação do usuário (e ao limpar o campo)        |
| `selectionChange` | `SAutocompleteOption<T> \| null` | Opção selecionada, ou `null` quando a seleção é desfeita |

##### Modelo

```ts
export interface SAutocompleteOption<T = unknown> {
  label: string;
  value: T;
  disabled?: boolean;
}

export type SAutocompleteSelection<T = unknown> = SAutocompleteOption<T> | null;
```

Uso:

```ts
cities: SAutocompleteOption<number>[] = [
  { label: 'João Pessoa', value: 1 },
  { label: 'Recife', value: 2 },
];
```

##### Busca

O componente **não faz chamadas HTTP**. Ele apenas emite `search` com o texto
digitado; a aplicação busca/filtra e devolve o resultado em `options`.

```ts
@Component({
  standalone: true,
  imports: [ReactiveFormsModule, SAutocompleteComponent],
  template: `
    <form [formGroup]="form">
      <s-autocomplete
        formControlName="userId"
        label="Usuário"
        [options]="users()"
        [loading]="loadingUsers()"
        (search)="searchUsers($event)"
        (selectionChange)="selectUser($event)"
      ></s-autocomplete>
    </form>
  `,
})
export class ExampleComponent {
  private readonly http = inject(HttpClient);

  readonly users = signal<SAutocompleteOption<number>[]>([]);
  readonly loadingUsers = signal(false);

  readonly form = new FormGroup({
    userId: new FormControl<number | null>(null),
  });

  searchUsers(term: string): void {
    this.loadingUsers.set(true);
    this.http.get<User[]>(`/api/users?q=${term}`).subscribe((users) => {
      this.users.set(users.map((u) => ({ label: u.name, value: u.id })));
      this.loadingUsers.set(false);
    });
  }

  selectUser(option: SAutocompleteSelection<number>): void {
    console.log(option?.value ?? null);
  }
}
```

##### Reactive Forms

O componente implementa `ControlValueAccessor`. O valor do `FormControl` é o
`value` da opção (`T`), nunca o objeto interno do Material — a aplicação **não**
precisa criar um `FormControl` extra para o input interno:

```ts
form = new FormGroup({
  cityId: new FormControl<number | null>(null),
});
```

```html
<s-autocomplete formControlName="cityId" label="Cidade" [options]="cities"></s-autocomplete>
```

Comportamento coberto:

- **value** — `writeValue` resolve o `label` a partir de `options`; se o valor
  chegar antes das opções (busca assíncrona), o texto é preenchido assim que
  `options` mudar;
- **disabled** — `setDisabledState` (`control.disable()`) e o input `[disabled]`
  desabilitam o campo;
- **touched** — `onTouched` é disparado no `blur` do input;
- **change** — selecionar emite o novo valor; voltar a digitar após uma seleção
  limpa o valor (emite `null`), evitando valor "fantasma" no formulário.

##### Estados

| Estado    | Comportamento                                              |
| --------- | ---------------------------------------------------------- |
| Default   | Lista as `options` recebidas                               |
| Required  | Asterisco no label e `aria-required` no input              |
| Disabled  | Input desabilitado; botão de limpar oculto                 |
| Loading   | `mat-spinner` no sufixo do campo + `loadingText` no painel |
| Empty     | `noResultsText` no painel (só quando `loading` é `false`)  |
| Com valor | Botão de limpar (ícone `close`) no sufixo do campo         |

### Dados

#### `<s-table>`

```html
<s-table
  [columns]="colunas"
  [rows]="jornadas()"
  [actions]="acoes"
  [sort]="sort()"
  [total]="total()"
  itemsLabel="jornadas"
  (sortChange)="ordenar($event)"
  (actionClick)="executar($event)"
  (pageChange)="irPara($event)"
/>
```

| Input             | Tipo                 | Padrão         | Descrição                                |
| ----------------- | -------------------- | -------------- | ---------------------------------------- |
| `columns`         | `STableColumn<T>[]`  | `[]`           | Colunas, na ordem                        |
| `rows`            | `T[]`                | `[]`           | Linhas da página atual                   |
| `actions`         | `STableAction<T>[]`  | `[]`           | Ações da última coluna; vazio esconde    |
| `sort`            | `STableSort \| null` | `null`         | Ordenação atual (controlada)             |
| `loading`         | `boolean`            | `false`        | Consulta em andamento                    |
| `empty`           | `STableEmpty`        | `{}`           | O que mostrar sem linhas                 |
| `zebra`           | `boolean`            | `false`        | Linhas zebradas                          |
| `caption`         | `string`             | `''`           | Rótulo acessível da tabela               |
| `page`            | `number`             | `1`            | Página atual                             |
| `pageSize`        | `number`             | `10`           | Registros por página                     |
| `total`           | `number`             | `0`            | Total do resultado; `0` esconde o rodapé |
| `pageSizeOptions` | `number[]`           | `[10, 25, 50]` | Opções do seletor de tamanho             |
| `itemsLabel`      | `string`             | `'registros'`  | Substantivo da contagem                  |

| `selectable` | `boolean` | `false`| Acrescenta a coluna de seleção |
| `selection` | `T[]` | `[]` | Linhas marcadas (controlado) |
| `compareWith` | `(a: T, b: T) => boolean` | identidade | Compara linhas ao conferir a seleção |

Saídas: `sortChange`, `selectionChange`, `actionClick`, `pageChange`,
`pageSizeChange` e `emptyAction`.

A seleção é controlada, como a ordenação: a tabela emite `selectionChange` e
espera receber `selection` de volta. A caixa do cabeçalho vale para a **página
atual**, não para o resultado inteiro — marcar 10 linhas e desmarcar 4.812 sem
aviso seria uma surpresa cara.

Use `selectable` só quando a tela tem ação em lote. Sem uma, a coluna ocupa
espaço e sugere algo que não acontece.

##### Por que existe uma tabela só

O Professores tinha duas: `app-table-custom` (a tabela) e `app-generic-list`
(título, botão de criar e a tabela dentro). A segunda não acrescentava
comportamento de tabela — acrescentava **moldura de tela**.

Aqui isso virou composição, e cada peça tem um dono claro:

```html
<s-page-header title="Jornadas de Trabalho" />
<!-- título e ação de criar -->
<s-filter-card (search)="buscar()" (clear)="limpar()">…</s-filter-card>
<s-table [columns]="colunas" [rows]="jornadas()" />
```

Quem só precisa de tabela escreve uma linha; quem precisa da tela inteira
escreve três — sem ter que escolher entre dois componentes concorrentes, e sem
que a tabela carregue um botão de criar que metade das telas não usa.

Esse é o caminho para tela nova. Tela que já existe com `app-generic-list`
migra pelo modo `options`, abaixo, sem reescrever a configuração.

##### Migrando do `app-generic-list`

O `<s-table>` aceita os mesmos inputs, outputs e templates do generic-list do
Professores e do Educacional. A migração é trocar a tag e o nome dos tipos — o
objeto de configuração e o `onLazyLoad` da tela ficam como estão:

```html
<!-- antes -->
<app-generic-list
  [options]="genericListOptions"
  [itensPaginated]="paginatedResource.value()"
  (filter)="onLazyLoad($event)"
  (edit)="editar($event)"
  (remove)="onDelete($event)"
/>

<!-- depois -->
<s-table
  [options]="genericListOptions"
  [itensPaginated]="paginatedResource.value()"
  (filter)="onLazyLoad($event)"
  (edit)="editar($event)"
  (remove)="onDelete($event)"
/>
```

| Antes (app)                   | Aqui                    |
| ----------------------------- | ----------------------- |
| `GenericListOptions<T>`       | `SListOptions<T>`       |
| `GenericListTableConfig<T>`   | `SListTableConfig<T>`   |
| `ColumnDataTable<T>`          | `SListColumn<T>`        |
| `GenericListActionsConfig`    | `SListActionsConfig`    |
| `GenericListPermissionConfig` | `SListPermissionConfig` |
| `TableLazyLoadEvent`          | `SListLazyLoadEvent`    |

- **Inputs:** `options`, `itensPaginated`, `itens`, `emptyMessage`.
- **Outputs:** `filter`, `create`, `view`, `edit`, `remove`, `inactivate`.
- **Templates:** `#customActions` (com `let-item` e `let-i="index"`),
  `#addButton` e `#emptyMessage`.
- **Página do servidor:** aceita `PaginacaoDto` (`data`/`total`) e `PagedResult`
  (`items`/`totalCount`), sem conversão na tela.
- **`(filter)`** leva `{ first, rows, sortField, sortOrder }` como o `p-table`,
  inclusive a emissão na criação (desligada com `tableConfig.lazy: false`). A
  tabela acompanha `tableConfig.first` quando a tela o altera, como faz o
  `generic-list-form-base`.
- **`itens` com `lazy: false`** pagina e ordena em memória.
- **`routeBase`** faz editar e visualizar navegarem para
  `routeBase/editar/:id` e `routeBase/visualizar/:id`.
- **Permissões** (`permissionConfig`) são conferidas pelo `SPermissionChecker`
  que a aplicação registra — a biblioteca não conhece `ngx-permissions`:

```ts
// app.config.ts
providers: [provideSiagePermissionChecker(NgxPermissionChecker)];
```

Sem verificador registrado, todas as ações configuradas aparecem.

O que muda de verdade, porque a biblioteca não depende de PrimeNG:

- `pTag` **recebe a linha**, como no Educacional. No Professores recebia o
  valor do campo: troque `(valor) => …` por `(linha) => … linha.campo`.
- Ícones (`iconTitle`, `addButton.icon`, `pTagIcon`) são nomes do Material
  Symbols (`'add'`, `'groups'`). Classes `pi pi-*` são ignoradas.
- A ordenação segue o ciclo do guia: `asc → desc → ordem original`, e a ordem
  original sai como `sortField: null`.
- `rowsPerPageOptions` sem valor usa as opções do guia (10, 25 e 50).
- `rowHover`, `globalFilterFields` e `currentPageReportTemplate` são aceitos,
  mas não têm efeito: hover é sempre ligado, a busca é do `<s-filter-card>` e a
  contagem segue o formato fixo do guia.

Para converter paginação à mão, `pageFromFirst(first, rows)` e
`firstFromPage(page, pageSize)` fazem a conta entre os dois vocabulários.

##### Os quatro estados, sem `@if` na tela

A tabela decide sozinha o que mostrar:

| Situação   | O que aparece                               |
| ---------- | ------------------------------------------- |
| `loading`  | esqueleto nas colunas, **depois do limiar** |
| sem linhas | `<s-empty-state>` com a variante de `empty` |
| com linhas | as linhas                                   |

##### Colunas

`STableColumn<T>` aceita `value` (texto derivado), `secondary` (segunda linha
da célula, para nome + matrícula), `badge` (coluna de status), `help` (o "i" no
cabeçalho), `width` e `sortable`.

O `align` é **fixo pelo tipo do dado**, nunca por preferência visual: texto à
esquerda; número, hora, percentual e moeda à direita; status, booleano e ações
ao centro. É o que permite comparar valores lendo a coluna de cima a baixo.

A ordenação é controlada — a tabela emite `sortChange` e espera receber `sort`
de volta. O ciclo é `asc → desc → ordem original`, e quem reordena é a
aplicação, normalmente delegando ao backend.

`truncate` corta o texto que não cabe e leva o conteúdo inteiro para o tooltip,
sem nunca variar a altura da linha — é a proposta registrada em **Fora de
escopo**, e por isso continua desligada por padrão. A largura do corte vem do
`width` da coluna; sem ele, 28ch. `tooltip` explica a célula por linha, para o
que não cabe na coluna.

##### Célula com template próprio

A configuração cobre texto, badge e dado agrupado. Quando a célula **age** — um
botão, um link, um ícone —, declare um template para a coluna:

```html
<s-table [columns]="colunas" [rows]="linhas()">
  <ng-template sTableCell="emUso" let-linha>
    @if (linha.emUso) {
    <s-button variant="ghost" icon="link" (click)="verUsos(linha)">Ver usos</s-button>
    } @else {
    <span>—</span>
    }
  </ng-template>
</s-table>
```

O contexto é a linha (`let-linha`), tipado pelo genérico da tabela. Isso mantém
a configuração declarativa para as outras colunas sem obrigar a biblioteca a
prever cada caso — que é como uma coluna nova terminava virando mais um `if`
dentro do componente.

#### `<s-filter-card>`

| Input                                                                       | Tipo      | Padrão      | Descrição                                                                                       |
| --------------------------------------------------------------------------- | --------- | ----------- | ----------------------------------------------------------------------------------------------- |
| `title`                                                                     | `string`  | `'Filtros'` | Título do bloco                                                                                 |
| `searchLabel`                                                               | `string`  | `'Buscar'`  | Rótulo do botão de buscar                                                                       |
| `clearLabel`                                                                | `string`  | `'Limpar'`  | Rótulo do botão de limpar                                                                       |
| `clearDisabled`                                                             | `boolean` | `false`     | Desabilita Limpar                                                                               |
| `loading`                                                                   | `boolean` | `false`     | Buscar entra em carregamento                                                                    |
| `disableSearchWithoutValue`                                                 | `boolean` | `false`     | Desabilita Buscar (e o Enter) enquanto o formulário não tem valor                               |
| `searchWhenEmptied`                                                         | `boolean` | `false`     | Com `requireValue`/`disableSearchWithoutValue`, busca também ao esvaziar os filtros pelos chips |
| Os botões se chamam **Buscar** e **Limpar** — nunca "Aplicar", "Filtrar" ou |
| "Pesquisar". São os mesmos verbos em todos os sistemas da rede, e trocar um |
| deles numa tela quebra o reconhecimento em todas as outras. Ficam em grupo  |
| único ao pé, à direita, com Limpar antes de Buscar.                         |

`Enter` em qualquer campo projetado dispara `search`. Dentro de uma área de
texto o Enter continua quebrando linha.

A grade não tem número fixo de colunas: cabem tantas quantas a largura permitir,
cada uma com no mínimo 240px. Campo que pede mais espaço leva
`class="s-filter-card__largo"` (duas colunas) ou `class="s-filter-card__inteiro"`
(a linha inteira).

#### `<s-pagination>` e `<s-record-count>`

Dentro de um `<s-table>` já vêm montados. Use avulsos quando a listagem não for
uma tabela.

O formato da contagem é fixo pelo guia, e as três regras costumam ser quebradas
por engano:

- **`1–10 de 47`**, com meia-risca e **sem espaços**. Não é hífen, não é "1 - 10"
- sem paginação, vira **`12 registros`**
- com zero resultados **não renderiza nada** — quem comunica ausência é o
  `<s-empty-state>`

`total` é sempre o total do **resultado atual**, já filtrado, nunca o da base.

#### `<s-empty-state>`

| Variante     | Situação                             | Ação oferecida            |
| ------------ | ------------------------------------ | ------------------------- |
| `no-data`    | nunca houve registro                 | criar                     |
| `no-results` | há registros, nenhum passa no filtro | limpar — **nunca criar**  |
| `error`      | a consulta falhou                    | tentar de novo            |
| `forbidden`  | sem permissão                        | nenhuma; diz a quem pedir |

A distinção não é cosmética: oferecer a ação errada manda o usuário para o lugar
errado. Cada variante já traz glifo, título, descrição e rótulo coerentes;
sobrescreva o que a tela souber dizer melhor.

O título é um `h3` por padrão, para o estado vazio dentro de um card ou seção que
já tem o seu `h2`. Numa tela que só tem o `h1`, passe `headingLevel="2"` (no
`s-table`, `empty.headingLevel`): pular nível desorienta quem navega pelos
títulos com leitor de tela. O tamanho não muda.

#### `<s-skeleton>` e `<s-table-skeleton>`

**Nunca spinner central** em tabela ou card — spinner só dentro de botão em
carregamento. O esqueleto ocupa o mesmo espaço que o dado vai ocupar, então a
tela não salta quando a resposta chega.

##### Quando o carregamento aparece

O guia não define o limiar. A equipe fixou **3 segundos**:

```ts
// app.config.ts, para mudar
import { provideSiageLoadingDelay } from '@siage/siage-ui';

providers: [provideSiageLoadingDelay(1500)];
```

Uma resposta rápida que pisca o esqueleto por 80ms incomoda mais que a espera,
porque a tela salta duas vezes em vez de uma. Numa tabela isso já vem pronto;
fora dela, use `adiarCarregamento()`.

### Feedback

Três superfícies, três persistências. Escolher errado é o erro mais comum:

| Componente      | Quando                              | Persistência             |
| --------------- | ----------------------------------- | ------------------------ |
| `SToastService` | confirma algo que **já aconteceu**  | some em 4s (erro, nunca) |
| `<s-alert>`     | condição que **continua valendo**   | fica até ser resolvida   |
| `SModalService` | decisão que **exige atenção agora** | até responder            |

Nunca use modal para confirmar um sucesso simples, e nunca modal com
temporizador.

#### `<s-alert>`

```html
<s-alert type="warning" title="Modificação pendente" dismissible (close)="esconder()">
  Esta jornada tem alteração aguardando aprovação da gerência regional.
</s-alert>
```

| Input         | Tipo                                          | Padrão   | Descrição               |
| ------------- | --------------------------------------------- | -------- | ----------------------- |
| `type`        | `'info' \| 'success' \| 'warning' \| 'error'` | `'info'` | Ícone e cor semântica   |
| `title`       | `string`                                      | `''`     | Título curto            |
| `dismissible` | `boolean`                                     | `false`  | Exibe o botão de fechar |

Fundo tint 12%, borda 24%, ícone na variante `on-surface` — a versão discreta da
linguagem que o toast usa em 24% e cor cheia. O texto fica sempre neutro.

**A cor nunca vem sozinha:** todo tipo traz ícone. `--info` existe
exclusivamente aqui e nunca em elemento clicável.

#### `SToastService`

```ts
private readonly toast = inject(SToastService);

this.toast.success('Jornada salva', 'As alterações foram aplicadas.');
this.toast.error('Não foi possível salvar');
```

Atalhos: `success`, `info`, `warning`, `error`. Para controle fino, `show({
title, message, type, duration })`; `dismiss(id)` e `clear()` fecham.

**A pilha guarda três**, mais recente no topo. A partir do quarto, o primeiro que
foi acionado sai — o mais antigo já teve tempo de tela, e uma parede de seis
avisos não é lida por ninguém.

**Erro não fecha sozinho.** Os demais somem em 4s. Uma falha que some em quatro
segundos é uma falha que ninguém leu.

Por dentro: o `MatSnackBar` mostra um por vez (`openFromComponent` fecha o
anterior), então o serviço abre _um_ snackbar cujo conteúdo é a pilha inteira. É
por isso que o prazo de cada aviso vive no serviço, e não no `duration` do
Material — aquele encerraria o container, levando junto os outros dois.

#### `SModalService`

```ts
const confirmou = await this.modal.confirm({
  variant: 'destructive',
  title: 'Excluir Registro de Aula?',
  description: 'Esta ação não pode ser desfeita.',
  confirmLabel: 'Sim, excluir registro',
});
```

Esc e clique fora resolvem `false`. Para diálogos com conteúdo próprio,
`open(componente, config)` recebe um componente, e o `<s-modal>` continua
servindo de casca lá dentro.

Variantes: `default`, `destructive` (ação preenchida em `--destructive`) e
`result` (botão único em largura total, quando não há decisão a tomar).

**Cancelar sempre à esquerda, ação nomeada sempre à direita.** Quem confirma dez
vezes por dia decora a posição, não o texto — trocar a ordem numa tela faz a
pessoa clicar em excluir por reflexo motor. E o rótulo nomeia a consequência:
"Sim, excluir registro", nunca "OK".

**Responsivo.** A partir de 768px, os botões ficam em linha, alinhados à direita.
Abaixo disso (`max-width: 767.98px`) empilham em coluna, cada um com largura total
e 48px de altura mínima, com a ação principal no topo e Cancelar por último. Vale
para as ações padrão, para o rodapé próprio (`[sModalFooter]`) e para `result`.
Só o desenho inverte (`column-reverse`): no DOM Cancelar continua antes da ação
principal, então Tab e leitor de tela seguem a ordem de sempre. Não há input para
isso, é automático nos dois temas.

`confirm()` aceita `autoFocus` (como `open()`), e `disableClose` esconde o `x`.

### Navegação

#### `<s-page-header>`

```html
<s-page-header
  [breadcrumbs]="[{ label: 'Configurações', href: '/config' }, { label: 'Jornadas' }]"
  title="Jornadas de Trabalho"
  description="Gerencie as jornadas que definem o horário padrão de trabalho."
  showBack
  (back)="voltar()"
>
  <s-button action variant="primary" icon="add">Nova Jornada</s-button>
</s-page-header>
```

| Input         | Tipo            | Padrão  | Descrição                      |
| ------------- | --------------- | ------- | ------------------------------ |
| `breadcrumbs` | `SBreadcrumb[]` | `[]`    | Trilha; o último item é a tela |
| `title`       | `string`        | `''`    | Título em `--text-h1`          |
| `description` | `string`        | `''`    | Uma ou duas linhas             |
| `showBack`    | `boolean`       | `false` | Seta de voltar                 |

A ordem é obrigatória: trilha, título, descrição. Nessa sequência, sempre.

**Por que existe um só:** o Professores tinha `app-header-page` (título,
subtítulo, tag, voltar) e `app-generic-page-structure` (título e subtítulo). O
segundo era um subconjunto do primeiro; a `tag` virou `badge`.

O slot `[action]` recebe **a** ação da tela, no singular. Duas ações primárias
competindo no topo equivalem a nenhuma.

#### `<s-top-bar>`

```html
<s-top-bar
  systemName="SIAGE"
  systemSubtitle="Professores"
  homeLink="/"
  [schoolYears]="anos()"
  [schoolYear]="ano()"
  [schoolYearLoading]="carregandoAnos()"
  (schoolYearChange)="trocarAno($event)"
  (profileClick)="menuDoUsuario.toggle($event)"
>
  <img brand src="logo.png" alt="" />
</s-top-bar>
```

| Input                   | Tipo                       | Padrão    | Descrição                               |
| ----------------------- | -------------------------- | --------- | --------------------------------------- |
| `systemName`            | `string`                   | `'SIAGE'` | Vazio esconde o texto                   |
| `systemSubtitle`        | `string`                   | `''`      | Módulo, embaixo do nome                 |
| `homeLink`              | `string`                   | `''`      | A marca vira link para o início         |
| `showMenuButton`        | `boolean`                  | `true`    | Botão de recolher o menu                |
| `schoolYears`           | `(string \| SOption<T>)[]` | `[]`      | Vazio esconde o seletor                 |
| `schoolYear`            | `T \| string`              | `null`    | Ano selecionado (o `value` da opção)    |
| `schoolYearCompareWith` | `(a: T, b: T) => boolean`  | `===`     | Para valor que é objeto                 |
| `schoolYearLoading`     | `boolean`                  | `false`   | Desabilita o seletor enquanto carrega   |
| `schoolYearDisabled`    | `boolean`                  | `false`   | Telas em que trocar o ano não se aplica |
| `showNotifications`     | `boolean`                  | `false`   | Exibe o sino                            |
| `notifications`         | `number`                   | `0`       | `0` esconde o indicador                 |
| `theme`                 | `'light' \| 'dark'`        | `'light'` | Só escolhe o glifo do botão             |

Saídas: `toggleMenu`, `schoolYearChange`, `toggleTheme`, `notificationsClick` e
`profileClick` — as duas últimas com o `MouseEvent`, para um menu em popup se
ancorar no botão. O logotipo entra pelo slot `[brand]`; o que mais a aplicação
projetar entra antes do ano letivo, como a busca global do Educacional.

As ações da direita são só-ícone, em 24px: a barra orienta, quem chama a atenção
é a tela. Painel de notificações e menu de perfil estão **fora de escopo no
guia** — os botões emitem eventos e o que abre fica na aplicação.

#### `<s-sidebar>`

| Input       | Tipo             | Padrão             | Descrição                |
| ----------- | ---------------- | ------------------ | ------------------------ |
| `items`     | `SSidebarItem[]` | `[]`               | Destinos, na ordem       |
| `activeId`  | `string`         | `''`               | Id do item ativo         |
| `collapsed` | `boolean`        | `false`            | 72px, só ícones          |
| `ariaLabel` | `string`         | `'Menu principal'` | Rótulo acessível do menu |

256px expandido, item de 44px. O item ativo usa `--gradient-primary` com rótulo
branco — **na web esse gradiente não existe em nenhum outro lugar**, e é o que
faz "onde estou" ser reconhecido de relance. O glifo ativo também ganha o eixo
`FILL`, então a marcação não depende só de cor.

Recolhido, o rótulo vira tooltip. O componente não navega: emite `select` com o
id, e a aplicação decide.

> **Navegação inferior (`BottomNav`) não existe aqui.** É um componente mobile, e
> o mobile do SIAGE é Flutter. A regra continua descrita no guia de design.

### Genéricos

Não estão no guia de design. Entraram porque são comuns a todos os sistemas da
rede e, sem eles, cada tela resolveria do seu jeito. Todos seguem os tokens e a
anatomia dos componentes que o guia define.

#### `<s-chips>`

| Input          | Tipo                       | Padrão  | Descrição                          |
| -------------- | -------------------------- | ------- | ---------------------------------- |
| `options`      | `SAutocompleteOption<T>[]` | `[]`    | Sugestões; ignorado com `url`      |
| `url`          | `string`                   | `''`    | Consulta via `SAutocompleteSource` |
| `params`       | `Record<string, unknown>`  | `{}`    | Filtros da busca                   |
| `minLength`    | `number`                   | `1`     | Caracteres antes de consultar      |
| `debounceTime` | `number`                   | `300`   | Espera antes da consulta, ms       |
| `max`          | `number`                   | `0`     | Teto de etiquetas; `0` não limita  |
| `placeholder`  | `string`                   | `''`    | Texto de exemplo                   |
| `invalid`      | `boolean`                  | `false` | Borda em `--destructive`           |

Saídas: `add`, `remove`, `search` e `duplicate`.

A diferença para o `<s-multiselect>` é o que fica visível: aqui **cada escolha
ocupa espaço na tela**, com o próprio botão de remover. Use quando a lista
escolhida importa tanto quanto o ato de escolher. Quando o que importa é só a
contagem, o multiselect gasta menos espaço.

O que já foi escolhido some das sugestões, e `Backspace` no campo vazio remove a
última etiqueta.

#### `<s-file-upload>`

| Input           | Tipo       | Padrão                       | Descrição                    |
| --------------- | ---------- | ---------------------------- | ---------------------------- |
| `accept`        | `string[]` | `['pdf','png','jpg','jpeg']` | Extensões, sem ponto         |
| `maxSizeMb`     | `number`   | `10`                         | Limite em MB; `0` não limita |
| `buttonLabel`   | `string`   | `'Escolher arquivo'`         | Rótulo do botão              |
| `buttonIcon`    | `string`   | `'upload_file'`              | Glifo do botão               |
| `fileName`      | `string`   | `''`                         | Nome de arquivo já enviado   |
| `allowDownload` | `boolean`  | `false`                      | Botão de baixar              |
| `allowRemove`   | `boolean`  | `true`                       | Botão de remover             |

Saídas: `fileSelected`, `fileRemoved`, `fileError` e `download`.

**Não faz upload.** Valida extensão e tamanho, mostra o que foi escolhido e
entrega o `File` — a aplicação decide para onde mandar. Validar antes de enviar
poupa a viagem: um PDF de 40MB recusado no navegador economiza o upload inteiro.

Numa tela de edição o arquivo está no servidor e não há `File` para mostrar;
`fileName` exibe o nome sem exigir que a aplicação baixe o conteúdo.

#### `<s-radio-group>`

| Input         | Tipo                         | Padrão       | Descrição            |
| ------------- | ---------------------------- | ------------ | -------------------- |
| `options`     | `SOption<T>[]`               | `[]`         | Opções exibidas      |
| `orientation` | `'vertical' \| 'horizontal'` | `'vertical'` | Distribuição         |
| `name`        | `string`                     | gerado       | Nome do grupo nativo |

A regra para decidir entre rádio e `<s-select>` é a quantidade: **até cinco
opções curtas**, mostrar todas poupa um clique. Acima disso o grupo ocupa mais
espaço do que informa.

#### `<s-selection-buttons>`

| Input              | Tipo                      | Padrão    | Descrição                          |
| ------------------ | ------------------------- | --------- | ---------------------------------- |
| `options`          | `SOption<T>[]`            | `[]`      | Opções exibidas                    |
| `multiple`         | `boolean`                 | `false`   | Valor vira array                   |
| `allowDeselection` | `boolean`                 | `true`    | Desmarcar clicando na já escolhida |
| `ariaLabel`        | `string`                  | `''`      | Nome do grupo sem rótulo do campo  |
| `ariaLabelledby`   | `string`                  | `''`      | Id externo que nomeia o grupo      |
| `groupRole`        | `'group' \| 'radiogroup'` | `'group'` | `radiogroup` só na escolha única   |

Alvo grande, feito para ser tocado; a escolha costuma aplicar na hora. É o
controle dos filtros rápidos e das escalas curtas.

> **`groupRole="radiogroup"` não desmarca.** Como todo rádio, clicar ou apertar
> Espaço na opção marcada a mantém; `allowDeselection` é ignorado nesse papel.

> **`multiple` é definido na montagem.** O grupo do Material não lida bem com a
> troca em tempo de execução — a seleção se perde. Se a tela precisar dos dois
> modos, use `@if` e deixe o Angular recriar o componente.

#### `<s-tabs>`

| Input       | Tipo     | Padrão     | Descrição                 |
| ----------- | -------- | ---------- | ------------------------- |
| `tabs`      | `STab[]` | `[]`       | Abas, na ordem            |
| `activeId`  | `string` | `''`       | Id da aba ativa           |
| `ariaLabel` | `string` | `'Seções'` | Rótulo acessível do grupo |

Não envolve o `mat-tab-group`: ele gerencia o **conteúdo** das abas, com
animação e renderização tardia. Aqui as abas só navegam; o conteúdo é da tela, e
muitas vezes de uma rota filha.

São `<button>` com `role="tab"`: as setas do teclado navegam (pulando as
desabilitadas) e só a ativa fica no fluxo de tabulação.

#### `<s-stat-card>`

| Input   | Tipo         | Padrão      | Descrição              |
| ------- | ------------ | ----------- | ---------------------- |
| `label` | `string`     | `''`        | O que o número mede    |
| `value` | `string`     | `''`        | O número, já formatado |
| `hint`  | `string`     | `''`        | Uma linha de contexto  |
| `icon`  | `string`     | `''`        | Glifo de 24px          |
| `tone`  | `SBadgeTone` | `'default'` | Cor do glifo           |

Use tom semântico **só quando o número for bom ou ruim**. Um total neutro
pintado de verde sugere uma avaliação que ninguém fez.

#### `SThemeService` e `<s-theme-toggle>`

```ts
private readonly tema = inject(SThemeService);

this.tema.set('dark');     // 'light' | 'dark' | 'system'
this.tema.toggle();
this.tema.resolvido();     // 'light' | 'dark', com system já resolvido
```

O serviço escreve `data-theme` no `<html>` — o mesmo atributo que o guia usa.

**Seguir o sistema é um estado, não um terceiro tema:** em `system` o serviço
não escreve atributo nenhum, e a regra `@media (prefers-color-scheme: dark)` do
tema assume. A escolha vai para o `localStorage`; se ele estiver indisponível, o
serviço continua funcionando, só não lembra na próxima visita.

O `<s-theme-toggle>` é o botão pronto, normalmente na `<s-top-bar>`.

---

## CRUD (`@siage/siage-ui/crud`)

Entry point separado, com a **camada de tela** do CRUD: o estado e o
comportamento de uma listagem, a casca visual e o contrato de dados que a
aplicação implementa.

```ts
import { injectCrudList, SCrudListComponent, siageCrudDataSource } from '@siage/siage-ui/crud';
```

Fica fora do pacote principal de propósito: `@siage/siage-ui` é o design system
— componentes que só desenham. Aqui há navegação, consulta e decisão, que é
arquitetura de tela. Quem quer só a tabela não importa nada disto.

### As três peças

| Peça                     | O que é                                                                                                   |
| ------------------------ | --------------------------------------------------------------------------------------------------------- |
| `SCrudDataSource<T>`     | Contrato de dados. A biblioteca **não faz HTTP**                                                          |
| `injectCrudList(config)` | Estado e comportamento, sem template: consulta, filtro, ordenação, página, confirmação, aviso e navegação |
| `<s-crud-list>`          | A casca: `<s-page-header>` + `<s-filter-card>` + `<s-table>` montados                                     |

O comportamento **não depende** do componente: quem precisa de outro arranjo
monta as três peças na mão e continua com filtro, paginação, ordenação e
confirmação prontos.

### Uma tela inteira

```ts
@Component({
  selector: 'app-tipo-falta-list',
  imports: [
    ReactiveFormsModule,
    SCrudListComponent,
    SFieldComponent,
    SInputComponent,
    SSelectComponent,
  ],
  templateUrl: './tipo-falta-list.component.html',
})
export class TipoFaltaListComponent {
  protected readonly filtros = inject(FormBuilder).group({
    nome: [''],
    ativo: [null as boolean | null],
  });

  protected readonly crud = injectCrudList<TipoFaltaListDto>({
    entity: { name: 'Tipo de Falta', namePlural: 'Tipos de Falta', gender: 'masculine' },
    dataSource: siageCrudDataSource(inject(TipoFaltaService)),
    routes: { base: '/configuracoes-ponto/tipos-falta' },
    filters: this.filtros,
    columns: [
      { key: 'nome', label: 'Nome do Tipo de Falta', sortable: true, truncate: true },
      {
        key: 'ativo',
        label: 'Status',
        align: 'center',
        badge: (t) => (t.ativo ? null : { label: 'Inativo', tone: 'secondary' }),
        value: (t) => (t.ativo ? 'Ativo' : 'Inativo'),
      },
    ],
    actions: { view: true, edit: true, remove: true, inactivate: true },
  });
}
```

```html
<s-crud-list [crud]="crud">
  <form filters [formGroup]="filtros">
    <s-field label="Nome"><s-input icon="search" formControlName="nome" /></s-field>
    <s-field label="Status">
      <s-select [options]="status" placeholder="Todos" formControlName="ativo" />
    </s-field>
  </form>
</s-crud-list>
```

Isso é a tela toda: cabeçalho com trilha e botão "Novo Tipo de Falta", card de
filtros com Buscar e Limpar, tabela com os quatro estados, paginação, modal de
confirmação da exclusão, aviso de sucesso e navegação para o formulário.

### O que dispara consulta

Trocar de página, de tamanho de página ou de ordenação consulta na hora.
**Digitar num filtro não consulta**: os filtros entram na consulta quando a
pessoa clica em Buscar (ou tecla Enter no card). É o que evita uma chamada por
tecla e mantém a lista parada enquanto alguém preenche três campos.

Ao aplicar filtros, campo vazio (`''`, `null`, lista vazia) sai da consulta —
mas `false` e `0` ficam: "Documento obrigatório: Não" é um recorte, não a
ausência de recorte.

### A fonte de dados

```ts
export abstract class SCrudDataSource<T> {
  abstract list(query: SCrudQuery): Observable<SCrudPage<T>>;
  remove?(row: T): Observable<unknown>;
  setActive?(row: T, active: boolean): Observable<unknown>;
}
```

Uma ação só aparece se houver como executá-la: sem `remove()`, a lixeira não
aparece — ainda que a configuração peça. Um botão que não faz nada é pior que um
botão ausente.

Para os services que já seguem o contrato do SIAGE
(`getByFilterPaginated`/`PagedResult`), `siageCrudDataSource(service)` faz a
tradução, incluindo `page`, `pageSize`, `sort` e `sortDirection`. Nome de
parâmetro diferente se ajusta por opção; API fora do contrato implementa a
classe.

### Colunas que agem

O `<ng-template sTableCell="chave">` declarado dentro do `<s-crud-list>` chega à
coluna correspondente da tabela — é como a coluna "Em uso" ganha um botão sem
que a biblioteca precise conhecer o caso.

### Navegação e outputs

Com `routes`, visualizar, editar e cadastrar navegam sozinhos
(`base/visualizar/:id`, `base/editar/:id`, `base/cadastrar` — os segmentos são
configuráveis). Sem `routes`, nada é navegado, e os outputs `view`/`edit`/
`create` do `<s-crud-list>` são o caminho da tela: o caso de quem abre o
formulário em modal.

Excluir e inativar **sempre** passam pelo modal de confirmação e pela fonte de
dados; os outputs correspondentes são aviso, não substituição.

### Vindo do `app-generic-crud-list-wrapper`

| Antes (em cada sistema)             | Agora (na biblioteca)                        |
| ----------------------------------- | -------------------------------------------- |
| `CrudConfig`                        | `SCrudConfig`                                |
| `GenericCrudListBaseComponent`      | `injectCrudList()` — função, não herança     |
| `app-generic-crud-list-wrapper`     | `<s-crud-list>`                              |
| `app-generic-list` + `table-custom` | `<s-table>` (mesmos inputs, ver `<s-table>`) |
| `IGenericService`                   | `SCrudDataSource` (+ `siageCrudDataSource`)  |
| `ColumnDataTable.bodyTemplate`      | `<ng-template sTableCell="...">`             |
| `ColumnDataTable.pTag`              | `badge` na coluna, ou `pTag` em `options`    |
| `TableLazyLoadEvent`                | `SCrudQuery` — sem tipo de terceiro na API   |

A diferença de fundo é a herança: em vez de a tela **ser** um componente base,
ela **tem** uma listagem. Nada de `override protected get service()`, de
`setTimeout` no construtor ou de `@ViewChild` injetando template em `computed`.

---

## Classes utilitárias

Fazem o papel do PrimeFlex, com a diferença que é o motivo de existirem: **só os
valores do design system têm classe**. São oito passos de espaçamento e oito
classes: `p-9` não existe, e o erro aparece na hora de escrever — não numa
revisão de layout três semanas depois.

São opcionais e globais. Ative no `styles.scss` da aplicação:

```scss
@use '@siage/siage-ui/styles/theme' as siage;
@use '@siage/siage-ui/styles/utilities' as siageUtils;

html {
  @include siage.theme();
}

@include siageUtils.utilities();
```

Sem SCSS, importe o CSS pronto (13 KB minificado):

```json
"styles": ["node_modules/@siage/siage-ui/styles/utilities.css", "src/styles.scss"]
```

### O que existe

Oito passos, oito classes: `p-1` a `p-8`, mais o zero. O número é a posição na
escala, não o valor.

| Classe |      |     | Classe |      |
| ------ | ---- | --- | ------ | ---- |
| `p-0`  | 0    |     | `p-5`  | 24px |
| `p-1`  | 4px  |     | `p-6`  | 32px |
| `p-2`  | 8px  |     | `p-7`  | 48px |
| `p-3`  | 12px |     | `p-8`  | 64px |
| `p-4`  | 16px |     |        |      |

#### Padding

`p-{passo}` nos quatro lados, ou com prefixo de lado:

| Prefixo                     | Aplica em          |
| --------------------------- | ------------------ |
| `p-4`                       | os quatro lados    |
| `pt-4` `pr-4` `pb-4` `pl-4` | um lado            |
| `px-4`                      | esquerda e direita |
| `py-4`                      | topo e base        |

#### Margin

Os mesmos prefixos com `m`, mais quatro que não vêm da escala, porque `auto` não
é uma medida — é uma instrução de centralizar:

| Classe    | Para quê                                |
| --------- | --------------------------------------- |
| `mx-auto` | centraliza um bloco de largura fixa     |
| `m-auto`  | centraliza nos dois eixos               |
| `ml-auto` | empurra o item para a direita num flex  |
| `mr-auto` | empurra o item para a esquerda num flex |

#### Espaço entre itens

`gap-{passo}`, `row-gap-{passo}` e `column-gap-{passo}`. Quase sempre melhor que
margem entre irmãos: não sobra espaço na ponta, e não há margem que colapse com
a vizinha.

#### Tipografia

Onze classes — os seis títulos e os cinco tamanhos de texto corrido:

| Classe         |      | Uso                      |
| -------------- | ---- | ------------------------ |
| `text-h1`      | 36px | título de tela           |
| `text-h2`      | 30px | título de tela no mobile |
| `text-h3`      | 24px | título de modal          |
| `text-h4`      | 20px | título de estado vazio   |
| `text-h5`      | 18px | título de seção          |
| `text-h6`      | 16px | título de card           |
| `text-body-lg` | 16px | corpo no mobile          |
| `text-body`    | 14px | corpo na web             |
| `text-label`   | 14px | rótulo de campo e botão  |
| `text-caption` | 12px | apoio, trilha, contagem  |
| `text-badge`   | 12px | texto de badge           |

Tamanhos se repetem em pares de propósito: o nome diz **onde** aquele tamanho é
usado, e é o que permite mudar um dos dois depois sem caçar cada ocorrência.

Mais `font-regular`, `font-medium`, `font-semibold`, `font-display`, `font-ui`,
`text-left/center/right`, `leading-tight/normal/relaxed`, `text-nowrap`,
`text-truncate` e `tabular-nums`.

#### Cor semântica

Cada uma de `primary`, `success`, `warning`, `destructive` e `info` tem os passos
que o guia desenhou — e só eles:

| Classe                                     | O que é                                                  |
| ------------------------------------------ | -------------------------------------------------------- |
| `text-primary`                             | a cor cheia, sobre fundo neutro                          |
| `text-primary-on-surface`                  | texto sobre a superfície tingida com o próprio token     |
| `text-primary-hover`                       | 10% mais escura (só `primary`, `success`, `destructive`) |
| `bg-primary-subtle` `-container` `-strong` | os tints de 8%, 12% e 24%                                |
| `bg-primary` `border-primary`              | a cor cheia                                              |

Não há rampa `-100`…`-900`. Uma rampa derivada teria de se inverter entre os
temas — `-200` é legível sobre o card branco do tema claro e invisível sobre o
navy do escuro — e o mesmo nome de classe carregaria contrastes opostos. Os
tints não têm esse problema porque são opacidade sobre `transparent`: tingem o
fundo que houver.

#### Exibição e flex

| Grupo          | Classes                                                                |
| -------------- | ---------------------------------------------------------------------- |
| Exibição       | `flex` `inline-flex` `block` `inline-block` `inline` `hidden`          |
| Direção        | `flex-row` `flex-column` `flex-row-reverse` `flex-column-reverse`      |
| Quebra         | `flex-wrap` `flex-nowrap`                                              |
| Crescimento    | `flex-1` `flex-auto` `flex-none`                                       |
| Eixo cruzado   | `align-items-*` `align-self-*` — start, center, end, baseline, stretch |
| Eixo principal | `justify-content-*` — start, center, end, between, around, evenly      |

`grid` não é uma classe de exibição aqui: é a grade de 12 colunas, com colunas e
gap já definidos. `hidden` é `display: none`, então o elemento sai também da
árvore de acessibilidade.

Respondem a largura de tela, com `sm:` `md:` `lg:` `xl:`: `hidden`, `block`,
`flex`, `inline-flex`, `flex-row`, `flex-column` e `col-1`…`col-12`.

#### Borda, raio e elevação

| Classe                                                    |                                  |
| --------------------------------------------------------- | -------------------------------- |
| `border-round`                                            | 8px, o raio de controle          |
| `border-round-lg`                                         | 12px, o raio de container        |
| `border-round-full`                                       | círculo                          |
| `border-round-none`                                       | quadra os quatro cantos          |
| `border-round-top` `-right` `-bottom` `-left`             | 8px nos dois cantos daquele lado |
| `border-round-top-lg` … `-left-lg`                        | o mesmo, com 12px                |
| `border-1` `border-top-1` … `border-left-1` `border-none` | a borda de 1px                   |
| `shadow-1` `shadow-2` `shadow-3` `shadow-none`            | elevação                         |

#### Estados

`hover:`, `focus:` e `active:` na frente da classe, como no PrimeFlex:

```html
<a class="text-color hover:text-primary hover:bg-primary-subtle border-round px-3 py-2">
  Ver turma
</a>
```

Só cor e elevação ganham prefixo — as classes de `text-`, `bg-`,
`border-{cor}` e `shadow-`. Espaçamento e layout ficam de fora de propósito:
mudar padding no hover reflui o conteúdo vizinho, e o resultado é a tela
tremendo sob o cursor.

Duas pegadinhas. **`focus:` casa `:focus`, não `:focus-visible`** — é a
semântica do PrimeFlex, mas acende também no clique de mouse; os componentes da
biblioteca usam `:focus-visible` internamente, que é o certo para anel de foco.
E **`hover:text-primary-hover` não é redundante**: o `hover:` da frente é o
estado, o `-hover` do fim é o nome do token.

#### Tamanho

`w-full` `w-auto` `h-full` `h-auto` `max-w-full` `min-w-0` `overflow-auto`
`overflow-hidden` `overflow-x-auto`.

#### Grade

`grid` e `col-1`…`col-12`, com `sm:` `md:` `lg:` `xl:`.

A grade usa CSS Grid, e não a combinação de flex com margem negativa do
PrimeFlex: `col-6` vira `grid-column: span 6`, sem gutter falso feito de padding
que depois precisa ser desfeito na borda. As classes de coluna têm o mesmo nome,
então `col-12` e `md:col-6` continuam funcionando na migração.

Cada grupo pode ser desligado, para uma aplicação que já tenha a própria grade:

```scss
@include siageUtils.utilities($grid: false, $responsive: false);
```

> **Breakpoints:** o guia de design não define nenhum. Os usados aqui — 576,
> 768, 992 e 1200px — são os do PrimeFlex, mantidos para que a migração seja
> uma troca de nome de classe e não um redesenho de tela.

### Migrando do PrimeFlex

O espaçamento é o que mais muda, porque o PrimeFlex indexa a escala e aqui o
nome é o valor:

| PrimeFlex           | SIAGE               |      |
| ------------------- | ------------------- | ---- |
| `p-1` `m-1` `gap-1` | `p-1` `m-1` `gap-1` | 4px  |
| `p-2` `m-2` `gap-2` | `p-2` `m-2` `gap-2` | 8px  |
| —                   | `p-3` `m-3` `gap-3` | 12px |
| `p-3` `m-3` `gap-3` | `p-4` `m-4` `gap-4` | 16px |
| `p-4` `m-4` `gap-4` | `p-5` `m-5` `gap-5` | 24px |
| `p-5` `m-5` `gap-5` | `p-6` `m-6` `gap-6` | 32px |
| `p-6` `m-6` `gap-6` | `p-7` `m-7` `gap-7` | 48px |
| `p-7` `m-7` `gap-7` | `p-8` `m-8` `gap-8` | 64px |

Só `1` e `2` querem dizer a mesma coisa nos dois. Do `3` em diante, o mesmo nome
é um passo menor aqui — `p-3` é 16px lá e 12px aqui —, e a classe continua
existindo, então a tela não quebra: só fica mais apertada, em silêncio. Por isso
a troca é renumerar (`3`→`4`, `4`→`5`…`7`→`8`), não manter o nome.

A escala do PrimeFlex não tem 12px, e a nossa não tem os 80px do `p-8`.

Tipografia, por tamanho equivalente:

| PrimeFlex   | SIAGE          |      |
| ----------- | -------------- | ---- |
| `text-xs`   | `text-caption` | 12px |
| `text-sm`   | `text-body`    | 14px |
| `text-base` | `text-body-lg` | 16px |
| `text-lg`   | `text-h5`      | 18px |
| `text-xl`   | `text-h4`      | 20px |
| `text-2xl`  | `text-h3`      | 24px |
| `text-3xl`  | `text-h2`      | 30px |
| `text-4xl`  | `text-h1`      | 36px |

E o resto:

| PrimeFlex                                        | SIAGE            |
| ------------------------------------------------ | ---------------- |
| `text-color` `text-secondary`                    | iguais           |
| `text-white`                                     | `text-on-filled` |
| `font-bold`                                      | `font-semibold`  |
| `border-round` `border-1` `col-*` `flex*` `gap`… | iguais           |
| `w-5rem` `h-3rem` e afins                        | sem equivalente  |

`font-bold` não tem correspondente porque a escala do guia tem três pesos —
regular (400), medium (500) e semibold (600). O 700 não é um deles.

As medidas arbitrárias (`w-5rem`, `h-5rem`) ficaram de fora de propósito: são
101 usos no Professores, quase todos em avatares, e medida de componente
pertence ao CSS do componente — não a uma classe que qualquer tela pode aplicar
em qualquer lugar.

## Registry Gitea

A biblioteca é privada e publicada no npm Package Registry do Gitea interno
(`seepb.qa`), sob a organização `SEEPB-DesignSystem`.

`.npmrc` (na raiz do workspace ou da aplicação consumidora):

```ini
@siage:registry=http://seepb.qa/api/packages/SEEPB-DesignSystem/npm/
//seepb.qa/api/packages/SEEPB-DesignSystem/npm/:_authToken=${GITEA_NPM_TOKEN}
```

O registry npm do Gitea é sempre escopado ao owner — `SEEPB-DesignSystem` é a
organização dona do package.

`GITEA_NPM_TOKEN` é o seu token pessoal do Gitea, com escopo de packages,
exportado como variável de ambiente (ou escrito direto no `.npmrc`). **Nunca**
comite o token nem um `.npmrc` preenchido — `.npmrc` está no `.gitignore`.

Use o `.npmrc.example` do workspace como base: só o token precisa ser ajustado.

### Gerando o token no Gitea

O token precisa do escopo **`package`**. Um token só com escopo de repositório
autentica no `git push`, mas **não** no registry npm — e o npm reporta isso como
`E401 Incorrect or missing password`, mensagem que não ajuda em nada.

1. Acesse `http://seepb.qa/user/settings/applications`.
2. Em **Generate New Token**, dê um nome (ex.: `npm-siage-ui`).
3. Nos escopos, marque:
   - **`package` -> `read:package`** — suficiente para _instalar_ a biblioteca
     numa aplicação;
   - **`package` -> `write:package`** — necessário para _publicar_ (já inclui a
     leitura).
4. Gere e copie o token: ele só é exibido uma vez.
5. Para publicar sob uma **organização**, seu usuário também precisa de
   permissão de escrita em packages naquela organização.

O Gitea não permite alterar os escopos de um token já criado: se faltar algum,
gere um novo e apague o antigo.

Para conferir o token sem depender das mensagens do npm (na API do Gitea,
**401 = token inválido**, **403 = token válido sem o escopo pedido**):

```bash
# 200 = tem escopo de package | 403 = válido, mas SEM escopo de package
curl -s -o /dev/null -w '%{http_code}' -H "Authorization: token $TOKEN" "http://seepb.qa/api/v1/packages/SEEPB-DesignSystem"; echo
```

### Publicando

O caminho normal é por tag — a publicação acontece no CI, com o token do
repositório, e não depende da máquina de ninguém.

```bash
# 1. Na branch da major do Angular, mova o que está em [Não publicado] no
#    CHANGELOG.md para uma seção [20.2.0] com a data, e faça o commit
git checkout v20
git commit -am "docs(changelog): 20.2.0"
git push origin v20

# 2. A tag v publica o pacote — a versão sai do nome da tag
git tag v20.2.0
git push origin v20.2.0

# 3. A tag s atualiza o Storybook (opcional, quando a documentação mudou)
git tag s20.2.0
git push origin s20.2.0
```

Acompanhe em **Actions** no Gitea.

#### Não existe publicação manual

A biblioteca tem `"private": true`: `npm publish` feito de uma máquina falha
com `EPRIVATE`, mesmo com token de escrita. Só a esteira da tag `v` remove a
trava. Com o runner fora do ar, espere ele voltar e re-execute o job.

#### Antes de publicar

```bash
npm run format:check
npx ng test siage-ui --watch=false
npm run build
```

Os três rodam no CI a cada push, mas rodar antes da tag evita descobrir um
problema com a versão já marcada.

> O `package.json` da biblioteca **não** define `publishConfig.registry` de
> propósito: assim o pacote não fica preso a uma URL. O destino vem do `.npmrc`
> (`@siage:registry`), que é específico do ambiente.

---

## Desenvolvimento

```bash
npm install        # dependências do workspace
npm run build      # ng build siage-ui  -> dist/siage-ui
npm run test:ci    # ng test siage-ui --watch=false
```

Os testes rodam no runner padrão do workspace (Karma + Jasmine, builder
`@angular/build:karma`) em `ChromeHeadless` e sem Zone.js — o workspace Angular 20
é zoneless por padrão e os componentes funcionam nos dois modos.
