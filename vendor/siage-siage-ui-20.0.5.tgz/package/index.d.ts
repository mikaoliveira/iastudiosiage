import * as _angular_core from '@angular/core';
import { TemplateRef, InjectionToken, Signal, EnvironmentProviders, AfterViewInit, OnDestroy, Type, OnInit, DoCheck, Provider, ElementRef } from '@angular/core';
import { AbstractControl, ValidationErrors, ControlValueAccessor, Validator, FormControl, NgModel, FormGroup } from '@angular/forms';
import { MatButtonAppearance } from '@angular/material/button';
import * as i1 from '@angular/material/tooltip';
import { MatSelectChange } from '@angular/material/select';
import { MatPseudoCheckboxState, NativeDateAdapter, MatDateFormats } from '@angular/material/core';
import * as _siage_siage_ui from '@siage/siage-ui';
import { ComponentType } from '@angular/cdk/portal';
import { MatCalendarView, MatCalendarCellClassFunction, MatDatepickerInputEvent, MatDatepickerIntl } from '@angular/material/datepicker';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { MatDialogRef } from '@angular/material/dialog';
import * as i1$1 from '@angular/cdk/a11y';
import { ComponentType as ComponentType$1 } from '@angular/cdk/overlay';
import { HttpInterceptorFn } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { MatRadioChange } from '@angular/material/radio';
import * as i1$2 from '@angular/cdk/accordion';

/**
 * Opcao de um controle de escolha (`<s-select>`, `<s-multiselect>`).
 *
 * O tipo generico `T` e o valor de dominio devolvido para a aplicacao — um id
 * numerico, um uuid, um objeto de negocio. O componente nunca inspeciona esse
 * valor: apenas o devolve.
 *
 * Tem a mesma forma de `SAutocompleteOption`, entao uma lista serve aos dois
 * controles sem conversao.
 */
interface SOption<T = unknown> {
    /** Texto exibido na lista e no gatilho. */
    label: string;
    /** Valor associado a opcao. E este valor que trafega no formulario. */
    value: T;
    /** Desabilita a opcao individualmente. */
    disabled?: boolean;
}

/** O que o template de opcao recebe. */
interface SOptionTemplateContext<T = unknown> {
    /** A opcao desenhada. Disponivel como `let-opcao`. */
    $implicit: SOption<T>;
    /** `true` quando a opcao esta selecionada. Disponivel como `let-selecionada="selected"`. */
    selected: boolean;
}
/**
 * Desenho proprio para cada opcao de `<s-select>`, `<s-multiselect>` e
 * `<s-autocomplete>`.
 *
 * Sem ele a opcao mostra so o `label`. Use quando a lista precisa de uma segunda
 * linha (matricula abaixo do nome), um badge de situacao ou um icone - o painel,
 * o teclado e a selecao continuam sendo do componente.
 *
 * O `label` continua obrigatorio na `SOption`: e ele que vai para o gatilho
 * fechado, para o filtro e para o leitor de tela.
 *
 * @example
 * ```html
 * <s-select [options]="alunos" formControlName="aluno">
 *   <ng-template sOption let-opcao>
 *     <strong>{{ opcao.label }}</strong>
 *     <small>Matrícula {{ opcao.value }}</small>
 *   </ng-template>
 * </s-select>
 * ```
 */
declare class SOptionTemplateDirective<T = unknown> {
    readonly template: TemplateRef<SOptionTemplateContext<T>>;
    /**
     * Tipo das opcoes, so para o template ganhar checagem de tipo:
     * `<ng-template sOption [sOptionOf]="alunos" let-opcao>`.
     */
    readonly sOptionOf: _angular_core.InputSignal<readonly SOption<T>[] | null>;
    static ngTemplateContextGuard<T>(_diretiva: SOptionTemplateDirective<T>, contexto: unknown): contexto is SOptionTemplateContext<T>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SOptionTemplateDirective<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SOptionTemplateDirective<any>, "ng-template[sOption]", never, { "sOptionOf": { "alias": "sOptionOf"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Quanto tempo um carregamento precisa durar antes de aparecer na tela, em ms.
 *
 * O guia **nao** define esse limiar — diz o que mostrar (esqueleto no formato do
 * conteudo final, nunca spinner central) e deixa o "a partir de quando" em
 * aberto. O valor foi decidido pela equipe.
 *
 * Ele existe porque uma resposta rapida que pisca o esqueleto por 80ms incomoda
 * mais do que a espera em si: a tela salta duas vezes em vez de uma.
 *
 * Para ajustar, registre outro valor uma unica vez na aplicacao:
 *
 * ```ts
 * providers: [provideSiageLoadingDelay(1500)]
 * ```
 */
declare const S_LOADING_DELAY: InjectionToken<number>;
/** Troca o limiar de exibicao do estado de carregamento em toda a aplicacao. */
declare function provideSiageLoadingDelay(delayMs: number): EnvironmentProviders;
/**
 * Adia a exibicao do carregamento pelo limiar configurado.
 *
 * Devolve um sinal que so fica `true` depois que `carregando` permanece `true`
 * pelo tempo de `S_LOADING_DELAY`. Voltar para `false` cancela o relogio, entao
 * uma resposta rapida nunca chega a piscar o esqueleto.
 *
 * Chame de um campo de classe ou do construtor — precisa de contexto de
 * injecao, como qualquer `inject()`.
 *
 * @param carregando Sinal com o estado bruto da requisicao.
 */
declare function adiarCarregamento(carregando: Signal<boolean>): Signal<boolean>;

/**
 * Escala de tamanho de icone.
 *
 * Sao quatro medidas, e apenas quatro: as do guia. O nome existe para que um
 * quinto valor nao entre — `size="18"` nao e uma opcao, e o erro aparece na
 * hora de escrever em vez de numa revisao de layout.
 *
 * A escala do guia e nomeada por **papel** (icone de controle, de navegacao, de
 * badge, de estado vazio); o input e nomeado por **tamanho**, porque quem
 * escreve o template ja sabe o papel pelo componente em que esta:
 *
 * | Token | px | Papel no guia |
 * | ----- | -- | ------------- |
 * | `xs`  | 16 | badge e o "i" de ajuda ao lado de rotulo |
 * | `sm`  | 20 | dentro de campo e de botao |
 * | `md`  | 24 | barra superior, menu lateral, acao de linha |
 * | `lg`  | 48 | estado vazio |
 */
type SIconSize = 'xs' | 'sm' | 'md' | 'lg';
/**
 * O que um template pode escrever num input de tamanho de icone.
 *
 * Alem dos quatro nomes, os quatro numeros continuam valendo — como texto
 * (`size="24"`) ou como valor (`[size]="24"`). Nao e conveniencia: e o que
 * mantem funcionando o codigo escrito antes dos nomes existirem. Em codigo novo
 * use o nome, que diz a intencao sem exigir a tabela.
 */
type SIconSizeInput = SIconSize | 16 | 20 | 24 | 48 | '16' | '20' | '24' | '48';
/** O tamanho em pixels de um passo da escala. */
declare function pixelsDoTamanho(tamanho: SIconSize): number;
/**
 * O token CSS de um passo da escala.
 *
 * O componente escreve a referencia ao token, e nao o numero: assim a medida
 * continua saindo do tema, e um sistema que precise redefinir a escala redefine
 * `--icon-md` uma vez em vez de caçar `24px` em cada componente.
 */
declare function variavelDoTamanho(tamanho: SIconSize): string;
/**
 * Transform de input: aceita o nome ou o numero, devolve sempre o nome.
 *
 * Recebe o padrao do componente porque cada um tem o seu — o badge nasce `xs`, o
 * botao so-icone nasce `md`. Um valor fora da escala cai no padrao, com aviso em
 * desenvolvimento: o componente continua desenhando, e quem escreveu fica
 * sabendo.
 */
declare function tamanhoDeIcone(padrao: SIconSize): (valor: SIconSizeInput) => SIconSize;

/**
 * Como transformar um erro de validacao em texto.
 *
 * A funcao recebe o valor que o validador colocou no erro — `minlength` devolve
 * `{ requiredLength, actualLength }`, por exemplo — para a mensagem poder citar
 * o numero em vez de falar em abstrato.
 */
type SValidationMessage = string | ((erro: unknown, controle: AbstractControl | null) => string);
/** Mensagens por nome de erro. */
type SValidationMessages = Record<string, SValidationMessage>;
/**
 * As mensagens que a biblioteca ja traz.
 *
 * Cobrem os validadores do Angular e os do datepicker do Material, que sao os
 * que aparecem sem ninguem escrever validador nenhum.
 */
declare const S_MENSAGENS_PADRAO: SValidationMessages;
/**
 * Mensagens de validacao da aplicacao.
 *
 * Existe para que "campo obrigatorio" seja a **mesma frase** nas 87 telas do
 * Professores. Sem isso, cada uma escreve a sua — e o usuario aprende que o
 * sistema fala de tres jeitos diferentes sobre a mesma coisa.
 *
 * O que a aplicacao registra e mesclado com os padroes: informe so o que quiser
 * trocar ou acrescentar.
 *
 * ```ts
 * providers: [
 *   provideSiageValidationMessages({
 *     required: 'Preencha este campo.',
 *     cpfInvalido: 'CPF inválido.',
 *   }),
 * ]
 * ```
 */
declare const S_VALIDATION_MESSAGES: InjectionToken<SValidationMessages>;
/** Registra ou sobrescreve mensagens de validacao em toda a aplicacao. */
declare function provideSiageValidationMessages(messages: SValidationMessages): EnvironmentProviders;
/**
 * Escolhe a mensagem do primeiro erro que tiver uma.
 *
 * Um controle pode falhar em varios validadores ao mesmo tempo; mostrar todos
 * empilhados so aumenta o ruido. O primeiro basta — resolvido ele, o proximo
 * aparece.
 */
/**
 * Todas as mensagens de um objeto de erros, na ordem em que os validadores as
 * registraram.
 *
 * Erro sem mensagem mapeada e ignorado, e nao vira uma linha em branco: quando
 * nenhum tem mapeamento, a lista volta vazia e a faixa fica reservada, sem
 * texto.
 */
declare function todasAsMensagens(erros: ValidationErrors | null, controle: AbstractControl | null, mensagens: SValidationMessages): string[];
declare function primeiraMensagem(erros: ValidationErrors | null, controle: AbstractControl, mensagens: SValidationMessages): string;

type SIconVariant = 'primary' | 'secondary' | 'success' | 'warning' | 'info' | 'destructive' | 'default';
/**
 * Glifo do Material Symbols Rounded, sobre o `mat-icon`.
 *
 * Decorativo por padrao; com `label`, e anunciado. `iconFilled` preenche o
 * glifo e `filled` poe o fundo da `variant` — os dois combinam.
 */
declare class SIconComponent {
    /** Nome do glifo no Material Symbols */
    readonly name: _angular_core.InputSignal<string>;
    /**
     * Passo da escala do guia: `xs` (16), `sm` (20), `md` (24) ou `lg` (48).
     */
    readonly size: _angular_core.InputSignalWithTransform<SIconSize, SIconSizeInput>;
    /** Preenche o glifo (eixo `FILL`). No guia, so o item ativo da navegacao. */
    readonly iconFilled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Poe o fundo na cor da `variant`. Sem `variant`, nao tem efeito. */
    readonly filled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Cor explicita. Por padrao o icone herda a cor do texto ao redor. */
    readonly color: _angular_core.InputSignal<string>;
    /** Torna o icone anunciavel. Use apenas quando ele for o unico conteudo com significado. */
    readonly label: _angular_core.InputSignal<string>;
    /** Cor do papel (`text-*`). Requer `@siage/siage-ui/styles/utilities`. */
    readonly variant: _angular_core.InputSignal<SIconVariant>;
    protected readonly tamanho: _angular_core.Signal<string>;
    protected readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SIconComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SIconComponent, "s-icon", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "iconFilled": { "alias": "iconFilled"; "required": false; "isSignal": true; }; "filled": { "alias": "filled"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Variantes de botao.
 *
 * A escolha e semantica, nao estetica:
 *
 * - `primary` — a unica acao principal da tela;
 * - `secondary` — acao de apoio ao lado da principal;
 * - `success` — acao que conclui ou aprova;
 * - `warning` — acao que exige atencao, sem ser destrutiva;
 * - `info` — acao informativa;
 * - `destructive` — acao que remove ou desfaz algo, sempre nomeada;
 * - `ghost` — acao discreta dentro de linha de tabela ou card;
 * - `link` — navegacao com aparencia de texto, sem altura de controle.
 *
 * **Nao ha `outline`.** Contorno e modificador, nao papel: qualquer variante
 * preenchida vira contornada com o atributo `outlined`. O antigo
 * `variant="outline"` do guia e hoje `variant="secondary" outlined`, que produz
 * exatamente o mesmo botao.
 *
 * As tres semanticas — `success`, `warning`, `info` — sao adicao desta
 * biblioteca. O guia so preve primaria, secundaria, neutra, destrutiva e link,
 * e sobre `--info` ele e explicito: "existe exclusivamente [no alerta], nunca
 * em elemento clicavel". Use com parcimonia; se a cor for a unica coisa que
 * distingue duas acoes, o rotulo e que esta fraco.
 */
type SButtonVariant = 'primary' | 'secondary' | 'success' | 'warning' | 'info' | 'destructive' | 'ghost' | 'link';
/** Valor do atributo `type` do botao nativo. */
type SButtonType = 'button' | 'submit' | 'reset';
/**
 * @deprecated Use `SButtonVariant`. O botao so-icone passou a aceitar as mesmas
 * variantes do botao com texto; `neutral` virou `ghost`.
 */
type SIconButtonTone = 'neutral' | 'destructive';

/**
 * Botao de acao, sobre o `matButton`. A `variant` e o papel da acao na tela.
 *
 * Em `loading` continua focavel, mas ignora o clique e anuncia `aria-busy`.
 */
declare class SButtonComponent {
    /** Papel da acao na tela. Ver `SButtonVariant`. */
    readonly variant: _angular_core.InputSignal<SButtonVariant>;
    /** Troca o preenchimento por um contorno. Ignorado em `ghost` e `link`. */
    readonly outlined: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Ocupa toda a largura disponivel e ganha a altura maior do guia. */
    readonly fullWidth: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Botao de alternancia: `true`/`false` viram `aria-pressed` no botao nativo,
     * que e quem recebe o foco. `null` (padrao) e um botao comum.
     */
    readonly pressed: _angular_core.InputSignal<boolean | null>;
    /**
     * Papel ARIA do botao nativo, para quando ele e a opcao de um composto (ex.:
     * `radio` num `radiogroup`). `null` (padrao) mantem o papel de botao. Quem usa
     * `radio` deve passar `checked` e deixar `pressed` em `null`.
     */
    readonly buttonRole: _angular_core.InputSignal<string | null>;
    /** `aria-checked` do botao nativo, para `buttonRole="radio"`. `null` (padrao) nao escreve nada. */
    readonly checked: _angular_core.InputSignal<boolean | null>;
    /**
     * `tabindex` do botao nativo, para o "roving tabindex" de um composto: `0` na
     * opcao que entra no Tab e `-1` nas demais. `null` (padrao) nao escreve nada.
     */
    readonly focusIndex: _angular_core.InputSignal<number | null>;
    /** Exibe o glifo de progresso e bloqueia o clique, sem desabilitar o botao. */
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Texto exibido no lugar do rotulo enquanto `loading` e `true` ("Salvando...").
     *
     * Sem ele (padrao) o rotulo nao muda, como sempre. Com ele, a troca e anunciada
     * ao leitor de tela (`aria-live="polite"`) e o foco fica no botao. O botao
     * continua habilitado durante o `loading`: para travar os demais botoes da
     * barra, use `[disabled]` neles com o mesmo estado da tela.
     */
    readonly loadingText: _angular_core.InputSignal<string | undefined>;
    /** Desabilita o botao. Indica indisponibilidade da acao, nao carregamento. */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Glifo a esquerda do texto, em 20px. */
    readonly icon: _angular_core.InputSignal<string>;
    /** Glifo a direita do texto, em 20px. Escondido enquanto `loading`. */
    readonly iconRight: _angular_core.InputSignal<string>;
    /** Atributo `type` do botao nativo. */
    readonly type: _angular_core.InputSignal<SButtonType>;
    /** Nome acessivel, quando o texto visivel nao basta (ex.: "Ver" numa tabela). */
    readonly label: _angular_core.InputSignal<string>;
    /** `true` quando `outlined` foi pedido numa variante que o suporta. */
    private readonly isOutlined;
    protected readonly appearance: _angular_core.Signal<MatButtonAppearance>;
    protected readonly hostClasses: _angular_core.Signal<string>;
    /**
     * Barra o clique enquanto `loading`, venha do mouse ou do teclado (Enter e
     * Espaco tambem geram `click` no botao nativo).
     *
     * `preventDefault` impede o envio do formulario em `type="submit"`;
     * `stopPropagation` impede que o evento suba ate o `<s-button>`, onde a tela
     * liga o `(click)`.
     */
    protected aoClicar(evento: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SButtonComponent, "s-button", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "outlined": { "alias": "outlined"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "pressed": { "alias": "pressed"; "required": false; "isSignal": true; }; "buttonRole": { "alias": "buttonRole"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "focusIndex": { "alias": "focusIndex"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingText": { "alias": "loadingText"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "iconRight": { "alias": "iconRight"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * Botao so com icone, sobre o `matIconButton`.
 *
 * `label` e obrigatorio: vira o `aria-label` e a dica do hover. Escreva a acao
 * ("Excluir jornada"), nunca o nome do glifo.
 */
declare class SIconButtonComponent {
    /** Nome do glifo no Material Symbols. */
    readonly icon: _angular_core.InputSignal<string>;
    /** Texto que descreve a acao. Vira `aria-label` e `title`. */
    readonly label: _angular_core.InputSignal<string>;
    /** Papel da acao na tela. Ver `SButtonVariant`. */
    readonly variant: _angular_core.InputSignal<SButtonVariant>;
    /** Contorno na cor da variante. Ignorado em `ghost` e `link`. */
    readonly outlined: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Sem fundo nem moldura: so o glifo, com a cor da variante no hover. */
    readonly text: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Passo da escala do guia: `xs` (16), `sm` (20), `md` (24) ou `lg` (48).
     */
    readonly size: _angular_core.InputSignalWithTransform<SIconSize, SIconSizeInput>;
    /** Preenche o glifo (eixo `FILL`), como no `<s-icon>`. */
    readonly iconFilled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Desabilita o botao. */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Mostra o progresso e ignora o clique, mas continua focavel (`aria-busy`). */
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Atributo `type` do botao nativo. */
    readonly type: _angular_core.InputSignal<SButtonType>;
    /**
     * Com `sTooltip` no mesmo elemento, a dica e dele: o `title` nativo abriria
     * uma segunda, a do navegador, por cima.
     */
    protected readonly comDica: boolean;
    /** `true` quando `outlined` foi pedido numa variante que o suporta. */
    private readonly isOutlined;
    /** `true` quando `text` foi pedido numa variante que o suporta. */
    private readonly isText;
    protected readonly hostClasses: _angular_core.Signal<string>;
    /**
     * Lado da area clicavel, derivado do tamanho do glifo.
     *
     * Sem isto a area ficava fixa em 40px: com `size="lg"` o icone de 48px
     * transbordava o proprio hover, que aparecia menor que o desenho. Os 16px de
     * folga sao os que levam o glifo de 24px a area de 40px que o guia fixa.
     */
    protected readonly area: _angular_core.Signal<string>;
    /** Ver `SButtonComponent.aoClicar`: barra o clique durante `loading`. */
    protected aoClicar(evento: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SIconButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SIconButtonComponent, "s-icon-button", never, { "icon": { "alias": "icon"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "outlined": { "alias": "outlined"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "iconFilled": { "alias": "iconFilled"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Espacamento interno, em passos da escala de 4px. Lista fechada de proposito:
 * para os 20px que o guia cita em cards indicadores, use 24.
 */
type SCardPadding = 0 | 12 | 16 | 24 | 32;
/** Nivel de elevacao do card. `0` remove a sombra. */
type SCardElevation = 0 | 1 | 2 | 3;
/**
 * Superficie de conteudo: fundo, borda e raio de container. No tema escuro a
 * sombra some e a hierarquia fica com a borda (ja resolvido nos tokens).
 *
 * Com `sCardHeader`, `sCardContent` ou `sCardFooter`, o espacamento passa a ser
 * das secoes. `sCardTitle` marca o titulo do cabecalho.
 *
 * ```html
 * <s-card>
 *   <header sCardHeader><h2 sCardTitle>Jornadas</h2></header>
 *   <div sCardContent>Corpo</div>
 *   <footer sCardFooter><s-button>Salvar</s-button></footer>
 * </s-card>
 * ```
 */
declare class SCardComponent {
    /**
     * Espacamento interno, em passos da escala de 4px. Sem valor, e 16 — ou 0
     * quando o card usa secoes, que trazem o proprio espacamento.
     */
    readonly padding: _angular_core.InputSignalWithTransform<SCardPadding | undefined, unknown>;
    /** Nivel de sombra. `0` deixa o card sem elevacao, apoiado apenas na borda. */
    readonly elevation: _angular_core.InputSignalWithTransform<SCardElevation, unknown>;
    private readonly cabecalhos;
    private readonly conteudos;
    private readonly rodapes;
    private readonly temSecoes;
    protected readonly paddingValue: _angular_core.Signal<string>;
    protected readonly shadow: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SCardComponent, "s-card", never, { "padding": { "alias": "padding"; "required": false; "isSignal": true; }; "elevation": { "alias": "elevation"; "required": false; "isSignal": true; }; }, {}, ["cabecalhos", "conteudos", "rodapes"], ["[sCardHeader]", "[sCardContent]", "*", "[sCardFooter]"], true, never>;
}

/**
 * Cabecalho do `<s-card>`: uma linha com o titulo e o que mais vier — badge,
 * acoes. Com `sCardTitle` no titulo, o resto vai para a direita.
 *
 * @example
 * ```html
 * <s-card>
 *   <header sCardHeader>
 *     <h2 sCardTitle>Jornadas pendentes</h2>
 *     <s-badge tone="warning">3</s-badge>
 *   </header>
 *   <div sCardContent>Corpo do conteudo</div>
 *   <footer sCardFooter>Acoes</footer>
 * </s-card>
 * ```
 */
declare class SCardHeaderDirective {
    protected readonly papel: string | null;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SCardHeaderDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SCardHeaderDirective, "[sCardHeader]", never, {}, {}, never, never, true, never>;
}
/**
 * Titulo do card, dentro do `sCardHeader`.
 *
 * Use num titulo de verdade (`<h2>`, `<h3>`…), no nivel que a pagina pede: e o
 * que leva o card para a lista de titulos do leitor de tela. A diretiva tira a
 * margem do navegador e aplica a tipografia de titulo de card, entao o nivel
 * nao muda o tamanho.
 */
declare class SCardTitleDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SCardTitleDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SCardTitleDirective, "[sCardTitle]", never, {}, {}, never, never, true, never>;
}
/**
 * Corpo do `<s-card>`.
 *
 * Aplica o espacamento da escala do card. Se o card nao usa secoes, o conteudo
 * projetado direto (sem diretiva) continua funcionando como antes.
 */
declare class SCardContentDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SCardContentDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SCardContentDirective, "[sCardContent]", never, {}, {}, never, never, true, never>;
}
/**
 * Rodape (acoes) do `<s-card>`.
 *
 * As acoes ficam numa linha, alinhadas a direita, como no modal — a principal
 * por ultimo. Vem sempre por ultimo no card, mesmo que haja conteudo solto.
 */
declare class SCardFooterDirective {
    protected readonly papel: string | null;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SCardFooterDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SCardFooterDirective, "[sCardFooter]", never, {}, {}, never, never, true, never>;
}

/**
 * Tom do badge.
 *
 * Os cinco primeiros sao semanticos: fundo tintado em 12% do token e texto na
 * variante `on-surface`, que e a regra do guia para texto sobre superficie
 * tingida. `secondary` usa a cor neutra em forca total e `outline` nao tem
 * fundo — serve para rotular sem chamar atencao.
 *
 * O guia nomeia o tom informativo de `type`; aqui ele se chama `info`, igual ao
 * token que pinta (`--info`). E a unica divergencia de nome com a documentacao,
 * e existe porque `type` num componente Angular colide com o vocabulario de
 * atributo nativo.
 *
 * Por que `tone`, e nao `variant` como no botao: `variant` diz o **papel** de
 * uma acao (primaria, secundaria, destrutiva); `tone` diz a **cor** de um
 * rotulo. Os conjuntos nao sao os mesmos - `outline` e `default` nao existem
 * no botao, `ghost` e `link` nao fazem sentido num rotulo -, e e `tone` em todo
 * lugar que pinta um rotulo: `s-badge`, `s-stat-card` e a coluna `badge` da
 * tabela.
 */
type SBadgeTone = 'default' | 'success' | 'warning' | 'destructive' | 'info' | 'secondary' | 'outline';

/**
 * Rotulo curto de estado — "Ativo", "Pendente". Nao e clicavel.
 *
 * Nao usa o `mat-badge`, que e um contador sobreposto a outro elemento.
 */
declare class SBadgeComponent {
    /** Tom do badge. Ver `SBadgeTone`. */
    readonly tone: _angular_core.InputSignal<SBadgeTone>;
    /**
     * Permite que o rotulo quebre em varias linhas em area estreita. Padrao
     * `false`: uma linha so, 24px de altura. Ligado, os 24px viram altura minima
     * e o badge cresce com o texto.
     */
    readonly wrap: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Glifo a esquerda, sempre em 16px: com a altura de 24px (ou minima, em
     * `wrap`), glifo maior desalinharia o texto. Obrigatorio em `warning` e
     * `destructive`: avisa no console sem ele.
     */
    readonly icon: _angular_core.InputSignal<string>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SBadgeComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SBadgeComponent, "s-badge", never, { "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "wrap": { "alias": "wrap"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * Posicao do tooltip. O guia preve `top` e `bottom`; `left`/`right` servem a
 * menu lateral, e `auto` deixa o overlay escolher o lado que cabe.
 */
type STooltipPosition = 'top' | 'bottom' | 'left' | 'right' | 'auto';
/**
 * Dica curta no hover e no foco por teclado, sobre o `matTooltip`.
 *
 * E apoio, nunca instrucao obrigatoria. Use em elemento focavel (botao, link,
 * `s-button`, `s-icon-button`): fora deles a dica so existe para o mouse.
 * Enquanto ligada, o elemento mostra o cursor de mao (`s-tooltip-alvo`).
 *
 * @example
 * ```html
 * <s-icon-button
 *   icon="history"
 *   label="Histórico"
 *   sTooltip="Alteração aguardando aprovação da gerência regional."
 * />
 * ```
 */
declare class STooltipDirective {
    /** Texto exibido. Uma a duas linhas. */
    readonly text: _angular_core.InputSignal<string>;
    /** Posicao em relacao ao elemento. */
    readonly position: _angular_core.InputSignal<STooltipPosition>;
    /** Desliga o tooltip sem remover a diretiva do template. */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Atraso do hover em ms. O guia define a faixa 300–500. */
    readonly delay: _angular_core.InputSignalWithTransform<number, unknown>;
    private readonly tooltip;
    private readonly host;
    private readonly descritor;
    private readonly foco;
    /** O focavel de dentro do host que recebeu a descricao. Ver `ligarAoFocavelInterno`. */
    private descrito;
    private monitorando;
    constructor();
    /**
     * Quando o host e um componente - `<s-button sTooltip>`, `<s-icon-button
     * sTooltip>` -, quem recebe o foco e o `<button>` de dentro, e nao o host.
     * O `matTooltip` so olha o host: o `aria-describedby` ficava num elemento que
     * o leitor de tela nunca visita, e o foco por teclado no botao nao abria a
     * dica. Aqui as duas coisas sao levadas ao focavel interno.
     */
    private ligarAoFocavelInterno;
    private descrever;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<STooltipDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<STooltipDirective, "[sTooltip]", never, { "text": { "alias": "sTooltip"; "required": true; "isSignal": true; }; "position": { "alias": "sTooltipPosition"; "required": false; "isSignal": true; }; "disabled": { "alias": "sTooltipDisabled"; "required": false; "isSignal": true; }; "delay": { "alias": "sTooltipDelay"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.MatTooltip; inputs: {}; outputs: {}; }]>;
}

/**
 * Tipo para armazenar erros processados de validação.
 * Mapeia nome do campo para a mensagem de erro.
 *
 * @example
 * ```typescript
 * validatorErrors = signal<ValidatorErrors>({
 *   nome: 'Nome obrigatório',
 *   email: 'E-mail inválido'
 * });
 * ```
 */
type ValidatorErrors = Record<string, string>;
/**
 * Base dos controles de formulario da biblioteca.
 *
 * Reune o que todo controle repete: o valor, os dois estados de desabilitado
 * (o input do template e o do Reactive Forms) e os callbacks do
 * `ControlValueAccessor`.
 *
 * Nao tem relacao com o Angular Material — a regra de encapsular o Material por
 * composicao continua valendo; isto e apenas o denominador comum dos nossos
 * proprios controles, para que `s-input`, `s-select` e os demais se comportem
 * igual diante de um formulario.
 */
declare abstract class SControlBase<T> implements ControlValueAccessor {
    /**
     * Nome acessivel do controle quando ele esta **fora** de um `<s-field>` -
     * um filtro solto numa barra de ferramentas, por exemplo. Vira
     * `aria-label`. Dentro de um campo, o rotulo do campo prevalece.
     */
    readonly label: _angular_core.InputSignal<string>;
    /** Texto de exemplo. Nunca substitui o rotulo. */
    readonly placeholder: _angular_core.InputSignal<string>;
    /** Exibe o valor sem permitir edicao. Fundo neutro, sem moldura. Nao e `disabled`. */
    readonly readOnly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Marca o campo como invalido mesmo sem `<s-field error>`. */
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Erros processados de validacao, por nome de campo.
     *
     * @deprecated Sem efeito: nenhum controle le este input. A mensagem de erro e
     * do `<s-field>` (`error`, ou as mensagens do proprio controle do
     * formulario). Sai na proxima major.
     */
    readonly errors: _angular_core.InputSignal<ValidatorErrors>;
    /**
     * Desabilita o controle. Tambem pode vir do Reactive Forms.
     *
     * `booleanAttribute`, como nos demais booleanos: `disabled="false"` e falso.
     */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected readonly value: _angular_core.WritableSignal<T | null>;
    private readonly disabledByForm;
    /** `true` quando desabilitado pelo template ou pelo formulario. */
    protected readonly isDisabled: _angular_core.Signal<boolean>;
    protected onChange: (valor: T | null) => void;
    protected onTouched: () => void;
    /** Grava o valor e avisa o formulario. Use sempre que o usuario alterar algo. */
    protected setValue(valor: T | null): void;
    /**
     * Somente-leitura num controle que nao tem esse estado nativo - checkbox e
     * switch: o clique (mouse, ou Espaco, que tambem gera `click`) nao muda o
     * valor. O controle continua focavel e anunciado, com `aria-readonly`.
     */
    protected barrarSeSomenteLeitura(evento: Event): void;
    /**
     * Marca como tocado quando o foco **sai** de um grupo de opcoes.
     *
     * Para controles feitos de varios elementos focaveis (radios, botoes de
     * selecao). `(blur)` no elemento do grupo nao serve: o grupo nunca recebe o
     * foco - quem recebe sao as opcoes - e `blur` nao borbulha. `focusout`
     * borbulha, mas dispara tambem ao passar de uma opcao para a outra; por isso
     * a conferencia de para onde o foco foi.
     */
    protected onGroupFocusOut(evento: FocusEvent): void;
    writeValue(valor: T | null): void;
    registerOnChange(fn: (valor: T | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SControlBase<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SControlBase<any>, never, never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "readOnly": { "alias": "readOnly"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "errors": { "alias": "errors"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * Contrato que o `<s-field>` oferece aos controles projetados dentro dele.
 *
 * O campo e quem gera os ids; o controle apenas os consome. E assim que o
 * rotulo aponta para o controle certo e que a mensagem de erro chega ao leitor
 * de tela sem a aplicacao amarrar nada a mao.
 */
declare abstract class SFieldContext {
    /** Id que o controle deve assumir, para o `for` do rotulo apontar para ele. */
    abstract readonly controlId: () => string;
    /** Id da faixa de erro, ou `null` quando nao ha erro. */
    abstract readonly errorId: () => string | null;
    /** `true` quando o campo esta em erro. */
    abstract readonly hasError: () => boolean;
    /** `true` quando o campo foi marcado como obrigatorio. */
    abstract readonly isRequired: () => boolean;
    /**
     * Id do rotulo, ou `null` quando o campo nao tem rotulo.
     *
     * Controles nativos se ligam ao rotulo pelo `for`; os que nao sao um elemento
     * de formulario — o `mat-select`, por exemplo — precisam apontar para ele com
     * `aria-labelledby`.
     */
    abstract readonly labelId: () => string | null;
}

type SFieldError = string | readonly string[] | ValidationErrors | null;
/**
 * Envelope de qualquer controle de formulario.
 *
 * Reune o que o guia exige em volta de um campo: rotulo sempre visivel,
 * asterisco de obrigatoriedade, icone de ajuda e faixa de erro.
 *
 * A faixa de erro **existe mesmo quando vazia**. E o detalhe que faz a validacao
 * nao mudar a altura do formulario: sem ela, a tela inteira salta quando a
 * primeira mensagem aparece.
 *
 * O campo tambem cuida da amarracao acessivel. Ele gera o id, o rotulo aponta
 * para ele com `for`, e o controle projetado dentro o consome — junto com
 * `aria-invalid` e `aria-describedby` — sem a aplicacao ligar nada a mao.
 * A ajuda entra nessa descricao do controle, porque ela explica o criterio do
 * preenchimento sem virar parte do nome do campo.
 *
 * Prefixo e icone ficam no controle que desenha a superficie. O `<s-field>` nao
 * injeta conteudo dentro da moldura para nao quebrar textarea, select e outros
 * formatos; para busca e campos de linha unica, use `s-input icon="search"`.
 *
 * @example
 * ```html
 * <s-field label="Nome da Jornada de Trabalho" required [error]="erro()">
 *   <s-input placeholder="Buscar por nome" formControlName="nome" />
 * </s-field>
 * ```
 */
declare class SFieldComponent implements SFieldContext {
    /** Rotulo do campo. Sempre visivel, alinhado a esquerda, com altura minima fixa. */
    readonly label: _angular_core.InputSignal<string>;
    /** Marca o campo como obrigatorio. Opcional nao recebe marcacao nenhuma. */
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Texto do icone "i" de 16px — apoio nao essencial, uma a duas linhas. */
    readonly help: _angular_core.InputSignal<string>;
    /**
     * Exibe o contador `n/max` quando o controle tem limite de caracteres.
     *
     * O limite vem primeiro deste input, para os casos em que o controle esta fora
     * do conteudo projetado, e depois do `maxlength` do `input`/`textarea` nativo
     * dentro do campo. Assim o contador acompanha `formControlName`,
     * `[formControl]`, `[(ngModel)]` e tambem o uso avulso sem formulario.
     */
    readonly showCharCounter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Limite usado pelo contador quando nao ha como ler o `maxlength` do controle.
     *
     * Prefira manter o mesmo valor no controle (`<s-input maxlength="120">` ou
     * `<s-textarea maxlength="120">`), porque e o nativo que bloqueia a digitacao;
     * este input existe para composicoes em que o campo recebe o `control` por fora.
     */
    readonly maxlength: _angular_core.InputSignalWithTransform<number | null, unknown>;
    /**
     * Erro escrito pela tela. Vence a mensagem automatica.
     *
     * Aceita tres formas, e a escolha depende do que a tela ja tem em maos:
     *
     * - **texto** — `error="Informe a matrícula."`, para uma mensagem so;
     * - **lista** — `[error]="['Informe a matrícula.', 'Use 7 dígitos.']"`, para
     *   varias, uma por linha;
     * - **`ValidationErrors`** — `[error]="form.controls.nome.errors"`, e cada
     *   erro vira a frase mapeada em `provideSiageValidationMessages()`. E o
     *   caminho para quem ja calcula os erros fora do campo.
     *
     * A faixa continua reservada quando esta vazia — o formulario nao salta
     * quando a validacao dispara.
     */
    readonly error: _angular_core.InputSignal<SFieldError>;
    /**
     * Mensagens ja calculadas pela tela para o formulario inteiro, por nome de
     * campo — o `validatorErrors` do `FormBaseComponent`. O campo mostra a do
     * seu nome (`name`, ou o do `formControlName` projetado), uma linha por
     * `<br />`.
     *
     * Informado, a tela decide quando a mensagem aparece: a automatica fica
     * desligada, para nao acusar o erro antes da tela pedir.
     */
    readonly validationErrors: _angular_core.InputSignal<ValidatorErrors | null | undefined>;
    /** Chave deste campo em `validationErrors`. Sem ela, vale o nome do controle projetado. */
    readonly name: _angular_core.InputSignal<string>;
    /**
     * Controle de formulario deste campo.
     *
     * So e preciso informar quando o controle nao esta projetado aqui dentro —
     * um `<s-input formControlName="...">` se registra sozinho.
     */
    readonly control: _angular_core.InputSignal<AbstractControl<any, any, any> | null>;
    /**
     * Quando a mensagem automatica aparece.
     *
     * O padrao e `touched`, que e o momento em que o guia manda validar: acusar
     * "campo obrigatorio" antes de a pessoa chegar no campo e cobrar por algo
     * que ela ainda ia fazer.
     */
    readonly showErrorsWhen: _angular_core.InputSignal<"touched" | "dirty" | "always">;
    /** Id do controle. Informe apenas para reaproveitar um id que ja existe. */
    readonly controlIdInput: _angular_core.InputSignal<string>;
    private readonly idGerado;
    private readonly element;
    private readonly mensagens_;
    /**
     * O controle de formulario do campo projetado aqui dentro.
     *
     * A consulta de conteudo acha a diretiva `NgControl` — `formControlName`,
     * `formControl` ou `ngModel` — sem que o controle precise se registrar. O
     * caminho inverso (o controle pedir `NgControl` por injecao) fecharia um
     * ciclo, porque ele mesmo fornece o `NG_VALUE_ACCESSOR`.
     */
    private readonly ngControl;
    /** Muda a cada evento do controle, para as mensagens recalcularem. */
    private readonly versao;
    private readonly detectedMaxlength;
    private readonly controle;
    constructor();
    protected onProjectedInput(): void;
    /** As mensagens que vem dos validadores do proprio controle. */
    private readonly errosAutomaticos;
    /**
     * Quando a mensagem automatica mostra todos os erros do controle.
     *
     * O padrao e so o primeiro, que e o que o guia pede: uma frase por vez, a que
     * a pessoa precisa resolver agora. Ligue quando o campo tiver validadores
     * independentes — formato **e** intervalo —, e corrigir um de cada vez
     * significaria enviar o formulario tres vezes para descobrir os tres.
     */
    readonly showAllErrors: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** A mensagem deste campo em `validationErrors`, quebrada nas linhas. */
    private readonly mensagensDoMapa;
    /** As linhas da faixa. A da tela vence a automatica. */
    readonly mensagens: _angular_core.Signal<readonly string[]>;
    /** A primeira linha. Existe para o contrato do campo e para os testes. */
    readonly mensagem: _angular_core.Signal<string>;
    /** Normaliza as tres formas aceitas pelo input `error` em uma lista. */
    private readonly mensagensDaTela;
    readonly controlId: _angular_core.Signal<string>;
    readonly hasError: _angular_core.Signal<boolean>;
    readonly isRequired: _angular_core.Signal<boolean>;
    readonly errorMessageId: _angular_core.Signal<string | null>;
    readonly helpId: _angular_core.Signal<string | null>;
    readonly errorId: _angular_core.Signal<string | null>;
    readonly labelId: _angular_core.Signal<string | null>;
    protected readonly counterLimit: _angular_core.Signal<number | null>;
    protected readonly currentLength: _angular_core.Signal<number>;
    protected readonly showCounter: _angular_core.Signal<boolean>;
    protected readonly counterText: _angular_core.Signal<string>;
    protected readonly counterAriaLive: _angular_core.Signal<"polite" | null>;
    private updateDetectedMaxlength;
    private nativeControl;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SFieldComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SFieldComponent, "s-field", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "help": { "alias": "help"; "required": false; "isSignal": true; }; "showCharCounter": { "alias": "showCharCounter"; "required": false; "isSignal": true; }; "maxlength": { "alias": "maxlength"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "validationErrors": { "alias": "validationErrors"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "control": { "alias": "control"; "required": false; "isSignal": true; }; "showErrorsWhen": { "alias": "showErrorsWhen"; "required": false; "isSignal": true; }; "controlIdInput": { "alias": "controlId"; "required": false; "isSignal": true; }; "showAllErrors": { "alias": "showAllErrors"; "required": false; "isSignal": true; }; }, {}, ["ngControl"], ["*"], true, never>;
}

/**
 * Tipos de `<input>` que o design system preve.
 *
 * A lista e fechada porque cada tipo fora dela ja tem componente proprio: data
 * e `s-datepicker`, escolha em dominio fechado e `s-select`, e numero e
 * `s-input-number` — o `type="number"` nativo entrega texto, aceita `e` e
 * ponto em vez de virgula, e muda o valor com a roda do mouse.
 *
 * `time` e o horario do dia (entrada, saida, inicio de aula). Usa o `<input
 * type="time">` nativo: so aceita horario valido, digitado ou escolhido no
 * seletor do navegador, e o valor trafega como `"HH:mm"` (`"08:00"`), ou `""`
 * quando o campo esta incompleto. Um campo de texto aceitaria `"15:abc"`.
 */
type SInputType = 'text' | 'email' | 'tel' | 'password' | 'search' | 'url' | 'time';

/**
 * Campo de linha unica da biblioteca `@siage/siage-ui`.
 *
 * Tambem e o campo de busca do sistema: com `icon="search"` ele ganha o glifo de
 * 20px a esquerda que o guia descreve.
 *
 * Nao envolve o `matInput`, que so funciona dentro de um `mat-form-field` — e o
 * `mat-form-field` traz o rotulo flutuante dentro da moldura, que nao e o que o
 * guia define. Aqui o rotulo fica acima, no `<s-field>`, e o controle e um
 * `<input>` nativo com a superficie do design system.
 *
 * `readOnly` **nao** e `disabled`: o guia trata os dois como estados
 * diferentes. Somente-leitura mostra o dado em fundo neutro, sem moldura e sem
 * aparencia de bloqueado; desabilitado indica que a acao esta indisponivel.
 *
 * @example
 * ```html
 * <s-field label="Nome" required>
 *   <s-input icon="search" placeholder="Buscar por nome" formControlName="nome" />
 * </s-field>
 * ```
 */
declare class SInputComponent extends SControlBase<string> {
    /**
     * Tipo do campo. Ver `SInputType`.
     *
     * Com `type="time"` o campo so aceita horario (`"HH:mm"`); o `placeholder`
     * nao aparece, porque o navegador desenha a propria mascara (`--:--`).
     */
    readonly type: _angular_core.InputSignal<SInputType>;
    /** Glifo de 20px a esquerda, ex. `search`. */
    readonly icon: _angular_core.InputSignal<string>;
    /** Liga o eixo FILL do glifo. No guia so o item ativo da navegacao usa. */
    readonly iconFilled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Limite de caracteres, quando houver. Vazio remove o limite. */
    readonly maxlength: _angular_core.InputSignalWithTransform<number | null, unknown>;
    /** Valor de `autocomplete` do navegador. */
    readonly autocomplete: _angular_core.InputSignal<string>;
    private readonly campo;
    private readonly host;
    protected readonly controlId: _angular_core.Signal<string>;
    protected readonly ariaLabel: _angular_core.Signal<string | null>;
    protected readonly describedBy: _angular_core.Signal<string | null>;
    protected readonly required: _angular_core.Signal<boolean>;
    /** Invalido pelo input proprio ou pelo `<s-field>` que envolve o controle. */
    protected readonly isInvalid: _angular_core.Signal<boolean>;
    protected readonly texto: _angular_core.Signal<string>;
    protected readonly passwordVisible: _angular_core.WritableSignal<boolean>;
    /**
     * Senha sempre tem o botao de mostrar/ocultar, como o `p-password toggleMask`
     * que as telas ja usam; nos outros tipos nao ha o que revelar. Some em
     * `disabled` (e o `readOnly` nem desenha o campo), porque ali ofereceria uma
     * acao que nao existe.
     */
    protected readonly showReveal: _angular_core.Signal<boolean>;
    protected readonly nativeType: _angular_core.Signal<SInputType>;
    protected readonly revealIcon: _angular_core.Signal<"visibility_off" | "visibility">;
    protected readonly revealLabel: _angular_core.Signal<"Ocultar senha" | "Mostrar senha">;
    constructor();
    protected onInput(event: Event): void;
    protected onBlur(): void;
    protected toggleReveal(): void;
    private updateAriaPressed;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SInputComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SInputComponent, "s-input", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "iconFilled": { "alias": "iconFilled"; "required": false; "isSignal": true; }; "maxlength": { "alias": "maxlength"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Campo numerico da biblioteca `@siage/siage-ui`.
 *
 * O valor entregue ao formulario e sempre `number | null`: vazio vira `null`, e
 * nunca a string que o `<input type="number">` nativo devolveria. A digitacao
 * fica em `type="text"` com `inputmode`, porque o formato pt-BR (`1.234,56`)
 * nao e aceito pelo controle numerico nativo dos navegadores.
 *
 * A mascara e aplicada durante a digitacao: o milhar entra conforme os digitos
 * chegam, a virgula (ou o ponto do teclado numerico) abre as casas decimais e o
 * cursor fica onde estava. O `blur` so completa as casas minimas. A colagem de
 * valores como `1.234,56` ou `1234.56` leva `1234.56` ao formulario.
 *
 * `min` e `max` validam, mas nao fazem clamp: corrigir silenciosamente no blur
 * esconderia que a tela recebeu um valor fora da regra. O erro gerado segue o
 * mesmo formato de `Validators.min`/`Validators.max`, entao o `<s-field>` usa a
 * mensagem padrao da biblioteca.
 *
 * `prefix` e `suffix` cobrem moeda e percentual sem acoplar o componente a uma
 * lista de moedas. Ficam fora do `<input>`, fixos na moldura: nao da para
 * selecionar nem apagar, e o texto editado e so o numero. Se a aplicacao precisar de regras fiscais de moeda, elas
 * continuam no dominio da tela.
 *
 * @example
 * ```html
 * <s-field label="Valor" [error]="form.controls.value.errors">
 *   <s-input-number formControlName="value" prefix="R$" useGrouping [minFractionDigits]="2" [maxFractionDigits]="2" />
 * </s-field>
 * ```
 */
declare class SInputNumberComponent extends SControlBase<number> implements Validator {
    /**
     * Desenha separador de milhar ao formatar.
     *
     * Desligado por padrao: a maior parte dos numeros das telas e codigo, ano,
     * carga horaria ou quantidade pequena, em que `2.026` le como erro. Ligue em
     * valores monetarios e contagens grandes. Colar `1.234,56` funciona nos dois
     * casos.
     */
    readonly useGrouping: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Casas minimas exibidas no blur. Use `2` para decimal monetario. */
    readonly minFractionDigits: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Casas maximas aceitas e exibidas. `0` mantem o campo inteiro. */
    readonly maxFractionDigits: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Menor valor aceito; gera erro `min` em vez de alterar o valor digitado. */
    readonly min: _angular_core.InputSignalWithTransform<number | null, unknown>;
    /** Maior valor aceito; gera erro `max` em vez de alterar o valor digitado. */
    readonly max: _angular_core.InputSignalWithTransform<number | null, unknown>;
    /** Incremento usado por ArrowUp/ArrowDown. */
    readonly step: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Texto fixo antes do numero, como `R$`. Nao participa do valor do formulario. */
    readonly prefix: _angular_core.InputSignal<string>;
    /** Texto fixo depois do numero, como `%`. Nao participa do valor do formulario. */
    readonly suffix: _angular_core.InputSignal<string>;
    /**
     * Mantem na tela os zeros a esquerda digitados: `0001` continua `0001` no
     * blur e nas setas.
     *
     * O formulario continua recebendo `number` (`1`), porque numero nao carrega
     * zero a esquerda. Quando o zero faz parte do dado (matricula, codigo INEP),
     * use `<s-input sOnlyDigits>`, que entrega a string. Com `useGrouping`, o
     * separador de milhar tambem entra entre os zeros (`0.001`).
     */
    readonly keepLeadingZeros: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private readonly fieldBinding;
    private readonly editableText;
    private readonly editing;
    private readonly leadingDigits;
    private onValidatorChange;
    protected readonly inputId: _angular_core.Signal<string>;
    protected readonly ariaLabel: _angular_core.Signal<string | null>;
    protected readonly prefixText: _angular_core.Signal<string>;
    protected readonly suffixText: _angular_core.Signal<string>;
    protected readonly prefixId: _angular_core.Signal<string>;
    protected readonly suffixId: _angular_core.Signal<string>;
    protected readonly describedBy: _angular_core.Signal<string | null>;
    protected readonly required: _angular_core.Signal<boolean>;
    protected readonly isInvalid: _angular_core.Signal<boolean>;
    protected readonly inputMode: _angular_core.Signal<"decimal" | "numeric">;
    protected readonly displayText: _angular_core.Signal<string>;
    protected readonly readOnlyText: _angular_core.Signal<string>;
    /** Formato do texto editavel: so o numero, sem prefixo e sufixo. */
    private readonly formatOptions;
    constructor();
    writeValue(value: number | null): void;
    validate(control: AbstractControl<number | null>): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
    protected onBeforeInput(event: InputEvent): void;
    protected onInput(event: Event): void;
    /** Clicar no prefixo ou no sufixo leva o foco ao campo, sem selecionar o texto fixo. */
    protected focusNative(event: MouseEvent, inputElement: HTMLInputElement): void;
    protected onBlur(): void;
    protected onFocus(): void;
    protected onKeyDown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SInputNumberComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SInputNumberComponent, "s-input-number", never, { "useGrouping": { "alias": "useGrouping"; "required": false; "isSignal": true; }; "minFractionDigits": { "alias": "minFractionDigits"; "required": false; "isSignal": true; }; "maxFractionDigits": { "alias": "maxFractionDigits"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "prefix": { "alias": "prefix"; "required": false; "isSignal": true; }; "suffix": { "alias": "suffix"; "required": false; "isSignal": true; }; "keepLeadingZeros": { "alias": "keepLeadingZeros"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Configuracao pura de leitura e escrita do numero no padrao pt-BR. */
interface SInputNumberFormatOptions {
    readonly useGrouping: boolean;
    readonly minFractionDigits: number;
    readonly maxFractionDigits: number;
    readonly prefix?: string;
    readonly suffix?: string;
    /** Total minimo de digitos inteiros, completado com zeros a esquerda. */
    readonly minIntegerDigits?: number;
}
/** Resultado do parse: `null` e vazio valido; `invalid` preserva o texto digitado. */
interface SInputNumberParseResult {
    readonly value: number | null;
    readonly invalid: boolean;
}
/** Aceita digitacao e colagem em pt-BR, incluindo `1.234,56`. */
declare function parsePtBrNumber(text: string, options: SInputNumberFormatOptions): SInputNumberParseResult;
/** Formata `number | null` para exibicao; vazio continua vazio. */
declare function formatPtBrNumber(value: number | null, options: SInputNumberFormatOptions): string;
/** Texto mascarado durante a digitacao, com o cursor ja reposicionado. */
interface SInputNumberMaskResult {
    readonly text: string;
    readonly caret: number;
    readonly value: number | null;
    /** Digitos inteiros quando o texto comeca com zero; `0` quando nao ha zero a preservar. */
    readonly leadingDigits: number;
}
/**
 * Aplica a mascara pt-BR enquanto a pessoa digita.
 *
 * Fica so com sinal, digitos e a primeira virgula; descarta o resto, agrupa o
 * milhar e corta as casas que passam de `maxFractionDigits`. Nao completa casas
 * minimas: isso fica para o blur, senao `1` viraria `1,00` no primeiro toque.
 *
 * No campo inteiro (`maxFractionDigits` 0) a virgula tambem marca o fim da parte
 * inteira: o que vem depois dela e casa decimal, e sai inteiro. `1234,56` vira
 * `1234`, e nao `123456`.
 *
 * O cursor e contado pelos digitos, e nao pela posicao: na parte inteira, pelos
 * digitos a direita (o ponto de milhar entra a esquerda); na decimal, pelos
 * digitos a esquerda da virgula.
 */
declare function maskPtBrNumber(rawText: string, rawCaret: number, options: SInputNumberFormatOptions, keepLeadingZeros?: boolean): SInputNumberMaskResult;
/**
 * Quantos digitos inteiros o texto tem, contando zeros a esquerda. Devolve `0`
 * quando o texto nao comeca com zero seguido de digito: sem zero a esquerda nao
 * ha o que preservar.
 */
declare function integerDigitCount(text: string, options: SInputNumberFormatOptions): number;
/** Erro compatível com `Validators.min`/`Validators.max`. */
declare function validateMinMax(value: number | null, min: number | null, max: number | null): ValidationErrors | null;

/** Presets conhecidos pela diretiva `sMask`. */
type SMaskPreset = 'cpf' | 'cnpj' | 'cep' | 'phone';
/** Valor gravado no formulario: sem literais da mascara ou como aparece na tela. */
type SMaskValue = 'raw' | 'formatted';
/** Resultado da formatacao pura, usado pela diretiva e pelos testes. */
interface SMaskResult {
    formatted: string;
    raw: string;
    complete: boolean;
}

/**
 * Mascara de digitacao para `<s-input>` e `<input>` nativo.
 *
 * O valor padrao do formulario e `raw`: nos presets de documento ele fica so
 * com digitos, sem ponto, barra ou hifen. Essa escolha evita que cada tela
 * limpe o valor antes de chamar a API. Em mascara livre, `raw` preserva os
 * caracteres que preencheram `0`, `A` e `*`. Quando a API legada espera a
 * mascara pronta, use `maskValue="formatted"`.
 *
 * A mascara nao substitui validacao de dominio. `sMaskValidate` so adiciona o
 * erro `sMaskIncomplete` quando o texto ainda nao preencheu todos os tokens.
 */
declare class SMaskDirective implements AfterViewInit, OnDestroy, Validator {
    /** Preset (`cpf`, `cnpj`, `cep`, `phone`) ou mascara livre com `0`, `A` e `*`. */
    readonly mask: _angular_core.InputSignal<string>;
    /** Define se o formulario recebe o valor sem literais ou o texto formatado. */
    readonly maskValue: _angular_core.InputSignal<SMaskValue>;
    /** Liga o erro `sMaskIncomplete` enquanto a mascara estiver incompleta. */
    readonly maskValidate: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private readonly host;
    private readonly injector;
    private readonly siageInput;
    private ngControl;
    private subscription;
    private applying;
    private onValidatorChange;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    validate(control: AbstractControl<string | null>): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
    onInput(event: Event): void;
    onBlur(): void;
    private nativeInput;
    private formatCurrentView;
    /**
     * Formata o valor que veio do formulario, e nao o texto da tela.
     *
     * No `<s-input>` zoneless o texto so chega ao DOM na proxima change
     * detection: ler a tela aqui pegava o valor antigo e o devolvia ao campo,
     * apagando o que o `setValue` acabou de gravar.
     */
    private formatModelValue;
    private formatElement;
    private setControlValue;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SMaskDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SMaskDirective, "s-input[sMask], input[sMask]", never, { "mask": { "alias": "sMask"; "required": false; "isSignal": true; }; "maskValue": { "alias": "maskValue"; "required": false; "isSignal": true; }; "maskValidate": { "alias": "sMaskValidate"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Restringe o campo a digitos, inclusive em colagem.
 *
 * Serve para substituir `pKeyFilter="int"` quando nao ha mascara visual. O
 * formulario recebe sempre a string de digitos, porque zeros a esquerda podem
 * ser significativos em matricula, codigo e documento.
 */
declare class SOnlyDigitsDirective implements AfterViewInit {
    /** Permite desligar a diretiva por binding mantendo o template estruturalmente igual. */
    readonly onlyDigits: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private readonly host;
    private readonly injector;
    private readonly siageInput;
    private ngControl;
    ngAfterViewInit(): void;
    onBeforeInput(event: Event): void;
    onInput(event: Event): void;
    onBlur(): void;
    formatCurrentValue(): void;
    private sincronizar;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SOnlyDigitsDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SOnlyDigitsDirective, "s-input[sOnlyDigits], input[sOnlyDigits]", never, { "onlyDigits": { "alias": "sOnlyDigits"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Formata um texto conforme uma mascara livre: `0`, `A`, `*` e literais. */
declare function formatPattern(value: string, pattern: string): SMaskResult;
/** Formata telefone brasileiro, alternando fixo e celular pelo total de digitos. */
declare function formatPhone(value: string): SMaskResult;
/** Formata pelos presets conhecidos ou por uma mascara livre. */
declare function formatMask(value: string, mask: SMaskPreset | string): SMaskResult;
/** Conta caracteres que preenchem tokens antes do cursor atual. */
declare function rawCountBeforeCursor(value: string, cursor: number, mask: SMaskPreset | string): number;
/** Indice logo depois do `n`-esimo caractere util do texto formatado. */
declare function positionAfterRaw(formatted: string, rawCount: number): number;

/** Regra exibida pelo `s-password-requirements`. */
interface SPasswordRule {
    /** Texto que a pessoa entende como requisito de senha. */
    label: string;
    /** Retorna `true` quando o valor atual ja atende ao requisito. */
    test: (value: string) => boolean;
}
/**
 * Regras padrao usadas nas telas de troca de senha do SIAGE.
 *
 * Ficam exportadas para a aplicacao reutilizar a mesma politica no validador do
 * formulario. A lista visual nao substitui validacao no envio; ela so antecipa
 * o que ainda falta antes de a pessoa tentar salvar.
 */
declare const S_PASSWORD_RULES: readonly SPasswordRule[];

/**
 * Lista acessivel de requisitos de senha.
 *
 * O componente recebe o `value` do campo de senha e avalia cada regra. Ele nao
 * faz HTTP nem decide a politica da aplicacao: quando a tela precisa de outra
 * regra, passa `rules` e reutiliza a mesma lista no validador do formulario.
 *
 * A regiao `aria-live="polite"` anuncia apenas o resumo (quantos requisitos
 * foram atendidos), nao cada item a cada tecla. Assim a pessoa que usa leitor
 * de tela recebe progresso suficiente sem ouvir quatro frases repetidas durante
 * a digitacao.
 */
declare class SPasswordRequirementsComponent {
    /** Valor atual da senha. `null` e tratado como vazio para simplificar formularios. */
    readonly value: _angular_core.InputSignal<string | null>;
    /**
     * Requisitos avaliados na ordem exibida.
     *
     * O padrao cobre a politica mais comum do SIAGE, mas fica configuravel porque
     * senha e regra de seguranca da aplicacao, nao do componente visual.
     */
    readonly rules: _angular_core.InputSignal<readonly SPasswordRule[]>;
    protected readonly currentValue: _angular_core.Signal<string>;
    protected readonly items: _angular_core.Signal<{
        valid: boolean;
        label: string;
        test: (value: string) => boolean;
    }[]>;
    protected readonly validCount: _angular_core.Signal<number>;
    protected readonly summary: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SPasswordRequirementsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SPasswordRequirementsComponent, "s-password-requirements", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "rules": { "alias": "rules"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Campo de texto longo da biblioteca `@siage/siage-ui`.
 *
 * 80px de altura, com redimensionamento apenas vertical.
 *
 * Na ordem do formulario, campos descritivos longos vem **depois** dos de alto
 * impacto — data, turma, periodo. Quem preenche decide se continua com base nos
 * campos que definem o registro, nao no texto livre.
 */
declare class STextareaComponent extends SControlBase<string> {
    /**
     * Limite de caracteres do texto livre.
     *
     * O limite fica no `textarea` nativo para o navegador impedir excesso antes
     * da validacao, e o `<s-field showCharCounter>` le esse mesmo `maxlength`
     * para exibir `n/max` sem duplicar configuracao de formulario.
     */
    readonly maxlength: _angular_core.InputSignal<number | null>;
    private readonly campo;
    protected readonly controlId: _angular_core.Signal<string>;
    protected readonly ariaLabel: _angular_core.Signal<string | null>;
    protected readonly describedBy: _angular_core.Signal<string | null>;
    protected readonly required: _angular_core.Signal<boolean>;
    protected readonly isInvalid: _angular_core.Signal<boolean>;
    protected readonly texto: _angular_core.Signal<string>;
    protected onInput(event: Event): void;
    protected onBlur(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<STextareaComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<STextareaComponent, "s-textarea", never, { "maxlength": { "alias": "maxlength"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Escolha em dominio fechado, com a anatomia do input e chevron de 20px.
 *
 * Encapsula (por composicao) o `mat-select` - **sem** `mat-form-field`. O
 * `mat-select` injeta o campo do Material como opcional, entao da para ficar
 * so com o que ele tem de melhor (o painel em overlay, a navegacao por teclado,
 * a semantica de combobox) e desenhar a superficie com a regra do guia, em vez
 * de brigar com o rotulo flutuante do `mat-form-field`.
 *
 * Nunca use um campo de texto generico no lugar de uma escolha. Em card de
 * filtros, a opcao padrao e sempre "Todos".
 *
 * Opcoes com desenho proprio: `<ng-template sOption let-opcao>` dentro do
 * componente. Ver `SOptionTemplateDirective`.
 *
 * @example
 * ```html
 * <s-field label="Status">
 *   <s-select [options]="status" formControlName="status" placeholder="Todos" />
 * </s-field>
 * ```
 */
declare class SSelectComponent<T = unknown> extends SControlBase<T> {
    /** Opcoes exibidas no painel. */
    readonly options: _angular_core.InputSignal<readonly SOption<T>[]>;
    /**
     * Compara valor selecionado com o valor da opcao.
     *
     * O padrao e igualdade estrita, que basta para id e string. Informe uma
     * funcao quando o valor for um objeto vindo de duas respostas diferentes da
     * API - sem isso, dois objetos iguais nao se reconhecem.
     */
    readonly compareWith: _angular_core.InputSignal<(a: T, b: T) => boolean>;
    /**
     * Mostra o botao de limpar quando ha valor.
     *
     * Sem ele, depois de escolher uma opcao nao ha como voltar ao "nada
     * escolhido" - so trocando por outra. Desligue quando o campo e obrigatorio
     * e o vazio nao e um estado valido.
     */
    readonly clearable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Campo de busca no topo do painel.
     *
     * Ligue a partir de umas dez opcoes: rolar uma lista de 27 UFs e mais lento
     * que digitar "pa". O filtro ignora acento e caixa.
     */
    readonly filterable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Texto de exemplo do campo de busca. */
    readonly filterPlaceholder: _angular_core.InputSignal<string>;
    /** Texto exibido quando a busca nao acha nenhuma opcao. */
    readonly noResultsText: _angular_core.InputSignal<string>;
    /** Texto exibido quando nao ha nenhuma opcao para listar. */
    readonly emptyText: _angular_core.InputSignal<string>;
    private readonly campo;
    private readonly busca;
    private readonly seletor;
    /** Desenho proprio da opcao, quando a aplicacao projeta um. */
    protected readonly opcaoTemplate: _angular_core.Signal<SOptionTemplateDirective<any> | undefined>;
    protected readonly controlId: _angular_core.Signal<string>;
    protected readonly ariaLabel: _angular_core.Signal<string | null>;
    protected readonly describedBy: _angular_core.Signal<string | null>;
    protected readonly labelledBy: _angular_core.Signal<string | null>;
    protected readonly required: _angular_core.Signal<boolean>;
    protected readonly isInvalid: _angular_core.Signal<boolean>;
    /**
     * O `mat-select` escreve o proprio `aria-invalid` a partir do `errorState`,
     * que ele so recalcula quando tem um `NgControl` - aqui quem e controle de
     * formulario e este componente, entao ele ficava em `false` e vencia o
     * atributo da lib. O erro passa a ser entregue a ele.
     */
    private readonly sincronizaErro;
    protected readonly termo: _angular_core.WritableSignal<string>;
    /** Opcoes que batem com a busca. As demais so ficam ocultas - ver o template. */
    protected readonly visiveis: _angular_core.Signal<Set<SOption<T>>>;
    protected readonly semResultado: _angular_core.Signal<boolean>;
    protected readonly listaVazia: _angular_core.Signal<boolean>;
    /** Valor da opcao sentinela: nunca e igual a nada que a aplicacao use. */
    protected readonly sentinela: T;
    protected readonly temValor: _angular_core.Signal<boolean>;
    /** Com valor, o "x" toma o lugar do chevron: os dois lado a lado competem. */
    protected readonly mostraLimpar: _angular_core.Signal<boolean>;
    /** Rotulo da opcao selecionada, usado no modo somente-leitura. */
    protected readonly textoSelecionado: _angular_core.Signal<string>;
    protected selecionada(opcao: SOption<T>): boolean;
    protected onSelectionChange(event: MatSelectChange<T>): void;
    protected limpar(evento: Event): void;
    protected onOpenedChange(aberto: boolean): void;
    protected onBusca(evento: Event): void;
    /**
     * Passar pelo campo com Tab, sem abrir, tambem o marca como tocado - senao o
     * erro do `<s-field>` nunca aparecia para quem pula um obrigatorio. Com o
     * painel aberto o foco vai para a busca; ali quem marca e o fechamento.
     */
    protected aoSairDoCampo(): void;
    /** Texto fica na busca; setas e Enter navegam no painel. Ver `teclaNaBusca`. */
    protected onBuscaKeydown(evento: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SSelectComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SSelectComponent<any>, "s-select", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "compareWith": { "alias": "compareWith"; "required": false; "isSignal": true; }; "clearable": { "alias": "clearable"; "required": false; "isSignal": true; }; "filterable": { "alias": "filterable"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "noResultsText": { "alias": "noResultsText"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; }, {}, ["opcaoTemplate"], never, true, never>;
}

/**
 * Escolha multipla em dominio fechado.
 *
 * Mesma anatomia do `<s-select>` - na verdade o mesmo `mat-select`, em modo
 * `multiple`, que ja desenha a caixa de selecao ao lado de cada opcao.
 *
 * **Nao esta no guia de design.** Entrou na biblioteca porque o Professores
 * usa selecao multipla em 14 lugares e o alternativo seria cada tela resolver
 * do seu jeito. Por isso segue a anatomia do campo a risca: quem olhar a tela
 * nao deve distinguir um `<s-select>` de um `<s-multiselect>` fechado.
 *
 * Ate `maxLabels` selecoes o gatilho lista os rotulos; acima disso passa a
 * mostrar a contagem, para o campo nao crescer nem truncar no meio de um nome.
 * No painel, rotulo longo quebra linha em vez de ser cortado.
 *
 * Em somente-leitura **todas** as selecoes aparecem, uma etiqueta por opcao,
 * quebrando linha: quem so le nao tem como abrir o painel para ver o resto.
 *
 * Opcoes com desenho proprio: `<ng-template sOption let-opcao>` dentro do
 * componente. Ver `SOptionTemplateDirective`.
 *
 * ## De onde vem a lista
 *
 * Como no multiselect do Professores e do Educacional, quem decide e o `url`:
 *
 * - **sem `url`**, a lista e `options`, e a busca (`filterable`) filtra por ela;
 * - **com `url`**, a busca aparece sempre, abrir o painel ja consulta e cada
 *   digitacao consulta de novo a `SAutocompleteSource` da aplicacao - a mesma
 *   fonte do `<s-autocomplete>`. A biblioteca nao faz HTTP.
 *
 * Com `url`, o que ja esta marcado continua marcado mesmo quando a busca atual
 * nao traz aquele item: ele sai da vista, nao do valor.
 */
declare class SMultiselectComponent<T = unknown> extends SControlBase<T[]> {
    /** Opcoes exibidas no painel. Com `url`, quem fornece a lista e a fonte. */
    readonly options: _angular_core.InputSignal<readonly (object | SOption<T>)[]>;
    /**
     * Chave do rotulo quando `options` (ou a fonte) traz objetos de dominio.
     * Informada, cada **objeto inteiro** entra no array do formulario. Ver o
     * `<s-autocomplete>`.
     */
    readonly optionLabel: _angular_core.InputSignal<string>;
    /** Chave que identifica o objeto (`id`). Vence `compareWith`. */
    readonly dataKey: _angular_core.InputSignal<string>;
    /** Nome do parametro do termo na busca por `url`. Vai para a fonte. */
    readonly searchFor: _angular_core.InputSignal<string>;
    /** Recurso onde `url` mora. Vai para a fonte. */
    readonly controller: _angular_core.InputSignal<string>;
    /**
     * Recurso a consultar, no lugar de `options`.
     *
     * Informado, o componente pede as opcoes a `SAutocompleteSource` que a
     * aplicacao registrou - ao abrir o painel e a cada digitacao na busca. Sem
     * `url`, a lista e `options` e a busca filtra localmente.
     */
    readonly url: _angular_core.InputSignal<string>;
    /** Filtros adicionais enviados junto da busca. So tem efeito com `url`. */
    readonly params: _angular_core.InputSignal<Record<string, unknown>>;
    /** Caracteres minimos antes de consultar. `0` consulta ja ao abrir. So com `url`. */
    readonly minLength: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Espera entre a digitacao e a consulta, em ms. So tem efeito com `url`. */
    readonly debounceTime: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Com `url`, consulta a fonte sem termo ao abrir o painel e filtra a lista no
     * navegador a cada digitacao. Para listas curtas — componentes, turmas —, em
     * que uma consulta por letra so custa viagens.
     */
    readonly loadOnce: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Texto exibido no painel enquanto a consulta por `url` corre. */
    readonly loadingText: _angular_core.InputSignal<string>;
    /** Quantos rotulos cabem no gatilho antes de virar contagem. */
    readonly maxLabels: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Substantivo usado na contagem, no plural. */
    readonly itemsLabel: _angular_core.InputSignal<string>;
    /** Compara valor selecionado com o valor da opcao. Ver `<s-select>`. */
    readonly compareWith: _angular_core.InputSignal<(a: T, b: T) => boolean>;
    /**
     * Campo de busca no topo do painel. Ignora acento e caixa.
     *
     * Ligado por padrao, como no multiselect do PrimeNG; desligue com
     * `[filterable]="false"` numa lista curta, em que a busca so ocupa espaco.
     * Com busca ativa, a caixa de marcar todas vale so para as opcoes
     * encontradas - e o que permite "marcar todas as turmas do 9º ano". Com `url`
     * a busca aparece sempre: e ela que consulta a fonte.
     */
    readonly filterable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Texto de exemplo do campo de busca. */
    readonly filterPlaceholder: _angular_core.InputSignal<string>;
    /** Texto exibido quando a busca nao acha nenhuma opcao. */
    readonly noResultsText: _angular_core.InputSignal<string>;
    /** Texto exibido quando nao ha nenhuma opcao para listar. */
    readonly emptyText: _angular_core.InputSignal<string>;
    /**
     * Caixa de "marcar todas" no topo do painel, ao lado da busca.
     *
     * Marca o que esta visivel; com tudo marcado, desmarca. Opcao desabilitada
     * nao muda de estado por ela: se veio marcada, continua.
     */
    readonly selectAll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Mostra o botao de limpar quando ha selecao, como no `<s-select>`.
     *
     * Desmarcar uma a uma, numa lista de vinte, e o que este botao poupa.
     * Desligue quando o campo e obrigatorio e o vazio nao e um estado valido.
     */
    readonly clearable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Nome acessivel da caixa quando ela vai marcar todas. */
    readonly selectAllLabel: _angular_core.InputSignal<string>;
    /** Nome acessivel da caixa quando ela vai desmarcar todas. */
    readonly clearAllLabel: _angular_core.InputSignal<string>;
    private readonly campo;
    private readonly fonte;
    /** Opcoes que a fonte devolveu na ultima consulta. */
    private readonly buscadas;
    protected readonly buscando: _angular_core.WritableSignal<boolean>;
    /**
     * Opcoes ja vistas que estao marcadas. Com `url`, e daqui que saem o rotulo e
     * a `mat-option` de um item marcado que a busca atual nao trouxe.
     */
    private readonly conhecidas;
    /** Valor da opcao sentinela: nunca e igual a nada que a aplicacao use. */
    protected readonly sentinela: T;
    private readonly consultas;
    /** `loadOnce`: a lista inteira, da primeira consulta. */
    private carregadas;
    private filtrarCarregadas;
    private readonly aResolver;
    private readonly busca;
    private readonly seletor;
    /** Desenho proprio da opcao, quando a aplicacao projeta um. */
    protected readonly opcaoTemplate: _angular_core.Signal<SOptionTemplateDirective<any> | undefined>;
    protected readonly controlId: _angular_core.Signal<string>;
    protected readonly ariaLabel: _angular_core.Signal<string | null>;
    protected readonly describedBy: _angular_core.Signal<string | null>;
    protected readonly labelledBy: _angular_core.Signal<string | null>;
    protected readonly required: _angular_core.Signal<boolean>;
    protected readonly isInvalid: _angular_core.Signal<boolean>;
    /**
     * O `mat-select` escreve o proprio `aria-invalid` a partir do `errorState`,
     * que ele so recalcula quando tem um `NgControl` - aqui quem e controle de
     * formulario e este componente, entao ele ficava em `false` e vencia o
     * atributo da lib. O erro passa a ser entregue a ele.
     */
    private readonly sincronizaErro;
    protected readonly selecionados: _angular_core.Signal<T[]>;
    /** `options` no formato do painel. */
    private readonly opcoesBase;
    /** `dataKey` vence `compareWith`. */
    protected readonly comparar: _angular_core.Signal<(a: T, b: T) => boolean>;
    /** Com selecao, o "x" toma o lugar do chevron. */
    protected readonly mostraLimpar: _angular_core.Signal<boolean>;
    protected readonly termo: _angular_core.WritableSignal<string>;
    protected readonly comUrl: _angular_core.Signal<boolean>;
    protected readonly mostraBusca: _angular_core.Signal<boolean>;
    /**
     * Tudo o que vira `mat-option`. Com `url`: o que a busca trouxe mais o que ja
     * esta marcado e ela nao trouxe - sem a opcao, o `mat-select` descartaria
     * esse valor no proximo clique.
     */
    protected readonly opcoes: _angular_core.Signal<readonly SOption<T>[]>;
    protected readonly visiveis: _angular_core.Signal<Set<SOption<T>>>;
    protected readonly semResultado: _angular_core.Signal<boolean>;
    protected readonly listaVazia: _angular_core.Signal<boolean>;
    /** Opcoes que as acoes em massa alcancam: visiveis e habilitadas. */
    private readonly alcancaveis;
    protected readonly todasMarcadas: _angular_core.Signal<boolean>;
    protected readonly nenhumaMarcada: _angular_core.Signal<boolean>;
    protected readonly temAlcancaveis: _angular_core.Signal<boolean>;
    /** Estado da caixa do cabecalho: todas, nenhuma ou algumas das visiveis. */
    protected readonly estadoTodas: _angular_core.Signal<MatPseudoCheckboxState>;
    /** Rotulos das opcoes selecionadas, na ordem das opcoes. */
    protected readonly rotulos: _angular_core.Signal<string[]>;
    constructor();
    writeValue(valor: T[] | null): void;
    /** Texto do gatilho: os rotulos ate `maxLabels`, e a contagem acima disso. */
    protected readonly resumo: _angular_core.Signal<string>;
    protected selecionada(opcao: SOption<T>): boolean;
    protected onSelectionChange(event: MatSelectChange<T[]>): void;
    protected marcarTodas(): void;
    /** Grava a selecao e guarda as opcoes marcadas, para o rotulo sobreviver a busca. */
    private marcar;
    private lembrar;
    private exigirFonte;
    protected alternarTodas(): void;
    protected fechar(): void;
    /** Esvazia a selecao inteira - inclusive o que a busca atual nao trouxe. */
    protected limpar(evento: Event): void;
    protected desmarcarTodas(): void;
    protected onOpenedChange(aberto: boolean): void;
    protected onBusca(evento: Event): void;
    /** Ver `<s-select>`: Tab pelo campo fechado tambem marca como tocado. */
    protected aoSairDoCampo(): void;
    /** Texto fica na busca; setas e Enter navegam no painel. Ver `teclaNaBusca`. */
    protected onBuscaKeydown(evento: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SMultiselectComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SMultiselectComponent<any>, "s-multiselect", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "searchFor": { "alias": "searchFor"; "required": false; "isSignal": true; }; "controller": { "alias": "controller"; "required": false; "isSignal": true; }; "url": { "alias": "url"; "required": false; "isSignal": true; }; "params": { "alias": "params"; "required": false; "isSignal": true; }; "minLength": { "alias": "minLength"; "required": false; "isSignal": true; }; "debounceTime": { "alias": "debounceTime"; "required": false; "isSignal": true; }; "loadOnce": { "alias": "loadOnce"; "required": false; "isSignal": true; }; "loadingText": { "alias": "loadingText"; "required": false; "isSignal": true; }; "maxLabels": { "alias": "maxLabels"; "required": false; "isSignal": true; }; "itemsLabel": { "alias": "itemsLabel"; "required": false; "isSignal": true; }; "compareWith": { "alias": "compareWith"; "required": false; "isSignal": true; }; "filterable": { "alias": "filterable"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "noResultsText": { "alias": "noResultsText"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; "selectAll": { "alias": "selectAll"; "required": false; "isSignal": true; }; "clearable": { "alias": "clearable"; "required": false; "isSignal": true; }; "selectAllLabel": { "alias": "selectAllLabel"; "required": false; "isSignal": true; }; "clearAllLabel": { "alias": "clearAllLabel"; "required": false; "isSignal": true; }; }, {}, ["opcaoTemplate"], never, true, never>;
}

/**
 * Caixa de selecao da biblioteca `@siage/siage-ui`.
 *
 * Caixa de 20px com rotulo a direita, dentro de formularios **que sao salvos**.
 * Para alternancia com efeito imediato o componente e o `<s-switch>`.
 *
 * Nao envolve o `mat-checkbox`: o do Material desenha a propria caixa com
 * medidas e area de ripple fixas, e o guia especifica caixa de 20px com check
 * de 16px, sem ripple. Reproduzir isso por cima do Material daria mais CSS do
 * que o controle inteiro.
 *
 * O rotulo faz parte da area de clique — por isso o componente inteiro e um
 * `<label>`, e nao um `<div>` com um rotulo ao lado.
 */
declare class SCheckboxComponent extends SControlBase<boolean> {
    /**
     * Estado visual indeterminado (traco, nao check).
     *
     * O valor do model continua sendo `boolean` — `indeterminate` e apenas uma
     * dica visual, nao um terceiro valor possivel. Util para checkbox de
     * cabecalho que representa uma selecao parcial.
     */
    readonly indeterminate: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Tres estados pelo clique: desmarcado -> marcado -> indeterminado ->
     * desmarcado. O valor do formulario vira `false`, `true` ou `null` — o
     * indeterminado aqui e um valor de verdade, para filtro do tipo "sim / nao /
     * tanto faz", e nao so a dica visual de `indeterminate`.
     *
     * `null` aparece como indeterminado: um `FormControl` sem valor inicial comeca
     * assim. Para comecar desmarcado, inicie o controle com `false`.
     */
    readonly triState: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Nome para o leitor de tela quando nao ha `label` visivel, como na caixa de
     * selecao de uma linha de tabela. Vai no `<input>`, que e o que o leitor de
     * tela anuncia: um `aria-label` no host `<s-checkbox>` nao chega ate ele.
     * Com `label`, o rotulo visivel nomeia e este fica de fora.
     */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    private readonly nativoRef;
    private readonly campo;
    protected readonly controlId: _angular_core.Signal<string>;
    protected readonly describedBy: _angular_core.Signal<string | null>;
    protected readonly required: _angular_core.Signal<boolean>;
    protected readonly isInvalid: _angular_core.Signal<boolean>;
    protected readonly marcado: _angular_core.Signal<boolean>;
    /** Traco no lugar do check: pedido pela tela, ou o `null` do `triState`. */
    protected readonly misto: _angular_core.Signal<boolean>;
    constructor();
    protected onToggle(event: Event): void;
    protected onBlur(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SCheckboxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SCheckboxComponent, "s-checkbox", never, { "indeterminate": { "alias": "indeterminate"; "required": false; "isSignal": true; }; "triState": { "alias": "triState"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Alternancia booleana da biblioteca `@siage/siage-ui`.
 *
 * Use `<s-switch>` para estado que **aplica na hora**, sem botao de salvar; e
 * `<s-checkbox>` dentro de formulario que e salvo. A escolha entre os dois nao
 * e estetica: ela informa ao usuario se a mudanca ja valeu.
 *
 * Nao envolve o `mat-slide-toggle`, pelo mesmo motivo do checkbox: a trilha do
 * guia tem 44x24 com polegar de 20px, e o do Material vem com outra proporcao e
 * uma area de ripple que o design system nao usa.
 */
declare class SSwitchComponent extends SControlBase<boolean> {
    /** Descricao para leitor de tela quando nao ha rotulo visivel. */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /**
     * Emitido quando o usuario liga ou desliga, com o novo estado. E o gancho do
     * efeito imediato — salvar a preferencia, ativar o registro — sem
     * precisar de formulario. Nao dispara quando o valor muda pelo formulario
     * (`setValue`, `reset`, `patchValue`).
     *
     * Recebe sempre `boolean`: o `change` nativo do checkbox interno nao sobe ate
     * o `<s-switch>`, senao `(change)` na tela rodaria duas vezes, uma delas com
     * o `Event`.
     */
    readonly change: _angular_core.OutputEmitterRef<boolean>;
    private readonly campo;
    protected readonly controlId: _angular_core.Signal<string>;
    protected readonly describedBy: _angular_core.Signal<string | null>;
    protected readonly required: _angular_core.Signal<boolean>;
    protected readonly isInvalid: _angular_core.Signal<boolean>;
    protected readonly ligado: _angular_core.Signal<boolean>;
    protected onToggle(event: Event): void;
    protected onBlur(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SSwitchComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SSwitchComponent, "s-switch", never, { "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "change": "change"; }, never, never, true, never>;
}

/**
 * Valor do `<s-datepicker range>`.
 *
 * As duas pontas sao opcionais: enquanto o usuario escolhe, o inicio chega
 * antes do fim. Um filtro "a partir de" e so `{ start, end: null }`.
 */
interface SDateRange {
    /** Primeiro dia do periodo. */
    start: Date | null;
    /** Ultimo dia do periodo, inclusive. */
    end: Date | null;
}

/** Valor do campo: uma data, ou um periodo quando `range` esta ligado. */
type SDateValue = Date | SDateRange;
/** Estado e navegacao do calendario, entregues ao `<ng-template sDatepickerHeader>`. */
interface SDatepickerHeaderControls {
    /** Texto do periodo exibido ("MARÇO DE 2026", "2026", "2016 – 2039"). */
    label: string;
    /** Tela atual do calendario. */
    view: MatCalendarView;
    /** Data em foco: define o mes ou o ano exibido. */
    activeDate: Date;
    /** Nao ha periodo anterior por causa de `min`. */
    previousDisabled: boolean;
    /** Nao ha proximo periodo por causa de `max`. */
    nextDisabled: boolean;
    /** Rotulo acessivel do botao de periodo anterior ("Mês anterior"). */
    previousLabel: string;
    /** Rotulo acessivel do botao de proximo periodo ("Próximo mês"). */
    nextLabel: string;
    /** Volta um mes, um ano ou uma pagina de anos, conforme a tela. */
    previous(): void;
    /** Avanca um mes, um ano ou uma pagina de anos, conforme a tela. */
    next(): void;
    /** Alterna entre os dias e a lista de anos, como o botao de periodo do Material. */
    toggleView(): void;
    /** Troca a tela do calendario. */
    setView(view: MatCalendarView): void;
    /** Leva o calendario ate a data, sem seleciona-la. */
    goTo(date: Date): void;
}
/** Contexto do cabecalho: `let-cal` recebe os controles; cada um tambem vem pelo nome. */
interface SDatepickerHeaderContext extends SDatepickerHeaderControls {
    $implicit: SDatepickerHeaderControls;
}
/** Valor e acoes entregues ao `<ng-template sDatepickerFooter>`. */
interface SDatepickerFooterControls {
    /** Valor atual do campo. */
    value: SDateValue | null;
    /**
     * Grava o valor e fecha o calendario. Data fora de `min`/`max` vira `null`,
     * como na digitacao. Com `range`, uma `Date` vira o inicio do periodo.
     */
    select(value: SDateValue | null): void;
    /** Fecha o calendario em overlay. */
    close(): void;
}
/** Contexto do rodape: `let-cal` recebe valor e acoes; cada um tambem vem pelo nome. */
interface SDatepickerFooterContext extends SDatepickerFooterControls {
    $implicit: SDatepickerFooterControls;
}
/**
 * Cabecalho proprio para o calendario: navegacao, atalhos, titulo do periodo.
 *
 * Substitui o cabecalho inteiro do Material - setas e botao de periodo
 * incluidos. O contexto traz o texto do periodo e as acoes de navegacao, que
 * respeitam `min` e `max`. Use botoes de verdade (`<s-icon-button>`), com os
 * rotulos de `previousLabel`/`nextLabel`: o calendario em overlay prende o foco,
 * e e pelo Tab que o teclado chega neles.
 *
 * @example
 * ```html
 * <s-datepicker formControlName="data">
 *   <ng-template sDatepickerHeader let-cal>
 *     <s-icon-button icon="chevron_left" [label]="cal.previousLabel"
 *       [disabled]="cal.previousDisabled" (click)="cal.previous()" />
 *     <strong>{{ cal.label }}</strong>
 *     <s-icon-button icon="chevron_right" [label]="cal.nextLabel"
 *       [disabled]="cal.nextDisabled" (click)="cal.next()" />
 *   </ng-template>
 * </s-datepicker>
 * ```
 */
declare class SDatepickerHeaderDirective {
    readonly template: TemplateRef<SDatepickerHeaderContext>;
    static ngTemplateContextGuard(_diretiva: SDatepickerHeaderDirective, contexto: unknown): contexto is SDatepickerHeaderContext;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SDatepickerHeaderDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SDatepickerHeaderDirective, "ng-template[sDatepickerHeader]", never, {}, {}, never, never, true, never>;
}
/**
 * Conteudo abaixo dos dias: legenda das marcas de `dateClass`, atalhos como
 * "Hoje" e "Limpar", um aviso sobre o prazo.
 *
 * Aparece no calendario de data e no de periodo. Para uma legenda com as
 * mesmas cores dos dias marcados, use as classes `s-datepicker-legend`,
 * `s-datepicker-legend__item` e `s-datepicker-mark s-datepicker-mark--<marca>`.
 *
 * @example
 * ```html
 * <s-datepicker formControlName="data" [dateClass]="marcar">
 *   <ng-template sDatepickerFooter let-cal>
 *     <s-button variant="ghost" (click)="cal.select(hoje)">Hoje</s-button>
 *     <s-button variant="ghost" [disabled]="!cal.value" (click)="cal.select(null)">Limpar</s-button>
 *   </ng-template>
 * </s-datepicker>
 * ```
 */
declare class SDatepickerFooterDirective {
    readonly template: TemplateRef<SDatepickerFooterContext>;
    static ngTemplateContextGuard(_diretiva: SDatepickerFooterDirective, contexto: unknown): contexto is SDatepickerFooterContext;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SDatepickerFooterDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SDatepickerFooterDirective, "ng-template[sDatepickerFooter]", never, {}, {}, never, never, true, never>;
}
/** O que o cabecalho no overlay precisa do `<s-datepicker>` que o abriu. */
interface SDatepickerSlots {
    readonly headerTemplate: Signal<TemplateRef<SDatepickerHeaderContext> | undefined>;
    readonly footerTemplate: Signal<TemplateRef<SDatepickerFooterContext> | undefined>;
    readonly footerContext: SDatepickerFooterContext;
}

/** Marca semantica de um dia no calendario. */
type SDayMark = 'success' | 'warning' | 'destructive' | 'info' | 'muted';
/** Retorno do classificador semantico de dias. */
type SDayMarkResult = SDayMark | readonly SDayMark[] | undefined;
/** Funcao chamada para marcar um dia do calendario. */
type SDayMarkFn = (date: Date) => SDayMarkResult;
/** Modo de selecao do calendario. */
type SDatepickerSelectionMode = 'date' | 'month' | 'year';
/**
 * Campo de data da biblioteca `@siage/siage-ui` — uma data ou um periodo.
 *
 * Encapsula (por composicao) o `matDatepicker` - **sem** `mat-form-field`, como
 * o `<s-select>`. A superficie e a mesma dos demais campos; o que vem do
 * Material e o calendario em overlay, a navegacao por teclado e a leitura de
 * datas.
 *
 * Clicar no campo abre o calendario, e a digitacao continua disponivel: so
 * aceita digitos, com a mascara do idioma (`dd/mm/aaaa` em `pt-BR`). Data que
 * nao existe, incompleta ou fora de `min`/`max` e apagada ao sair do campo e o
 * formulario recebe `null` - manter a ultima data valida faria o usuario
 * acreditar que o que digitou foi aceito.
 *
 * ## Periodo
 *
 * Com `range`, o mesmo campo recebe **uma ou duas datas** e o valor vira um
 * `SDateRange` (`{ start, end }`). Um filtro "a partir de" e so o inicio; o
 * separador "a" so aparece quando ha fim para separar. Para exigir as duas
 * pontas, ligue `requireEnd`: o periodo sem fim fica invalido com o erro
 * `sDateRangeIncomplete`, que o `<s-field>` ja traduz.
 *
 * Cada ponta e validada sozinha: data invalida ou fora de `min`/`max` e apagada
 * sem levar a outra junto. Fim antes do inicio tambem e apagado - um periodo
 * invertido nao filtra nada e nao avisa ninguem. Sem nenhuma das duas, o valor
 * e `null`, para `Validators.required` funcionar como num campo comum.
 *
 * **Nao esta no guia de design**, que nao define calendario. Segue a anatomia
 * do campo e o tamanho de icone de controle (20px).
 *
 * ## Templates
 *
 * O calendario aceita dois `ng-template` para desenho proprio, nos dois modos
 * (data e periodo):
 *
 * - `sDatepickerHeader` substitui o cabecalho (setas e periodo) e recebe a
 *   navegacao pronta, respeitando `min`/`max`;
 * - `sDatepickerFooter` entra abaixo dos dias - legenda, "Hoje", "Limpar" - e
 *   recebe o valor com `select()` e `close()`.
 *
 * Os dias continuam do Material, que nao aceita template de celula: para
 * pinta-los use `dateClass`.
 *
 * A aplicacao precisa registrar `provideSiageDateAdapter()` uma vez, no
 * `app.config.ts` - e o que ensina o Material a ler e escrever a data no idioma
 * escolhido (padrao `pt-BR`).
 *
 * @example
 * ```html
 * <s-field label="Data da aula" required>
 *   <s-datepicker formControlName="data" [max]="hoje" />
 * </s-field>
 *
 * <s-field label="Período">
 *   <s-datepicker formControlName="periodo" range />
 * </s-field>
 *
 * <s-datepicker formControlName="data">
 *   <ng-template sDatepickerFooter let-cal>
 *     <s-button variant="ghost" (click)="cal.select(hoje)">Hoje</s-button>
 *   </ng-template>
 * </s-datepicker>
 * ```
 */
declare class SDatepickerComponent extends SControlBase<SDateValue> implements Validator, SDatepickerSlots {
    /**
     * Transforma o campo em periodo: aceita uma ou duas datas e o valor passa a
     * ser `SDateRange`. O calendario marca o inicio e o fim de uma vez.
     */
    readonly range: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Com `range`, exige as duas datas. O periodo so com inicio fica invalido
     * (`sDateRangeIncomplete`) — sem isso, uma data so e um periodo valido.
     */
    readonly requireEnd: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Primeira data selecionavel. Data digitada antes dela e apagada. */
    readonly min: _angular_core.InputSignal<Date | null>;
    /** Ultima data selecionavel. Data digitada depois dela e apagada. */
    readonly max: _angular_core.InputSignal<Date | null>;
    /** Impede a digitacao, deixando apenas a escolha pelo calendario. */
    readonly pickerOnly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Abre o calendario ao clicar no campo.
     *
     * Desligue quando a tela e de lancamento em massa e o usuario digita as
     * datas: o calendario abrindo a cada clique atrapalha quem ja sabe o dia.
     */
    readonly openOnClick: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Com `range`: texto de exemplo da data inicial. Padrao: o formato do idioma. */
    readonly startPlaceholder: _angular_core.InputSignal<string>;
    /** Com `range`: texto de exemplo da data final. Padrao: o formato do idioma. */
    readonly endPlaceholder: _angular_core.InputSignal<string>;
    /** Com `range`: rotulo acessivel da data inicial. */
    readonly startLabel: _angular_core.InputSignal<string>;
    /** Com `range`: rotulo acessivel da data final. */
    readonly endLabel: _angular_core.InputSignal<string>;
    /**
     * Primeira tela aberta pelo calendario.
     *
     * Use `year` quando a escolha costuma ser mensal, e `multi-year` quando a
     * tela precisa navegar rapido entre anos. A selecao continua sendo diaria a
     * menos que `selectionMode` tambem seja ajustado.
     */
    readonly startView: _angular_core.InputSignal<MatCalendarView>;
    /** Mes ou ano inicial do calendario quando o valor ainda esta vazio. */
    readonly startAt: _angular_core.InputSignal<Date | null>;
    /**
     * Granularidade gravada no formulario.
     *
     * `month` grava o primeiro dia do mes escolhido; `year` grava 1º de janeiro.
     * Essa convencao entrega um `Date` simples para relatorios mensais/anuais sem
     * inventar outro tipo de valor. Em `range`, a granularidade permanece diaria.
     */
    readonly selectionMode: _angular_core.InputSignal<SDatepickerSelectionMode>;
    /**
     * Marca dias com semantica do design system, e nao com classes da aplicacao.
     *
     * O calendario do Material vive em overlay; CSS da tela consumidora nao
     * atravessa esse encapsulamento de forma confiavel. Por isso a API recebe
     * `success`, `warning`, `destructive`, `info` ou `muted`, e a biblioteca
     * mapeia para tokens. A marca visual nao basta para acessibilidade: explique o
     * significado numa legenda no `<ng-template sDatepickerFooter>` e, quando a
     * regra exigir detalhe por dia, no texto/fluxo da propria tela.
     */
    readonly dateClass: _angular_core.InputSignal<SDayMarkFn | null>;
    private readonly cabecalhoDiretiva;
    private readonly rodapeDiretiva;
    private readonly calendarioPopup;
    private readonly periodoPopup;
    /** @internal Lido pelo cabecalho do calendario, que vive no overlay. */
    readonly headerTemplate: _angular_core.Signal<TemplateRef<_siage_siage_ui.SDatepickerHeaderContext> | undefined>;
    /** @internal Lido pelo cabecalho do calendario, que vive no overlay. */
    readonly footerTemplate: _angular_core.Signal<TemplateRef<SDatepickerFooterContext> | undefined>;
    /** O rodape de `showClear`, quando a tela nao projeta um. */
    private readonly rodapeLimpar;
    /** Botao "Limpar" no rodape do calendario. Um rodape proprio (`sDatepickerFooter`) vence. */
    readonly showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Periodo como `[inicio, fim]` no formulario, no lugar de `{ start, end }` —
     * o formato que as telas vindas do PrimeNG ja usam. Datas em texto (ISO, da
     * API) tambem sao aceitas na entrada.
     */
    readonly rangeAsArray: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Data escolhida (no periodo, a ultima marcada). */
    readonly dateSelect: _angular_core.OutputEmitterRef<Date>;
    /** O valor foi apagado. */
    readonly cleared: _angular_core.OutputEmitterRef<void>;
    /** @internal Objeto unico com getter: o template le sempre o valor atual. */
    readonly footerContext: SDatepickerFooterContext;
    /**
     * Sem template, o `mat-calendar` fica com o cabecalho do Material e a altura
     * fixa do overlay. O input do Material nao aceita vazio na tipagem, embora
     * trate `undefined` como "use o padrao".
     */
    protected readonly cabecalho: _angular_core.Signal<ComponentType<unknown>>;
    private readonly campo;
    protected readonly config: _siage_siage_ui.SDateConfig;
    protected readonly maxLength = 10;
    protected readonly controlId: _angular_core.Signal<string>;
    protected readonly ariaLabel: _angular_core.Signal<string | null>;
    protected readonly describedBy: _angular_core.Signal<string | null>;
    protected readonly required: _angular_core.Signal<boolean>;
    protected readonly isInvalid: _angular_core.Signal<boolean>;
    protected readonly textoExemplo: _angular_core.Signal<string>;
    protected readonly data: _angular_core.Signal<Date | null>;
    protected readonly inicio: _angular_core.Signal<Date | null>;
    protected readonly fim: _angular_core.Signal<Date | null>;
    protected readonly calendarDateClass: _angular_core.Signal<MatCalendarCellClassFunction<Date>>;
    /** O fim esta sendo digitado: o separador aparece mesmo sem fim ainda. */
    protected readonly editandoFim: _angular_core.WritableSignal<boolean>;
    /**
     * Saiu do campo ou fechou o calendario. O periodo incompleto so pinta a borda
     * depois disso — enquanto escolhe o inicio, o fim ainda vai chegar.
     */
    private readonly tocado;
    /**
     * Com `requireEnd`, o periodo so com inicio e invalido tambem fora de um
     * formulario: o validador so roda com `FormControl`, a borda nao depende dele.
     */
    protected readonly periodoIncompleto: _angular_core.Signal<boolean>;
    /** Inicio e fim no mesmo dia: um periodo de um dia so, escrito uma vez. */
    protected readonly mesmoDia: _angular_core.Signal<boolean>;
    /** "a" so entre duas datas diferentes — sozinho ou repetido, so o inicio aparece. */
    /**
     * Com `range` e `placeholder`, o periodo vazio mostra um texto so ("Selecione a
     * Data"), sem o formato da data final nem o separador. Escolhido o inicio, o
     * campo volta a mostrar as duas pontas.
     */
    protected readonly textoUnico: _angular_core.Signal<boolean>;
    protected readonly placeholderInicio: _angular_core.Signal<string>;
    protected readonly placeholderFim: _angular_core.Signal<string>;
    protected readonly semSeparador: _angular_core.Signal<boolean>;
    /** Texto da data ou do periodo no modo somente-leitura. */
    protected readonly textoLeitura: _angular_core.Signal<string>;
    private aoMudarValidacao;
    constructor();
    validate(controle: AbstractControl<SDateValue | null>): ValidationErrors | null;
    writeValue(valor: SDateValue | null): void;
    /** Grava, avisa o formulario no formato dele e emite `dateSelect`/`cleared`. */
    protected setValue(valor: SDateValue | null): void;
    /** O valor do formulario no formato do componente: texto vira data, `[a, b]` vira periodo. */
    private doFormulario;
    private paraFormulario;
    registerOnValidatorChange(fn: () => void): void;
    protected onBeforeInput(evento: InputEvent): void;
    protected onInput(evento: Event): void;
    protected abrirPeloClique(calendario: {
        open(): void;
    }): void;
    protected onDateChange(event: MatDatepickerInputEvent<Date>): void;
    protected onMonthSelected(date: Date, calendar: {
        close(): void;
    }): void;
    protected onYearSelected(date: Date, calendar: {
        close(): void;
    }): void;
    protected onStartChange(event: MatDatepickerInputEvent<Date>): void;
    protected onEndChange(event: MatDatepickerInputEvent<Date>): void;
    protected onBlur(): void;
    protected onEndBlur(): void;
    /** Fechar o calendario so com o inicio escolhido tambem e sair do campo. */
    protected onPeriodoFechado(): void;
    private criarContextoRodape;
    /** `select()` do rodape: grava no formato do modo, dentro de `min`/`max`, e fecha. */
    private selecionar;
    private fecharCalendario;
    /** Sem nenhuma ponta o periodo e `null`, e o `required` do formulario enxerga. */
    private gravarPeriodo;
    /** Devolve a data, ou apaga o texto e devolve `null` quando ela nao vale. */
    private validar;
    /**
     * Mes e ano valem quando algum dia deles cabe na faixa: o Material deixa
     * escolher o mes do `min`, e o dia 1 dele pode cair antes do limite.
     */
    private normalizeMonth;
    private normalizeYear;
    private periodoForaDaFaixa;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SDatepickerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SDatepickerComponent, "s-datepicker", never, { "range": { "alias": "range"; "required": false; "isSignal": true; }; "requireEnd": { "alias": "requireEnd"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "pickerOnly": { "alias": "pickerOnly"; "required": false; "isSignal": true; }; "openOnClick": { "alias": "openOnClick"; "required": false; "isSignal": true; }; "startPlaceholder": { "alias": "startPlaceholder"; "required": false; "isSignal": true; }; "endPlaceholder": { "alias": "endPlaceholder"; "required": false; "isSignal": true; }; "startLabel": { "alias": "startLabel"; "required": false; "isSignal": true; }; "endLabel": { "alias": "endLabel"; "required": false; "isSignal": true; }; "startView": { "alias": "startView"; "required": false; "isSignal": true; }; "startAt": { "alias": "startAt"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; "dateClass": { "alias": "dateClass"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "rangeAsArray": { "alias": "rangeAsArray"; "required": false; "isSignal": true; }; }, { "dateSelect": "dateSelect"; "cleared": "cleared"; }, ["cabecalhoDiretiva", "rodapeDiretiva"], never, true, never>;
}

/** Parte de uma data numerica. */
type SDatePart = 'day' | 'month' | 'year';
/**
 * Como o campo le e escreve datas.
 *
 * Sai do idioma por `criarConfigData()`: `pt-BR` escreve `dd/mm/aaaa`, `en-US`
 * escreve `mm/dd/yyyy`, `de-DE` escreve `dd.mm.yyyy`. A aplicacao informa so o
 * idioma - ordem e separador vem do `Intl` do navegador.
 */
interface SDateConfig {
    /** Codigo do idioma. Os nomes de mes e dia do calendario tambem saem dele. */
    locale: string;
    /** Ordem das partes na digitacao e na exibicao. */
    order: readonly SDatePart[];
    /** Separador entre as partes. */
    separator: string;
    /** Texto de exemplo do campo. */
    placeholder: string;
}
/** Opcoes de `provideSiageDateAdapter()`. */
interface SDateAdapterOptions {
    /** Idioma. Padrao: `pt-BR`. */
    locale?: string;
    /** Sobrescreve o texto de exemplo derivado do idioma. */
    placeholder?: string;
}
/** Quantos digitos cada parte aceita. */
declare const S_DATE_PART_LENGTH: Record<SDatePart, number>;
/**
 * Monta a configuracao de data de um idioma, perguntando ao `Intl` em que ordem
 * e com que separador ele escreve uma data numerica.
 */
declare function criarConfigData(options?: SDateAdapterOptions): SDateConfig;
/** Configuracao em uso. Sem `provideSiageDateAdapter()`, vale `pt-BR`. */
declare const S_DATE_CONFIG: InjectionToken<SDateConfig>;
/**
 * Aplica a mascara da data ao que foi digitado.
 *
 * So digitos passam; o separador entra sozinho entre as partes, e so quando ha
 * digito depois dele - assim o backspace nunca esbarra num separador que volta.
 */
declare function mascararData(texto: string, config: SDateConfig): string;
/**
 * Formatos de data do SIAGE.
 *
 * A entrada e a exibicao do campo seguem `S_DATE_CONFIG`; os rotulos
 * acessiveis do calendario ficam por extenso, que e o que o leitor de tela
 * anuncia.
 */
declare const S_DATE_FORMATS: MatDateFormats;
/**
 * Adaptador de data que respeita a ordem do idioma.
 *
 * O `NativeDateAdapter` do Material delega a leitura de texto ao
 * `Date.parse` do navegador, que interpreta `03/04/2026` como 4 de marco -
 * ordem americana. Numa folha de ponto isso e um erro silencioso e caro, entao
 * `parse` e `format` seguem `S_DATE_CONFIG`.
 *
 * A extensao por heranca aqui e o ponto de extensao documentado do Material
 * para adaptadores; a regra de encapsular por composicao vale para componentes.
 */
declare class SDateAdapter extends NativeDateAdapter {
    private readonly config;
    parse(value: unknown): Date | null;
    format(date: Date, displayFormat: unknown): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SDateAdapter, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SDateAdapter>;
}
/** Rotulos do calendario em portugues - os do Material vem em ingles. */
declare class SDatepickerIntl extends MatDatepickerIntl {
    calendarLabel: string;
    openCalendarLabel: string;
    closeCalendarLabel: string;
    prevMonthLabel: string;
    nextMonthLabel: string;
    prevYearLabel: string;
    nextYearLabel: string;
    prevMultiYearLabel: string;
    nextMultiYearLabel: string;
    switchToMonthViewLabel: string;
    switchToMultiYearViewLabel: string;
    startDateLabel: string;
    endDateLabel: string;
    comparisonDateLabel: string;
    formatYearRangeLabel(start: string, end: string): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SDatepickerIntl, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SDatepickerIntl>;
}
/**
 * Registra o adaptador de data da biblioteca na aplicacao.
 *
 * Necessario quando a aplicacao usa `<s-datepicker>`. Sem
 * ele o Material lanca erro em tempo de execucao pedindo um `DateAdapter`.
 *
 * O padrao e `pt-BR`. Para outro idioma, informe o codigo - a ordem das partes,
 * o separador e o texto de exemplo acompanham. Os rotulos do calendario so sao
 * traduzidos para portugues; em outro idioma ficam os do Material.
 *
 * ```ts
 * // app.config.ts
 * providers: [provideSiageDateAdapter()]            // pt-BR
 * providers: [provideSiageDateAdapter('en-US')]     // mm/dd/yyyy
 * providers: [provideSiageDateAdapter({ locale: 'pt-BR', placeholder: 'Ex.: 03/04/2026' })]
 * ```
 */
declare function provideSiageDateAdapter(options?: string | SDateAdapterOptions): EnvironmentProviders;

/**
 * Rodape do painel do `<s-autocomplete>`, abaixo das opcoes — para o que
 * completa a escolha sem sair do campo, como cadastrar um item que a busca
 * nao achou.
 *
 * Fica fixo no fim do painel enquanto as opcoes rolam. O clique e a digitacao
 * dentro dele nao fecham o painel nem escolhem uma opcao.
 *
 * Os controles do rodape **nao se ligam ao `<s-field>` em volta** do
 * autocomplete: sem isto, um `<s-input>` ali dentro herdaria o id, o rotulo e o
 * erro do campo. Nomeie-os pelo proprio `label`, que vira `aria-label`.
 *
 * Quando o template vem de outra tela e so e repassado (`ngTemplateOutlet`),
 * marque tambem o template de origem com `sAutocompleteFooter`: e la que o
 * conteudo procura o campo.
 *
 * @example
 * ```html
 * <s-autocomplete formControlName="recurso" url="recursos-educacionais">
 *   <ng-template sAutocompleteFooter>
 *     <s-input label="Novo recurso" placeholder="Digite o novo recurso" [(ngModel)]="novo" />
 *     <s-button icon="add" (click)="adicionar()">Adicionar</s-button>
 *   </ng-template>
 * </s-autocomplete>
 * ```
 */
declare class SAutocompleteFooterDirective {
    readonly template: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SAutocompleteFooterDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SAutocompleteFooterDirective, "ng-template[sAutocompleteFooter]", never, {}, {}, never, never, true, never>;
}

/**
 * Opção exibida pelo `<s-autocomplete>`.
 *
 * O tipo genérico `T` representa o valor de domínio devolvido para a aplicação
 * consumidora (um id numérico, um uuid, um objeto de negócio etc.).
 */
interface SAutocompleteOption<T = unknown> {
    /** Texto exibido na lista e no input. */
    label: string;
    /** Valor associado à opção. É este valor que trafega no formulário. */
    value: T;
    /** Desabilita a opção individualmente. */
    disabled?: boolean;
}
/**
 * Payload do output `selectionChange`.
 *
 * `null` indica que a seleção foi desfeita (o usuário limpou o campo ou voltou
 * a digitar depois de ter selecionado uma opção).
 */
type SAutocompleteSelection<T = unknown> = SAutocompleteOption<T> | null;

/** Valor interno do input: texto digitado ou opção selecionada. */
type SearchControlValue<T> = string | SAutocompleteOption<T> | null;
/**
 * Autocomplete da biblioteca `@siage/siage-ui`.
 *
 * Encapsula (por composição) `mat-autocomplete` e `mat-option`, sobre a mesma
 * superfície dos demais campos — **sem** `mat-form-field`, que traria o rótulo
 * flutuante dentro da moldura em vez do rótulo acima que o guia define.
 *
 * Como `<s-input>` e `<s-select>`, ele espera viver dentro de um `<s-field>`,
 * que fornece rótulo, obrigatoriedade e faixa de erro, e amarra `for`,
 * `aria-required`, `aria-invalid` e `aria-describedby`.
 *
 * A busca é responsabilidade da aplicação: o componente apenas emite `search`
 * com o texto digitado e renderiza o que receber em `options`.
 */
declare class SAutocompleteComponent<T = unknown> extends SControlBase<T> {
    /**
     * Opções exibidas no painel.
     *
     * Sem `url`, o próprio componente filtra a lista pelo texto digitado,
     * ignorando acento e caixa. Com `url`, quem filtra é a fonte de dados — como
     * no autocomplete do Professores e do Educacional, o `url` é o que decide.
     */
    readonly options: _angular_core.InputSignal<readonly (object | SAutocompleteOption<T>)[]>;
    /**
     * Chave do rotulo quando `options` (ou a fonte) traz objetos de dominio —
     * `{ id, nome }` da API. Informada, o **objeto inteiro** e o valor do
     * formulario, como no `optionLabel` sem `optionValue` do PrimeNG; o campo ja
     * preenchido mostra o rotulo do proprio objeto, sem consulta.
     */
    readonly optionLabel: _angular_core.InputSignal<string>;
    /**
     * Chave que identifica o objeto (`id`), para reconhecer o valor do
     * formulario entre as opcoes mesmo vindo de outra resposta da API. Vence
     * `compareWith`.
     */
    readonly dataKey: _angular_core.InputSignal<string>;
    /** Nome do parametro do termo na busca por `url` (`nome`, `descricao`). Vai para a fonte. */
    readonly searchFor: _angular_core.InputSignal<string>;
    /** Recurso onde `url` mora (`Autocomplete`, por padrao, na fonte do Professores). */
    readonly controller: _angular_core.InputSignal<string>;
    /**
     * Com `url`, abre ja listando ao focar o campo — sem esperar `minLength`
     * letras. Para listas curtas, em que o painel funciona como um select.
     */
    readonly searchOnFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Texto digitado sem escolher uma opcao e descartado ao sair do campo. Sem
     * isto, o campo mostra um texto que nao esta no formulario.
     */
    readonly forceSelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Recurso a consultar a cada digitação, no lugar de `options`.
     *
     * Quando informado, o componente delega a busca à `SAutocompleteSource` que a
     * aplicação registrou — ele **não** faz HTTP. Sem `url`, nada muda: a tela
     * continua ouvindo `search` e alimentando `options`.
     */
    readonly url: _angular_core.InputSignal<string>;
    /** Filtros adicionais enviados junto da busca. Só tem efeito com `url`. */
    readonly params: _angular_core.InputSignal<Record<string, unknown>>;
    /** Caracteres mínimos antes de consultar. Só tem efeito com `url`. */
    readonly minLength: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Compara o valor escolhido com o valor de cada opção, como no `<s-select>`.
     *
     * O padrão é igualdade estrita, que basta para id e texto. Informe uma
     * função quando o valor for um objeto vindo de duas respostas diferentes da
     * API — sem isso, a tela de edição não reconhece o valor que veio preenchido.
     */
    readonly compareWith: _angular_core.InputSignal<(a: T, b: T) => boolean>;
    /** Espera entre a digitação e a consulta, em ms. Só tem efeito com `url`. */
    readonly debounceTime: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Marca o campo como obrigatório.
     *
     * Dentro de um `<s-field required>` a obrigatoriedade já vem do campo; este
     * input existe para o uso avulso.
     */
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Exibe indicador de carregamento no campo e no painel. */
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Texto exibido quando não há opções e não está carregando. */
    readonly noResultsText: _angular_core.InputSignal<string>;
    /** Texto exibido quando não há nenhuma opção para listar. */
    readonly emptyText: _angular_core.InputSignal<string>;
    /** Texto exibido no painel enquanto `loading` é `true`. */
    readonly loadingText: _angular_core.InputSignal<string>;
    /** Emitido quando uma opção é selecionada, ou `null` quando a seleção é desfeita. */
    readonly selectionChange: _angular_core.OutputEmitterRef<SAutocompleteSelection<T>>;
    /** Emitido a cada alteração do texto digitado pelo usuário.
     *  Respeita o mesmo `debounceTime` de 300ms.
     */
    readonly search: _angular_core.OutputEmitterRef<string>;
    /** Controle interno do input. Nunca é exposto para a aplicação consumidora. */
    protected readonly searchControl: FormControl<SearchControlValue<T>>;
    /** `true` quando existe um valor selecionado (habilita o botão de limpar). */
    protected readonly hasValue: _angular_core.Signal<boolean>;
    private readonly source;
    private readonly fetched;
    private readonly fetching;
    /** As opções que o painel realmente lista: as buscadas com `url`, ou as da tela. */
    /** `options` no formato do painel. */
    private readonly opcoesBase;
    /** `dataKey` vence `compareWith`. */
    protected readonly comparar: _angular_core.Signal<(a: T, b: T) => boolean>;
    protected readonly visibleOptions: _angular_core.Signal<readonly SAutocompleteOption<T>[]>;
    /** Texto digitado, para o filtro local. Zera ao selecionar. */
    private readonly termo;
    /** Desenho próprio da opção, quando a aplicação projeta um. */
    protected readonly opcaoTemplate: _angular_core.Signal<SOptionTemplateDirective<any> | undefined>;
    /** Rodape do painel, abaixo das opcoes. Ver `SAutocompleteFooterDirective`. */
    protected readonly rodape: _angular_core.Signal<SAutocompleteFooterDirective | undefined>;
    /** Carregando por `loading` da tela ou por uma consulta em andamento. */
    protected readonly isLoading: _angular_core.Signal<boolean>;
    /** `true` quando não há opções para exibir e não está carregando. */
    protected readonly isEmpty: _angular_core.Signal<boolean>;
    /** Lista local vazia: nao e a busca que nao achou, e que nao ha o que listar. */
    protected readonly listaVazia: _angular_core.Signal<boolean>;
    /** Texto exibido no modo somente-leitura: o rotulo da opcao selecionada. */
    protected readonly textoSomenteLeitura: _angular_core.Signal<string>;
    private readonly campo;
    /** Valores que chegaram do formulário e ainda não têm rótulo conhecido. */
    private readonly aResolver;
    private readonly buscaAoFocar;
    protected readonly controlId: _angular_core.Signal<string>;
    protected readonly describedBy: _angular_core.Signal<string | null>;
    /** Obrigatório pelo input próprio ou pelo `<s-field>` que envolve o controle. */
    protected readonly isRequired: _angular_core.Signal<boolean>;
    /** Inválido pelo input próprio ou pelo `<s-field>` que envolve o controle. */
    protected readonly isInvalid: _angular_core.Signal<boolean>;
    /** O rótulo interno só existe fora de um `<s-field>`. Ver o input `label`. */
    protected readonly rotuloProprio: _angular_core.Signal<boolean>;
    /** Painel aberto: a seta aponta para cima e passa a fechar. */
    protected readonly painelAberto: _angular_core.WritableSignal<boolean>;
    private readonly gatilho;
    constructor();
    /** Exibe o `label` da opção no input (usado pelo `displayWith` do Material). */
    protected readonly displayFn: (option: SearchControlValue<T>) => string;
    protected onOptionSelected(event: MatAutocompleteSelectedEvent): void;
    protected onBlur(): void;
    protected onFocus(): void;
    /** `forceSelection`: o texto que nao virou escolha sai do campo. */
    private descartarTextoSolto;
    /** O pedido a fonte, so com as chaves que a tela informou. */
    private pedido;
    protected ehSelecionada(opcao: SAutocompleteOption<T>): boolean;
    protected clear(event: Event): void;
    /**
     * Grava o valor via base, avisa o formulario e emite `selectionChange`.
     *
     * Diferente do `setValue` da base (que apenas grava e notifica o form), este
     * metodo tambem dispara o output de selecao — logica propria do autocomplete.
     */
    private emitirSelecao;
    writeValue(value: T | null): void;
    onOpened(): void;
    onClosed(): void;
    /**
     * A seta abre e fecha o painel, como o chevron do `<s-select>`. O foco vai
     * para o input, que e onde a digitacao e o teclado do painel acontecem.
     */
    protected alternarPainel(campo: HTMLInputElement): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SAutocompleteComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SAutocompleteComponent<any>, "s-autocomplete", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "searchFor": { "alias": "searchFor"; "required": false; "isSignal": true; }; "controller": { "alias": "controller"; "required": false; "isSignal": true; }; "searchOnFocus": { "alias": "searchOnFocus"; "required": false; "isSignal": true; }; "forceSelection": { "alias": "forceSelection"; "required": false; "isSignal": true; }; "url": { "alias": "url"; "required": false; "isSignal": true; }; "params": { "alias": "params"; "required": false; "isSignal": true; }; "minLength": { "alias": "minLength"; "required": false; "isSignal": true; }; "compareWith": { "alias": "compareWith"; "required": false; "isSignal": true; }; "debounceTime": { "alias": "debounceTime"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "noResultsText": { "alias": "noResultsText"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; "loadingText": { "alias": "loadingText"; "required": false; "isSignal": true; }; }, { "selectionChange": "selectionChange"; "search": "search"; }, ["opcaoTemplate", "rodape"], never, true, never>;
}

/** O que a fonte recebe para resolver um valor que ja veio preenchido. */
interface SAutocompleteLookup {
    /** Valor do input `url` do componente. */
    url: string;
    /** O valor que o formulario entregou — um id, normalmente. */
    value: unknown;
    /** Filtros adicionais informados pela tela, via input `params`. */
    params: Record<string, unknown>;
    /** Valor do input `controller`: o recurso onde `url` mora. Vazio, vale o padrao da fonte. */
    controller?: string;
    /**
     * Valor do input `optionLabel`. Informado, a tela quer o **objeto inteiro**
     * como valor: a fonte devolve `{ label: item[optionLabel], value: item }`.
     */
    optionLabel?: string;
}
/** O que o `<s-autocomplete>` entrega a fonte de dados a cada busca. */
interface SAutocompleteQuery {
    /** Valor do input `url` do componente — o recurso a consultar. */
    url: string;
    /** Texto digitado pelo usuario. */
    term: string;
    /** Filtros adicionais informados pela tela, via input `params`. */
    params: Record<string, unknown>;
    /** Valor do input `searchFor`: o nome do parametro do termo. Vazio, vale o padrao da fonte. */
    searchFor?: string;
    /** Valor do input `controller`: o recurso onde `url` mora. Vazio, vale o padrao da fonte. */
    controller?: string;
    /** Ver `SAutocompleteLookup.optionLabel`: com ele, `value` de cada opcao e o item inteiro. */
    optionLabel?: string;
}
/**
 * Fonte de dados do `<s-autocomplete>`.
 *
 * A biblioteca **nao faz HTTP**: nao importa `HttpClient`, nao conhece a URL
 * base da API, nao sabe o formato da resposta. Ela apenas descreve o pedido — a
 * aplicacao implementa esta classe e resolve como buscar.
 *
 * Foi o que permitiu trazer o atributo `url` do Professores sem trazer junto o
 * acoplamento: cada sistema (Professores, Gestor, Aluno) tem a sua camada de
 * API, e todos escrevem a mesma coisa no template.
 *
 * @example
 * ```ts
 * @Injectable({ providedIn: 'root' })
 * export class SiageAutocompleteSource extends SAutocompleteSource {
 *   private readonly api = inject(ApiService);
 *
 *   search({ url, term, params }: SAutocompleteQuery): Observable<SAutocompleteOption[]> {
 *     const busca = new URLSearchParams({ ...params, termo: term } as Record<string, string>);
 *     return this.api
 *       .get(`Autocomplete/${url}?${busca}`)
 *       .pipe(map((r) => r.body.data.map((i) => ({ label: i.descricao, value: i.id }))));
 *   }
 * }
 * ```
 */
declare abstract class SAutocompleteSource {
    /**
     * Devolve as opcoes que atendem ao pedido.
     *
     * O componente cancela a consulta anterior a cada nova digitacao, entao a
     * implementacao nao precisa se preocupar com respostas fora de ordem.
     *
     * O valor de cada opcao e `unknown` aqui e volta tipado no componente, pelo
     * generico de `<s-autocomplete>` — a fonte nao precisa saber o tipo de
     * dominio de cada tela.
     */
    abstract search(query: SAutocompleteQuery): Observable<readonly SAutocompleteOption<unknown>[]>;
    /**
     * Descobre o rotulo de um valor que ja veio preenchido.
     *
     * Numa tela de edicao o formulario entrega um id, e o componente nao tem
     * como saber o texto correspondente — nenhuma busca aconteceu ainda. Sem
     * isto, o campo fica em branco ate a pessoa digitar, e a tela precisa
     * buscar o item por fora so para preencher `options`.
     *
     * E **opcional**: sem implementacao, o comportamento e o de antes.
     *
     * @example
     * ```ts
     * resolve({ url, value }: SAutocompleteLookup) {
     *   return this.api
     *     .get(`Autocomplete/${url}/${value}`)
     *     .pipe(map((r) => ({ label: r.body.data.descricao, value })));
     * }
     * ```
     */
    resolve?(lookup: SAutocompleteLookup): Observable<SAutocompleteOption<unknown> | null>;
}
/**
 * Registra a fonte de dados dos autocompletes da aplicacao.
 *
 * Necessario apenas quando alguma tela usa `<s-autocomplete url="...">`. Sem
 * `url`, o componente continua recebendo `options` da tela e nao consulta nada.
 *
 * ```ts
 * // app.config.ts
 * providers: [provideSiageAutocompleteSource(SiageAutocompleteSource)]
 * ```
 */
declare function provideSiageAutocompleteSource(source: Type<SAutocompleteSource>): EnvironmentProviders;

/**
 * Por que a area esta sem conteudo.
 *
 * A distincao nao e cosmetica: cada variante oferece uma acao diferente, e
 * oferecer a errada manda o usuario para o lugar errado.
 *
 * - `no-data` — nunca houve registro. Oferece **criar**.
 * - `no-results` — ha registros, mas nenhum passa no filtro. Oferece
 *   **limpar** e nunca criar: criar aqui sugere que o cadastro nao existe.
 * - `error` — a consulta falhou. Oferece **tentar de novo**.
 * - `forbidden` — o usuario nao tem permissao. Explica a restricao e a quem
 *   pedir acesso; nunca tela branca nem 403 cru.
 */
type SEmptyStateVariant = 'no-data' | 'no-results' | 'error' | 'forbidden';
/**
 * Tres dos quatro estados obrigatorios do guia: vazio, erro de carregamento e
 * sem permissao. O quarto, carregando, e o `<s-skeleton>`.
 *
 * Cada variante ja vem com glifo, titulo, descricao e rotulo de acao coerentes
 * — o minimo para nao aparecer uma tela branca. Sobrescreva o que a tela souber
 * dizer melhor: "Nenhuma jornada encontrada" ensina mais que "Nenhum resultado".
 */
declare class SEmptyStateComponent {
    /** Por que a area esta sem conteudo. Ver `SEmptyStateVariant`. */
    readonly variant: _angular_core.InputSignal<SEmptyStateVariant>;
    /** Glifo de 48px. Por padrao, o da variante. */
    readonly icon: _angular_core.InputSignal<string>;
    /** Titulo curto. Por padrao, o da variante. */
    readonly title: _angular_core.InputSignal<string>;
    /** Uma linha explicando o que aconteceu. Por padrao, a da variante. */
    readonly description: _angular_core.InputSignal<string>;
    /**
     * Rotulo da acao unica. Por padrao, o da variante.
     *
     * String vazia esconde o botao — e o caso de `forbidden`, em que nao ha nada
     * que o usuario possa fazer na propria tela.
     */
    readonly actionLabel: _angular_core.InputSignal<string | null>;
    /**
     * Nivel do titulo. O padrao, 3, serve ao estado vazio dentro de um card ou
     * secao que ja tem o seu `h2`. Numa tela que so tem o `h1` (uma listagem
     * direto abaixo do cabecalho), use 2: pular nivel desorienta quem navega pelos
     * titulos com leitor de tela. O tamanho nao muda com o nivel.
     */
    readonly headingLevel: _angular_core.InputSignal<2 | 3 | 4>;
    /** Disparado pelo botao da acao. */
    readonly action: _angular_core.OutputEmitterRef<void>;
    private readonly padrao;
    protected readonly glifo: _angular_core.Signal<string>;
    protected readonly titulo: _angular_core.Signal<string>;
    protected readonly descricao: _angular_core.Signal<string>;
    protected readonly rotuloAcao: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SEmptyStateComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SEmptyStateComponent, "s-empty-state", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; "isSignal": true; }; "headingLevel": { "alias": "headingLevel"; "required": false; "isSignal": true; }; }, { "action": "action"; }, never, never, true, never>;
}

/**
 * Alinhamento de uma coluna.
 *
 * O guia fixa o alinhamento **pelo tipo do dado**, nunca por preferencia
 * visual, porque e o que permite comparar valores lendo a coluna de cima a
 * baixo:
 *
 * - `start` — texto, e data isolada quando a linha tem mais contexto
 * - `end` — numero, hora, percentual e moeda (as casas alinham)
 * - `center` — status, booleano, icone e a coluna de acoes
 */
type STableAlign = 'start' | 'center' | 'end';
/**
 * Uma coluna da tabela.
 *
 * `key` e tipada como `keyof T & string`, de modo que o compilador rejeita
 * chaves que nao existem no tipo da linha — evita erros de digitacao que so
 * apareceriam em tempo de execucao.
 */
interface STableColumn<T> {
    /** Identificador da coluna. Tambem e a chave lida de cada linha por padrao. */
    key: keyof T & string;
    /** Texto do cabecalho. */
    label: string;
    /** Ver `STableAlign`. O padrao e `start`. */
    align?: STableAlign;
    /** Permite ordenar por esta coluna. Coluna de acao nunca e ordenavel. */
    sortable?: boolean;
    /** Largura fixa em CSS, ex. `'120px'`. Sem isto a coluna se ajusta. */
    width?: string;
    /** Texto do "i" de 16px ao lado do cabecalho, quando o titulo nao basta. */
    help?: string;
    /**
     * Corta o texto que nao cabe, com reticencias, e mostra o conteudo inteiro
     * em tooltip.
     *
     * E a proposta registrada em **Fora de escopo** para truncamento em coluna
     * de tabela: a altura da linha nunca varia, e o conteudo completo continua
     * alcancavel. Enquanto o guia nao fecha a definicao, o padrao e `false` — a
     * celula quebra em duas linhas, como sempre fez.
     *
     * Sem `width`, o corte acontece a partir de 28ch.
     */
    truncate?: boolean;
    /**
     * Tooltip da celula, por linha.
     *
     * Use para o que **explica** o valor exibido e nao cabe na coluna — a data em
     * que uma modificacao pendente passa a valer, por exemplo. Devolver
     * `undefined` nao mostra tooltip nenhum, que e o certo nas linhas em que nao
     * ha o que explicar.
     *
     * Com `truncate` ligado e sem esta funcao, o tooltip e o proprio texto
     * completo da celula.
     */
    tooltip?: (row: T) => string | undefined;
    /** Texto exibido. Sem isto, o valor bruto de `row[key]`. */
    value?: (row: T) => string;
    /**
     * Segunda linha da celula, menor e em `--text-secondary`.
     *
     * E como o guia agrupa dados que andam juntos — nome e matricula, escola e
     * codigo INEP — sem gastar duas colunas. Os dois ficam alinhados a esquerda.
     */
    secondary?: (row: T) => string;
    /**
     * Exibe um `<s-badge>` no lugar do texto. Use na coluna de status.
     *
     * Badge so no que foge do normal: devolva `null` para "Ativo" ou "Nao" e de
     * o texto em `value`. Com badge em toda linha, nenhuma chama atencao.
     *
     * Quem migra a coluna `pTag` do PrimeNG traduz a severidade assim:
     * `success` → `success`, `secondary` → `secondary`, `info` → `info`,
     * `warn` → `warning`, `danger` → `destructive`, `contrast`/`null` →
     * `default`. Ver `SBadgeTone`.
     */
    badge?: (row: T) => {
        label: string;
        tone?: SBadgeTone;
        icon?: string;
    } | null;
}
/** Ordenacao atual. `null` significa a ordem em que os dados chegaram. */
interface STableSort {
    key: string;
    direction: 'asc' | 'desc';
}
/**
 * Uma acao da ultima coluna.
 *
 * O guia manda que acoes sejam sempre `ghost` ou so-icone, na ultima coluna,
 * centralizadas, e que essa coluna nunca seja ordenavel.
 */
interface STableAction<T> {
    /** Identificador devolvido no output `actionClick`. */
    id: string;
    /** Glifo do Material Symbols. */
    icon: string;
    /** Descricao da acao. Vira `aria-label` e `title`. */
    label: string | ((row: T) => string);
    /** `destructive` escurece so o hover, como no `<s-icon-button>`. */
    /**
     * Variante do botao da acao. O padrao e `ghost`, e quase sempre e o certo.
     *
     * O guia e explicito: acao destrutiva e preenchida "so no modal de
     * confirmacao; contorno ou ghost nos demais contextos". Uma coluna de acoes
     * com um botao vermelho por linha compete com o dado e apaga a diferenca
     * entre a linha que exige atencao e as outras.
     */
    variant?: SButtonVariant;
    /**
     * So o glifo, neutro, ate o usuario apontar: a cor da variante aparece no
     * hover. Com `variant: 'destructive'` e o "excluir" da linha, que nao pinta a
     * coluna de vermelho antes de qualquer intencao. Ver `SIconButtonComponent.text`.
     */
    text?: boolean;
    /** Esconde a acao em linhas onde ela nao se aplica. */
    hidden?: (row: T) => boolean;
    /** Mostra a acao desabilitada, quando some-la confundiria mais. */
    disabled?: (row: T) => boolean;
}
/** O que a tabela mostra no lugar das linhas quando nao ha o que mostrar. */
interface STableEmpty {
    /** Ver `SEmptyStateVariant`. O padrao e `no-data`. */
    variant?: SEmptyStateVariant;
    title?: string;
    description?: string;
    /** String vazia esconde o botao. */
    actionLabel?: string;
    /** Nivel do titulo do estado vazio. Ver `SEmptyStateComponent.headingLevel`; o padrao e 3. */
    headingLevel?: 2 | 3 | 4;
}
/** Payload de `actionClick`. */
interface STableActionEvent<T> {
    action: string;
    row: T;
}
/**
 * O que o template de celula recebe.
 *
 * `$implicit` e a linha, entao `let-linha` basta; `column` esta ali para o
 * template que serve mais de uma coluna.
 */
interface STableCellContext<T> {
    $implicit: T;
    row: T;
    column: STableColumn<T>;
    /** Posicao da linha na pagina, a partir de 0. */
    index: number;
}

/**
 * Tipos da configuracao por `options` do `<s-table>`.
 *
 * Tem a mesma forma do `GenericListOptions` do Professores e do Educacional, de
 * proposito: migrar uma tela e trocar `<app-generic-list>` por `<s-table>` e o
 * nome dos tipos no import — o objeto de configuracao fica como esta.
 *
 * | Antes (app)                  | Aqui                    |
 * | ---------------------------- | ----------------------- |
 * | `GenericListOptions<T>`      | `SListOptions<T>`       |
 * | `GenericListTableConfig<T>`  | `SListTableConfig<T>`   |
 * | `ColumnDataTable<T>`         | `SListColumn<T>`        |
 * | `GenericListActionsConfig`   | `SListActionsConfig`    |
 * | `GenericListActionsTooltips` | `SListActionsTooltips`  |
 * | `GenericListAddButtonConfig` | `SListAddButtonConfig`  |
 * | `GenericListPermissionConfig`| `SListPermissionConfig` |
 * | `TableLazyLoadEvent`         | `SListLazyLoadEvent`    |
 *
 * O que muda de verdade esta registrado no JSDoc de cada campo — sao poucos, e
 * todos vem de a biblioteca nao depender de PrimeNG.
 */
/**
 * Severidade do `p-tag` do PrimeNG, aceita como esta para a coluna nao mudar.
 *
 * Vira o tom do `<s-badge>`: `warn` → `warning`, `danger` → `destructive`,
 * `primary` → `info`, `contrast` e `null` → `default`. Ver `SBadgeTone`.
 */
type SListTagSeverity = 'success' | 'secondary' | 'info' | 'warn' | 'danger' | 'contrast' | 'primary' | null | undefined;
/** Coluna no formato do `ColumnDataTable` das aplicacoes. */
interface SListColumn<T> {
    /** Campo lido de cada linha. */
    field: keyof T;
    /** Texto do cabecalho. */
    header: string;
    /**
     * Nome do campo de ordenacao enviado no `(filter)`. Informar liga a
     * ordenacao da coluna.
     *
     * Pode ser diferente de `field` — e o caso de ordenar "Turma" pelo codigo.
     */
    sort?: string;
    /**
     * Texto da celula, a partir da linha inteira.
     *
     * Aceita marcacao de layout, como antes: `div`, `span`, `p`, `br`,
     * `strong`, `b`, `em`, `i`, `small` e listas, com `class`, `title` e
     * `aria-*`. Imagem, link, iframe, estilo e qualquer outro elemento saem — o
     * texto de dentro fica —, porque o `formatter` costuma misturar dado de quem
     * cadastrou (nome de anexo, de turma) e um `<img src>` ou `<a href>` ali
     * carregaria conteudo de fora. Com `truncate`, e exibido como texto puro.
     */
    formatter?: (row: T) => string;
    /**
     * Exibe um `<s-badge>` no lugar do texto, com a severidade devolvida.
     *
     * **Recebe a linha**, como no Educacional. No Professores recebia o valor do
     * campo: ao migrar, troque `(valor) => ...` por `(linha) => ... linha.campo`.
     */
    pTag?: (row: T) => SListTagSeverity;
    /**
     * Glifo do Material Symbols dentro do badge (`'check'`, `'schedule'`).
     * Classes do PrimeIcons (`'pi pi-check'`) nao existem aqui e sao ignoradas.
     */
    pTagIcon?: string;
    /** Template da celula. Contexto: `$implicit` e a linha, `index` a posicao. */
    bodyTemplate?: TemplateRef<unknown>;
    /**
     * Alinhamento do conteudo e do titulo da coluna.
     *
     * Sem informar, vem do `styleClass`: `text-center` centraliza e
     * `text-right`/`text-end` alinha ao fim, como as telas ja escreviam. Assim o
     * titulo acompanha a celula, e nao fica a esquerda de um valor centralizado.
     */
    align?: STableAlign;
    /** Classe aplicada na `<td>`. */
    styleClass?: string;
    /** Estilo aplicado na `<td>`. */
    style?: Partial<CSSStyleDeclaration>;
    /** Corta com reticencias e mostra o texto inteiro em tooltip. */
    truncate?: boolean;
}
/** Configuracao da tabela, no formato do `GenericListTableConfig`. */
interface SListTableConfig<T> {
    /** Colunas, na ordem. */
    columns: SListColumn<T>[];
    /**
     * Opcoes do seletor de tamanho. Vazio esconde o seletor.
     *
     * Sem informar, valem as do guia (10, 25 e 50) — antes eram 5, 10 e 25.
     */
    rowsPerPageOptions?: number[];
    /** Registros por pagina. Padrao `10`. */
    defaultRows?: number;
    /**
     * Indice (zero-based) do primeiro registro exibido, como no PrimeNG.
     *
     * A tabela acompanha mudancas feitas por fora — e o que o
     * `generic-list-form-base` faz ao voltar para a primeira pagina depois de um
     * filtro.
     */
    first?: number;
    /** `false` esconde o rodape de paginacao. Padrao `true`. */
    paginator?: boolean;
    /**
     * Com `itens` (lista completa), `false` faz a tabela paginar e ordenar em
     * memoria e dispensa o `(filter)` da criacao. Com `itensPaginated`, `false`
     * so dispensa esse `(filter)` inicial: quem pagina e o servidor.
     */
    lazy?: boolean;
    /** Campo de ordenacao inicial — o mesmo valor do `sort` da coluna. */
    sortField?: string;
    /** `1` crescente, `-1` decrescente. Padrao `1`. */
    sortOrder?: number;
    /** Aceito para a migracao nao quebrar; o hover da linha e sempre ligado. */
    rowHover?: boolean;
    /** Aceito para a migracao nao quebrar; a busca e do card de filtros. */
    globalFilterFields?: string[];
    /**
     * Aceito para a migracao nao quebrar; a contagem segue o formato fixo do
     * guia ("1–10 de 47").
     */
    currentPageReportTemplate?: string;
}
/** Quais acoes padrao aparecem na ultima coluna. */
interface SListActionsConfig {
    view?: boolean;
    edit?: boolean;
    remove?: boolean;
    /** Chave de ativo/inativo — so aparece nas linhas que tem o campo `ativo`. */
    inactivate?: boolean;
}
/** Texto de cada acao padrao. Vira `aria-label` e tooltip do botao. */
interface SListActionsTooltips {
    view?: string;
    edit?: string;
    remove?: string;
    inactivate?: string;
}
/** Botao de cadastrar, no cabecalho do card. */
interface SListAddButtonConfig {
    show: boolean;
    label?: string;
    /** Glifo do Material Symbols (`'add'`). Classes do PrimeIcons sao ignoradas. */
    icon?: string;
}
/**
 * Permissoes por acao, conferidas pelo `SPermissionChecker` que a aplicacao
 * registra. Ver `provideSiagePermissionChecker`.
 */
interface SListPermissionConfig {
    /**
     * Liga a conferencia. Desligado, todas as acoes configuradas aparecem.
     *
     * Ligado sem `provideSiagePermissionChecker`, tambem aparecem todas (com
     * aviso no console em desenvolvimento). So esconde botoes: o backend
     * precisa autorizar cada operacao.
     */
    enabled: boolean;
    /** Permissao exigida por acao, no padrao `modulo.acao`. */
    permissions?: {
        view?: string;
        create?: string;
        edit?: string;
        remove?: string;
        inactivate?: string;
    };
}
/** Configuracao completa, no formato do `GenericListOptions`. */
interface SListOptions<T> {
    /** Titulo do card, acima da tabela. */
    title?: string;
    /**
     * Glifo do Material Symbols ao lado do titulo (`'groups'`). Classes do
     * PrimeIcons (`'pi pi-users'`) nao existem aqui e sao ignoradas.
     */
    iconTitle?: string;
    /** Ver `SListAddButtonConfig`. */
    addButton?: SListAddButtonConfig;
    /** Ver `SListActionsConfig`. */
    actions?: SListActionsConfig;
    /** Ver `SListActionsTooltips`. */
    actionsTooltips?: SListActionsTooltips;
    /** Ver `SListTableConfig`. */
    tableConfig: SListTableConfig<T>;
    /**
     * Acoes extras da linha. O `<ng-template #customActions>` projetado na
     * tabela tem prioridade sobre este.
     */
    customActionsTemplate?: TemplateRef<unknown>;
    /** Ver `SListPermissionConfig`. */
    permissionConfig?: SListPermissionConfig;
    /**
     * Rota base de editar e visualizar: `'/trilha-censo/atendimentos'`.
     *
     * Informada, as acoes navegam para `routeBase/editar/:id` e
     * `routeBase/visualizar/:id` em vez de emitir `(edit)` e `(view)`.
     */
    routeBase?: string;
}
/**
 * Pagina vinda do servidor.
 *
 * Aceita os dois formatos em uso — `PaginacaoDto` do Professores
 * (`data`/`total`) e `PagedResult` do Educacional (`items`/`totalCount`) — sem
 * a tela converter nada.
 */
type SPagedData<T> = {
    data?: readonly T[] | null;
    total?: number | null;
} | {
    items?: readonly T[] | null;
    totalCount?: number | null;
};
/**
 * Payload do `(filter)`, com os campos do `TableLazyLoadEvent` do PrimeNG que as
 * telas leem. Por ser compativel, o handler existente continua tipado como
 * estava.
 */
interface SListLazyLoadEvent {
    /** Indice zero-based do primeiro registro da pagina. */
    first: number;
    /** Registros por pagina. */
    rows: number;
    /** Campo de ordenacao (`sort` da coluna), ou `null` sem ordenacao. */
    sortField: string | null;
    /** `1` crescente, `-1` decrescente. */
    sortOrder: number;
}
/** @internal — traduz a severidade do PrimeNG para o tom do `<s-badge>`. */
declare function severityTone(severidade: SListTagSeverity): SBadgeTone;

/** Coluna ja traduzida, com a coluna original quando veio por `options`. */
type ResolvedColumn<T> = STableColumn<T> & {
    source?: SListColumn<T>;
};
/**
 * Tabela de listagem, dentro de card, com os quatro estados obrigatorios.
 *
 * ## Por que existe uma so
 *
 * O Professores tinha duas: `app-table-custom` (a tabela) e `app-generic-list`
 * (titulo, botao de criar e a tabela dentro). A segunda nao acrescentava
 * comportamento de tabela — acrescentava **moldura de tela**.
 *
 * Aqui isso vira composicao, e cada peca tem um dono claro:
 *
 * ```html
 * <s-page-header title="Jornadas" [action]="..." />   <!-- titulo e criar -->
 * <s-filter-card (search)="buscar()" (clear)="limpar()">…</s-filter-card>
 * <s-table [columns]="colunas" [rows]="linhas()" />   <!-- so a tabela -->
 * ```
 *
 * Quem so precisa de tabela usa uma linha; quem precisa da tela inteira usa
 * tres, sem ter que escolher entre dois componentes concorrentes.
 *
 * ## Os quatro estados
 *
 * A tabela resolve os quatro sozinha, e e por isso que a tela nao precisa de
 * `@if` nenhum em volta dela:
 *
 * | Situacao | O que aparece |
 * | --- | --- |
 * | `loading` | linhas de esqueleto nas colunas, depois do limiar de `S_LOADING_DELAY` |
 * | sem linhas | `<s-empty-state>` com a variante de `empty` |
 * | com linhas | as linhas |
 * | erro / sem permissao | `<s-empty-state>`, informando `empty.variant` |
 *
 * O esqueleto **so aparece depois de 800ms** (ajustavel em `S_LOADING_DELAY`).
 * Uma resposta rapida que pisca o esqueleto por 80ms incomoda mais que a
 * espera. Ate la, sem linhas antigas para manter, o corpo fica em branco na
 * altura do esqueleto - nunca com o estado vazio, que afirmaria "nenhum
 * registro" antes de a consulta responder.
 *
 * ## Ordenacao
 *
 * E controlada: a tabela emite `sortChange` e espera receber `sort` de volta.
 * O ciclo do guia e `asc → desc → ordem original`, e quem reordena os dados e a
 * aplicacao — que muitas vezes vai delegar ao backend.
 *
 * ## Migrando do `app-generic-list`
 *
 * A tabela aceita os mesmos inputs, outputs e templates do generic-list do
 * Professores e do Educacional. A troca e so de tag e de nome de tipo:
 *
 * ```html
 * <s-table
 *   [options]="genericListOptions"
 *   [itensPaginated]="paginatedResource.value()"
 *   (filter)="onLazyLoad($event)"
 *   (create)="novo()" (view)="ver($event)" (edit)="editar($event)"
 *   (remove)="onDelete($event)" (inactivate)="onInactive($event)"
 * >
 *   <ng-template #customActions let-item>…</ng-template>
 * </s-table>
 * ```
 *
 * Com `options` informado, a tabela passa a controlar pagina, tamanho e
 * ordenacao por conta propria e avisa por `(filter)`, com `first`/`rows` como
 * o `p-table` fazia — o `onLazyLoad` da tela continua como esta. Os tipos
 * equivalentes estao em `SListOptions`.
 */
declare class STableComponent<T extends object = Record<string, unknown>> implements OnInit, DoCheck {
    /** Colunas exibidas, na ordem. */
    readonly columns: _angular_core.InputSignal<readonly STableColumn<T>[]>;
    /**
     * Nome acessivel da tabela, anunciado pelo leitor de tela.
     *
     * Vira `aria-label` no `<table>`. Use quando o titulo da secao ja diz o que a
     * tabela contem e nao ha motivo para repetir no HTML visivel. Numa tela com
     * mais de uma listagem, e o que distingue uma da outra para quem navega por
     * leitor de tela — que anuncia "tabela" e nada mais quando o nome falta.
     *
     * Quando ambos estiverem preenchidos, `caption` vence: o `<caption>` e visivel
     * **e** acessivel, e a presenca de `aria-label` junto de `<caption>` cria
     * anuncio duplicado. Prefira um ou outro; se informar os dois, `label` sera
     * ignorado e o template usa so `<caption>`.
     */
    readonly label: _angular_core.InputSignal<string>;
    /** Linhas da pagina atual. */
    readonly rows: _angular_core.InputSignal<readonly T[]>;
    /** Acoes da ultima coluna. Vazio esconde a coluna. */
    readonly actions: _angular_core.InputSignal<readonly STableAction<T>[]>;
    /**
     * Templates de celula por `key` de coluna, quando quem monta a tabela nao e
     * quem escreve o template.
     *
     * Usar `<ng-template sTableCell="...">` dentro da propria `<s-table>` e o
     * caminho normal, e continua sendo o recomendado. Este input existe para o
     * componente intermediario — o `<s-crud-list>` e casos parecidos — que
     * recebe os templates da tela e precisa repassa-los para a tabela que ele
     * possui por dentro.
     */
    readonly cellTemplates: _angular_core.InputSignal<Readonly<Record<string, TemplateRef<STableCellContext<T>>>>>;
    /** Ordenacao atual. `null` e a ordem em que os dados chegaram. */
    readonly sort: _angular_core.InputSignal<STableSort | null>;
    /** Consulta em andamento. O esqueleto so aparece apos `S_LOADING_DELAY`. */
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** O que mostrar quando nao ha linhas. Ver `STableEmpty`. */
    readonly empty: _angular_core.InputSignal<STableEmpty>;
    /** Rotulo acessivel da tabela, visivel e anunciado por leitores de tela.
     *
     * Renderiza um `<caption>` dentro do `<table>`. Prefira quando o nome da
     * tabela deve aparecer na interface; quando basta o anuncio invisivel, use
     * `label` (que vira `aria-label`). Evite informar os dois: `caption` tem
     * prioridade, e `label` sera ignorado para nao duplicar o anuncio.
     */
    readonly caption: _angular_core.InputSignal<string>;
    /**
     * Acrescenta a coluna de selecao, antes de todas as outras.
     *
     * Use quando a tela tem acoes em lote — inativar varias jornadas, exportar
     * um recorte. Sem uma acao em lote, a coluna so ocupa espaco e sugere algo
     * que nao acontece.
     */
    readonly selectable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Linhas marcadas. A selecao e controlada, como a ordenacao. */
    readonly selection: _angular_core.InputSignal<readonly T[]>;
    /**
     * Compara linha com linha ao conferir a selecao.
     *
     * O padrao e identidade, que basta quando as linhas da tela sao as mesmas
     * instancias. Informe uma funcao quando os dados forem recriados a cada
     * resposta — comparar por id resolve.
     */
    readonly compareWith: _angular_core.InputSignal<(a: T, b: T) => boolean>;
    /** Pagina atual. O rodape so aparece quando `total` e maior que zero. */
    readonly page: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Registros por pagina. */
    readonly pageSize: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Total do resultado atual, ja filtrado. `0` esconde o rodape. */
    readonly total: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Opcoes do seletor de tamanho. */
    readonly pageSizeOptions: _angular_core.InputSignal<readonly number[]>;
    /** Substantivo usado na contagem. */
    readonly itemsLabel: _angular_core.InputSignal<string>;
    /**
     * Configuracao completa no formato do `GenericListOptions`: colunas, acoes
     * padrao, titulo, botao de cadastrar, permissoes e paginacao.
     *
     * Informada, substitui `columns`, `page`, `pageSize`, `sort` e
     * `pageSizeOptions`: a tabela guarda o estado de pagina e ordenacao e avisa
     * por `(filter)`. E o caminho para migrar tela que usava `app-generic-list`
     * sem reescrever o objeto de configuracao. Tela nova pode usar os inputs
     * soltos.
     */
    readonly options: _angular_core.InputSignal<SListOptions<T> | null>;
    /**
     * Pagina vinda do servidor, como `PaginacaoDto` (`data`/`total`) ou
     * `PagedResult` (`items`/`totalCount`). Tem prioridade sobre `itens`.
     */
    readonly itensPaginated: _angular_core.InputSignal<SPagedData<T> | null | undefined>;
    /**
     * Lista completa, sem paginacao no servidor. Com `tableConfig.lazy: false`,
     * a tabela pagina e ordena em memoria; sem isso, exibe a lista como veio.
     */
    readonly itens: _angular_core.InputSignal<readonly T[] | null | undefined>;
    /**
     * Lista vazia, no modo `options`: com texto, ele aparece sozinho, numa
     * linha, como aviso da propria tela ("Nenhuma certidão adicionada."). Sem
     * texto, vale o estado vazio de "nenhum resultado". O template
     * `#emptyMessage` e `empty` tem prioridade.
     */
    readonly emptyMessage: _angular_core.InputSignal<string>;
    /**
     * Sem a moldura de card (fundo, borda, sombra). Para a tabela que ja mora
     * dentro de um card da tela — duas molduras uma dentro da outra pesam.
     */
    readonly frameless: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Botao de cadastrar do cabecalho (`options.addButton`). */
    readonly create: _angular_core.OutputEmitterRef<void>;
    /** Acao "Visualizar". Nao emite quando `options.routeBase` navega. */
    readonly view: _angular_core.OutputEmitterRef<T>;
    /** Acao "Editar". Nao emite quando `options.routeBase` navega. */
    readonly edit: _angular_core.OutputEmitterRef<T>;
    /** Acao "Remover". A confirmacao e da tela. */
    readonly remove: _angular_core.OutputEmitterRef<T>;
    /**
     * Chave de ativo/inativo. Emite a linha como estava antes do clique; quem
     * confirma e persiste e a tela.
     */
    readonly inactivate: _angular_core.OutputEmitterRef<T>;
    /**
     * Pagina, tamanho ou ordenacao mudaram — e uma vez na criacao, como o
     * `onLazyLoad` do `p-table`, a menos que `tableConfig.lazy` seja `false`.
     * So emite com `options`.
     */
    readonly filter: _angular_core.OutputEmitterRef<SListLazyLoadEvent>;
    /** Nova ordenacao pedida. Ciclo: asc, desc, original. */
    readonly sortChange: _angular_core.OutputEmitterRef<STableSort | null>;
    /** Nova selecao. Quem escuta deve devolver em `selection`. */
    readonly selectionChange: _angular_core.OutputEmitterRef<readonly T[]>;
    /** Acao acionada numa linha. */
    readonly actionClick: _angular_core.OutputEmitterRef<STableActionEvent<T>>;
    /** Nova pagina. */
    readonly pageChange: _angular_core.OutputEmitterRef<number>;
    /** Novo tamanho de pagina. Quem escuta deve voltar para a pagina 1. */
    readonly pageSizeChange: _angular_core.OutputEmitterRef<number>;
    /** Botao do estado vazio. */
    readonly emptyAction: _angular_core.OutputEmitterRef<void>;
    /** Carregando ha tempo suficiente para valer a pena mostrar. */
    protected readonly showSkeleton: _angular_core.Signal<boolean>;
    /**
     * Linhas de esqueleto no corpo: depois do limiar, ou antes dele quando nao ha
     * linhas antigas para manter na tela.
     *
     * No segundo caso elas entram invisiveis (ver `skeletonHidden`), so para
     * reservar a altura. O que nao pode aparecer ali e o estado vazio: "nenhum
     * registro cadastrado" com o botao de cadastrar, durante uma consulta que
     * ainda nao respondeu, e uma afirmacao falsa.
     */
    protected readonly skeletonVisible: _angular_core.Signal<boolean>;
    protected readonly skeletonHidden: _angular_core.Signal<boolean>;
    /** Cinco linhas: o bastante para ler como tabela sem empurrar o rodape. */
    protected readonly skeletonRows: readonly [0, 1, 2, 3, 4];
    private readonly router;
    private readonly permissionChecker;
    private readonly documento;
    private readonly htmlFiltrado;
    private readonly listFirst;
    private readonly listRows;
    private readonly listSort;
    private seenConfig;
    /** Acoes extras da linha: a projetada vence a da configuracao. */
    private readonly projectedActionsTemplate;
    protected readonly addButtonTemplate: _angular_core.Signal<TemplateRef<unknown> | undefined>;
    protected readonly emptyMessageTemplate: _angular_core.Signal<TemplateRef<unknown> | undefined>;
    protected readonly listMode: _angular_core.Signal<boolean>;
    protected readonly customActionsTemplate: _angular_core.Signal<TemplateRef<unknown> | null>;
    protected readonly resolvedColumns: _angular_core.Signal<readonly ResolvedColumn<T>[]>;
    protected readonly resolvedRows: _angular_core.Signal<readonly T[]>;
    protected readonly resolvedTotal: _angular_core.Signal<number>;
    protected readonly resolvedPageSize: _angular_core.Signal<number>;
    protected readonly resolvedPage: _angular_core.Signal<number>;
    protected readonly resolvedPageSizeOptions: _angular_core.Signal<readonly number[]>;
    protected readonly resolvedSort: _angular_core.Signal<STableSort | null>;
    /** Acoes padrao do generic-list, ja filtradas pela configuracao e permissao. */
    private readonly listActions;
    protected readonly resolvedActions: _angular_core.Signal<STableAction<T>[]>;
    /** A chave de ativo/inativo; na linha, so aparece se ela tiver `ativo`. */
    protected readonly hasInactivate: _angular_core.Signal<boolean>;
    protected readonly inactivateLabel: _angular_core.Signal<string>;
    protected readonly addButton: _angular_core.Signal<{
        label: string;
        icon: string;
    } | null>;
    protected readonly titleIcon: _angular_core.Signal<string>;
    protected readonly hasHeader: _angular_core.Signal<boolean>;
    protected readonly isEmpty: _angular_core.Signal<boolean>;
    protected readonly hasFooter: _angular_core.Signal<boolean>;
    protected readonly hasActions: _angular_core.Signal<boolean>;
    /** Colunas mais as duas que nao sao configuraveis: selecao e acoes. */
    protected readonly columnCount: _angular_core.Signal<number>;
    /**
     * Quantas linhas **desta pagina** estao marcadas. A caixa do cabecalho fala
     * da pagina; contar a selecao inteira dava "15 de 10 linhas selecionadas"
     * quando havia marcadas em outras paginas.
     */
    private readonly marcadasNaPagina;
    protected readonly allSelected: _angular_core.Signal<boolean>;
    /** Algumas, mas nao todas — o estado que a caixa do cabecalho representa. */
    protected readonly someSelected: _angular_core.Signal<boolean>;
    protected readonly emptyVariant: _angular_core.Signal<_siage_siage_ui.SEmptyStateVariant>;
    protected readonly emptyTitle: _angular_core.Signal<string>;
    /** O aviso em texto simples de `emptyMessage` (ver o input). */
    protected readonly emptyText: _angular_core.Signal<string>;
    /**
     * Aria-label dinamico do checkbox do cabecalho, refletindo a quantidade
     * selecionada para quem navega por leitor de tela.
     */
    protected readonly headerCheckboxLabel: _angular_core.Signal<string>;
    /**
     * Referencia ao `<s-checkbox>` do cabecalho, para setar `indeterminate` no
     * `<input>` nativo que ele encapsula. O Angular nao expoe esse estado por
     * binding (`[indeterminate]` nao e um atributo HTML refletido em booleano),
     * entao e preciso acesso direto ao DOM.
     */
    private readonly headerCheckboxRef;
    constructor();
    ngOnInit(): void;
    ngDoCheck(): void;
    /** Aplica o que mudou na `tableConfig` desde a ultima verificacao. */
    private syncWithConfig;
    private emitFilter;
    private isAllowed;
    private toTableColumn;
    /** `itens` com `lazy: false`: ordena e recorta a pagina aqui mesmo. */
    private paginateInMemory;
    /** Templates declarados dentro da propria tag. */
    private readonly projectedCellTemplates;
    /**
     * Os dois caminhos somados: o que veio projetado vence o que veio por input,
     * porque quem escreveu o template ali na tela e quem esta mais perto do caso.
     */
    protected readonly cellTemplateMap: _angular_core.Signal<Readonly<Record<string, TemplateRef<STableCellContext<T>>>>>;
    protected cellTemplate(column: STableColumn<T>): TemplateRef<STableCellContext<T>> | null;
    protected cellContext(column: STableColumn<T>, row: T, index: number): STableCellContext<T>;
    /**
     * Tooltip da celula: o que a coluna definir; na falta dele, o texto inteiro,
     * mas so quando a coluna trunca — repetir em tooltip o que ja esta legivel na
     * tela e ruido.
     */
    protected cellTooltip(column: STableColumn<T>, row: T): string;
    protected cellText(column: STableColumn<T>, row: T): string;
    /** Celula do `formatter`: so a marcacao de layout passa (ver `celula-html.ts`). */
    protected cellHtml(column: STableColumn<T>, row: T): string;
    /**
     * A primeira coluna costuma ser o nome, a mais longa; as demais alternam
     * para o esqueleto nao virar uma barra de progresso.
     */
    protected skeletonWidth(index: number): string;
    protected actionLabel(action: STableAction<T>, row: T): string;
    protected isSelected(row: T): boolean;
    protected toggleRow(row: T): void;
    /**
     * A caixa do cabecalho vale para a **pagina atual**, nao para o resultado
     * inteiro: marcar 10 linhas e desmarcar 4.812 sem aviso seria uma surpresa
     * cara. Selecionar tudo alem da pagina, se a tela precisar, e acao dela.
     *
     * Pelo mesmo motivo, o que foi marcado em outras paginas fica como esta: a
     * caixa so marca e desmarca as linhas que a pessoa esta vendo.
     */
    protected toggleAll(): void;
    /** Como a linha e chamada para o leitor de tela: o texto da primeira coluna. */
    protected rowLabel(row: T): string;
    /**
     * A chave de ativo/inativo so avisa a tela; quem muda `row.ativo` e ela,
     * depois de confirmar e persistir. Ate la a chave volta para o valor da
     * linha - se a tela cancelar, o `[ngModel]` nao mudaria e a chave ficaria
     * invertida, mostrando um estado que nao e o do registro.
     */
    protected alternarAtivo(row: T & {
        ativo: unknown;
    }, chave: NgModel): void;
    protected visibleActions(row: T): readonly STableAction<T>[];
    /**
     * Toda acao sai por `actionClick`; as padrao do generic-list tambem pelo
     * output com o nome dela, que e o que a tela migrada escuta.
     */
    protected runAction(action: STableAction<T>, row: T): void;
    /** Com `routeBase` e `id`, navega como o Educacional; sem, emite. */
    private navigateOrEmit;
    protected hasActiveFlag(row: T): row is T & {
        ativo: unknown;
    };
    protected goToPage(page: number): void;
    protected changePageSize(size: number): void;
    /** `aria-sort` da coluna, para o leitor de tela anunciar a ordenacao. */
    protected ariaSort(column: STableColumn<T>): 'ascending' | 'descending' | 'none' | null;
    protected sortIcon(column: STableColumn<T>): string;
    /**
     * Ciclo do guia: ascendente, descendente, ordem original. Com `options`, a
     * tabela guarda a ordenacao, volta para a primeira pagina (como o `p-table`)
     * e avisa por `(filter)`; a ordem original sai como `sortField: null`.
     */
    protected toggleSort(column: ResolvedColumn<T>): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<STableComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<STableComponent<any>, "s-table", never, { "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "actions": { "alias": "actions"; "required": false; "isSignal": true; }; "cellTemplates": { "alias": "cellTemplates"; "required": false; "isSignal": true; }; "sort": { "alias": "sort"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "empty": { "alias": "empty"; "required": false; "isSignal": true; }; "caption": { "alias": "caption"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; "selection": { "alias": "selection"; "required": false; "isSignal": true; }; "compareWith": { "alias": "compareWith"; "required": false; "isSignal": true; }; "page": { "alias": "page"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "total": { "alias": "total"; "required": false; "isSignal": true; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; "isSignal": true; }; "itemsLabel": { "alias": "itemsLabel"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "itensPaginated": { "alias": "itensPaginated"; "required": false; "isSignal": true; }; "itens": { "alias": "itens"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "frameless": { "alias": "frameless"; "required": false; "isSignal": true; }; }, { "create": "create"; "view": "view"; "edit": "edit"; "remove": "remove"; "inactivate": "inactivate"; "filter": "filter"; "sortChange": "sortChange"; "selectionChange": "selectionChange"; "actionClick": "actionClick"; "pageChange": "pageChange"; "pageSizeChange": "pageSizeChange"; "emptyAction": "emptyAction"; }, ["projectedActionsTemplate", "addButtonTemplate", "emptyMessageTemplate", "projectedCellTemplates"], never, true, never>;
}

/**
 * Template proprio para uma coluna, quando o texto nao da conta.
 *
 * A coluna comum e declarada em `STableColumn` — rotulo, alinhamento, badge,
 * valor formatado. Isso cobre a maioria das celulas, e por isso continua sendo
 * o caminho padrao. O que nao cabe ali e a celula que **age**: um botao que
 * abre o detalhe de "em uso", um link para outra tela, um progresso.
 *
 * Escrever a excecao como template mantem a configuracao declarativa para o
 * resto da tabela, sem obrigar a biblioteca a prever cada caso — que e como
 * uma coluna nova terminava virando um `if` a mais dentro do componente.
 *
 * @example
 * ```html
 * <s-table [columns]="colunas" [rows]="linhas()">
 *   <ng-template sTableCell="emUso" let-linha>
 *     @if (linha.emUso) {
 *       <s-button variant="ghost" icon="link" (click)="verUsos(linha)">Ver usos</s-button>
 *     } @else {
 *       <span aria-hidden="true">—</span>
 *     }
 *   </ng-template>
 * </s-table>
 * ```
 */
declare class STableCellDirective<T = Record<string, unknown>> {
    /** `key` da coluna que este template desenha. */
    readonly column: _angular_core.InputSignal<string>;
    /** @internal — lido pela tabela, nao pela aplicacao. */
    readonly template: TemplateRef<STableCellContext<T>>;
    /**
     * Tipa `let-linha` no template, em vez de entregar `any`.
     *
     * Sem isto o `strictTemplates` trata o contexto como implicito e qualquer
     * erro de nome so aparece em execucao.
     */
    static ngTemplateContextGuard<T>(_diretiva: STableCellDirective<T>, _contexto: unknown): _contexto is STableCellContext<T>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<STableCellDirective<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<STableCellDirective<any>, "ng-template[sTableCell]", never, { "column": { "alias": "sTableCell"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
/** Mapa de templates por `key` de coluna, como a tabela os consome. */
type STableCellTemplates<T> = Readonly<Record<string, TemplateRef<STableCellContext<T>>>>;
/** @internal — usado pela tabela e pelo `<s-crud-list>`. */
declare function mapCellTemplates<T>(diretivas: readonly STableCellDirective<T>[]): Record<string, TemplateRef<STableCellContext<T>>>;

/**
 * Rodape da tabela: registros por pagina, contagem e navegacao.
 *
 * Encapsula o `<s-record-count>` e o seletor de tamanho, para que a tela nao
 * precise montar os tres a mao. Fica **sempre no rodape da tabela**, nunca
 * flutuante.
 *
 * Nao envolve o `mat-paginator`: ele traz o proprio texto ("1 – 10 of 47"), a
 * propria ordem de controles e um `MatPaginatorIntl` global para traduzir. Como
 * o formato da contagem e fixo pelo guia e o seletor usa o `<s-select>` do
 * design system, sobrava pouco do Material para aproveitar.
 */
declare class SPaginationComponent {
    /** Pagina atual, comecando em 1. */
    readonly page: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Registros por pagina. */
    readonly pageSize: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Nome acessivel da navegacao entre paginas.
     *
     * Vira `aria-label` no `<nav>`. So precisa mudar quando a tela tem mais de uma
     * listagem paginada — dai "Paginação" sozinho deixa de distinguir qual.
     */
    readonly label: _angular_core.InputSignal<string>;
    /** Total do resultado atual, ja filtrado. */
    readonly total: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Opcoes do seletor de tamanho. O guia fixa 10, 25 e 50. */
    readonly pageSizeOptions: _angular_core.InputSignal<readonly number[]>;
    /** Substantivo usado na contagem sem paginacao. */
    readonly itemsLabel: _angular_core.InputSignal<string>;
    /** Esconde o seletor de tamanho, quando a tela nao permite trocar. */
    readonly hidePageSize: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Nova pagina escolhida. */
    readonly pageChange: _angular_core.OutputEmitterRef<number>;
    /** Novo tamanho de pagina. Quem escuta deve voltar para a pagina 1. */
    readonly pageSizeChange: _angular_core.OutputEmitterRef<number>;
    protected readonly totalPaginas: _angular_core.Signal<number>;
    protected readonly naPrimeira: _angular_core.Signal<boolean>;
    protected readonly naUltima: _angular_core.Signal<boolean>;
    protected readonly opcoesDeTamanho: _angular_core.Signal<SOption<number>[]>;
    protected irPara(pagina: number): void;
    protected trocarTamanho(tamanho: number | null): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SPaginationComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SPaginationComponent, "s-pagination", never, { "page": { "alias": "page"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "total": { "alias": "total"; "required": false; "isSignal": true; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; "isSignal": true; }; "itemsLabel": { "alias": "itemsLabel"; "required": false; "isSignal": true; }; "hidePageSize": { "alias": "hidePageSize"; "required": false; "isSignal": true; }; }, { "pageChange": "pageChange"; "pageSizeChange": "pageSizeChange"; }, never, never, true, never>;
}

/**
 * Faixa de contagem do resultado atual.
 *
 * O formato e fixo pelo guia, e vale a pena ler devagar porque as tres regras
 * costumam ser quebradas por engano:
 *
 * 1. **`1–10 de 47`**, com meia-risca e **sem espacos** em volta dela. Nao e
 *    hifen, nao e "1 - 10".
 * 2. Sem paginacao, some a faixa e fica so **`12 registros`**.
 * 3. Com zero resultados **nao renderiza nada** — quem comunica ausencia e o
 *    `<s-empty-state>`, que explica o motivo e oferece a acao certa.
 *
 * `total` e sempre o total do **resultado atual**, ja filtrado — nunca o total
 * da base. Mostrar 4.812 quando o filtro devolveu 3 desorienta.
 */
declare class SRecordCountComponent {
    /** Pagina atual, comecando em 1. */
    readonly page: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Registros por pagina. `0` significa sem paginacao. */
    readonly pageSize: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Total do resultado atual, ja filtrado. */
    readonly total: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Substantivo da contagem sem paginacao: `12 registros`, `12 turmas`. */
    readonly itemsLabel: _angular_core.InputSignal<string>;
    protected readonly texto: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SRecordCountComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SRecordCountComponent, "s-record-count", never, { "page": { "alias": "page"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "total": { "alias": "total"; "required": false; "isSignal": true; }; "itemsLabel": { "alias": "itemsLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Conversao entre os dois vocabularios de paginacao que o SIAGE usa.
 *
 * O `<s-pagination>` e o `<s-table>` falam `page` (1-based) e `pageSize`,
 * porque e o que aparece na tela: "página 2 de 5". Paginadores baseados em
 * `p-table` (PrimeNG) — o que a listagem antiga usava — falam `first`, o
 * indice 0-based do primeiro registro da pagina, e `rows`.
 *
 * Quem migra uma tela do PrimeNG para o `<s-table>` traduz o evento de
 * paginacao com estas duas funcoes, em vez de reescrever a conta em cada tela.
 */
/** `first`/`rows` do PrimeNG -> `page` (1-based) do `<s-table>`. */
declare function pageFromFirst(first: number, rows: number): number;
/** `page` (1-based) do `<s-table>` -> `first` (0-based) do PrimeNG. */
declare function firstFromPage(page: number, pageSize: number): number;

/**
 * Confere se o usuario tem uma permissao.
 *
 * A biblioteca **nao conhece** o sistema de permissoes de cada aplicacao — o
 * Educacional usa `ngx-permissions`, outro sistema pode ler do token. Ela so
 * pergunta; a aplicacao implementa e responde. E o que o `<s-table>` usa para
 * esconder acoes quando `options.permissionConfig.enabled` esta ligado.
 *
 * Regras como "administrador pode tudo" sao da implementacao, nao daqui.
 *
 * **Esconder acao nao e controle de acesso.** O botao some da tela, mas a
 * rota e o endpoint continuam la: o backend precisa autorizar cada operacao,
 * e as rotas de edicao precisam de guard proprio.
 *
 * @example
 * ```ts
 * @Injectable({ providedIn: 'root' })
 * export class NgxPermissionChecker extends SPermissionChecker {
 *   private readonly permissoes = inject(NgxPermissionsService);
 *
 *   has(permission: string): boolean {
 *     const atuais = this.permissoes.getPermissions();
 *     return permission in atuais || PERFIL.ADMIN in atuais;
 *   }
 * }
 * ```
 */
declare abstract class SPermissionChecker {
    /** `true` quando o usuario atual tem a permissao. */
    abstract has(permission: string): boolean;
}
/**
 * Registra o verificador de permissoes da aplicacao.
 *
 * Sem ele, a tabela mostra todas as acoes configuradas mesmo com
 * `permissionConfig.enabled` — esconder tudo por falta de configuracao
 * pareceria defeito na tela, nao falta de permissao. Em desenvolvimento, o
 * `<s-table>` e o `<s-crud-form>` avisam no console quando isso acontece.
 *
 * ```ts
 * // app.config.ts
 * providers: [provideSiagePermissionChecker(NgxPermissionChecker)]
 * ```
 */
declare function provideSiagePermissionChecker(checker: Type<SPermissionChecker>): EnvironmentProviders;

/**
 * Placeholder no formato do conteudo final.
 *
 * O quarto dos estados obrigatorios do guia. A regra e curta e vale sempre:
 * **nunca spinner central** em tabela ou card — spinner so dentro de botao em
 * carregamento. O esqueleto ocupa o mesmo espaco que o dado vai ocupar, entao a
 * tela nao salta quando a resposta chega.
 *
 * Quando mostrar e decisao da aplicacao. Para uma tabela, o `<s-table>` ja
 * cuida disso com o limiar de `S_LOADING_DELAY`.
 */
declare class SSkeletonComponent {
    /** Largura. Numero vira px; string passa direto (`'60%'`). */
    readonly width: _angular_core.InputSignal<string | number>;
    /** Altura. Numero vira px; string passa direto. */
    readonly height: _angular_core.InputSignal<string | number>;
    /** Deixa o bloco redondo — para o lugar de um avatar. */
    readonly circle: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected readonly larguraCss: _angular_core.Signal<string>;
    protected readonly alturaCss: _angular_core.Signal<string>;
    protected readonly raioCss: _angular_core.Signal<"var(--radius-full, 9999px)" | "var(--radius-control, 8px)">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SSkeletonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SSkeletonComponent, "s-skeleton", never, { "width": { "alias": "width"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "circle": { "alias": "circle"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * Esqueleto no formato de uma tabela.
 *
 * Desenha `rows` x `columns` blocos com a mesma altura de linha do
 * `<s-table>`, para que a troca do esqueleto pelos dados nao mova nada.
 *
 * `hasSelection` e `hasActions` desenham as colunas nao configuraveis do
 * `<s-table>` (caixa de selecao e acoes) com a mesma largura de conteudo
 * (`width:1%`) que elas tem na tabela real — sem isso, a grade uniforme
 * alargava a coluna de acoes e o esqueleto "pulava" na troca pelos dados.
 */
declare class STableSkeletonComponent {
    /** Linhas desenhadas. */
    readonly rows: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Colunas de dados desenhadas — sem contar selecao e acoes. */
    readonly columns: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Desenha a coluna de caixas de selecao, estreita como na tabela real. */
    readonly hasSelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Desenha a coluna de acoes, estreita como na tabela real. */
    readonly hasActions: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected readonly linhas: _angular_core.Signal<number[]>;
    protected readonly colunasDeDados: _angular_core.Signal<number[]>;
    protected readonly colunasCss: _angular_core.Signal<string>;
    protected larguraDaCelula(coluna: number): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<STableSkeletonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<STableSkeletonComponent, "s-table-skeleton", never, { "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "hasSelection": { "alias": "hasSelection"; "required": false; "isSignal": true; }; "hasActions": { "alias": "hasActions"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface SFilterActiveChip {
    readonly key: string;
    readonly label: string;
    readonly value: unknown;
    readonly text: string;
    readonly removeLabel: string;
}
/**
 * Formata um valor de filtro quando a tela tem uma regra de exibicao propria.
 *
 * Retorne `null` para deixar o card usar o rotulo de `optionMap`, data em
 * `dd/MM/yyyy` ou texto padrao. Assim a tela so especializa os casos de
 * dominio sem perder os formatos consistentes da biblioteca.
 */
type SFilterValueFormatter = (key: string, value: unknown) => string | null;
/**
 * Contrato de persistencia dos filtros do card.
 *
 * A implementacao padrao usa `sessionStorage` porque filtro de listagem e
 * contexto de navegacao: voltar para a tela na mesma sessao deve manter a
 * consulta, mas abrir o sistema outro dia nao deve herdar uma busca antiga que
 * esconde registros sem o usuario perceber.
 */
declare abstract class SFilterStorage {
    abstract get(key: string): Record<string, unknown> | null;
    abstract set(key: string, value: Record<string, unknown>): void;
    abstract remove(key: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SFilterStorage, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SFilterStorage>;
}
/**
 * Troca o armazenamento de filtros sem colocar HTTP ou regra de app no card.
 *
 * A classe precisa de `@Injectable()` propria: sem ela, o Angular herda a
 * fabrica de `SFilterStorage` e entrega o `SSessionFilterStorage` padrao, sem
 * erro nenhum.
 */
declare function provideSiageFilterStorage(storage: Type<SFilterStorage>): Provider;
declare class SSessionFilterStorage extends SFilterStorage {
    get(key: string): Record<string, unknown> | null;
    set(key: string, value: Record<string, unknown>): void;
    remove(key: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SSessionFilterStorage, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SSessionFilterStorage>;
}
/**
 * Bloco de filtros em card proprio, acima de toda tabela de listagem.
 *
 * ## Vocabulario fixo
 *
 * Os dois botoes se chamam **Buscar** e **Limpar**. Nao "Aplicar", nao
 * "Filtrar", nao "Pesquisar". Sao os mesmos verbos em todos os sistemas da
 * rede, e trocar um deles numa tela quebra o reconhecimento em todas as
 * outras — por isso os rotulos nao sao configuraveis por engano: ha inputs,
 * mas com esses padroes.
 *
 * Eles formam um grupo unico ao pe, a direita, com **Limpar antes de Buscar**:
 * a acao de confirmar fica sempre na posicao mais a direita, como no modal.
 *
 * ## A grade se ajusta a largura
 *
 * Cabem tantas colunas quantas a largura permitir, cada uma com no minimo
 * 240px — o mesmo card serve a tela cheia, a janela dividida e o tablet, sem
 * um numero fixo de colunas que so vale para uma delas. Campo que pede mais
 * espaco leva `class="s-filter-card__largo"` (duas colunas) ou
 * `class="s-filter-card__inteiro"` (a linha inteira).
 *
 * ## Enter tambem busca
 *
 * O card escuta `Enter` em qualquer campo projetado e dispara `search`. Quem
 * preenche um filtro e tecla Enter espera que a consulta aconteca, e sem isto
 * cada tela teria que ligar isso a mao em cada campo.
 *
 * @example
 * ```html
 * <s-filter-card (search)="buscar()" (clear)="limpar()">
 *   <s-field label="Nome">
 *     <s-input icon="search" formControlName="nome" />
 *   </s-field>
 *   <s-field label="Status">
 *     <s-select [options]="status" placeholder="Todos" formControlName="status" />
 *   </s-field>
 * </s-filter-card>
 * ```
 */
declare class SFilterCardComponent {
    /** Titulo do bloco. */
    readonly title: _angular_core.InputSignal<string>;
    /** Rotulo do botao de buscar. Trocar quebra o vocabulario do ecossistema. */
    readonly searchLabel: _angular_core.InputSignal<string>;
    /** Rotulo do botao de limpar. */
    readonly clearLabel: _angular_core.InputSignal<string>;
    /** Desabilita o botao de limpar — util quando nenhum filtro esta preenchido. */
    readonly clearDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Buscar so age com algum filtro preenchido no `form`: sem nenhum, a
     * consulta seria a lista inteira, que a tela nao quer trazer por engano.
     */
    readonly requireValue: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Desabilita o botao Buscar (e o Enter) enquanto nenhum campo do `form` tem
     * valor. Diferente de `requireValue`, que deixa o botao habilitado e so
     * ignora o clique, este avisa a pessoa de antemao que ainda nao ha o que
     * buscar. Precisa do `form` (projetado ou via input); sem ele nao desabilita.
     * Vazio e `null`, `undefined`, `''`, lista vazia e intervalo sem inicio e fim.
     */
    readonly disableSearchWithoutValue: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Com `requireValue` ou `disableSearchWithoutValue`, remover o ultimo chip ou
     * usar "Limpar todos" so atualiza os chips, sem emitir `search`: a consulta
     * sem filtro seria justamente a que a tela quer evitar. Ligue quando, nessa
     * tela, esvaziar os filtros significa voltar a lista completa. Sem as duas
     * travas, a busca sempre e emitida e este input nao tem efeito.
     */
    readonly searchWhenEmptied: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Limpar tambem esvazia o `form` (`reset()`), antes de emitir `clear`. */
    readonly resetOnClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Os chips de filtro ativo depois da busca. Desligue quando a tela usa o
     * `form` so para `requireValue`/`resetOnClear`, sem os chips.
     */
    readonly showActiveFilters: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Consulta em andamento: o botao Buscar entra em carregamento. */
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Identificador estavel da listagem para restaurar filtros ao voltar a ela.
     *
     * Sem `filterId`, o card nao grava nada: filtros sem identidade nao devem
     * disputar a mesma chave no armazenamento da sessao.
     */
    readonly filterId: _angular_core.InputSignal<string>;
    /**
     * Formulario de filtros quando a tela prefere passar explicitamente.
     *
     * Normalmente o card encontra o `[formGroup]` projetado sozinho; este input
     * existe para composicoes que encapsulam o form em outro componente.
     */
    readonly form: _angular_core.InputSignal<FormGroup<any> | null>;
    /**
     * Rotulos humanos por chave do formulario.
     *
     * O nome tecnico do controle raramente e o texto que a pessoa viu no campo;
     * chips usam este mapa para repetir a linguagem da tela.
     */
    readonly labelMap: _angular_core.InputSignal<Record<string, string>>;
    /**
     * Opcoes por chave para transformar ids de select/multiselect em rotulos.
     *
     * O formulario guarda o valor de dominio, mas o chip precisa mostrar o mesmo
     * texto escolhido na lista.
     */
    readonly optionMap: _angular_core.InputSignal<Record<string, readonly SOption<unknown>[]>>;
    /**
     * Formata valores que nao cabem em `optionMap`.
     *
     * Use para regras de dominio; datas e arrays ja recebem formato legivel pelo
     * card para manter a paridade entre listagens.
     */
    readonly valueFormatter: _angular_core.InputSignal<SFilterValueFormatter | null>;
    /** Dispara a consulta. Tambem emitido no `Enter` de qualquer campo. */
    readonly search: _angular_core.OutputEmitterRef<void>;
    /** Redefine os campos. */
    readonly clear: _angular_core.OutputEmitterRef<void>;
    /**
     * Filtros restaurados de `filterId` ao abrir a tela.
     *
     * A restauracao so preenche o formulario; quem consulta precisa saber que ha
     * filtros valendo para buscar de novo, senao a tabela mostra o resultado sem
     * filtro debaixo de chips que dizem o contrario.
     */
    readonly restored: _angular_core.OutputEmitterRef<void>;
    private readonly storage;
    private readonly projectedForm;
    private readonly currentForm;
    private readonly restoredFilters;
    private readonly activeChips;
    protected readonly chips: _angular_core.Signal<readonly SFilterActiveChip[]>;
    private readonly formHasValue;
    protected readonly searchDisabled: _angular_core.Signal<boolean>;
    constructor();
    /**
     * Enter num campo de digitacao busca. So nele:
     * - num botao, Enter e o clique dele - em "Limpar", buscar seria o oposto
     *   do pedido;
     * - num `<textarea>`, quebra linha;
     * - no gatilho de um select, abre o painel;
     * - quando o proprio campo ja usou o Enter (o autocomplete escolhendo a
     *   opcao destacada, o chips criando uma etiqueta), o evento chega aqui com
     *   `defaultPrevented`, e a tecla ja teve dono.
     *
     * E nada acontece durante `loading`: o botao Buscar esta bloqueado, e o
     * teclado nao pode ser um atalho para disparar a mesma consulta de novo.
     */
    protected aoTeclarEnter(evento: Event): void;
    /**
     * `refresh` e a remocao de chip (ou "Limpar todos"): os chips e o
     * armazenamento sempre acompanham o form. Se o form ficou vazio e a tela
     * exige valor (`requireValue`/`disableSearchWithoutValue`), nao emite
     * `search`, salvo com `searchWhenEmptied`.
     */
    protected searchFilters(refresh?: boolean): void;
    protected removeFilter(chip: SFilterActiveChip): void;
    protected clearActiveFilters(): void;
    protected clearFilters(): void;
    private syncHasValue;
    private formValue;
    private updateChips;
    private persist;
    private createChips;
    private createChip;
    private formatValue;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SFilterCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SFilterCardComponent, "s-filter-card", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "searchLabel": { "alias": "searchLabel"; "required": false; "isSignal": true; }; "clearLabel": { "alias": "clearLabel"; "required": false; "isSignal": true; }; "clearDisabled": { "alias": "clearDisabled"; "required": false; "isSignal": true; }; "requireValue": { "alias": "requireValue"; "required": false; "isSignal": true; }; "disableSearchWithoutValue": { "alias": "disableSearchWithoutValue"; "required": false; "isSignal": true; }; "searchWhenEmptied": { "alias": "searchWhenEmptied"; "required": false; "isSignal": true; }; "resetOnClear": { "alias": "resetOnClear"; "required": false; "isSignal": true; }; "showActiveFilters": { "alias": "showActiveFilters"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "filterId": { "alias": "filterId"; "required": false; "isSignal": true; }; "form": { "alias": "form"; "required": false; "isSignal": true; }; "labelMap": { "alias": "labelMap"; "required": false; "isSignal": true; }; "optionMap": { "alias": "optionMap"; "required": false; "isSignal": true; }; "valueFormatter": { "alias": "valueFormatter"; "required": false; "isSignal": true; }; }, { "search": "search"; "clear": "clear"; "restored": "restored"; }, ["projectedForm"], ["*"], true, never>;
}

/**
 * Natureza da mensagem.
 *
 * `info` e o unico lugar do sistema em que o token `--info` aparece — o guia
 * proibe usa-lo em qualquer elemento clicavel, para que azul-claro nunca seja
 * confundido com "clique aqui".
 */
type SAlertType = 'info' | 'success' | 'warning' | 'error';
/**
 * Banner inline: feedback contextual que **permanece na pagina** ate a condicao
 * ser resolvida.
 *
 * A diferenca para o toast e a persistencia, nao a aparencia. Toast confirma
 * algo que ja aconteceu e some; alerta descreve uma condicao que continua
 * valendo — "esta jornada tem alteracao aguardando aprovacao" segue verdade
 * depois de quatro segundos.
 *
 * Os dois compartilham a linguagem visual (fundo tintado, borda, icone
 * on-surface), mas o alerta usa a versao mais discreta: tint 12% e borda 24%,
 * contra 24% e cor cheia do toast. Ele fica na pagina; nao precisa competir.
 *
 * **A cor nunca vem sozinha.** Todo tipo traz um icone, porque cerca de 8% dos
 * homens nao distingue vermelho de verde.
 */
declare class SAlertComponent {
    /** Natureza da mensagem. Ver `SAlertType`. */
    readonly type: _angular_core.InputSignal<SAlertType>;
    /** Titulo curto. Sem ele, so o conteudo projetado aparece. */
    readonly title: _angular_core.InputSignal<string>;
    /** Permite dispensar o aviso antes de resolver a condicao ou terminar o prazo. */
    readonly dismissible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Prazo em milissegundos para emitir `close`. Zero ou negativo mantem o aviso permanente.
     *
     * Use apenas em mensagens transitorias: condicoes que ainda exigem atencao
     * devem permanecer visiveis. Alterar o prazo reinicia a contagem.
     */
    readonly duration: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Disparado pelo botao de fechar ou ao terminar `duration`.
     *
     * O alerta **nao se esconde sozinho**: quem decide e a tela, que o tira com
     * um `@if` - e pode, por exemplo, lembrar que a pessoa ja dispensou o aviso.
     *
     * ```html
     * @if (mostrarAviso()) {
     *   <s-alert dismissible (close)="mostrarAviso.set(false)">...</s-alert>
     * }
     * ```
     */
    readonly close: _angular_core.OutputEmitterRef<void>;
    protected readonly glifo: _angular_core.Signal<string>;
    private relogio;
    constructor();
    protected fechar(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SAlertComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SAlertComponent, "s-alert", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; "duration": { "alias": "duration"; "required": false; "isSignal": true; }; }, { "close": "close"; }, never, ["*"], true, never>;
}

/**
 * Natureza do aviso.
 *
 * `error` e o unico que **nao fecha sozinho**: uma falha que some em quatro
 * segundos e uma falha que o usuario nao leu.
 */
type SToastType = 'success' | 'info' | 'warning' | 'error';
/** O que a aplicacao pede ao servico. */
interface SToastConfig {
    /** Titulo curto. */
    title: string;
    /** Uma linha de detalhe, quando o titulo nao basta. */
    message?: string;
    /** Ver `SToastType`. O padrao e `success`. */
    type?: SToastType;
    /**
     * Quanto tempo ate fechar sozinho, em ms.
     *
     * Sem isto, vale o padrao de `provideSiageToast`: 4000 para os demais tipos
     * e **nunca** para `error`. Informe `0` para tornar qualquer aviso
     * permanente.
     */
    duration?: number;
}
/** Opcoes dos atalhos (`success`, `info`, `warning`, `error`). */
type SToastOptions = Pick<SToastConfig, 'duration'>;
/**
 * Padroes da aplicacao inteira, registrados uma vez com `provideSiageToast`.
 *
 * Um aviso com `duration` proprio sempre vence o padrao.
 */
interface SToastDefaults {
    /** Prazo, em ms, de sucesso, informacao e aviso. Padrao: 4000. */
    duration: number;
    /**
     * Prazo, em ms, de erro. Padrao: `0` — erro nao fecha sozinho. Mude so se a
     * aplicacao tiver outro canal para a falha (um alerta na pagina, por exemplo).
     */
    errorDuration: number;
}
/** Um aviso ja na pilha. */
interface SToast extends SToastConfig {
    /** Identificador gerado pelo servico. */
    id: number;
    type: SToastType;
}
/** Quantos avisos ficam visiveis ao mesmo tempo. */
declare const S_TOAST_MAXIMO = 3;
/** Tempo padrao de permanencia, em ms. */
declare const S_TOAST_DURACAO = 4000;

/**
 * Avisos que confirmam algo concluido, sem exigir atencao nem clique.
 *
 * ## Como a pilha funciona
 *
 * Ficam **tres visiveis**, o mais recente no topo. A partir do quarto, o
 * primeiro que foi acionado sai para dar lugar — o mais antigo ja teve tempo de
 * tela, e empilhar seis avisos vira uma parede que ninguem le.
 *
 * ## Por que um unico snackbar
 *
 * O `MatSnackBar` cobre posicao, animacao, overlay e tema, mas mostra **um por
 * vez**: `openFromComponent` fecha o anterior ao abrir o proximo. Entao o
 * servico abre *um* snackbar cujo conteudo e a pilha inteira, e empurra itens
 * nele. E por isso que o prazo de cada aviso vive aqui, e nao no `duration` do
 * Material — aquele encerraria o container inteiro, levando junto os outros
 * dois.
 *
 * Pelo mesmo motivo o anuncio para leitor de tela e feito item a item: com um
 * container de vida longa, so o primeiro seria anunciado.
 *
 * @example
 * ```ts
 * private readonly toast = inject(SToastService);
 *
 * salvar(): void {
 *   this.servico.salvar().subscribe({
 *     next: () => this.toast.success('Jornada salva', 'As alterações foram aplicadas.'),
 *     error: () => this.toast.error('Não foi possível salvar'),
 *   });
 * }
 *
 * // Prazo proprio, em ms, so para este aviso:
 * this.toast.info('Sincronizando', 'Pode levar alguns segundos.', { duration: 8000 });
 * ```
 */
declare class SToastService {
    private readonly snackBar;
    private readonly announcer;
    private readonly padroes;
    /** A pilha visivel, do mais recente para o mais antigo. */
    readonly toasts: _angular_core.WritableSignal<readonly SToast[]>;
    private referencia?;
    private readonly relogios;
    private sequencia;
    /** Confirma uma acao concluida. */
    success(title: string, message?: string, options?: SToastOptions): number;
    /** Informa algo que o usuario nao pediu, mas precisa saber. */
    info(title: string, message?: string, options?: SToastOptions): number;
    /** Chama atencao para algo que ainda vai dar problema. */
    warning(title: string, message?: string, options?: SToastOptions): number;
    /** Comunica uma falha. **Nao fecha sozinho.** */
    error(title: string, message?: string, options?: SToastOptions): number;
    /** Publica um aviso e devolve o id, para poder fecha-lo antes da hora. */
    show(config: SToastConfig): number;
    /** Fecha um aviso pelo id. */
    dismiss(id: number): void;
    /**
     * Segura o prazo de um aviso enquanto a pessoa esta nele - com o mouse em
     * cima ou o foco no botao de fechar. Sem isto, quem le devagar ou navega
     * pelo teclado ate o "fechar" via o aviso sumir no caminho (WCAG 2.2.1).
     *
     * Chamado pela pilha; a aplicacao nao precisa chamar.
     */
    pause(id: number): void;
    /** Retoma o prazo de onde parou. Ver `pause`. */
    resume(id: number): void;
    /** Fecha todos. Util ao trocar de rota. */
    clear(): void;
    private abrirSePreciso;
    private anunciar;
    private agendarFechamento;
    private iniciarRelogio;
    private pararRelogio;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SToastService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SToastService>;
}

/** Padroes em vigor. Sem `provideSiageToast`, os do guia. */
declare const S_TOAST_DEFAULTS: InjectionToken<SToastDefaults>;
/**
 * Troca o prazo padrao dos avisos da aplicacao inteira.
 *
 * Os 4s do guia servem a maioria das telas; uma aplicacao de uso em sala, com
 * o professor olhando para a turma e nao para a tela, pode querer mais.
 *
 * @example
 * ```ts
 * // app.config.ts
 * providers: [provideSiageToast({ duration: 6000 })]
 * ```
 */
declare function provideSiageToast(defaults: Partial<SToastDefaults>): EnvironmentProviders;

/**
 * Formato do dialogo.
 *
 * - `default` — decisao comum. Cancelar a esquerda, acao nomeada a direita.
 * - `destructive` — remove ou desfaz. A acao de confirmar vem preenchida em
 *   `--destructive`, e o rotulo dela **nomeia o que vai acontecer**: nunca um
 *   "OK" generico numa confirmacao destrutiva.
 * - `result` — comunica um desfecho. Botao unico em largura total; nao ha
 *   decisao a tomar, so ciencia a dar.
 */
type SModalVariant = 'default' | 'destructive' | 'result';
/**
 * Largura semantica do dialogo.
 *
 * O guia define explicitamente o dialogo medio em 520px. `sm` (400px) atende
 * confirmacoes curtas que vinham do `showModal()` antigo; `lg` (720px) atende
 * formularios compactos sem transformar modal em pagina. Se `width` vier junto,
 * ele vence para manter compatibilidade com chamadas existentes.
 */
type SModalSize = 'sm' | 'md' | 'lg';
/** O que o `SModalService.confirm()` recebe. */
interface SModalConfig {
    /** Titulo em `--text-h3`. */
    title: string;
    /** Consequencia da acao, em linguagem clara. */
    description?: string;
    /** Ver `SModalVariant`. */
    variant?: SModalVariant;
    /**
     * Glifo Material Symbols mostrado no topo. Opcional: sem ele, o dialogo abre
     * direto no titulo. A cor segue a variante — `delete` numa exclusao sai em
     * `--destructive`.
     */
    icon?: string;
    /** Cor do icone, quando nao deve seguir a variante (um erro num `result`). */
    iconVariant?: SIconVariant;
    /**
     * Aviso embutido no corpo.
     *
     * Use para consequencias que precisam permanecer visiveis perto dos botoes,
     * como "Esta acao nao podera ser desfeita". O padrao visual e `warning`,
     * porque esse texto normalmente antecipa risco, nao sucesso.
     */
    alertMessage?: string;
    /** Tom do aviso embutido. */
    alertType?: SAlertType;
    /**
     * Rotulo da acao.
     *
     * Escreva o verbo do que vai acontecer — "Sim, excluir registro" e nao "OK".
     * Quem le so o botao precisa entender a consequencia.
     */
    confirmLabel?: string;
    /** Rotulo de cancelar. Fica sempre a esquerda. */
    cancelLabel?: string;
    /**
     * Largura semantica. Ver `SModalSize`.
     *
     * `width` explicito vence para preservar chamadas antigas que ja ajustavam a
     * largura em px.
     */
    size?: SModalSize;
    /** Largura maxima em px. Vence `size` por compatibilidade. */
    width?: number;
    /**
     * Quando `true`, a unica forma de fechar e escolher uma das acoes — usar com
     * moderacao, para confirmacoes realmente criticas (ex.: exclusao irreversivel).
     * Vence `closeOnBackdrop`.
     */
    disableClose?: boolean;
    /**
     * Fecha ao clicar fora do dialogo. Padrao: `false`.
     *
     * Desligado porque o clique fora costuma ser acidente — e, num formulario,
     * leva junto o que foi digitado. Esc e o `x` continuam fechando. Ligue em
     * dialogos so de leitura, em que fechar sem querer nao custa nada.
     */
    closeOnBackdrop?: boolean;
    /**
     * Onde o foco inicial cai. Padrao: `dialog`.
     *
     * Aceita um seletor CSS, `'first-tabbable'`, `'first-heading'`, `'dialog'`
     * ou `false` para nao mover o foco. Em confirmacao destrutiva, o seletor
     * `'[data-s-modal-cancel] button'` leva o foco ao botao Cancelar e evita que
     * Enter apague sem querer; o atributo e publico e estavel.
     *
     * `'first-tabbable'` cai no `x` do cabecalho quando ele aparece, e o foco
     * programatico nele pinta um quadrado cinza atras do botao.
     */
    autoFocus?: 'first-tabbable' | 'first-heading' | 'dialog' | string | boolean;
}
/**
 * Configuracao para `SModalService.open()`.
 *
 * Encapsula apenas as opcoes que a biblioteca expoe; por dentro o servico
 * converte para `MatDialogConfig`, sem vazar o tipo do Material na API publica.
 */
interface SOpenModalConfig<D = unknown> {
    /** Dados para o componente aberto, que os le com `injectModalData()`. */
    data?: D;
    /** Largura em px ou string CSS (`'600px'`, `'80vw'`). */
    width?: string;
    /**
     * Largura semantica. Ver `SModalSize`.
     *
     * `width` explicito vence para preservar chamadas antigas que ja ajustavam a
     * largura em CSS.
     */
    size?: SModalSize;
    /** Largura maxima. Padrao: `92vw`. */
    maxWidth?: string;
    /**
     * Impede fechar por Esc ou clique fora. Vence `closeOnBackdrop`.
     *
     * Use para acoes obrigatorias em que sair sem decidir nao e opcao.
     */
    disableClose?: boolean;
    /**
     * Fecha ao clicar fora do dialogo. Padrao: `false`.
     *
     * Desligado porque o clique fora costuma ser acidente — e, num formulario,
     * leva junto o que foi digitado. Esc e o `x` continuam fechando. Ligue em
     * dialogos so de leitura, em que fechar sem querer nao custa nada.
     */
    closeOnBackdrop?: boolean;
    /**
     * Onde o foco inicial cai. Padrao: `dialog`.
     *
     * Aceita um seletor CSS, `'first-tabbable'`, `'first-heading'`, `'dialog'`
     * ou `false` para nao mover o foco.
     */
    autoFocus?: 'first-tabbable' | 'first-heading' | 'dialog' | string | boolean;
}
/**
 * Referencia ao dialogo aberto por `SModalService.open()`.
 *
 * Encapsula `MatDialogRef` sem expor o tipo do Material na API publica.
 * A aplicacao usa apenas `close()`, `afterClosed()` e `componentInstance`.
 */
declare class SModalRef<T, R = unknown> {
    #private;
    /** @internal */
    constructor(ref: MatDialogRef<T, R>);
    /** Fecha o dialogo, opcionalmente com um resultado tipado. */
    close(result?: R): void;
    /** Observable que emite o resultado quando o dialogo fecha. */
    afterClosed(): Observable<R | undefined>;
    /** Instancia do componente aberto dentro do dialogo. */
    get componentInstance(): T;
}
/**
 * Os `data` passados a `SModalService.open()`, lidos de dentro do componente
 * aberto - sem a tela tocar no `MAT_DIALOG_DATA` do Material.
 *
 * Chame num campo de classe, como qualquer `inject()`.
 *
 * @example
 * ```ts
 * export class EditarJornadaComponent {
 *   protected readonly jornada = injectModalData<Jornada>();
 * }
 * ```
 */
declare function injectModalData<D>(): D;
/**
 * A referencia do proprio dialogo, de dentro do componente aberto por
 * `SModalService.open()`: e por ela que ele se fecha e devolve o resultado.
 *
 * @example
 * ```ts
 * export class EditarJornadaComponent {
 *   private readonly modal = injectModalRef<Jornada>();
 *
 *   salvar(jornada: Jornada): void {
 *     this.modal.close(jornada);
 *   }
 * }
 * ```
 */
declare function injectModalRef<R = unknown, T = unknown>(): SModalRef<T, R>;

/**
 * Marca o rodape proprio de um `<s-modal>`, no lugar dos botoes padrao.
 *
 * ```html
 * <s-modal [(visible)]="aberto" title="Adicionar comprovante">
 *   ...campos...
 *   <div sModalFooter>
 *     <s-button variant="secondary" outlined (click)="aberto.set(false)">Cancelar</s-button>
 *     <s-button (click)="salvar()">Salvar</s-button>
 *   </div>
 * </s-modal>
 * ```
 */
declare class SModalFooterDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SModalFooterDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SModalFooterDirective, "[sModalFooter]", never, {}, {}, never, never, true, never>;
}
/**
 * Dialogo centralizado.
 *
 * Aplicado **com moderacao**: so quando a interacao exige atencao imediata ou e
 * preciso manter o contexto da tela atras. Confirmar um sucesso simples e
 * trabalho do `SToastService`; um modal para isso interrompe sem necessidade.
 *
 * ## A ordem dos botoes nao e estetica
 *
 * Cancelar fica **sempre a esquerda** e a acao nomeada **sempre a direita**.
 * Quem confirma dez vezes por dia decora a posicao, nao o texto — trocar a
 * ordem numa tela faz a pessoa clicar em excluir por reflexo motor.
 *
 * ## Esta e a casca
 *
 * Para a confirmacao comum, use `SModalService.confirm()`, que abre este
 * componente e devolve a resposta. Use a casca direto quando o dialogo tiver
 * conteudo proprio — um formulario, uma tabela — projetado no meio.
 *
 * O focus trap esta ativo tanto via servico quanto no uso direto em template:
 * a diretiva `cdkTrapFocus` no proprio componente garante que o foco nao
 * escape do dialogo enquanto ele estiver visivel.
 *
 * O `x` do cabecalho emite o mesmo `cancel` do botao "Cancelar" — e uma saida
 * a mais, nao uma terceira decisao.
 *
 * ## Aberto pelo proprio template: `[(visible)]`
 *
 * Com `visible` ligado, o `<s-modal>` deixa de ser desenhado onde esta e abre
 * no overlay pelo `SModalService`, com o mesmo painel, Esc e rodape de tela
 * pequena. O conteudo continua no template da tela, com os bindings dela — e
 * o caminho para formularios que antes moravam num `p-dialog`. Os botoes
 * padrao podem dar lugar a um rodape proprio (`sModalFooter`) ou sumir
 * (`showActions`).
 *
 * Empilhamento de modais esta fora do guia, com uma excecao: uma confirmacao
 * (`confirm()`) pode abrir por cima de um modal de conteudo (`open()`) - e o
 * "Descartar alteracoes?" de um formulario em modal. Ver `SModalService`.
 */
declare class SModalComponent {
    #private;
    /** Fora do `MatDialog`: usado direto num template. */
    protected readonly avulso: boolean;
    protected readonly tituloId: string;
    protected readonly descricaoId: string;
    private readonly painel;
    private readonly caixa;
    protected readonly rodape: _angular_core.Signal<SModalFooterDirective | undefined>;
    constructor();
    /** Titulo em `--text-h3`. */
    readonly title: _angular_core.InputSignal<string>;
    /** Consequencia da acao, em linguagem clara. */
    readonly description: _angular_core.InputSignal<string>;
    /** Ver `SModalVariant`. */
    readonly variant: _angular_core.InputSignal<SModalVariant>;
    /**
     * Glifo Material Symbols no topo. Opcional: sem ele, o dialogo abre direto no
     * titulo, que e a estrutura minima do guia. A cor segue a variante.
     */
    readonly icon: _angular_core.InputSignal<string>;
    /** Cor do icone. Sem ela, segue a variante. */
    readonly iconVariant: _angular_core.InputSignal<SIconVariant | null>;
    /**
     * Aviso embutido no corpo, perto da decisao.
     *
     * Use quando a consequencia precisa continuar visivel ate a pessoa escolher
     * um botao; para feedback passageiro, prefira `SToastService`.
     */
    readonly alertMessage: _angular_core.InputSignal<string>;
    /** Tom do aviso embutido. */
    readonly alertType: _angular_core.InputSignal<SAlertType>;
    /** Rotulo da acao. Nomeie o que vai acontecer — nunca "OK" num destrutivo. */
    readonly confirmLabel: _angular_core.InputSignal<string>;
    /** Rotulo de cancelar. Fica sempre a esquerda. */
    readonly cancelLabel: _angular_core.InputSignal<string>;
    /**
     * Largura semantica.
     *
     * O guia fixa o medio em 520px. `sm` e `lg` existem para cobrir migracoes do
     * `showModal()` antigo sem espalhar numeros nas telas. `width` vence.
     */
    readonly size: _angular_core.InputSignal<SModalSize>;
    /**
     * Largura maxima. Numero e px; texto vai como CSS (`'40rem'`). Vence `size`
     * por compatibilidade.
     */
    readonly width: _angular_core.InputSignalWithTransform<string | number | null, unknown>;
    /**
     * Abre e fecha o dialogo no overlay, pelo proprio template. Sem ligar este
     * input, o `<s-modal>` e desenhado onde esta (ou dentro de `open()`).
     *
     * Volta a `false` quando o dialogo fecha por qualquer caminho: `x`,
     * Cancelar, Esc.
     */
    readonly visible: _angular_core.ModelSignal<boolean | undefined>;
    /**
     * Mostra o `x` do cabecalho. Desligado, o Esc tambem deixa de fechar o
     * dialogo aberto por `visible`: a saida passa a ser so pelos botoes da tela.
     */
    readonly closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Impede o Esc de fechar o dialogo aberto por `visible`. */
    readonly disableClose: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Botoes Cancelar e Confirmar. Ignorado quando ha rodape proprio (`sModalFooter`). */
    readonly showActions: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Titulo, conteudo e acoes centralizados — para avisos curtos. */
    readonly centered: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Acao confirmada. */
    readonly confirm: _angular_core.OutputEmitterRef<void>;
    /** Dialogo cancelado, pelo botao ou pelo `x` (solto na pagina, tambem pelo Esc). */
    readonly cancel: _angular_core.OutputEmitterRef<void>;
    /** O dialogo aberto por `visible` fechou, por qualquer caminho. */
    readonly closed: _angular_core.OutputEmitterRef<void>;
    /** `visible` ligado: abre no overlay em vez de ser desenhado aqui. */
    protected readonly declarativo: _angular_core.Signal<boolean>;
    /** Desenhado solto na pagina — e ele mesmo o dialogo. */
    protected readonly emLinha: _angular_core.Signal<boolean>;
    protected readonly classes: _angular_core.Signal<string>;
    /** `result` nao oferece escolha: um botao unico, em largura total. */
    protected readonly ehResultado: _angular_core.Signal<boolean>;
    protected readonly varianteDaAcao: _angular_core.Signal<"primary" | "destructive">;
    protected readonly larguraCss: _angular_core.Signal<string>;
    protected readonly iconName: _angular_core.Signal<string>;
    protected readonly corDoIcone: _angular_core.Signal<SIconVariant>;
    /** `x` e Cancelar: avisa e, aberto por `visible`, fecha. */
    protected cancelar(): void;
    /**
     * Esc cancela no uso direto em template. Aberto pelo servico (ou por
     * `visible`), quem trata o Esc e o `SModalService`, respeitando `disableClose`.
     */
    protected aoTeclarEsc(evento: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SModalComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SModalComponent, "s-modal", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "iconVariant": { "alias": "iconVariant"; "required": false; "isSignal": true; }; "alertMessage": { "alias": "alertMessage"; "required": false; "isSignal": true; }; "alertType": { "alias": "alertType"; "required": false; "isSignal": true; }; "confirmLabel": { "alias": "confirmLabel"; "required": false; "isSignal": true; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "disableClose": { "alias": "disableClose"; "required": false; "isSignal": true; }; "showActions": { "alias": "showActions"; "required": false; "isSignal": true; }; "centered": { "alias": "centered"; "required": false; "isSignal": true; }; }, { "visible": "visibleChange"; "confirm": "confirm"; "cancel": "cancel"; "closed": "closed"; }, ["rodape"], ["*", "[sModalFooter]"], true, [{ directive: typeof i1$1.CdkTrapFocus; inputs: {}; outputs: {}; }]>;
}

/**
 * Abre dialogos sem a aplicacao tocar no `MatDialog`.
 *
 * `confirm()` cobre o caso mais comum — perguntar antes de uma acao — numa
 * linha. Para dialogos com conteudo proprio, `open()` recebe um componente.
 *
 * @example
 * ```ts
 * private readonly modal = inject(SModalService);
 *
 * async excluir(jornada: Jornada): Promise<void> {
 *   const confirmou = await this.modal.confirm({
 *     variant: 'destructive',
 *     title: 'Excluir Registro de Aula?',
 *     description: 'Esta ação não pode ser desfeita.',
 *     confirmLabel: 'Sim, excluir registro',
 *   });
 *
 *   if (confirmou) {
 *     this.servico.excluir(jornada.id).subscribe();
 *   }
 * }
 * ```
 */
declare class SModalService {
    #private;
    private readonly dialog;
    /**
     * Pergunta antes de agir.
     *
     * Resolve `true` quando o usuario confirma e `false` quando cancela — pelo
     * botao, pelo `x` ou pelo Esc. Clicar fora so cancela com
     * `closeOnBackdrop`.
     */
    confirm(config: SModalConfig): Promise<boolean>;
    /**
     * Abre um componente proprio (ou um template) como dialogo.
     *
     * Use quando o conteudo for um formulario ou uma tabela. Dentro dele, o
     * `<s-modal>` continua servindo de casca, com titulo e botoes.
     *
     * Retorna {@link SModalRef} — a referencia da propria lib, sem expor
     * `MatDialogRef` na API publica.
     *
     * @example
     * ```ts
     * const ref = this.modal.open(MeuFormularioComponent, {
     *   data: { id: 42 },
     *   width: '600px',
     * });
     *
     * ref.afterClosed().subscribe((resultado) => { ... });
     * ```
     */
    open<T, D = unknown, R = unknown>(component: ComponentType$1<T> | Type<T> | TemplateRef<T>, config?: SOpenModalConfig<D>): SModalRef<T, R>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SModalService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SModalService>;
}

/**
 * Indicador circular indeterminado.
 *
 * O guia proíbe spinner central para carregamento de tela inteira: nesse caso,
 * prefira skeleton ou `<s-loading-overlay>` quando a aplicação ainda estiver
 * presa ao padrão antigo. Este componente existe para os pontos em que o estado
 * é curto e inline — o mesmo papel do `progress_activity` usado pelos botões em
 * `loading`.
 *
 * A implementação é CSS + `<s-icon>`, e não `mat-progress-spinner`, para manter
 * a mesma linguagem visual do botão e evitar dois desenhos de progresso dentro
 * da biblioteca.
 */
declare class SSpinnerComponent {
    /**
     * Passo da escala de ícone.
     *
     * Spinner inline acompanha a mesma escala dos ícones porque ele substitui um
     * glifo de estado, não um bloco de conteúdo. Para carregamento estrutural,
     * use skeleton.
     */
    readonly size: _angular_core.InputSignalWithTransform<SIconSize, SIconSizeInput>;
    /** Nome anunciado por leitor de tela quando não há texto visível por perto. */
    readonly label: _angular_core.InputSignal<string>;
    protected readonly sizeCss: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SSpinnerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SSpinnerComponent, "s-spinner", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Estado global de carregamento controlado pela aplicação.
 *
 * A biblioteca não faz HTTP dentro de componente. Este serviço só conta
 * operações que a aplicação informa: um `HttpInterceptorFn`, um resolver ou uma
 * ação manual chamam `begin()` e garantem `end()` no `finalize`.
 */
declare class SLoadingService {
    private readonly count;
    /** `true` enquanto existir ao menos uma operação em aberto. */
    readonly active: _angular_core.Signal<boolean>;
    /**
     * Marca o início de uma operação.
     *
     * Devolve uma função de finalização idempotente para o chamador não perder a
     * contagem em caminhos de erro, cancelamento ou `return` antecipado.
     */
    begin(): () => void;
    /** Marca o fim de uma operação. Chamadas sobrando não deixam a contagem negativa. */
    end(): void;
    /** Envolve um Observable garantindo `end()` em sucesso, erro ou cancelamento. */
    track<T>(source: Observable<T>): Observable<T>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SLoadingService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SLoadingService>;
}
/**
 * Interceptor opcional para ligar o overlay no HTTP da aplicação.
 *
 * Ele não viola a regra "nada de HTTP dentro de componente": fica fora dos
 * componentes, não conhece endpoint nenhum e só observa o ciclo da requisição.
 *
 * ```ts
 * provideHttpClient(withInterceptors([siageLoadingInterceptor]))
 * ```
 */
declare const siageLoadingInterceptor: HttpInterceptorFn;

/**
 * Bloqueio visual para carregamentos globais durante a migração.
 *
 * O guia prefere skeleton no formato do conteúdo. Este overlay existe para dar
 * paridade ao `app-loading` usado pelos sistemas enquanto cada tela migra para
 * estados mais específicos. O atraso de `S_LOADING_DELAY` evita o piscar de
 * requisições rápidas.
 */
declare class SLoadingOverlayComponent {
    /**
     * Estado controlado pela tela.
     *
     * Quando omitido, o componente usa `SLoadingService.active`, pensado para o
     * interceptor da aplicação.
     */
    readonly active: _angular_core.InputSignal<boolean | null>;
    /** Prende o overlay ao container posicionado pelo consumidor, em vez da viewport. */
    readonly contained: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Texto anunciado quando o overlay finalmente aparece. */
    readonly label: _angular_core.InputSignal<string>;
    private readonly loading;
    private readonly el;
    protected readonly rawActive: _angular_core.Signal<boolean>;
    protected readonly visible: _angular_core.Signal<boolean>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SLoadingOverlayComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SLoadingOverlayComponent, "s-loading-overlay", never, { "active": { "alias": "active"; "required": false; "isSignal": true; }; "contained": { "alias": "contained"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Modo de progresso. */
type SProgressBarMode = 'determinate' | 'indeterminate';
/**
 * Tom semântico da barra.
 *
 * São os tons com token de estado no guia. `info` fica fora de propósito: azul
 * claro no SIAGE comunica informação contextual, não avanço de processo.
 */
type SProgressBarTone = 'primary' | 'success' | 'warning' | 'destructive';

/**
 * Barra de progresso linear.
 *
 * Use `determinate` quando a aplicação sabe o percentual real; use
 * `indeterminate` quando só sabe que há trabalho em andamento. A barra não faz
 * requisição nem assume etapas: ela só comunica o estado recebido pela tela.
 */
declare class SProgressBarComponent {
    /** Percentual real do processo. Só é anunciado em `determinate`. */
    readonly value: _angular_core.InputSignalWithTransform<number, unknown>;
    /** `indeterminate` remove `aria-valuenow` porque não há percentual confiável. */
    readonly mode: _angular_core.InputSignal<SProgressBarMode>;
    /** Tom visual. Ver `SProgressBarTone`. */
    readonly tone: _angular_core.InputSignal<SProgressBarTone>;
    /** Exibe o percentual ao lado da barra quando ele ajuda a comparar avanço. */
    readonly showValue: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Nome acessível do progresso no contexto da tela. */
    readonly label: _angular_core.InputSignal<string>;
    protected readonly normalizedValue: _angular_core.Signal<number>;
    protected readonly valueCss: _angular_core.Signal<string>;
    protected readonly ariaValue: _angular_core.Signal<string | null>;
    protected readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SProgressBarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SProgressBarComponent, "s-progress-bar", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "showValue": { "alias": "showValue"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Um degrau da trilha de navegacao. Sem `href` nem `routerLink`, e apenas texto.
 *
 * - `routerLink` — navegacao interna do Angular Router, sem reload de pagina.
 *   Aceita string (`'/turmas'`) ou array (`['/turmas', turmaId]`).
 * - `href` — link externo ou pagina fora do Router. Causa reload completo.
 *
 * Quando ambos estiverem presentes, `routerLink` tem precedencia.
 */
interface SBreadcrumb {
    label: string;
    /** Glifo no lugar do texto (o inicio). O `label` vira o nome acessivel. */
    icon?: string;
    /**
     * URL externa ou rota que deve causar reload completo.
     * Use para links fora do Angular Router.
     */
    href?: string;
    /**
     * Rota interna do Angular Router, sem reload de pagina.
     * Aceita string (`'/turmas'`) ou array de segmentos (`['/turmas', id]`).
     * Quando definido, tem precedencia sobre `href`.
     */
    routerLink?: string | unknown[];
}
/**
 * Monta a trilha a partir de `data.breadcrumb` no Router, sem obrigar quem
 * prefere informar os itens manualmente a registrar providers extras.
 *
 * Use quando a aplicacao ja tem a hierarquia nas rotas. `breadcrumb: null`
 * pula o nivel; string vira o rotulo; objeto permite sobrescrever `href` ou
 * `routerLink`. O ultimo item continua marcado como pagina atual pelo
 * componente, por isso o link dele nao fica clicavel.
 *
 * @example
 * ```ts
 * const routes: Routes = [
 *   { path: 'configuracoes', data: { breadcrumb: 'Configurações' } },
 * ];
 *
 * readonly breadcrumbs = breadcrumbFromRoute(inject(ActivatedRoute));
 * ```
 */
declare function breadcrumbFromRoute(route: ActivatedRoute): SBreadcrumb[];

/**
 * Marca o conteudo projetado como estado do registro ao lado do titulo.
 *
 * O PageHeader nao recria tons de status porque o guia ja tem o `s-badge` para
 * isso. A diretiva so reserva o lugar certo no cabecalho; a aplicacao escolhe
 * o componente visual que conhece o estado do seu dominio.
 *
 * @example
 * ```html
 * <s-page-header title="Publicação">
 *   <s-badge sPageHeaderStatus tone="success">Publicado</s-badge>
 * </s-page-header>
 * ```
 */
declare class SPageHeaderStatusDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SPageHeaderStatusDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SPageHeaderStatusDirective, "[sPageHeaderStatus]", never, {}, {}, never, never, true, never>;
}

/**
 * Bloco inicial de toda tela: breadcrumbs, titulo, descricao e a acao primaria.
 *
 * ## A ordem e obrigatoria
 *
 * Trilha, titulo, descricao. Nessa sequencia, sempre — em cadastro, listagem,
 * visualizacao e dashboard. E o que faz alguem reconhecer onde esta antes de
 * ler qualquer coisa.
 *
 * ## Por que existe um so
 *
 * O Professores tinha `app-header-page` (titulo, subtitulo, tag e voltar) e
 * `app-generic-page-structure` (titulo e subtitulo). O segundo era um
 * subconjunto do primeiro, entao nao havia o que escolher — havia o que
 * unificar. Este componente cobre os dois. A `tag` ficou como slot
 * `[sPageHeaderStatus]`: estado do registro pertence ao conteudo da tela, mas
 * algumas telas precisam posicionar esse estado ao lado do titulo. A aplicacao
 * projeta um `<s-badge>` real e o PageHeader nao duplica tons.
 *
 * ## A acao primaria e uma so
 *
 * O slot `[action]` recebe **a** acao da tela, no singular. Duas acoes
 * primarias competindo no topo e o mesmo que nenhuma; a segunda desce para
 * dentro do conteudo. Permissao tambem fica na aplicacao: use `@if` ao projetar
 * a acao. A biblioteca nao consulta `SPermissionChecker` aqui porque cada tela
 * decide se a falta de permissao esconde, desabilita ou desloca a acao.
 *
 * @example
 * ```html
 * <s-page-header
 *   [breadcrumbs]="[{ label: 'Configurações' }, { label: 'Jornadas' }]"
 *   title="Jornadas de Trabalho"
 *   description="Gerencie as jornadas que definem o horário padrão de trabalho."
 *   showBack
 *   (back)="voltar()"
 * >
 *   <s-badge sPageHeaderStatus tone="warning" icon="warning">Rascunho</s-badge>
 *   <s-button action variant="primary" icon="add">Nova Jornada</s-button>
 * </s-page-header>
 * ```
 */
declare class SPageHeaderComponent {
    #private;
    /** Trilha de navegacao. O ultimo item e a tela atual. */
    readonly breadcrumbs: _angular_core.InputSignal<readonly SBreadcrumb[]>;
    /**
     * Monta a trilha sozinho, pelo `data.breadcrumb` das rotas ativas, e a
     * refaz a cada navegacao. Ver `breadcrumbFromRoute` para o formato. Vence
     * `breadcrumbs`.
     */
    readonly breadcrumbsFromRoute: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Rota do inicio (`'/'`). Informada, a trilha abre com o icone de casa, que
     * leva para la — so quando ha trilha para mostrar.
     */
    readonly homeLink: _angular_core.InputSignal<string | null>;
    /** Texto do status ao lado do titulo — para o caso comum, sem montar o badge. */
    readonly status: _angular_core.InputSignal<string>;
    /** Tom do status. Aceita tambem as severidades antigas (`warn`, `danger`...). */
    readonly statusTone: _angular_core.InputSignal<string | null | undefined>;
    /** Glifo do status. */
    readonly statusIcon: _angular_core.InputSignal<string>;
    /** Titulo da tela, em `--text-h1`. */
    readonly title: _angular_core.InputSignal<string>;
    /** Uma ou duas linhas dizendo para que serve a tela. */
    readonly description: _angular_core.InputSignal<string>;
    /**
     * Icone opcional antes da descricao.
     *
     * O guia permite iconografia quando ela ajuda a reconhecer o contexto do
     * subtitulo; o texto continua sendo a fonte de significado, entao o icone e
     * decorativo e usa o tamanho de controle.
     */
    readonly subtitleIcon: _angular_core.InputSignal<string>;
    /** Exibe a seta de voltar a esquerda do titulo. */
    readonly showBack: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Disparado pela seta de voltar. */
    readonly back: _angular_core.OutputEmitterRef<void>;
    protected readonly statusProjetado: _angular_core.Signal<SPageHeaderStatusDirective | undefined>;
    protected readonly tomDoStatus: _angular_core.Signal<SBadgeTone>;
    protected readonly trilha: _angular_core.Signal<readonly SBreadcrumb[]>;
    protected isCurrent(index: number): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SPageHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SPageHeaderComponent, "s-page-header", never, { "breadcrumbs": { "alias": "breadcrumbs"; "required": false; "isSignal": true; }; "breadcrumbsFromRoute": { "alias": "breadcrumbsFromRoute"; "required": false; "isSignal": true; }; "homeLink": { "alias": "homeLink"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "statusTone": { "alias": "statusTone"; "required": false; "isSignal": true; }; "statusIcon": { "alias": "statusIcon"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "subtitleIcon": { "alias": "subtitleIcon"; "required": false; "isSignal": true; }; "showBack": { "alias": "showBack"; "required": false; "isSignal": true; }; }, { "back": "back"; }, ["statusProjetado"], ["[sPageHeaderStatus]", "[action]"], true, never>;
}

/**
 * Barra superior de 64px: menu, marca, ano letivo, tema e perfil.
 *
 * ## Uma moldura, nao uma barra fechada
 *
 * O Professores e o Educacional tem barras parecidas, mas nao iguais: um tem
 * ano letivo, o outro busca global; nenhum tem notificacoes. Por isso cada
 * peca alem do menu, da marca, do tema e do perfil e opcional, e o espaco antes
 * do ano letivo recebe o que a aplicacao projetar — a lupa da busca global do
 * Educacional, por exemplo.
 *
 * ## Ela nao compete com o conteudo
 *
 * As acoes da direita sao **so-icone**, em 24px, cada uma com rotulo acessivel.
 * O seletor de ano letivo e o unico controle com texto, porque o ano vigente
 * muda o significado de tudo que a tela mostra.
 *
 * ## O que ela nao faz
 *
 * Menu de perfil e painel de notificacoes estao **fora de escopo no guia**. Os
 * botoes emitem o `MouseEvent` do clique, que e o que um menu em popup precisa
 * para se ancorar no botao (`menu.toggle(evento)` no PrimeNG).
 *
 * @example
 * ```html
 * <s-top-bar
 *   systemName="SIAGE"
 *   systemSubtitle="Professores"
 *   homeLink="/"
 *   [schoolYears]="anos()"
 *   [schoolYear]="ano()"
 *   [schoolYearLoading]="carregandoAnos()"
 *   (toggleMenu)="alternarMenu()"
 *   (schoolYearChange)="trocarAno($event)"
 *   (profileClick)="menuDoUsuario.toggle($event)"
 * >
 *   <img brand src="logo.png" alt="" />
 * </s-top-bar>
 * ```
 */
declare class STopBarComponent<T = string> {
    /** Nome do sistema. String vazia esconde o texto — util quando o logotipo ja o traz. */
    readonly systemName: _angular_core.InputSignal<string>;
    /** Segunda linha da marca, menor: o modulo — "Professores", "Educacional". */
    readonly systemSubtitle: _angular_core.InputSignal<string>;
    /**
     * Endereco do inicio. Informado, a marca vira link: com Router, navega sem
     * recarregar a pagina; sem ele, e um link comum.
     *
     * So caminho interno, comecando com `/` (nao `//`): o clique pode cair em
     * `location.assign`, que nao passa pelo sanitizador do Angular, entao um
     * `javascript:` ou endereco externo vindo de configuracao viraria execucao ou
     * redirecionamento. Fora disso a marca fica sem link.
     */
    readonly homeLink: _angular_core.InputSignal<string>;
    /** `homeLink` aceito: caminho interno, ou vazio. */
    protected readonly inicio: _angular_core.Signal<string>;
    /** Exibe o botao que recolhe e expande o menu lateral. */
    readonly showMenuButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Anos do seletor. Aceita texto (`'2026'`) ou `SOption` — o Professores usa
     * objetos `{ id, nome }`, que viram `{ label: nome, value: ... }`. Vazio
     * esconde o seletor.
     */
    readonly schoolYears: _angular_core.InputSignal<readonly (string | SOption<T>)[]>;
    /** Ano letivo selecionado: o `value` da opcao, ou o texto. */
    readonly schoolYear: _angular_core.InputSignal<string | T | null>;
    /** Compara o ano selecionado com o de cada opcao. Ver `<s-select>`. */
    readonly schoolYearCompareWith: _angular_core.InputSignal<(a: T, b: T) => boolean>;
    /** Anos ainda chegando: o seletor fica desabilitado, com reticencias no lugar do ano. */
    readonly schoolYearLoading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Desabilita o seletor — em telas onde trocar o ano nao se aplica. */
    readonly schoolYearDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Exibe o sino. Nenhum dos sistemas atuais tem notificacoes, entao vem desligado. */
    readonly showNotifications: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Nao lidas no sino. `0` esconde o indicador. */
    readonly notifications: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Tema que esta na tela, so para escolher o glifo do botao.
     *
     * A barra nao troca o tema sozinha: quem decide e a aplicacao, pelo
     * `toggleTheme` - ha sistemas com tema proprio, e a barra nao pode brigar com
     * ele. Com o tema da biblioteca, ligue os dois ao `SThemeService`, passando o
     * tema **resolvido** (com o sistema operacional ja considerado):
     *
     * ```html
     * <s-top-bar [theme]="tema.resolved()" (toggleTheme)="tema.toggle()" />
     * ```
     */
    readonly theme: _angular_core.InputSignal<"light" | "dark">;
    /** Recolher ou expandir o menu lateral. */
    readonly toggleMenu: _angular_core.OutputEmitterRef<void>;
    /** Novo ano letivo: o `value` da opcao escolhida. */
    readonly schoolYearChange: _angular_core.OutputEmitterRef<T>;
    /** Alternar o tema. */
    readonly toggleTheme: _angular_core.OutputEmitterRef<void>;
    /** Sino de notificacoes, com o clique para ancorar o painel. */
    readonly notificationsClick: _angular_core.OutputEmitterRef<MouseEvent>;
    /** Botao de perfil, com o clique para ancorar o menu do usuario. */
    readonly profileClick: _angular_core.OutputEmitterRef<MouseEvent>;
    protected readonly campoAno: SFieldContext;
    private readonly router;
    /** Anos no formato de opcao do `<s-select>`. */
    protected readonly opcoesAno: _angular_core.Signal<SOption<T>[]>;
    /** Clique na marca: com rotas configuradas, navega dentro da aplicacao. */
    protected irParaInicio(evento: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<STopBarComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<STopBarComponent<any>, "s-top-bar", never, { "systemName": { "alias": "systemName"; "required": false; "isSignal": true; }; "systemSubtitle": { "alias": "systemSubtitle"; "required": false; "isSignal": true; }; "homeLink": { "alias": "homeLink"; "required": false; "isSignal": true; }; "showMenuButton": { "alias": "showMenuButton"; "required": false; "isSignal": true; }; "schoolYears": { "alias": "schoolYears"; "required": false; "isSignal": true; }; "schoolYear": { "alias": "schoolYear"; "required": false; "isSignal": true; }; "schoolYearCompareWith": { "alias": "schoolYearCompareWith"; "required": false; "isSignal": true; }; "schoolYearLoading": { "alias": "schoolYearLoading"; "required": false; "isSignal": true; }; "schoolYearDisabled": { "alias": "schoolYearDisabled"; "required": false; "isSignal": true; }; "showNotifications": { "alias": "showNotifications"; "required": false; "isSignal": true; }; "notifications": { "alias": "notifications"; "required": false; "isSignal": true; }; "theme": { "alias": "theme"; "required": false; "isSignal": true; }; }, { "toggleMenu": "toggleMenu"; "schoolYearChange": "schoolYearChange"; "toggleTheme": "toggleTheme"; "notificationsClick": "notificationsClick"; "profileClick": "profileClick"; }, never, ["[brand]", "*"], true, never>;
}

type SSidebarRouterLink = string | readonly (string | number)[];
/** Um destino do menu. */
interface SSidebarItem {
    /** Identificador comparado com `activeId`. */
    id: string;
    /** Rotulo objetivo. Uma ou duas palavras. */
    label: string;
    /** Glifo do Material Symbols, exibido em 24px. */
    icon: string;
    /**
     * Rota do Angular Router.
     *
     * Quando existe, o item vira link real para que abrir em nova aba, copiar
     * endereco e `routerLinkActive` funcionem como numa navegacao nativa.
     */
    route?: SSidebarRouterLink;
    /**
     * Alias de `route` para quem prefere usar o mesmo nome da diretiva do Router.
     */
    routerLink?: SSidebarRouterLink;
    /**
     * Contador ou novidade do destino.
     *
     * O badge fica no item porque ele e parte da decisao de navegacao: mostra
     * que ha algo a resolver antes de a pessoa entrar na tela.
     */
    badge?: string | number;
    /** Tom do badge do item. */
    badgeTone?: SBadgeTone;
    /**
     * Secao do item em listas planas.
     *
     * Mantem a entrada antiga (`SSidebarItem[]`) e permite agrupar sem obrigar a
     * aplicacao a mudar o formato dos dados de uma vez.
     */
    group?: string;
}
/** Secao explicita do menu, para menus que ja chegam agrupados da aplicacao. */
interface SSidebarGroup {
    /** Titulo curto da secao. */
    label: string;
    /** Destinos daquela secao, na ordem. */
    items: readonly SSidebarItem[];
}
type SSidebarEntry = SSidebarItem | SSidebarGroup;
interface SSidebarResolvedGroup {
    readonly id: string;
    readonly label: string;
    readonly items: readonly SSidebarItem[];
}
/**
 * Menu lateral da web: 256px expandido, 72px recolhido.
 *
 * ## O gradiente aparece aqui, e so aqui
 *
 * O item ativo usa `--gradient-primary` com rotulo branco. Na web esse
 * gradiente **nao existe em nenhum outro lugar** — e o que faz "onde estou" ser
 * reconhecido de relance, sem ler. Usa-lo num card ou num botao gasta essa
 * distincao.
 *
 * O glifo do item ativo tambem ganha o eixo `FILL`, entao a marcacao nao depende
 * so de cor.
 *
 * ## Recolhido
 *
 * A 72px sobra o icone. O rotulo vira tooltip — sem ele, um menu recolhido e um
 * teste de memoria.
 */
declare class SSidebarComponent {
    private readonly el;
    private readonly destroyRef;
    private readonly documento;
    private readonly instanceId;
    private focusBeforeOverlay;
    private wasOverlayOpen;
    /** Destinos do menu, na ordem. */
    readonly items: _angular_core.InputSignal<readonly SSidebarEntry[]>;
    /** Id do item ativo. */
    readonly activeId: _angular_core.InputSignal<string>;
    /**
     * Recolhe para 72px, deixando so os icones.
     *
     * Suporta two-way binding: `[(collapsed)]="sinal"`. Tambem aceita binding
     * unidirecional `[collapsed]="valor"` — retrocompativel com o uso anterior.
     */
    readonly collapsed: _angular_core.ModelSignal<boolean>;
    /**
     * Mostra o botao de recolher/expandir no topo da sidebar.
     *
     * Desligue quando o cabecalho da aplicacao ja tem o proprio botao de menu
     * (o hamburguer do topo), para nao haver dois controles fazendo a mesma
     * coisa. O colapso continua pelo `[(collapsed)]`.
     */
    readonly showToggle: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Rotulo acessivel do menu, quando a tela tem mais de uma navegacao. */
    readonly label: _angular_core.InputSignal<string>;
    /**
     * Largura maxima, em px, para tratar a sidebar como sobreposicao.
     *
     * O padrao preserva o contrato anterior da lib. Sistemas que mantem a
     * navegacao lateral ate tablet largo, como o Professor, podem alinhar o
     * corte sem duplicar CSS.
     */
    readonly breakpoint: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Item escolhido. A aplicacao decide o que fazer — normalmente, navegar. */
    readonly select: _angular_core.OutputEmitterRef<string>;
    protected readonly isNarrowViewport: _angular_core.WritableSignal<boolean>;
    protected readonly groups: _angular_core.Signal<readonly SSidebarResolvedGroup[]>;
    protected readonly isOverlayOpen: _angular_core.Signal<boolean>;
    /** Alterna o estado de colapso. */
    protected alternarColapso(): void;
    constructor();
    /**
     * No mobile, clicar fora do menu aberto o fecha.
     *
     * A decisao fica para depois que o clique termina de ser tratado. O caso que
     * isso resolve e o botao de menu da top-bar, que fica fora da sidebar: ao
     * fechar por ele, decidir na hora fechava o menu e, em seguida, o
     * `(toggleMenu)` da tela o invertia de novo - o menu nunca fechava. Esperando,
     * o botao age primeiro, e so resta fechar se ninguem mais o fez.
     */
    private fecharAoClicarFora;
    protected closeOverlay(event?: Event): void;
    protected ehAtivo(item: SSidebarItem, routeActive?: boolean): boolean;
    protected hasRoute(item: SSidebarItem): boolean;
    protected itemRoute(item: SSidebarItem): SSidebarRouterLink | null;
    protected badgeText(item: SSidebarItem): string;
    private normalizeGroups;
    private createGroup;
    private isGroup;
    private syncOverlay;
    private activeElement;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SSidebarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SSidebarComponent, "s-sidebar", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "activeId": { "alias": "activeId"; "required": false; "isSignal": true; }; "collapsed": { "alias": "collapsed"; "required": false; "isSignal": true; }; "showToggle": { "alias": "showToggle"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "breakpoint": { "alias": "breakpoint"; "required": false; "isSignal": true; }; }, { "collapsed": "collapsedChange"; "select": "select"; }, never, ["[footer]"], true, never>;
}

type SAvatarSize = 'sm' | 'md' | 'lg';
declare const TONES: readonly ["primary", "success", "warning", "info", "destructive"];
type SAvatarTone = (typeof TONES)[number];
/**
 * Iniciais usadas quando a foto nao existe ou falha.
 *
 * O mesmo criterio da barra superior: nomes compostos usam a primeira e a ultima
 * palavra com sentido, ignorando conectivos comuns do pt-BR para que "Maria da
 * Silva" vire "MS", nao "MD".
 */
declare function avatarInitials(name: string): string;
/** Tom deterministico, restrito aos tokens semanticos do tema. */
declare function avatarTone(name: string): SAvatarTone;

/**
 * Avatar de pessoa da biblioteca `@siage/siage-ui`.
 *
 * Ele cobre os dois usos atuais: foto quando a aplicacao tem uma URL confiavel,
 * e iniciais quando nao tem. A cor de fundo nao e aleatoria; ela escolhe um dos
 * tokens semanticos do tema a partir do nome, para manter consistencia visual
 * entre telas sem criar cores fora do guia.
 */
declare class SAvatarComponent {
    /** Nome que identifica a pessoa e gera as iniciais quando a imagem nao aparece. */
    readonly name: _angular_core.InputSignal<string>;
    /** URL da foto. Se o carregamento falhar, o componente preserva o contexto com as iniciais. */
    readonly src: _angular_core.InputSignal<string>;
    /** Tamanho do avatar dentro da escala visual da biblioteca. */
    readonly size: _angular_core.InputSignal<SAvatarSize>;
    /** Texto alternativo da imagem quando a foto comunica algo mais especifico que o nome. */
    readonly alt: _angular_core.InputSignal<string>;
    private readonly imageFailed;
    protected readonly accessibleName: _angular_core.Signal<string>;
    protected readonly alternativeText: _angular_core.Signal<string>;
    protected readonly initials: _angular_core.Signal<string>;
    protected readonly showImage: _angular_core.Signal<boolean>;
    protected readonly hostClasses: _angular_core.Signal<string>;
    constructor();
    protected handleImageError(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SAvatarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SAvatarComponent, "s-avatar", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "src": { "alias": "src"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "alt": { "alias": "alt"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Menu flutuante da biblioteca `@siage/siage-ui`.
 *
 * O painel usa o `CdkMenu` para manter a navegação por teclado esperada de menu:
 * setas, Home/End, Esc e typeahead. A biblioteca desenha só a superfície e os
 * itens; a aplicação ancora o painel em qualquer botão com `[sMenuTriggerFor]`.
 */
declare class SMenuComponent implements OnDestroy {
    /** Nome acessivel do painel quando o gatilho sozinho nao descreve o conjunto de opcoes. */
    readonly label: _angular_core.InputSignal<string>;
    private readonly overlay;
    private readonly viewContainerRef;
    private readonly template;
    private readonly openState;
    private overlayRef;
    private origin;
    private closeSubscription;
    protected readonly isOpen: _angular_core.Signal<boolean>;
    open(origin: ElementRef<HTMLElement> | HTMLElement): void;
    openFromEvent(event: MouseEvent): void;
    toggle(origin: ElementRef<HTMLElement> | HTMLElement): void;
    close(): void;
    ariaExpanded(): string;
    ngOnDestroy(): void;
    private focusFirstItem;
    protected handleKeydown(event: KeyboardEvent): void;
    private focusItem;
    private finishClose;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SMenuComponent, "s-menu", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/** Item acionavel do `s-menu`. */
declare class SMenuItemComponent {
    /** Glifo opcional para ajudar a varrer visualmente uma lista curta de acoes. */
    readonly icon: _angular_core.InputSignal<string>;
    /** Desabilita a opcao sem remove-la do menu, preservando o mapa de acoes. */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Tom reservado para acoes irreversiveis, como sair ou excluir. */
    readonly destructive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Emite quando o CDK aciona o item por mouse ou teclado. */
    readonly triggered: _angular_core.OutputEmitterRef<void>;
    private readonly elementRef;
    protected handleTriggered(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SMenuItemComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SMenuItemComponent, "s-menu-item", never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "destructive": { "alias": "destructive"; "required": false; "isSignal": true; }; }, { "triggered": "triggered"; }, never, ["*"], true, never>;
}

/** Separador visual entre grupos de acoes do `s-menu`. */
declare class SMenuSeparatorComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SMenuSeparatorComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SMenuSeparatorComponent, "s-menu-separator", never, {}, {}, never, never, true, never>;
}

/** Gatilho que ancora um `s-menu` em qualquer botao ou elemento interativo. */
declare class SMenuTriggerDirective {
    readonly menu: _angular_core.InputSignal<SMenuComponent>;
    private readonly elementRef;
    protected handleClick(): void;
    protected handleKeyboardTrigger(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SMenuTriggerDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SMenuTriggerDirective, "[sMenuTriggerFor]", never, { "menu": { "alias": "sMenuTriggerFor"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Selecao multipla que vira etiquetas.
 *
 * A diferenca para o `<s-multiselect>` e o que fica visivel: aqui **cada
 * escolha ocupa espaco na tela**, com o proprio botao de remover. Use quando a
 * lista escolhida importa tanto quanto o ato de escolher — disciplinas de um
 * professor, turmas de uma escala. Quando o que importa e so a contagem, o
 * multiselect gasta menos espaco.
 *
 * **Nao esta no guia de design.** Segue a anatomia do campo e o tamanho de
 * badge (12px) nas etiquetas.
 *
 * Como o `<s-autocomplete>`, aceita `options` da tela ou consulta a
 * `SAutocompleteSource` quando recebe `url` — a biblioteca continua sem fazer
 * HTTP.
 */
declare class SChipsComponent<T = unknown> extends SControlBase<T[]> {
    /** Sugestoes do painel. Ignorado quando ha `url`. */
    readonly options: _angular_core.InputSignal<readonly SAutocompleteOption<T>[]>;
    /** Recurso consultado a cada digitacao, via `SAutocompleteSource`. */
    readonly url: _angular_core.InputSignal<string>;
    /** Filtros enviados junto da busca. So tem efeito com `url`. */
    readonly params: _angular_core.InputSignal<Record<string, unknown>>;
    /** Caracteres minimos antes de consultar. So tem efeito com `url`. */
    readonly minLength: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Compara valores, como no `<s-select>`: decide se uma opcao ja foi escolhida
     * e qual rotulo mostrar para um valor que veio do formulario. O padrao e
     * igualdade estrita; informe uma funcao quando o valor for um objeto.
     */
    readonly compareWith: _angular_core.InputSignal<(a: T, b: T) => boolean>;
    /** Espera entre a digitacao e a consulta, em ms. */
    readonly debounceTime: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Texto exibido no painel quando nao ha sugestoes. */
    readonly noResultsText: _angular_core.InputSignal<string>;
    /** Teto de etiquetas. `0` nao limita. */
    readonly max: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Etiqueta acrescentada. */
    readonly add: _angular_core.OutputEmitterRef<SAutocompleteOption<T>>;
    /** Etiqueta removida. */
    readonly remove: _angular_core.OutputEmitterRef<SAutocompleteOption<T>>;
    /** Texto digitado. Use quando a tela alimenta `options` por conta propria. */
    readonly search: _angular_core.OutputEmitterRef<string>;
    /** Tentativa de repetir uma etiqueta ja escolhida. */
    readonly duplicate: _angular_core.OutputEmitterRef<SAutocompleteOption<T>>;
    protected readonly searchControl: FormControl<string>;
    private readonly source;
    private readonly fetched;
    private readonly fetching;
    private readonly termo;
    /** As etiquetas escolhidas, com rotulo — nao so o valor. */
    private readonly escolhidas;
    /** Etiquetas que chegaram do formulario sem rotulo conhecido. */
    private readonly provisorias;
    private readonly campo;
    protected readonly controlId: _angular_core.Signal<string>;
    protected readonly ariaLabel: _angular_core.Signal<string | null>;
    protected readonly describedBy: _angular_core.Signal<string | null>;
    protected readonly required: _angular_core.Signal<boolean>;
    protected readonly isInvalid: _angular_core.Signal<boolean>;
    /**
     * As etiquetas, com o rotulo provisorio trocado assim que `options` ou a
     * busca trazem a opcao — o valor costuma chegar antes delas na edicao.
     */
    protected readonly chips: _angular_core.Signal<SAutocompleteOption<T>[]>;
    protected readonly isLoading: _angular_core.Signal<boolean>;
    /**
     * Sugestoes menos o que ja foi escolhido: repetir nao e opcao. Com `options`,
     * o texto digitado filtra aqui mesmo; com `url`, quem filtra e a consulta.
     */
    protected readonly sugestoes: _angular_core.Signal<SAutocompleteOption<T>[]>;
    protected readonly noLimite: _angular_core.Signal<boolean>;
    constructor();
    protected onOptionSelected(evento: MatAutocompleteSelectedEvent): void;
    protected remover(opcao: SAutocompleteOption<T>): void;
    /** Backspace no campo vazio remove a ultima etiqueta. */
    protected onBackspace(): void;
    protected onBlur(): void;
    private acrescentar;
    writeValue(valor: T[] | null): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SChipsComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SChipsComponent<any>, "s-chips", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "url": { "alias": "url"; "required": false; "isSignal": true; }; "params": { "alias": "params"; "required": false; "isSignal": true; }; "minLength": { "alias": "minLength"; "required": false; "isSignal": true; }; "compareWith": { "alias": "compareWith"; "required": false; "isSignal": true; }; "debounceTime": { "alias": "debounceTime"; "required": false; "isSignal": true; }; "noResultsText": { "alias": "noResultsText"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; }, { "add": "add"; "remove": "remove"; "search": "search"; "duplicate": "duplicate"; }, never, never, true, never>;
}

/**
 * Como o componente se apresenta antes da escolha.
 *
 * - `button` — so o botao de escolher. O padrao: cabe numa linha de
 *   formulario.
 * - `dropzone` — area tracejada com as regras e o botao, que tambem aceita
 *   arrastar e soltar, na largura disponivel. Para telas em que enviar o
 *   arquivo e a tarefa principal.
 * - `icon` — so o botao de icone. Para celula de tabela e barra de acoes, onde
 *   nao cabe texto; as regras ficam por conta da ajuda do `<s-field>`.
 */
type SFileUploadAppearance = 'button' | 'dropzone' | 'icon';
/** Por que um arquivo foi recusado. */
type SFileErrorKind = 'extension' | 'size';
/** O que o componente devolve quando recusa um arquivo. */
interface SFileError {
    kind: SFileErrorKind;
    file: File;
    message: string;
}
/**
 * Selecao de um arquivo, com validacao antes do envio.
 *
 * **Nao faz upload.** Ele valida extensao e tamanho, mostra o que foi
 * escolhido e entrega o `File` para a aplicacao — que decide para onde mandar.
 * E a mesma regra do `<s-autocomplete>`: a biblioteca nao conhece a API.
 *
 * Baixar tambem segue a regra: o arquivo escolhido agora o componente salva
 * sozinho; o ja enviado (`fileName` + `fileId`) e buscado pela `SFileSource`
 * que a aplicacao registra.
 *
 * **Nao esta no guia de design.** Segue a altura de controle dos botoes e a
 * superficie somente-leitura para o arquivo ja escolhido.
 *
 * Validar antes de enviar poupa a viagem: um PDF de 40MB recusado no navegador
 * economiza o upload inteiro e a mensagem de erro que so chegaria depois.
 */
declare class SFileUploadComponent extends SControlBase<File> {
    /** Extensoes aceitas, sem ponto. Vazio aceita qualquer uma. */
    readonly accept: _angular_core.InputSignal<readonly string[]>;
    /** Tamanho maximo em MB. `0` nao limita. */
    readonly maxSizeMb: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Rotulo do botao de escolher. */
    readonly buttonLabel: _angular_core.InputSignal<string>;
    /** Glifo do botao de escolher. */
    readonly buttonIcon: _angular_core.InputSignal<string>;
    /** Ver `SFileUploadAppearance`. */
    readonly appearance: _angular_core.InputSignal<SFileUploadAppearance>;
    /**
     * Botao na largura toda do container.
     *
     * Para colunas estreitas e formularios de uma coluna, onde um botao curto
     * a esquerda parece solto. `dropzone` ja ocupa a largura toda; `icon` ignora.
     */
    readonly fullWidth: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Texto opcional na `dropzone`, abaixo do botao (ex.: "ou arraste para cá"). */
    readonly dropLabel: _angular_core.InputSignal<string>;
    /**
     * Nome de um arquivo ja enviado antes.
     *
     * Numa tela de edicao o arquivo esta no servidor, nao no navegador: nao ha
     * `File` para mostrar. Este input exibe o nome sem exigir que a aplicacao
     * baixe o conteudo so para preencher o campo.
     */
    readonly fileName: _angular_core.InputSignal<string | null | undefined>;
    /**
     * Id do arquivo ja enviado, entregue a `SFileSource` para baixar.
     *
     * Tambem e o que libera remover um arquivo ja enviado: sem id, o nome e so
     * informativo (a foto atual, por exemplo) e so se troca escolhendo outro.
     */
    readonly fileId: _angular_core.InputSignal<string | null | undefined>;
    /** Exibe o botao de baixar. */
    readonly allowDownload: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Exibe o botao de remover. */
    readonly allowRemove: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Abre um modal quando o arquivo e recusado, com o formato aceito ou o
     * limite de tamanho.
     *
     * Ligado por padrao: sem ele, escolher um arquivo fora da regra nao mudava
     * nada na tela, e a pessoa nao sabia por que. Desligue quando a tela mostrar
     * a recusa por conta propria — `fileError` e emitido nos dois casos.
     */
    readonly showErrorDialog: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Mensagem de extensao recusada. `{formatos}` vira a lista aceita. */
    readonly invalidFormatMessage: _angular_core.InputSignal<string>;
    /** Mensagem de tamanho excedido. `{tamanho}` vira o limite (`10MB`). */
    readonly maxSizeMessage: _angular_core.InputSignal<string>;
    /**
     * Mostra "Selecione um arquivo." enquanto nao houver arquivo — ligue depois
     * da tentativa de salvar. Num `<s-field>` com `required`, a mensagem do
     * campo ja cobre o caso.
     */
    readonly showRequired: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Arquivo aceito ou, ao remover, `null`.
     *
     * O `null` deixa a tela tratar escolher e remover num lugar so; `fileRemoved`
     * continua para quem so quer saber da remocao.
     */
    readonly fileSelected: _angular_core.OutputEmitterRef<File | null>;
    /** Arquivo removido. */
    readonly fileRemoved: _angular_core.OutputEmitterRef<void>;
    /** Arquivo recusado, com o motivo. */
    readonly fileError: _angular_core.OutputEmitterRef<SFileError>;
    /** Pedido de download do arquivo ja enviado (alem da `SFileSource`, se houver). */
    readonly download: _angular_core.OutputEmitterRef<void>;
    /** O seletor de arquivos do sistema vai abrir. */
    readonly selectorOpened: _angular_core.OutputEmitterRef<void>;
    private readonly campo;
    private readonly modal;
    private readonly fonte;
    private readonly entrada;
    protected readonly controlId: _angular_core.Signal<string>;
    protected readonly describedBy: _angular_core.Signal<string | null>;
    protected readonly required: _angular_core.Signal<boolean>;
    /**
     * Nome do arquivo ja enviado, enquanto ele vale.
     *
     * Segue `fileName`, mas o usuario pode remove-lo: depois de "remover", o
     * campo fica vazio mesmo que a tela nao limpe `fileName`. Antes o nome
     * exibido voltava para o input, e o arquivo removido continuava na tela.
     */
    private readonly nomeRemoto;
    /** Um arquivo esta sendo arrastado sobre a `dropzone`. */
    protected readonly arrastando: _angular_core.WritableSignal<boolean>;
    /** O que aparece na tela: o arquivo escolhido agora ou o ja enviado. */
    protected readonly nomeExibido: _angular_core.Signal<string>;
    protected readonly temArquivo: _angular_core.Signal<boolean>;
    protected readonly tamanhoExibido: _angular_core.Signal<string>;
    protected readonly extensoesTexto: _angular_core.Signal<string>;
    protected readonly limiteTexto: _angular_core.Signal<string>;
    protected readonly atributoAccept: _angular_core.Signal<string>;
    /** Baixa o escolhido agora, ou o ja enviado quando ha como buscar. */
    protected readonly podeBaixar: _angular_core.Signal<boolean>;
    /** O escolhido agora sempre sai; o ja enviado, so com `fileId`. */
    protected readonly podeRemover: _angular_core.Signal<boolean>;
    protected readonly faltaArquivo: _angular_core.Signal<boolean>;
    /** Abre o seletor de arquivos do sistema. */
    protected abrirSeletor(): void;
    protected onFileChange(evento: Event): void;
    protected aoArrastar(evento: DragEvent): void;
    protected aoSoltar(evento: DragEvent): void;
    private receber;
    protected remover(): void;
    protected baixar(): void;
    protected onBlur(): void;
    /**
     * Volta ao estado inicial: sem arquivo escolhido, com o nome de `fileName`.
     * Para a tela limpar o campo depois de salvar ou cancelar.
     */
    reset(): void;
    private validar;
    writeValue(valor: File | null): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SFileUploadComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SFileUploadComponent, "s-file-upload", never, { "accept": { "alias": "accept"; "required": false; "isSignal": true; }; "maxSizeMb": { "alias": "maxSizeMb"; "required": false; "isSignal": true; }; "buttonLabel": { "alias": "buttonLabel"; "required": false; "isSignal": true; }; "buttonIcon": { "alias": "buttonIcon"; "required": false; "isSignal": true; }; "appearance": { "alias": "appearance"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "dropLabel": { "alias": "dropLabel"; "required": false; "isSignal": true; }; "fileName": { "alias": "fileName"; "required": false; "isSignal": true; }; "fileId": { "alias": "fileId"; "required": false; "isSignal": true; }; "allowDownload": { "alias": "allowDownload"; "required": false; "isSignal": true; }; "allowRemove": { "alias": "allowRemove"; "required": false; "isSignal": true; }; "showErrorDialog": { "alias": "showErrorDialog"; "required": false; "isSignal": true; }; "invalidFormatMessage": { "alias": "invalidFormatMessage"; "required": false; "isSignal": true; }; "maxSizeMessage": { "alias": "maxSizeMessage"; "required": false; "isSignal": true; }; "showRequired": { "alias": "showRequired"; "required": false; "isSignal": true; }; }, { "fileSelected": "fileSelected"; "fileRemoved": "fileRemoved"; "fileError": "fileError"; "download": "download"; "selectorOpened": "selectorOpened"; }, never, never, true, never>;
}

/** O arquivo ja enviado que a pessoa pediu para baixar. */
interface SFileDownload {
    /** Valor do input `fileId` do componente. */
    id: string;
    /** Nome exibido, com extensao (`certidao.pdf`). */
    fileName: string;
    /** Extensao, sem ponto e em minusculas (`pdf`). */
    extension: string;
}
/**
 * Fonte dos arquivos ja enviados do `<s-file-upload>`.
 *
 * A biblioteca **nao faz HTTP** — a mesma regra do `SAutocompleteSource`. O
 * arquivo escolhido agora, ainda no navegador, o componente baixa sozinho; o
 * que esta no servidor so a aplicacao sabe buscar. Com a fonte registrada, a
 * tela informa `fileId` e o botao de baixar funciona sem codigo na tela.
 *
 * @example
 * ```ts
 * @Injectable({ providedIn: 'root' })
 * export class SiageFileSource extends SFileSource {
 *   private readonly arquivos = inject(ArquivoService);
 *
 *   download({ id, fileName }: SFileDownload) {
 *     return this.arquivos.download(id).pipe(map((r) => salvar(r.body, fileName)));
 *   }
 * }
 * ```
 */
declare abstract class SFileSource {
    /**
     * Baixa o arquivo. Pode devolver um `Observable` (o componente se inscreve)
     * ou nada, quando a implementacao ja dispara o download por conta propria.
     */
    abstract download(arquivo: SFileDownload): Observable<unknown> | void;
}
/**
 * Registra a fonte dos arquivos ja enviados.
 *
 * ```ts
 * // app.config.ts
 * providers: [provideSiageFileSource(SiageFileSource)]
 * ```
 */
declare function provideSiageFileSource(source: Type<SFileSource>): EnvironmentProviders;

/** Como as opcoes se distribuem. */
type SRadioOrientation = 'vertical' | 'horizontal';
/**
 * Escolha unica entre poucas opcoes, todas visiveis.
 *
 * A regra para decidir entre radio e `<s-select>` e a quantidade: ate cinco
 * opcoes curtas, mostrar todas poupa um clique e deixa a comparacao visivel.
 * Acima disso o grupo ocupa mais espaco do que informa, e o select ganha.
 *
 * **Nao esta no guia de design**, que so preve checkbox e switch. Segue a
 * mesma anatomia deles: caixa de 20px, rotulo a direita fazendo parte da area
 * de clique.
 *
 * Encapsula o `mat-radio-group`, que ja resolve o que e chato num grupo de
 * radio: navegacao por setas, um unico ponto de tabulacao e o `role="radiogroup"`.
 */
declare class SRadioGroupComponent<T = unknown> extends SControlBase<T> {
    /** Opcoes exibidas. */
    readonly options: _angular_core.InputSignal<readonly SOption<T>[]>;
    /** Como as opcoes se distribuem. */
    readonly orientation: _angular_core.InputSignal<SRadioOrientation>;
    /** Nome do grupo no formulario nativo. Gerado quando ausente. */
    readonly name: _angular_core.InputSignal<string>;
    /**
     * Emitido quando o usuario escolhe uma opcao, com o valor dela. Nao dispara
     * quando o valor muda pelo formulario (`setValue`, `reset`, `patchValue`).
     */
    readonly selectionChange: _angular_core.OutputEmitterRef<T | null>;
    private readonly campo;
    private readonly nomeGerado;
    protected readonly describedBy: _angular_core.Signal<string | null>;
    protected readonly required: _angular_core.Signal<boolean>;
    protected readonly labelledBy: _angular_core.Signal<string | null>;
    protected readonly ariaLabel: _angular_core.Signal<string | null>;
    protected readonly nome: _angular_core.Signal<string>;
    protected onSelectionChange(evento: MatRadioChange<T>): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SRadioGroupComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SRadioGroupComponent<any>, "s-radio-group", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; }, { "selectionChange": "selectionChange"; }, never, never, true, never>;
}

/**
 * Uma opcao dos botoes de selecao.
 *
 * E o `SOption` dos demais controles com um icone opcional. As chaves de
 * rotulo e valor podem ter outro nome (`optionLabel`, `optionValue`), para
 * listas que ja chegam da API ou de enums como `{ value, name }`.
 */
interface SSelectionOption<T = unknown> {
    label?: string;
    value?: T;
    /** Glifo Material Symbols antes do rotulo. Sem ele, o escolhido ganha um `check`. */
    icon?: string;
    disabled?: boolean;
}
/**
 * Escolha em botoes, unica ou multipla.
 *
 * E o controle dos filtros rapidos e das escalas curtas — turno, dia da
 * semana, situacao. A diferenca para o `<s-radio-group>` nao e visual: aqui
 * cada opcao e um **alvo grande**, feito para ser tocado, e a escolha costuma
 * aplicar na hora.
 *
 * **Nao esta no guia de design.** Cada opcao e um `<s-button>`: o escolhido
 * cheio (`primary`), os demais contornados — a escolha nao depende so da
 * borda. Em tela estreita, os botoes empilham.
 *
 * Cada botao anuncia o proprio estado (`aria-pressed`) e o conjunto e um
 * `role="group"` rotulado pelo `<s-field>`. Na escolha unica, `groupRole="radiogroup"`
 * troca isso por `radiogroup` + `radio` com `aria-checked` e navegacao por setas.
 * Sem rotulo do `<s-field>`, nomeie o grupo com `ariaLabel` ou `ariaLabelledby`.
 */
declare class SSelectionButtonsComponent<T = unknown> extends SControlBase<T | T[]> {
    /**
     * Opcoes exibidas: `SSelectionOption`, ou qualquer objeto com as chaves de
     * `optionLabel` e `optionValue` (um enum `{ value, name }`, uma lista da API).
     */
    readonly options: _angular_core.InputSignal<readonly (object | SSelectionOption<T>)[]>;
    /** Chave do rotulo em cada opcao. Padrao: `label`. */
    readonly optionLabel: _angular_core.InputSignal<string>;
    /** Chave do valor em cada opcao. Padrao: `value`. */
    readonly optionValue: _angular_core.InputSignal<string>;
    /** Permite escolher mais de uma. O valor passa a ser um array. */
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Permite desmarcar clicando na opcao ja escolhida.
     *
     * So vale na escolha unica — no modo multiplo desmarcar sempre funciona. Sem
     * isto, uma escolha feita por engano so se corrige escolhendo outra. Em
     * `groupRole="radiogroup"` e ignorado: radio nunca desmarca (WAI-ARIA).
     */
    readonly allowDeselection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Linha de resumo abaixo dos botoes: "Selecionadas: Aula 1, Aula 2", ou
     * "Nenhuma opção selecionada" no modo multiplo.
     */
    readonly showSelectedSummary: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Uma opcao foi clicada, com o valor dela. Chega depois do formulario ja ter
     * o valor novo — a tela pode validar aqui.
     */
    readonly optionClick: _angular_core.OutputEmitterRef<T>;
    /**
     * Nome acessivel do grupo, para quando o `<s-field>` nao da rotulo (`label`
     * vazio ou ausente) e o `label` do proprio controle tambem nao existe. O
     * rotulo do campo, quando existe, prevalece.
     */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /**
     * Id de um elemento externo que nomeia o grupo (o titulo do cartao, por
     * exemplo). O rotulo do `<s-field>`, quando existe, prevalece.
     */
    readonly ariaLabelledby: _angular_core.InputSignal<string>;
    /**
     * Papel do conjunto. `radiogroup` so vale na escolha unica: o container vira
     * `radiogroup`, cada botao vira `radio` com `aria-checked`, so a opcao
     * marcada (ou a primeira) fica no Tab e as setas, Home e End movem foco e
     * escolha. Nesse papel, clicar ou apertar Espaco na opcao marcada nao a
     * desmarca (`allowDeselection` e ignorado). Com `multiple`, ou no padrao
     * `group`, nada disso muda.
     */
    readonly groupRole: _angular_core.InputSignal<"group" | "radiogroup">;
    private readonly campo;
    private readonly host;
    protected readonly describedBy: _angular_core.Signal<string | null>;
    protected readonly labelledBy: _angular_core.Signal<string | null>;
    private readonly rotuloAvulso;
    protected readonly rotuloGrupo: _angular_core.Signal<string | null>;
    protected readonly required: _angular_core.Signal<boolean>;
    protected readonly radio: _angular_core.Signal<boolean>;
    /** Valores escolhidos, como lista, nos dois modos. */
    private readonly escolhidos;
    protected readonly opcoes: _angular_core.Signal<{
        valor: T;
        rotulo: string;
        marcada: boolean;
        icone: string;
        desabilitada: boolean;
    }[]>;
    protected readonly resumo: _angular_core.Signal<string>;
    protected bloqueado(desabilitada: boolean): boolean;
    /** Opcao que entra no Tab no modo `radiogroup`: a marcada, ou a primeira habilitada. */
    private readonly indiceTab;
    protected tabIndexDe(indice: number): number | null;
    /** Setas, Home e End no modo `radiogroup`: movem foco e escolha, pulando desabilitadas. */
    protected aoTeclar(evento: KeyboardEvent): void;
    protected alternar(valor: T, desabilitada: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SSelectionButtonsComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SSelectionButtonsComponent<any>, "s-selection-buttons", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "allowDeselection": { "alias": "allowDeselection"; "required": false; "isSignal": true; }; "showSelectedSummary": { "alias": "showSelectedSummary"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledby": { "alias": "ariaLabelledby"; "required": false; "isSignal": true; }; "groupRole": { "alias": "groupRole"; "required": false; "isSignal": true; }; }, { "optionClick": "optionClick"; }, never, never, true, never>;
}

/** Uma aba. */
interface STab {
    /** Identificador comparado com `activeId`. */
    id: string;
    /** Rotulo curto. Uma ou duas palavras. */
    label: string;
    /** Glifo opcional de 20px a esquerda. */
    icon?: string;
    /** Contagem ao lado do rotulo — pendencias, por exemplo. */
    badge?: string;
    /** Desabilita a aba sem escondê-la. */
    disabled?: boolean;
}
/**
 * Navegacao por abas dentro de uma tela.
 *
 * **Nao esta no guia de design.** Entrou porque o Professores usa abas para
 * separar secoes de um mesmo registro — frequencia, notas, plano — e sem um
 * componente cada tela desenharia as suas.
 *
 * Nao envolve o `mat-tab-group`: ele gerencia o **conteudo** das abas, com
 * animacao de troca e lazy rendering. Aqui as abas so navegam; o conteudo e da
 * tela, e muitas vezes de uma rota filha. Trazer o grupo do Material
 * significaria adotar o modelo de conteudo dele junto.
 *
 * Sao `<button>` de verdade, com `role="tab"`: setas do teclado e leitor de
 * tela funcionam sem a tela ligar nada.
 */
declare class STabsComponent {
    /** Abas, na ordem. */
    readonly tabs: _angular_core.InputSignal<readonly STab[]>;
    /** Id da aba ativa. */
    readonly activeId: _angular_core.InputSignal<string>;
    /** Rotulo acessivel do grupo, quando a tela tem mais de um. */
    readonly label: _angular_core.InputSignal<string>;
    /** Aba escolhida. */
    readonly tabChange: _angular_core.OutputEmitterRef<string>;
    private readonly el;
    private readonly prefixo;
    /**
     * A aba que fica na ordem do Tab: a ativa, ou a primeira disponivel quando
     * `activeId` nao bate com nenhuma. Sem esse recuo, um `activeId` errado
     * deixava todas com `tabindex=-1` e a lista sumia do teclado.
     */
    protected readonly focavel: _angular_core.Signal<string>;
    /**
     * Id do botao da aba. Use no `aria-labelledby` do painel:
     *
     * ```html
     * <s-tabs #abas [tabs]="abas" [activeId]="ativa()" (tabChange)="ativa.set($event)" />
     * <div role="tabpanel" [id]="abas.panelElementId(ativa())"
     *      [attr.aria-labelledby]="abas.tabElementId(ativa())">...</div>
     * ```
     */
    tabElementId(id: string): string;
    /** Id esperado do painel da aba - e para onde o `aria-controls` dela aponta. */
    panelElementId(id: string): string;
    protected ehAtiva(aba: STab): boolean;
    protected escolher(aba: STab): void;
    /** Setas navegam entre abas, pulando as desabilitadas. Home/End vao a primeira/ultima. */
    protected aoTeclar(evento: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<STabsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<STabsComponent, "s-tabs", never, { "tabs": { "alias": "tabs"; "required": false; "isSignal": true; }; "activeId": { "alias": "activeId"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, { "tabChange": "tabChange"; }, never, never, true, never>;
}

/**
 * Grupo de secoes que abrem e fecham dentro de uma tela.
 *
 * Por padrao abre uma secao por vez: abrir outra fecha a anterior. Com `multi`,
 * cada uma abre e fecha sozinha.
 *
 * As setas do teclado andam entre os cabecalhos (Home e End vao ao primeiro e
 * ao ultimo), pulando os desabilitados.
 *
 * @example
 * ```html
 * <s-accordion>
 *   <s-accordion-item title="Dados gerais" expanded>...</s-accordion-item>
 *   <s-accordion-item title="Historico">...</s-accordion-item>
 * </s-accordion>
 * ```
 */
declare class SAccordionComponent {
    /** Permite mais de uma secao aberta ao mesmo tempo. */
    readonly multi: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private readonly cdk;
    private readonly host;
    constructor();
    /** Setas, Home e End entre os cabecalhos deste grupo — nao dos aninhados. */
    protected aoTeclar(evento: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SAccordionComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SAccordionComponent, "s-accordion", never, { "multi": { "alias": "multi"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, [{ directive: typeof i1$2.CdkAccordion; inputs: {}; outputs: {}; }]>;
}
/**
 * Conteudo que so e montado quando a secao abre.
 *
 * Para secoes caras — uma tabela que consulta a API, um grafico. Quanto tempo
 * ele fica montado depende do `lazyContent` do item: por padrao (`keep`), fica
 * depois da primeira abertura, e fechar e abrir de novo nao refaz a consulta
 * nem perde o que foi digitado; com `reload`, e desmontado ao fechar e montado
 * de novo a cada abertura, buscando dados frescos.
 *
 * @example
 * ```html
 * <s-accordion-item title="Historico">
 *   <ng-template sAccordionContent>
 *     <app-historico [id]="id" />
 *   </ng-template>
 * </s-accordion-item>
 * ```
 */
declare class SAccordionContentDirective {
    readonly template: TemplateRef<unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SAccordionContentDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SAccordionContentDirective, "ng-template[sAccordionContent]", never, {}, {}, never, never, true, never>;
}
/**
 * Quanto tempo o conteudo de `<ng-template sAccordionContent>` fica montado.
 *
 * - `keep`: montado na primeira abertura e mantido — fechar e abrir de novo nao
 *   refaz a consulta nem perde o que foi digitado.
 * - `reload`: montado a cada abertura e desmontado ao fechar — para dados que
 *   mudam enquanto a secao esta fechada, como o historico de um registro que a
 *   tela acabou de salvar.
 */
type SAccordionLazyContent = 'keep' | 'reload';
/** Contexto do `<ng-template sAccordionHeader>`. */
interface SAccordionHeaderContext {
    /** O `title` do item. */
    $implicit: string;
    /** Secao aberta. */
    expanded: boolean;
    /** Secao desabilitada. */
    disabled: boolean;
}
/**
 * Cabecalho proprio no lugar do `title`: um contador, um badge de status, uma
 * segunda linha de texto.
 *
 * O template entra **dentro do botao** que abre a secao. Por isso nao pode ter
 * nada clicavel — botao, link ou campo dentro de botao e HTML invalido e o
 * leitor de tela nao chega neles. O glifo de abrir e fechar continua sendo do
 * componente.
 *
 * Mantenha o `title` mesmo com o template: ele vira o contexto (`let-titulo`).
 *
 * @example
 * ```html
 * <s-accordion-item title="Pendencias">
 *   <ng-template sAccordionHeader let-titulo let-aberto="expanded">
 *     {{ titulo }} <s-badge tone="warning">3</s-badge>
 *   </ng-template>
 *   ...
 * </s-accordion-item>
 * ```
 */
declare class SAccordionHeaderDirective {
    readonly template: TemplateRef<SAccordionHeaderContext>;
    static ngTemplateContextGuard(_diretiva: SAccordionHeaderDirective, contexto: unknown): contexto is SAccordionHeaderContext;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SAccordionHeaderDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SAccordionHeaderDirective, "ng-template[sAccordionHeader]", never, {}, {}, never, never, true, never>;
}
/**
 * Uma secao do `<s-accordion>`.
 *
 * O cabecalho e um `<button>` dentro de um titulo (`role="heading"`), entao a
 * secao aparece na lista de titulos do leitor de tela. O painel continua no DOM
 * fechado, so escondido: o que foi digitado nele nao se perde ao fechar.
 */
declare class SAccordionItemComponent {
    /**
     * Texto do cabecalho. Com `<ng-template sAccordionHeader>`, o template ocupa
     * o lugar dele e o recebe no contexto.
     */
    readonly title: _angular_core.InputSignal<string>;
    /**
     * Secao aberta. Funciona sozinho, como valor inicial, ou ligado nos dois
     * sentidos: `[(expanded)]="aberto"`.
     */
    readonly expanded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Mantem a secao na lista, mas sem abrir nem fechar. */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Nivel do titulo para o leitor de tela. O padrao, 3, serve dentro de uma
     * pagina com `<h1>` no page-header e `<h2>` nas secoes; ajuste se o grupo
     * estiver em outro nivel.
     */
    readonly headingLevel: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Quanto tempo o `<ng-template sAccordionContent>` fica montado: `keep`
     * (padrao) mantem depois da primeira abertura; `reload` monta de novo a cada
     * abertura. Nao afeta o conteudo projetado direto no item, que e sempre
     * mantido.
     */
    readonly lazyContent: _angular_core.InputSignal<SAccordionLazyContent>;
    /** A secao abriu ou fechou: pelo clique ou porque outra abriu no grupo. */
    readonly expandedChange: _angular_core.OutputEmitterRef<boolean>;
    protected readonly conteudoTardio: _angular_core.Signal<SAccordionContentDirective | undefined>;
    protected readonly cabecalho: _angular_core.Signal<SAccordionHeaderDirective | undefined>;
    /** Estado que esta na tela, venha do input, do clique ou do grupo. */
    protected readonly aberto: _angular_core.WritableSignal<boolean>;
    /** Ja abriu alguma vez: no modo `keep`, o conteudo tardio fica montado. */
    private readonly jaAbriu;
    /** O conteudo tardio esta montado agora. */
    protected readonly montaTardio: _angular_core.Signal<boolean>;
    protected readonly contextoCabecalho: _angular_core.Signal<SAccordionHeaderContext>;
    private readonly cdk;
    private readonly prefixo;
    protected readonly headerId: string;
    protected readonly panelId: string;
    /** Escrita vinda do input: o CDK avisa, mas a tela nao precisa ouvir de volta. */
    private sincronizando;
    constructor();
    protected alternar(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SAccordionItemComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SAccordionItemComponent, "s-accordion-item", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "headingLevel": { "alias": "headingLevel"; "required": false; "isSignal": true; }; "lazyContent": { "alias": "lazyContent"; "required": false; "isSignal": true; }; }, { "expandedChange": "expandedChange"; }, ["conteudoTardio", "cabecalho"], ["*"], true, [{ directive: typeof i1$2.CdkAccordionItem; inputs: {}; outputs: {}; }]>;
}

/**
 * Uma etapa.
 *
 * O estado (concluída, atual, pendente) não é informado: sai da posição em
 * relação a `activeId`. Só o erro precisa vir da tela, porque só ela sabe que
 * a validação de uma etapa já passada falhou.
 */
interface SStep {
    /** Identificador comparado com `activeId`. */
    id: string;
    /** Rótulo curto. Uma ou duas palavras: "Dados", "Endereço", "Revisão". */
    label: string;
    /** Uma linha de detalhe abaixo do rótulo. Some quando falta espaço. */
    description?: string;
    /** A etapa tem pendência. Vence o estado da posição. */
    error?: boolean;
    /** Não pode ser escolhida, mesmo com `clickable`. */
    disabled?: boolean;
}
/** Estado de uma etapa, derivado da posição e de `error`. */
type SStepState = 'done' | 'current' | 'pending' | 'error';
/** Disposição das etapas. */
type SStepsOrientation = 'horizontal' | 'vertical';

/** Uma etapa com o estado já resolvido, para o template. */
interface EtapaResolvida {
    etapa: SStep;
    numero: number;
    estado: SStepState;
    /** O estado por extenso, para leitor de tela. */
    estadoTexto: string;
    escolhivel: boolean;
    /** E a etapa de `activeId` - mesmo quando o estado dela e `error`. */
    atual: boolean;
}
/**
 * Indicador de progresso de um fluxo em etapas — cadastro, matrícula,
 * importação.
 *
 * **Não está no guia de design.** Entrou para que cada fluxo em etapas não
 * desenhe o seu. Segue as cores do guia: concluída em `--primary`, atual com
 * anel em `--primary`, pendente neutra e pendência em `--destructive`.
 *
 * **Só indica.** O conteúdo de cada etapa é da tela, como nas abas de
 * `<s-tabs>`: o componente não esconde nem mostra nada, e a tela troca o que
 * renderiza ao ouvir `stepChange`. Não envolve o `mat-stepper` pelo mesmo
 * motivo — ele gerencia o conteúdo das etapas, e trazê-lo seria adotar esse
 * modelo junto.
 *
 * Em container estreito, a disposição horizontal esconde os rótulos das etapas
 * que não são a atual; os marcadores continuam mostrando onde se está.
 *
 * @example
 * ```html
 * <s-steps [steps]="etapas" [activeId]="etapa()" clickable (stepChange)="etapa.set($event)" />
 * ```
 */
declare class SStepsComponent {
    /** Etapas, na ordem. */
    readonly steps: _angular_core.InputSignal<readonly SStep[]>;
    /** Id da etapa atual. As anteriores contam como concluídas. */
    readonly activeId: _angular_core.InputSignal<string>;
    /**
     * Horizontal por padrão, acima do formulário. Vertical para fluxos longos ou
     * para uma coluna lateral, onde a descrição de cada etapa cabe.
     */
    readonly orientation: _angular_core.InputSignal<SStepsOrientation>;
    /**
     * As etapas viram botões e emitem `stepChange`.
     *
     * Desligado, o componente é só indicador: a tela avança pelos botões dela.
     */
    readonly clickable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Com `clickable`, só as etapas anteriores à atual podem ser escolhidas —
     * voltar para corrigir, sim; pular a validação, não. Desligue quando as
     * etapas forem independentes entre si.
     */
    readonly linear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Rótulo acessível da lista. */
    readonly label: _angular_core.InputSignal<string>;
    /** Etapa escolhida pelo usuário. */
    readonly stepChange: _angular_core.OutputEmitterRef<string>;
    protected readonly etapas: _angular_core.Signal<EtapaResolvida[]>;
    protected escolher(item: EtapaResolvida): void;
    private estadoDe;
    private podeEscolher;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SStepsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SStepsComponent, "s-steps", never, { "steps": { "alias": "steps"; "required": false; "isSignal": true; }; "activeId": { "alias": "activeId"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "clickable": { "alias": "clickable"; "required": false; "isSignal": true; }; "linear": { "alias": "linear"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, { "stepChange": "stepChange"; }, never, never, true, never>;
}

/**
 * Tendencia do indicador: comparacao percentual com um periodo anterior.
 *
 * A seta e a cor vem do **sinal do valor**, nao do tom do cartao — "descer"
 * usa a mesma seta e cor de queda mesmo quando descer e a noticia boa (ex.:
 * menos faltas). Quem le um cartao de indicador espera essa convencao; um
 * verde/vermelho que dependesse do significado do numero exigiria ler o
 * rotulo antes de entender a seta.
 */
interface SStatCardTrend {
    /** Variacao percentual em relacao ao periodo de comparacao. */
    readonly value: number;
    /** Texto do periodo de comparacao. Ex.: "vs. ontem". */
    readonly label: string;
}
/**
 * Cartao de indicador: um numero grande com o que ele significa.
 *
 * Aparece nos painteis de acompanhamento — frequencia, notas, ponto — onde a
 * pessoa precisa ler tres ou quatro numeros de relance antes de decidir se
 * abre a listagem.
 *
 * **Nao esta no guia de design.** Ele existe nas telas de exemplo do guia, sem
 * ficha de props; as medidas aqui saem dos tokens de card e da escala
 * tipografica.
 *
 * A ordem de leitura e selo → valor → rotulo → tendencia: o selo tintado
 * ancora o olho antes do numero, e a tendencia (ou o `hint`) fecha a leitura
 * dizendo se o numero e bom, ruim ou so contexto. O valor usa `--text-h2`
 * porque e o que a pessoa veio ler; o rotulo fica em `--text-secondary`,
 * porque so faz sentido depois do numero.
 */
declare class SStatCardComponent {
    /** O que o numero mede. Ex.: "Presenças no mês". */
    readonly label: _angular_core.InputSignal<string>;
    /** O numero em si. Texto quando a aplicacao ja formatou ("71,2%"); numero entra como esta. */
    readonly value: _angular_core.InputSignal<string | number>;
    /** Uma linha de contexto abaixo do valor. Ex.: "de 180 aulas".
     *
     * Ignorado quando `trend` esta presente — os dois ocupam a mesma linha, e a
     * tendencia e mais especifica.
     */
    readonly hint: _angular_core.InputSignal<string>;
    /** Glifo de 24px dentro do selo tintado, no topo do cartao. */
    readonly icon: _angular_core.InputSignal<string>;
    /**
     * Cor do glifo e do realce.
     *
     * Use tom semantico so quando o numero **for** bom ou ruim. Um total neutro
     * pintado de verde sugere uma avaliacao que ninguem fez.
     */
    readonly tone: _angular_core.InputSignal<SBadgeTone>;
    /** Comparacao com o periodo anterior, com seta e cor proprias. */
    readonly trend: _angular_core.InputSignal<SStatCardTrend | null>;
    /** `+12,5%`, `-3%`, `0%` - virgula decimal e sinal, como se le no Brasil. */
    protected readonly variacao: _angular_core.Signal<string>;
    /** O que a seta diz, para quem nao a ve. */
    protected readonly sentido: _angular_core.Signal<"Alta de" | "Queda de" | "Sem variação,">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SStatCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SStatCardComponent, "s-stat-card", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "trend": { "alias": "trend"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Preferencia de tema da pessoa. `system` segue o sistema operacional. */
type STheme = 'light' | 'dark' | 'system';
/**
 * Tema da aplicacao.
 *
 * A biblioteca ja emite os dois temas completos; o que faltava era quem
 * escrevesse `data-theme` no `<html>` — o mesmo atributo que o guia usa, e o
 * que o `styles/_theme.scss` observa.
 *
 * `system` nao escreve atributo nenhum: sem ele, a regra
 * `@media (prefers-color-scheme: dark)` do tema assume, e a tela acompanha o
 * sistema operacional sozinha. E por isso que "seguir o sistema" e um estado de
 * verdade, e nao um terceiro tema.
 *
 * A escolha e guardada em `localStorage`, entao sobrevive ao recarregamento.
 * Se o armazenamento estiver indisponivel — janela anonima, cookies
 * bloqueados — o servico continua funcionando, so nao lembra na proxima visita.
 */
declare class SThemeService {
    private readonly documento;
    private readonly destroyRef;
    /** Preferencia atual. */
    readonly theme: _angular_core.WritableSignal<STheme>;
    /** O sistema operacional esta no escuro. Acompanha a troca em tempo real. */
    private readonly sistemaEscuro;
    /**
     * O tema que esta valendo na tela, com `system` ja resolvido - e reage
     * quando o sistema operacional troca de tema com a tela aberta.
     */
    readonly resolved: _angular_core.Signal<"light" | "dark">;
    constructor();
    /** Troca a preferencia e aplica na hora. */
    set(theme: STheme): void;
    /**
     * Alterna entre claro e escuro.
     *
     * Partindo de `system`, vai para o oposto do que esta na tela — e o que a
     * pessoa espera de um botao que ela clicou justamente porque nao gostou do
     * que via.
     */
    toggle(): void;
    /**
     * O tema que esta valendo na tela, com `system` ja resolvido.
     *
     * @deprecated Use o signal `resolved`, que reage a troca de tema do sistema.
     */
    resolvido(): 'light' | 'dark';
    private acompanharSistema;
    private aplicar;
    private lerGuardado;
    private guardar;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SThemeService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SThemeService>;
}

/**
 * Botao que alterna entre claro e escuro.
 *
 * Encapsula o `SThemeService`, que e quem escreve `data-theme` no `<html>` e
 * guarda a escolha. A tela so precisa por o botao onde quiser — normalmente na
 * `<s-top-bar>`.
 *
 * O glifo mostra o tema **que esta valendo**, nao o que o clique vai trazer:
 * um sol quando a tela esta clara. E a convencao que a maioria dos sistemas
 * usa, e trocar isso confunde mais do que informa.
 */
declare class SThemeToggleComponent {
    /** Rotulo acessivel. Descreve o botao, nao o estado. */
    readonly label: _angular_core.InputSignal<string>;
    protected readonly tema: SThemeService;
    protected readonly glifo: _angular_core.Signal<"dark_mode" | "light_mode">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SThemeToggleComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SThemeToggleComponent, "s-theme-toggle", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { SAccordionComponent, SAccordionContentDirective, SAccordionHeaderDirective, SAccordionItemComponent, SAlertComponent, SAutocompleteComponent, SAutocompleteFooterDirective, SAutocompleteSource, SAvatarComponent, SBadgeComponent, SButtonComponent, SCardComponent, SCardContentDirective, SCardFooterDirective, SCardHeaderDirective, SCardTitleDirective, SCheckboxComponent, SChipsComponent, SDateAdapter, SDatepickerComponent, SDatepickerFooterDirective, SDatepickerHeaderDirective, SDatepickerIntl, SEmptyStateComponent, SFieldComponent, SFileSource, SFileUploadComponent, SFilterCardComponent, SFilterStorage, SIconButtonComponent, SIconComponent, SInputComponent, SInputNumberComponent, SLoadingOverlayComponent, SLoadingService, SMaskDirective, SMenuComponent, SMenuItemComponent, SMenuSeparatorComponent, SMenuTriggerDirective, SModalComponent, SModalFooterDirective, SModalRef, SModalService, SMultiselectComponent, SOnlyDigitsDirective, SOptionTemplateDirective, SPageHeaderComponent, SPageHeaderStatusDirective, SPaginationComponent, SPasswordRequirementsComponent, SPermissionChecker, SProgressBarComponent, SRadioGroupComponent, SRecordCountComponent, SSelectComponent, SSelectionButtonsComponent, SSessionFilterStorage, SSidebarComponent, SSkeletonComponent, SSpinnerComponent, SStatCardComponent, SStepsComponent, SSwitchComponent, STableCellDirective, STableComponent, STableSkeletonComponent, STabsComponent, STextareaComponent, SThemeService, SThemeToggleComponent, SToastService, STooltipDirective, STopBarComponent, S_DATE_CONFIG, S_DATE_FORMATS, S_DATE_PART_LENGTH, S_LOADING_DELAY, S_MENSAGENS_PADRAO, S_PASSWORD_RULES, S_TOAST_DEFAULTS, S_TOAST_DURACAO, S_TOAST_MAXIMO, S_VALIDATION_MESSAGES, adiarCarregamento, avatarInitials, avatarTone, breadcrumbFromRoute, criarConfigData, firstFromPage, formatMask, formatPattern, formatPhone, formatPtBrNumber, injectModalData, injectModalRef, integerDigitCount, mapCellTemplates, mascararData, maskPtBrNumber, pageFromFirst, parsePtBrNumber, pixelsDoTamanho, positionAfterRaw, primeiraMensagem, provideSiageAutocompleteSource, provideSiageDateAdapter, provideSiageFileSource, provideSiageFilterStorage, provideSiageLoadingDelay, provideSiagePermissionChecker, provideSiageToast, provideSiageValidationMessages, rawCountBeforeCursor, severityTone, siageLoadingInterceptor, tamanhoDeIcone, todasAsMensagens, validateMinMax, variavelDoTamanho };
export type { SAccordionHeaderContext, SAccordionLazyContent, SAlertType, SAutocompleteLookup, SAutocompleteOption, SAutocompleteQuery, SAutocompleteSelection, SAvatarSize, SAvatarTone, SBadgeTone, SBreadcrumb, SButtonType, SButtonVariant, SCardElevation, SCardPadding, SDateAdapterOptions, SDateConfig, SDatePart, SDateRange, SDateValue, SDatepickerFooterContext, SDatepickerFooterControls, SDatepickerHeaderContext, SDatepickerHeaderControls, SDatepickerSelectionMode, SDayMark, SDayMarkFn, SDayMarkResult, SEmptyStateVariant, SFieldError, SFileDownload, SFileError, SFileErrorKind, SFileUploadAppearance, SFilterValueFormatter, SIconButtonTone, SIconSize, SIconSizeInput, SIconVariant, SInputNumberFormatOptions, SInputNumberMaskResult, SInputNumberParseResult, SInputType, SListActionsConfig, SListActionsTooltips, SListAddButtonConfig, SListColumn, SListLazyLoadEvent, SListOptions, SListPermissionConfig, SListTableConfig, SListTagSeverity, SMaskPreset, SMaskResult, SMaskValue, SModalConfig, SModalSize, SModalVariant, SOpenModalConfig, SOption, SOptionTemplateContext, SPagedData, SPasswordRule, SProgressBarMode, SProgressBarTone, SRadioOrientation, SSelectionOption, SSidebarEntry, SSidebarGroup, SSidebarItem, SSidebarRouterLink, SStatCardTrend, SStep, SStepState, SStepsOrientation, STab, STableAction, STableActionEvent, STableAlign, STableCellContext, STableCellTemplates, STableColumn, STableEmpty, STableSort, STheme, SToast, SToastConfig, SToastDefaults, SToastOptions, SToastType, STooltipPosition, SValidationMessage, SValidationMessages, ValidatorErrors };
