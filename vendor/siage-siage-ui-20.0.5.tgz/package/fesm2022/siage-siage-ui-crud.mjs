import * as i0 from '@angular/core';
import { inject, DestroyRef, signal, computed, linkedSignal, input, output, contentChildren, ChangeDetectionStrategy, Component, booleanAttribute, ElementRef, effect, SimpleChange, Input, Directive } from '@angular/core';
import { rxResource, takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Router } from '@angular/router';
import { SModalService, SToastService, STableCellDirective, mapCellTemplates, SButtonComponent, SFilterCardComponent, SPageHeaderComponent, STableComponent, SPermissionChecker, SCardComponent, SCardContentDirective, SCardFooterDirective, SCardHeaderDirective } from '@siage/siage-ui';
import * as i1 from '@angular/forms';
import { FormGroupDirective, FormArray, FormGroup, FormRecord, ReactiveFormsModule, ControlContainer } from '@angular/forms';
import { map } from 'rxjs';

/**
 * Fonte de dados de uma listagem de CRUD.
 *
 * A biblioteca **nao faz HTTP** — mesma regra do `SAutocompleteSource`. Ela
 * descreve o pedido (`SCrudQuery`) e espera uma pagina de volta; quem sabe
 * chamar a API e o service do sistema.
 *
 * Para o contrato que os sistemas do SIAGE ja usam hoje
 * (`getByFilterPaginated`, `PagedResult`) existe o adaptador pronto
 * `siageCrudDataSource()` — nao e preciso escrever esta classe a mao.
 *
 * @example
 * ```ts
 * @Injectable({ providedIn: 'root' })
 * export class TipoFaltaDataSource extends SCrudDataSource<TipoFaltaListDto> {
 *   private readonly api = inject(TipoFaltaService);
 *
 *   list({ page, pageSize, sort, filters }: SCrudQuery) {
 *     return this.api.buscar({ page, pageSize, sort, ...filters }).pipe(
 *       map((r) => ({ items: r.items, total: r.totalCount })),
 *     );
 *   }
 *
 *   remove(row: TipoFaltaListDto) {
 *     return this.api.excluir(row.id);
 *   }
 * }
 * ```
 */
class SCrudDataSource {
}

/** Ids das acoes que a propria biblioteca executa. */
const ACOES_PADRAO = ['view', 'edit', 'remove', 'inactivate', 'activate'];
const PAGINA_VAZIA = { items: [], total: 0 };
function ehAcaoPadrao(id) {
    return ACOES_PADRAO.includes(id);
}
/**
 * O estado e o comportamento de uma listagem de CRUD, sem template nenhum.
 *
 * ## O que isto resolve
 *
 * Antes desta camada, cada sistema reescrevia a mesma listagem: um recurso
 * paginado, o formulario de filtro virando parametro, a ordenacao, o modal de
 * confirmacao, o aviso de sucesso e a navegacao para o formulario. Era muito
 * codigo para algo que nao muda de tela para tela — e cada copia envelhecia
 * sozinha, num sistema de cada vez.
 *
 * Aqui isso e uma funcao: `injectCrudList(config)`. A tela escreve o que e
 * dela — colunas, filtros, rotas, fonte de dados — e mais nada.
 *
 * ## Por que funcao, e nao classe base
 *
 * Herdar de um componente base obriga a tela a ser filha de alguem, amarra o
 * construtor e transforma qualquer ajuste em `override`. Uma funcao devolve um
 * objeto: a tela guarda numa propriedade, o template usa, e ela continua livre
 * para herdar de quem quiser — ou de ninguem.
 *
 * ## O que dispara consulta
 *
 * Trocar de pagina, de tamanho de pagina ou de ordenacao consulta na hora.
 * **Digitar num filtro nao consulta**: os filtros so entram na consulta quando
 * a pessoa clica em Buscar (ou tecla Enter no card de filtros). E o que evita
 * uma chamada por tecla e mantem a lista parada enquanto alguem preenche tres
 * campos.
 *
 * @example
 * ```ts
 * export class TipoFaltaListComponent {
 *   protected readonly crud = injectCrudList<TipoFaltaListDto>({
 *     entity: { name: 'Tipo de Falta', namePlural: 'Tipos de Falta', gender: 'masculine' },
 *     dataSource: siageCrudDataSource(inject(TipoFaltaService)),
 *     routes: { base: '/configuracoes-ponto/tipos-falta' },
 *     filters: inject(FormBuilder).group({ nome: [''], ativo: [null] }),
 *     columns: COLUNAS,
 *     actions: { view: true, edit: true, remove: true, inactivate: true },
 *   });
 * }
 * ```
 */
class SCrudList {
    /** Opcional: sem `Router` no injetor, so a navegacao automatica deixa de existir. */
    #router = inject(Router, { optional: true });
    #modal = inject(SModalService);
    #toast = inject(SToastService);
    #destroyRef = inject(DestroyRef);
    #config;
    /** Pagina atual, comecando em 1. */
    page = signal(1, ...(ngDevMode ? [{ debugName: "page" }] : []));
    /** Registros por pagina. */
    pageSize = signal(10, ...(ngDevMode ? [{ debugName: "pageSize" }] : []));
    /** Ordenacao atual, ou `null` para a ordem que o backend devolver. */
    sort = signal(null, ...(ngDevMode ? [{ debugName: "sort" }] : []));
    /** Filtros **aplicados** — o que foi para a consulta, nao o que esta digitado. */
    filters = signal({}, ...(ngDevMode ? [{ debugName: "filters" }] : []));
    /** Falso ate a primeira busca, quando `autoLoad` esta desligado. */
    #ligado = signal(true, ...(ngDevMode ? [{ debugName: "#ligado" }] : []));
    #consulta = computed(() => ({
        page: this.page(),
        pageSize: this.pageSize(),
        sort: this.sort(),
        filters: this.filters(),
    }), ...(ngDevMode ? [{ debugName: "#consulta" }] : []));
    /**
     * A consulta em si.
     *
     * O recurso cancela a resposta anterior quando um novo pedido sai, que e o
     * que impede a pagina 1 de chegar depois da 2 e sobrescreve-la.
     */
    #recurso = rxResource({
        params: () => (this.#ligado() ? this.#consulta() : undefined),
        stream: ({ params }) => this.#config.dataSource.list(params),
        defaultValue: { items: [], total: 0 },
    });
    constructor(config) {
        this.#config = config;
        this.pageSize.set(config.pageSize ?? 10);
        this.sort.set(config.sort ?? null);
        this.#ligado.set(config.autoLoad ?? true);
    }
    // --- o que a tela le ------------------------------------------------------
    /**
     * A ultima pagina que a fonte devolveu, mantida enquanto a proxima nao chega.
     *
     * O recurso volta ao `defaultValue` (lista vazia) a cada mudanca de pagina,
     * ordem ou filtro. Repassado a tabela, isso fazia toda troca de pagina
     * mostrar "nenhum registro cadastrado" e sumir com o paginador ate a resposta
     * chegar. Com a pagina anterior na tela, a tabela decide sozinha: mantem as
     * linhas antigas e, passado o limiar, troca pelo esqueleto.
     *
     * Erro nao herda nada: a tela precisa mostrar a falha, nao dados velhos.
     */
    #pagina = linkedSignal(...(ngDevMode ? [{ debugName: "#pagina", source: () => {
                if (this.#recurso.error()) {
                    return PAGINA_VAZIA;
                }
                if (this.#recurso.isLoading() || !this.#recurso.hasValue()) {
                    return undefined;
                }
                return this.#recurso.value();
            },
            computation: (atual, anterior) => atual ?? anterior?.value ?? PAGINA_VAZIA }] : [{
            source: () => {
                if (this.#recurso.error()) {
                    return PAGINA_VAZIA;
                }
                if (this.#recurso.isLoading() || !this.#recurso.hasValue()) {
                    return undefined;
                }
                return this.#recurso.value();
            },
            computation: (atual, anterior) => atual ?? anterior?.value ?? PAGINA_VAZIA,
        }]));
    /** Linhas da pagina atual. */
    rows = computed(() => this.#pagina().items, ...(ngDevMode ? [{ debugName: "rows" }] : []));
    /** Total do resultado ja filtrado. */
    total = computed(() => this.#pagina().total, ...(ngDevMode ? [{ debugName: "total" }] : []));
    /** Consulta em andamento. */
    loading = this.#recurso.isLoading;
    /** Erro da ultima consulta, quando houve. */
    error = this.#recurso.error;
    /** Formulario de filtros, quando a tela declarou um. */
    get filterForm() {
        return this.#config.filters;
    }
    /** Colunas configuradas, na ordem. */
    get columns() {
        return this.#config.columns;
    }
    /** Titulo da tela. */
    title = computed(() => this.#config.title ?? this.#config.entity.namePlural ?? this.#config.entity.name, ...(ngDevMode ? [{ debugName: "title" }] : []));
    /** Descricao sob o titulo. */
    description = computed(() => this.#config.description ?? '', ...(ngDevMode ? [{ debugName: "description" }] : []));
    /** Trilha do cabecalho. */
    breadcrumbs = computed(() => this.#config.breadcrumbs ?? [], ...(ngDevMode ? [{ debugName: "breadcrumbs" }] : []));
    /** Exibe a seta de voltar. */
    showBack = computed(() => this.#config.showBack ?? false, ...(ngDevMode ? [{ debugName: "showBack" }] : []));
    /** Exibe o botao de cadastrar. */
    showCreate = computed(() => this.#config.showCreate ?? true, ...(ngDevMode ? [{ debugName: "showCreate" }] : []));
    /** Rotulo do botao de cadastrar — "Novo Tipo de Falta". */
    createLabel = computed(() => this.#config.createLabel ?? `${this.#flexionar('Novo', 'Nova')} ${this.#config.entity.name}`, ...(ngDevMode ? [{ debugName: "createLabel" }] : []));
    /** Substantivo da contagem do rodape. */
    itemsLabel = computed(() => this.#config.itemsLabel ??
        (this.#config.entity.namePlural ?? this.#config.entity.name).toLocaleLowerCase('pt-BR'), ...(ngDevMode ? [{ debugName: "itemsLabel" }] : []));
    /** Opcoes do seletor de tamanho de pagina. */
    pageSizeOptions = computed(() => this.#config.pageSizeOptions ?? [10, 25, 50], ...(ngDevMode ? [{ debugName: "pageSizeOptions" }] : []));
    /** Colunas da grade de filtros. */
    /**
     * As acoes da ultima coluna.
     *
     * Uma acao so entra se houver como executa-la: sem `remove()` na fonte de
     * dados a lixeira nao aparece, ainda que a configuracao peca — um botao que
     * nao faz nada e pior que um botao ausente. Ativar e inativar sao duas acoes
     * que se escondem uma a outra, porque o icone muda conforme a linha.
     */
    actions = computed(() => {
        const config = this.#config;
        const pedidas = config.actions ?? { view: true, edit: true, remove: true };
        const fonte = config.dataSource;
        const nome = config.entity.name;
        const lista = [];
        if (pedidas.view) {
            lista.push({
                id: 'view',
                icon: 'visibility',
                label: (linha) => `Visualizar ${this.rowLabel(linha) || nome}`,
            });
        }
        if (pedidas.edit) {
            lista.push({
                id: 'edit',
                icon: 'edit',
                label: (linha) => `Editar ${this.rowLabel(linha) || nome}`,
            });
        }
        if (pedidas.inactivate && fonte.setActive) {
            lista.push({
                id: 'inactivate',
                icon: 'toggle_off',
                label: (linha) => `Inativar ${this.rowLabel(linha) || nome}`,
                hidden: (linha) => !this.#estaAtiva(linha),
            }, {
                id: 'activate',
                icon: 'toggle_on',
                label: (linha) => `Ativar ${this.rowLabel(linha) || nome}`,
                hidden: (linha) => this.#estaAtiva(linha),
            });
        }
        if (pedidas.remove && fonte.remove) {
            lista.push({
                id: 'remove',
                icon: 'delete',
                label: (linha) => `Excluir ${this.rowLabel(linha) || nome}`,
                // Neutro ate o hover, como o guia pede para a acao destrutiva fora do
                // modal de confirmacao.
                variant: 'destructive',
                text: true,
            });
        }
        return [...lista, ...(config.extraActions ?? [])];
    }, ...(ngDevMode ? [{ debugName: "actions" }] : []));
    /**
     * O que a tabela mostra quando nao ha linhas.
     *
     * Sao tres situacoes diferentes, e trata-las igual e o erro classico: erro de
     * carga nao e lista vazia, e filtro sem resultado nao e cadastro vazio —
     * oferecer "cadastrar" no primeiro caso responde a pergunta errada.
     */
    empty = computed(() => {
        const nome = this.#config.entity.name;
        if (this.error()) {
            return {
                variant: 'error',
                headingLevel: 2,
                title: 'Não foi possível carregar a listagem',
                description: 'Verifique sua conexão e tente buscar novamente.',
            };
        }
        if (Object.keys(this.filters()).length > 0) {
            return {
                variant: 'no-results',
                headingLevel: 2,
                title: 'Nenhum resultado para os filtros aplicados',
                description: 'Revise os filtros ou limpe a busca para ver todos os registros.',
            };
        }
        return {
            variant: 'no-data',
            // A listagem so tem o h1 do cabecalho: o titulo do vazio vem logo abaixo.
            headingLevel: 2,
            title: `Nenhum ${nome} cadastrado`,
            description: 'Cadastre o primeiro para começar.',
            actionLabel: this.showCreate() ? this.createLabel() : '',
        };
    }, ...(ngDevMode ? [{ debugName: "empty" }] : []));
    /** Como a linha e chamada nas mensagens. Ver `SCrudConfig.rowLabel`. */
    rowLabel(row) {
        if (this.#config.rowLabel) {
            return this.#config.rowLabel(row);
        }
        for (const chave of ['nome', 'descricao', 'titulo']) {
            const valor = row[chave];
            if (typeof valor === 'string' && valor !== '') {
                return valor;
            }
        }
        return '';
    }
    // --- o que a tela dispara -------------------------------------------------
    /** Aplica os filtros do formulario e volta para a primeira pagina. */
    search() {
        this.filters.set(this.#valoresDoFiltro());
        this.page.set(1);
        this.#ligado.set(true);
    }
    /** Limpa formulario, filtros e ordenacao, e busca de novo. */
    clear() {
        this.#config.filters?.reset();
        this.filters.set({});
        this.sort.set(this.#config.sort ?? null);
        this.page.set(1);
    }
    /** Troca de pagina. */
    goToPage(page) {
        this.page.set(page);
    }
    /** Troca o tamanho da pagina — sempre voltando para a primeira. */
    setPageSize(pageSize) {
        this.pageSize.set(pageSize);
        this.page.set(1);
    }
    /**
     * Troca a ordenacao.
     *
     * Volta para a primeira pagina: seguir na pagina 7 de uma ordem que acabou de
     * mudar mostra um recorte que nao quer dizer nada.
     */
    setSort(sort) {
        this.sort.set(sort);
        this.page.set(1);
    }
    /** Refaz a consulta atual, sem mexer em filtro, pagina ou ordem. */
    reload() {
        this.#recurso.reload();
    }
    /**
     * O botao do estado vazio, que faz uma coisa diferente em cada situacao -
     * ver `empty`: tentar de novo apos erro, limpar o filtro sem resultado, ou
     * cadastrar o primeiro registro.
     */
    emptyAction() {
        switch (this.empty().variant) {
            case 'error':
                this.reload();
                break;
            case 'no-results':
                this.clear();
                break;
            default:
                this.create();
        }
    }
    /** Vai para a tela de cadastro, quando ha `routes`. */
    create() {
        this.#navegar([this.#config.routes?.create ?? 'cadastrar']);
    }
    /** Vai para a tela de visualizacao, quando ha `routes`. */
    view(row) {
        this.#navegar([this.#config.routes?.detail ?? 'visualizar', this.#idDe(row)]);
    }
    /** Vai para a tela de edicao, quando ha `routes`. */
    edit(row) {
        this.#navegar([this.#config.routes?.edit ?? 'editar', this.#idDe(row)]);
    }
    /**
     * Confirma e exclui.
     *
     * A confirmacao nomeia o registro e a acao — "Sim, excluir" —, porque quem le
     * so o botao precisa entender a consequencia.
     */
    async remove(row) {
        const fonte = this.#config.dataSource;
        if (!fonte.remove) {
            return;
        }
        const nome = this.#config.entity.name;
        const rotulo = this.rowLabel(row);
        const flexao = this.#flexionar('o', 'a');
        const confirmou = await this.#modal.confirm({
            variant: 'destructive',
            title: `Excluir ${nome}?`,
            description: rotulo
                ? `${rotulo} será excluíd${flexao} permanentemente. Esta ação não pode ser desfeita.`
                : 'O registro será excluído permanentemente. Esta ação não pode ser desfeita.',
            confirmLabel: 'Sim, excluir',
        });
        if (!confirmou) {
            return;
        }
        fonte
            .remove(row)
            .pipe(takeUntilDestroyed(this.#destroyRef))
            .subscribe({
            next: () => {
                this.#toast.success(`${nome} excluíd${flexao} com sucesso`, rotulo);
                this.reload();
            },
            error: (erro) => {
                this.#toast.error(`Não foi possível excluir ${flexao} ${nome}`, this.#config.errorMessage?.(erro, 'remove'));
            },
        });
    }
    /** Confirma e alterna ativo/inativo. */
    async toggleActive(row) {
        const fonte = this.#config.dataSource;
        if (!fonte.setActive) {
            return;
        }
        const nome = this.#config.entity.name;
        const rotulo = this.rowLabel(row);
        const ativa = this.#estaAtiva(row);
        const verbo = ativa ? 'Inativar' : 'Ativar';
        const flexao = this.#flexionar('o', 'a');
        const confirmou = await this.#modal.confirm({
            title: `${verbo} ${nome}?`,
            description: ativa
                ? `${rotulo || 'O registro'} deixa de aparecer nas telas que dependem dele, mas continua no histórico.`
                : `${rotulo || 'O registro'} volta a ficar disponível para uso.`,
            confirmLabel: `Sim, ${verbo.toLocaleLowerCase('pt-BR')}`,
        });
        if (!confirmou) {
            return;
        }
        fonte
            .setActive(row, !ativa)
            .pipe(takeUntilDestroyed(this.#destroyRef))
            .subscribe({
            next: () => {
                this.#toast.success(`${nome} ${ativa ? 'inativad' : 'ativad'}${flexao} com sucesso`, rotulo);
                this.reload();
            },
            error: (erro) => {
                this.#toast.error(`Não foi possível ${verbo.toLocaleLowerCase('pt-BR')} ${flexao} ${nome}`, this.#config.errorMessage?.(erro, 'active'));
            },
        });
    }
    /**
     * Executa a acao padrao correspondente ao id.
     *
     * Devolve `false` para id que nao e da biblioteca — o sinal de que a acao e
     * da tela, e o `<s-crud-list>` a repassa no output `action`.
     */
    run(action, row) {
        if (!ehAcaoPadrao(action)) {
            return false;
        }
        switch (action) {
            case 'view':
                this.view(row);
                return true;
            case 'edit':
                this.edit(row);
                return true;
            case 'remove':
                void this.remove(row);
                return true;
            default:
                void this.toggleActive(row);
                return true;
        }
    }
    // --- por dentro -----------------------------------------------------------
    #valoresDoFiltro() {
        const form = this.#config.filters;
        if (!form) {
            return {};
        }
        const valores = form.getRawValue();
        const limpos = {};
        for (const [chave, valor] of Object.entries(valores)) {
            // `false` e `0` sao filtros validos — "Documento obrigatório: Não" e um
            // recorte, nao a ausencia de recorte. So o vazio de verdade sai.
            if (valor === null || valor === undefined || valor === '') {
                continue;
            }
            if (Array.isArray(valor) && valor.length === 0) {
                continue;
            }
            limpos[chave] = valor;
        }
        return limpos;
    }
    #estaAtiva(row) {
        return row[this.#config.activeKey ?? 'ativo'] === true;
    }
    #idDe(row) {
        const id = row[this.#config.idKey ?? 'id'];
        return id === null || id === undefined ? '' : String(id);
    }
    #navegar(segmentos) {
        const rotas = this.#config.routes;
        if (!rotas) {
            return;
        }
        void this.#router?.navigate([rotas.base, ...segmentos]);
    }
    #flexionar(masculino, feminino) {
        return this.#config.entity.gender === 'feminine' ? feminino : masculino;
    }
}
/**
 * Cria a listagem a partir da configuracao. Chame no campo de uma classe de
 * componente, como qualquer `inject()`.
 *
 * @see SCrudList
 */
function injectCrudList(config) {
    return new SCrudList(config);
}

/**
 * A tela de listagem inteira: cabecalho, filtros, tabela e rodape.
 *
 * ## O que ele e — e o que nao e
 *
 * E **composicao**, nao um componente novo de dados: por dentro sao os mesmos
 * `<s-page-header>`, `<s-filter-card>` e `<s-table>` que qualquer tela pode
 * montar a mao. Ele existe porque essa montagem e sempre igual, e repeti-la em
 * cada CRUD e onde a moldura de uma tela comeca a divergir da moldura da outra
 * — titulo em lugar diferente, botao com outro rotulo, tabela sem estado vazio.
 *
 * Quem precisa de um arranjo diferente continua livre para montar as tres
 * pecas na mao e usar so `injectCrudList()` — o comportamento nao depende deste
 * componente.
 *
 * ## Os dois slots
 *
 * - `[filters]` — os campos do card de filtros, com o `formGroup` da tela.
 * - `<ng-template sTableCell="chave">` — a celula que foge do texto: um botao,
 *   um link, um icone. Vai direto para a coluna correspondente da tabela.
 *
 * ## Outputs e comportamento padrao
 *
 * Os outputs sao **avisos**, e nao substituicoes: excluir sempre pede
 * confirmacao e chama a fonte de dados; visualizar e editar navegam **quando ha
 * `routes` na configuracao**. Sem `routes`, nada e navegado — e ai os outputs
 * `view`/`edit` sao o caminho da tela, que pode abrir um modal em vez de mudar
 * de rota.
 *
 * @example
 * ```html
 * <s-crud-list [crud]="crud">
 *   <form filters [formGroup]="filtros">
 *     <s-field label="Nome"><s-input icon="search" formControlName="nome" /></s-field>
 *     <s-field label="Status"><s-select [options]="status" formControlName="ativo" /></s-field>
 *   </form>
 *
 *   <ng-template sTableCell="emUso" let-linha>
 *     <s-button variant="ghost" size="sm" (click)="verUsos(linha)">Ver usos</s-button>
 *   </ng-template>
 * </s-crud-list>
 * ```
 */
class SCrudListComponent {
    /** A listagem criada por `injectCrudList()`. */
    crud = input.required(...(ngDevMode ? [{ debugName: "crud" }] : []));
    /**
     * Repassado ao `<s-filter-card>`: com ele os filtros sobrevivem a ida ao
     * cadastro e a volta, e a listagem reconsulta com eles ao reabrir.
     */
    filterId = input('', ...(ngDevMode ? [{ debugName: "filterId" }] : []));
    /** Rotulos dos chips de filtro ativo, por chave do formulario de filtros. */
    filterLabels = input({}, ...(ngDevMode ? [{ debugName: "filterLabels" }] : []));
    /** Opcoes por chave, para o chip mostrar o rotulo e nao o id do select. */
    filterOptions = input({}, ...(ngDevMode ? [{ debugName: "filterOptions" }] : []));
    /** Formatador dos valores de chip que as opcoes nao resolvem. */
    filterValueFormatter = input(null, ...(ngDevMode ? [{ debugName: "filterValueFormatter" }] : []));
    /** Botao de cadastrar acionado — inclusive o do estado vazio. */
    create = output();
    /** Acao de visualizar acionada numa linha. */
    view = output();
    /** Acao de editar acionada numa linha. */
    edit = output();
    /**
     * Acao de excluir acionada numa linha.
     *
     * O aviso sai **antes** da confirmacao: o modal e a chamada a fonte de dados
     * continuam sendo da biblioteca.
     */
    remove = output();
    /** Ativar ou inativar acionado numa linha. */
    inactivate = output();
    /** Acao declarada em `extraActions`, que a biblioteca nao executa. */
    action = output();
    /** Seta de voltar do cabecalho. */
    back = output();
    /**
     * Os templates de celula projetados na tela, repassados a tabela.
     *
     * A tabela e propriedade deste componente, entao os templates precisam
     * atravessa-lo: quem escreve `<ng-template sTableCell>` esta dentro do
     * `<s-crud-list>`, nao dentro da `<s-table>`.
     */
    templatesProjetados = contentChildren(STableCellDirective, ...(ngDevMode ? [{ debugName: "templatesProjetados", descendants: true }] : [{ descendants: true }]));
    templates = computed(() => mapCellTemplates(this.templatesProjetados()), ...(ngDevMode ? [{ debugName: "templates" }] : []));
    criar() {
        this.create.emit();
        this.crud().create();
    }
    /**
     * Botao do estado vazio. So "sem dados" cadastra - e passa por `criar` para
     * emitir `create` como o botao do cabecalho. Erro tenta de novo e filtro sem
     * resultado limpa a busca: ver `SCrudList.emptyAction`.
     */
    aoAcaoDoVazio() {
        if (this.crud().empty().variant === 'no-data') {
            this.criar();
        }
        else {
            this.crud().emptyAction();
        }
    }
    aoAcionar(evento) {
        const { action, row } = evento;
        switch (action) {
            case 'view':
                this.view.emit(row);
                break;
            case 'edit':
                this.edit.emit(row);
                break;
            case 'remove':
                this.remove.emit(row);
                break;
            case 'inactivate':
            case 'activate':
                this.inactivate.emit(row);
                break;
            default:
                // Acao da tela: a biblioteca nao sabe o que fazer com ela, e nao tenta.
                this.action.emit(evento);
                return;
        }
        this.crud().run(action, row);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCrudListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SCrudListComponent, isStandalone: true, selector: "s-crud-list", inputs: { crud: { classPropertyName: "crud", publicName: "crud", isSignal: true, isRequired: true, transformFunction: null }, filterId: { classPropertyName: "filterId", publicName: "filterId", isSignal: true, isRequired: false, transformFunction: null }, filterLabels: { classPropertyName: "filterLabels", publicName: "filterLabels", isSignal: true, isRequired: false, transformFunction: null }, filterOptions: { classPropertyName: "filterOptions", publicName: "filterOptions", isSignal: true, isRequired: false, transformFunction: null }, filterValueFormatter: { classPropertyName: "filterValueFormatter", publicName: "filterValueFormatter", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { create: "create", view: "view", edit: "edit", remove: "remove", inactivate: "inactivate", action: "action", back: "back" }, host: { classAttribute: "s-crud-list" }, queries: [{ propertyName: "templatesProjetados", predicate: STableCellDirective, descendants: true, isSignal: true }], ngImport: i0, template: "<s-page-header\n  [breadcrumbs]=\"crud().breadcrumbs()\"\n  [title]=\"crud().title()\"\n  [description]=\"crud().description()\"\n  [showBack]=\"crud().showBack()\"\n  (back)=\"back.emit()\"\n>\n  @if (crud().showCreate()) {\n    <s-button action variant=\"primary\" icon=\"add\" (click)=\"criar()\">\n      {{ crud().createLabel() }}\n    </s-button>\n  }\n</s-page-header>\n\n@if (crud().filterForm) {\n  <s-filter-card\n    [loading]=\"crud().loading()\"\n    [form]=\"crud().filterForm ?? null\"\n    [filterId]=\"filterId()\"\n    [labelMap]=\"filterLabels()\"\n    [optionMap]=\"filterOptions()\"\n    [valueFormatter]=\"filterValueFormatter()\"\n    (search)=\"crud().search()\"\n    (clear)=\"crud().clear()\"\n    (restored)=\"crud().search()\"\n  >\n    <ng-content select=\"[filters]\" />\n  </s-filter-card>\n}\n\n<s-table\n  [label]=\"crud().title()\"\n  [columns]=\"crud().columns\"\n  [rows]=\"crud().rows()\"\n  [actions]=\"crud().actions()\"\n  [cellTemplates]=\"templates()\"\n  [sort]=\"crud().sort()\"\n  [loading]=\"crud().loading()\"\n  [empty]=\"crud().empty()\"\n  [page]=\"crud().page()\"\n  [pageSize]=\"crud().pageSize()\"\n  [total]=\"crud().total()\"\n  [pageSizeOptions]=\"crud().pageSizeOptions()\"\n  [itemsLabel]=\"crud().itemsLabel()\"\n  (sortChange)=\"crud().setSort($event)\"\n  (pageChange)=\"crud().goToPage($event)\"\n  (pageSizeChange)=\"crud().setPageSize($event)\"\n  (actionClick)=\"aoAcionar($event)\"\n  (emptyAction)=\"aoAcaoDoVazio()\"\n/>\n", styles: [":host{display:flex;flex-direction:column;gap:var(--space-24, 24px)}\n"], dependencies: [{ kind: "component", type: SButtonComponent, selector: "s-button", inputs: ["variant", "outlined", "fullWidth", "pressed", "buttonRole", "checked", "focusIndex", "loading", "loadingText", "disabled", "icon", "iconRight", "type", "label"] }, { kind: "component", type: SFilterCardComponent, selector: "s-filter-card", inputs: ["title", "searchLabel", "clearLabel", "clearDisabled", "requireValue", "disableSearchWithoutValue", "searchWhenEmptied", "resetOnClear", "showActiveFilters", "loading", "filterId", "form", "labelMap", "optionMap", "valueFormatter"], outputs: ["search", "clear", "restored"] }, { kind: "component", type: SPageHeaderComponent, selector: "s-page-header", inputs: ["breadcrumbs", "breadcrumbsFromRoute", "homeLink", "status", "statusTone", "statusIcon", "title", "description", "subtitleIcon", "showBack"], outputs: ["back"] }, { kind: "component", type: STableComponent, selector: "s-table", inputs: ["columns", "label", "rows", "actions", "cellTemplates", "sort", "loading", "empty", "caption", "selectable", "selection", "compareWith", "page", "pageSize", "total", "pageSizeOptions", "itemsLabel", "options", "itensPaginated", "itens", "emptyMessage", "frameless"], outputs: ["create", "view", "edit", "remove", "inactivate", "filter", "sortChange", "selectionChange", "actionClick", "pageChange", "pageSizeChange", "emptyAction"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCrudListComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-crud-list', imports: [SButtonComponent, SFilterCardComponent, SPageHeaderComponent, STableComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-crud-list',
                    }, template: "<s-page-header\n  [breadcrumbs]=\"crud().breadcrumbs()\"\n  [title]=\"crud().title()\"\n  [description]=\"crud().description()\"\n  [showBack]=\"crud().showBack()\"\n  (back)=\"back.emit()\"\n>\n  @if (crud().showCreate()) {\n    <s-button action variant=\"primary\" icon=\"add\" (click)=\"criar()\">\n      {{ crud().createLabel() }}\n    </s-button>\n  }\n</s-page-header>\n\n@if (crud().filterForm) {\n  <s-filter-card\n    [loading]=\"crud().loading()\"\n    [form]=\"crud().filterForm ?? null\"\n    [filterId]=\"filterId()\"\n    [labelMap]=\"filterLabels()\"\n    [optionMap]=\"filterOptions()\"\n    [valueFormatter]=\"filterValueFormatter()\"\n    (search)=\"crud().search()\"\n    (clear)=\"crud().clear()\"\n    (restored)=\"crud().search()\"\n  >\n    <ng-content select=\"[filters]\" />\n  </s-filter-card>\n}\n\n<s-table\n  [label]=\"crud().title()\"\n  [columns]=\"crud().columns\"\n  [rows]=\"crud().rows()\"\n  [actions]=\"crud().actions()\"\n  [cellTemplates]=\"templates()\"\n  [sort]=\"crud().sort()\"\n  [loading]=\"crud().loading()\"\n  [empty]=\"crud().empty()\"\n  [page]=\"crud().page()\"\n  [pageSize]=\"crud().pageSize()\"\n  [total]=\"crud().total()\"\n  [pageSizeOptions]=\"crud().pageSizeOptions()\"\n  [itemsLabel]=\"crud().itemsLabel()\"\n  (sortChange)=\"crud().setSort($event)\"\n  (pageChange)=\"crud().goToPage($event)\"\n  (pageSizeChange)=\"crud().setPageSize($event)\"\n  (actionClick)=\"aoAcionar($event)\"\n  (emptyAction)=\"aoAcaoDoVazio()\"\n/>\n", styles: [":host{display:flex;flex-direction:column;gap:var(--space-24, 24px)}\n"] }]
        }], propDecorators: { crud: [{ type: i0.Input, args: [{ isSignal: true, alias: "crud", required: true }] }], filterId: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterId", required: false }] }], filterLabels: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterLabels", required: false }] }], filterOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterOptions", required: false }] }], filterValueFormatter: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterValueFormatter", required: false }] }], create: [{ type: i0.Output, args: ["create"] }], view: [{ type: i0.Output, args: ["view"] }], edit: [{ type: i0.Output, args: ["edit"] }], remove: [{ type: i0.Output, args: ["remove"] }], inactivate: [{ type: i0.Output, args: ["inactivate"] }], action: [{ type: i0.Output, args: ["action"] }], back: [{ type: i0.Output, args: ["back"] }], templatesProjetados: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => STableCellDirective), { ...{ descendants: true }, isSignal: true }] }] } });

/**
 * Casca padrao para formulario de cadastro, edicao e visualizacao de CRUD.
 *
 * ## Por que a casca desabilita o `FormGroup` em visualizacao
 *
 * O guia diferencia `readOnly` de `disabled`, mas esta casca recebe conteudo
 * projetado: pode haver `s-input`, `s-select`, componentes da aplicacao ou ate
 * controles nativos. Nao ha como propagar `readOnly` de forma confiavel para
 * todos sem impor uma API nova a cada controle. Por isso, em `mode="view"` a
 * casca desabilita o `FormGroup` com `emitEvent: false`: e uma trava
 * operacional para impedir edicao acidental. Se uma tela precisa da aparencia
 * de somente-leitura do guia, ela pode repassar `[readOnly]="mode === 'view'"`
 * aos controles projetados; o bloqueio do grupo continua protegendo o submit.
 *
 * ## Metadados por slot
 *
 * A ultima edicao entra pelo slot `[sCrudFormMeta]`, e nao por um input
 * formatado, porque autoria e auditoria variam por sistema. A biblioteca
 * reserva o lugar visual; a aplicacao decide texto, fuso, link ou badge.
 *
 * @example
 * ```html
 * <s-crud-form
 *   title="Nova Escola"
 *   description="Informe os dados cadastrais da escola."
 *   mode="create"
 *   [form]="form"
 *   (save)="save()"
 *   (cancelRequest)="goBack()"
 * >
 *   <s-field label="Nome" required>
 *     <s-input formControlName="schoolName" />
 *   </s-field>
 * </s-crud-form>
 * ```
 */
class SCrudFormComponent {
    formSignal = signal(null, ...(ngDevMode ? [{ debugName: "formSignal" }] : []));
    /**
     * Formulario reativo da tela.
     *
     * A casca marca como tocado no submit invalido, consulta `dirty` no cancelar
     * e bloqueia o grupo em `view`. A estrutura dos controles continua sendo da
     * aplicacao.
     *
     * Setter em vez de `input()`: o `FormGroupDirective` provido pela casca
     * precisa receber o grupo antes de os `formControlName` projetados se
     * registrarem, e um `effect()` chegaria tarde demais.
     */
    set form(form) {
        this.formSignal.set(form);
        this.syncFormDirective(form);
    }
    get form() {
        return this.formSignal();
    }
    /** Titulo do cabecalho da tela. */
    title = input('', ...(ngDevMode ? [{ debugName: "title" }] : []));
    /** Subtitulo que explica o objetivo do cadastro. */
    description = input('', ...(ngDevMode ? [{ debugName: "description" }] : []));
    /** Trilha de navegacao repassada ao `<s-page-header>`. */
    breadcrumbs = input([], ...(ngDevMode ? [{ debugName: "breadcrumbs" }] : []));
    /** Exibe a seta de voltar do cabecalho. */
    showBack = input(false, ...(ngDevMode ? [{ debugName: "showBack", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Estado da tela.
     *
     * `create` e `edit` exibem Salvar. `view` bloqueia o `FormGroup` e troca
     * Salvar por Editar, para a tela decidir se navega ou muda o modo.
     */
    mode = input('create', ...(ngDevMode ? [{ debugName: "mode" }] : []));
    /**
     * Indica salvamento em andamento.
     *
     * O botao permanece focavel pelo componente de botao, mas o submit e barrado
     * aqui tambem para cobrir envio por Enter.
     */
    saving = input(false, ...(ngDevMode ? [{ debugName: "saving", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Permissoes no mesmo formato das listagens.
     *
     * `create` controla Salvar em cadastro, `edit` controla Salvar/Editar em
     * edicao ou visualizacao, e `remove` controla Excluir.
     *
     * So esconde botoes: nao e controle de acesso, e o backend precisa autorizar
     * cada operacao. Sem `provideSiagePermissionChecker`, todos aparecem.
     */
    permissions = input(null, ...(ngDevMode ? [{ debugName: "permissions" }] : []));
    /** Rotulo do botao de salvar. */
    submitLabel = input('Salvar', ...(ngDevMode ? [{ debugName: "submitLabel" }] : []));
    /** Rotulo do botao de cancelar. */
    cancelLabel = input('Cancelar', ...(ngDevMode ? [{ debugName: "cancelLabel" }] : []));
    /** Rotulo do botao que pede edicao em modo visualizacao. */
    editLabel = input('Editar', ...(ngDevMode ? [{ debugName: "editLabel" }] : []));
    /** Rotulo do botao de exclusao. */
    deleteLabel = input('Excluir', ...(ngDevMode ? [{ debugName: "deleteLabel" }] : []));
    /** Nome do registro usado nas confirmacoes. */
    entityName = input('registro', ...(ngDevMode ? [{ debugName: "entityName" }] : []));
    /** Seta de voltar do cabecalho. */
    back = output();
    /** Salvar acionado com formulario valido. */
    save = output();
    /** Cancelamento confirmado ou sem alteracoes pendentes. */
    cancelRequest = output();
    /** Pedido de troca para edicao em `mode="view"`. */
    editRequest = output();
    /** Exclusao confirmada. O alias preserva a API `(delete)`. */
    remove = output({ alias: 'delete' });
    modal = inject(SModalService);
    permissionChecker = inject(SPermissionChecker, { optional: true });
    host = inject(ElementRef);
    destroyRef = inject(DestroyRef);
    formDirective = inject(FormGroupDirective, { self: true });
    disabledForm = null;
    originallyDisabledControls = new WeakMap();
    viewing = computed(() => this.mode() === 'view', ...(ngDevMode ? [{ debugName: "viewing" }] : []));
    canSave = computed(() => !this.viewing() && this.hasPermission(this.mode() === 'create' ? 'create' : 'edit'), ...(ngDevMode ? [{ debugName: "canSave" }] : []));
    canEdit = computed(() => this.viewing() && this.hasPermission('edit'), ...(ngDevMode ? [{ debugName: "canEdit" }] : []));
    canDelete = computed(() => this.mode() !== 'create' && this.hasPermission('remove'), ...(ngDevMode ? [{ debugName: "canDelete" }] : []));
    cardTitle = computed(() => {
        switch (this.mode()) {
            case 'create':
                return 'Dados do cadastro';
            case 'edit':
                return 'Dados para edição';
            default:
                return 'Dados para visualização';
        }
    }, ...(ngDevMode ? [{ debugName: "cardTitle" }] : []));
    constructor() {
        effect(() => this.syncViewMode(this.currentForm(), this.viewing()));
        // Mesmo aviso do `<s-table>`: sem verificador, a conferencia ligada mostra
        // todos os botoes.
        effect(() => {
            if (typeof ngDevMode !== 'undefined' &&
                ngDevMode &&
                this.permissions()?.enabled &&
                !this.permissionChecker) {
                console.warn('[SCrudFormComponent] permissions.enabled está ligado, mas a aplicação não registrou ' +
                    'provideSiagePermissionChecker: salvar, editar e excluir aparecem. Esconder ação não ' +
                    'é controle de acesso — o backend precisa autorizar cada operação.');
            }
        });
        this.destroyRef.onDestroy(() => this.restoreDisabledForm());
    }
    onSubmit() {
        const form = this.currentForm();
        if (!form || this.saving() || !this.canSave()) {
            return;
        }
        form.markAllAsTouched();
        form.updateValueAndValidity({ emitEvent: false });
        if (form.invalid) {
            this.focusFirstInvalid();
            return;
        }
        this.save.emit();
    }
    async onCancel() {
        const form = this.currentForm();
        if (form?.dirty) {
            const confirmed = await this.modal.confirm({
                title: 'Descartar alterações?',
                description: 'As informações preenchidas e ainda não salvas serão perdidas.',
                confirmLabel: 'Sim, descartar',
                cancelLabel: 'Continuar editando',
            });
            if (!confirmed) {
                return;
            }
        }
        this.cancelRequest.emit();
    }
    async onDelete() {
        if (!this.canDelete()) {
            return;
        }
        const confirmed = await this.modal.confirm({
            variant: 'destructive',
            title: `Excluir ${this.entityName()}?`,
            description: 'Esta ação não pode ser desfeita.',
            confirmLabel: 'Sim, excluir',
        });
        if (confirmed) {
            this.remove.emit();
        }
    }
    onEditRequest() {
        if (this.canEdit()) {
            this.editRequest.emit();
        }
    }
    hasPermission(action) {
        const config = this.permissions();
        const requiredPermission = config?.enabled ? config.permissions?.[action] : undefined;
        return (!requiredPermission ||
            !this.permissionChecker ||
            this.permissionChecker.has(requiredPermission));
    }
    currentForm() {
        return this.formSignal();
    }
    syncFormDirective(form) {
        if (!form || this.formDirective.form === form) {
            return;
        }
        this.formDirective.form = form;
        this.formDirective.ngOnChanges({
            form: new SimpleChange(null, form, false),
        });
    }
    syncViewMode(form, viewing) {
        if (this.disabledForm && this.disabledForm !== form) {
            this.restoreDisabledForm();
        }
        if (!form) {
            return;
        }
        if (viewing) {
            this.disableForView(form);
            return;
        }
        if (this.disabledForm === form) {
            this.restoreDisabledForm();
        }
    }
    disableForView(form) {
        if (this.disabledForm === form) {
            return;
        }
        this.originallyDisabledControls.set(form, this.disabledControls(form));
        this.disabledForm = form;
        form.disable({ emitEvent: false });
    }
    restoreDisabledForm() {
        const form = this.disabledForm;
        if (!form) {
            return;
        }
        const disabledControls = this.originallyDisabledControls.get(form) ?? new Set();
        form.enable({ emitEvent: false });
        for (const control of disabledControls) {
            control.disable({ emitEvent: false });
        }
        this.disabledForm = null;
    }
    disabledControls(control) {
        const disabledControls = new Set();
        const visit = (current) => {
            if (current.disabled) {
                disabledControls.add(current);
            }
            for (const child of this.childrenOf(current)) {
                visit(child);
            }
        };
        visit(control);
        return disabledControls;
    }
    childrenOf(control) {
        if (control instanceof FormArray) {
            return control.controls;
        }
        if (control instanceof FormGroup || control instanceof FormRecord) {
            return Object.values(control.controls);
        }
        return [];
    }
    focusFirstInvalid() {
        queueMicrotask(() => {
            const invalidControl = this.host.nativeElement.querySelector('.ng-invalid:not(form), [aria-invalid="true"]');
            const focusable = invalidControl?.matches('input, select, textarea, button, [tabindex]')
                ? invalidControl
                : invalidControl?.querySelector('input, select, textarea, button, [tabindex]');
            invalidControl?.scrollIntoView({ block: 'center' });
            focusable?.focus({ preventScroll: true });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCrudFormComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SCrudFormComponent, isStandalone: true, selector: "s-crud-form", inputs: { form: { classPropertyName: "form", publicName: "form", isSignal: false, isRequired: true, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, breadcrumbs: { classPropertyName: "breadcrumbs", publicName: "breadcrumbs", isSignal: true, isRequired: false, transformFunction: null }, showBack: { classPropertyName: "showBack", publicName: "showBack", isSignal: true, isRequired: false, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, saving: { classPropertyName: "saving", publicName: "saving", isSignal: true, isRequired: false, transformFunction: null }, permissions: { classPropertyName: "permissions", publicName: "permissions", isSignal: true, isRequired: false, transformFunction: null }, submitLabel: { classPropertyName: "submitLabel", publicName: "submitLabel", isSignal: true, isRequired: false, transformFunction: null }, cancelLabel: { classPropertyName: "cancelLabel", publicName: "cancelLabel", isSignal: true, isRequired: false, transformFunction: null }, editLabel: { classPropertyName: "editLabel", publicName: "editLabel", isSignal: true, isRequired: false, transformFunction: null }, deleteLabel: { classPropertyName: "deleteLabel", publicName: "deleteLabel", isSignal: true, isRequired: false, transformFunction: null }, entityName: { classPropertyName: "entityName", publicName: "entityName", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { back: "back", save: "save", cancelRequest: "cancelRequest", editRequest: "editRequest", remove: "delete" }, host: { classAttribute: "s-crud-form" }, providers: [FormGroupDirective, { provide: ControlContainer, useExisting: FormGroupDirective }], ngImport: i0, template: "<s-page-header\n  [breadcrumbs]=\"breadcrumbs()\"\n  [title]=\"title()\"\n  [description]=\"description()\"\n  [showBack]=\"showBack()\"\n  (back)=\"back.emit()\"\n/>\n\n@if (currentForm(); as currentForm) {\n  <form\n    [formGroup]=\"currentForm\"\n    (submit)=\"$event.stopPropagation()\"\n    (ngSubmit)=\"onSubmit()\"\n    novalidate\n  >\n    <s-card [padding]=\"0\">\n      <header sCardHeader class=\"s-crud-form__card-header\">\n        <span>{{ cardTitle() }}</span>\n        <ng-content select=\"[sCrudFormMeta]\" />\n      </header>\n\n      <section sCardContent class=\"s-crud-form__content\">\n        <ng-content />\n      </section>\n\n      <footer sCardFooter class=\"s-crud-form__actions\">\n        @if (canDelete()) {\n          <s-button type=\"button\" variant=\"destructive\" outlined icon=\"delete\" (click)=\"onDelete()\">\n            {{ deleteLabel() }}\n          </s-button>\n        }\n\n        <span class=\"s-crud-form__spacer\"></span>\n\n        <s-button type=\"button\" variant=\"secondary\" outlined (click)=\"onCancel()\">\n          {{ cancelLabel() }}\n        </s-button>\n\n        @if (canEdit()) {\n          <s-button type=\"button\" variant=\"primary\" icon=\"edit\" (click)=\"onEditRequest()\">\n            {{ editLabel() }}\n          </s-button>\n        }\n\n        @if (canSave()) {\n          <s-button\n            type=\"submit\"\n            variant=\"primary\"\n            icon=\"save\"\n            [loading]=\"saving()\"\n            [disabled]=\"saving()\"\n          >\n            {{ submitLabel() }}\n          </s-button>\n        }\n      </footer>\n    </s-card>\n  </form>\n}\n", styles: [":host{display:flex;flex-direction:column;gap:var(--space-24)}.s-crud-form__card-header{justify-content:space-between}.s-crud-form__content{display:grid;gap:var(--space-16)}.s-crud-form__actions{gap:var(--space-8)}.s-crud-form__spacer{flex:1 1 auto}:host ::ng-deep .s-crud-form__meta{color:var(--text-secondary);font-size:var(--text-caption);font-weight:var(--weight-regular)}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: SButtonComponent, selector: "s-button", inputs: ["variant", "outlined", "fullWidth", "pressed", "buttonRole", "checked", "focusIndex", "loading", "loadingText", "disabled", "icon", "iconRight", "type", "label"] }, { kind: "component", type: SCardComponent, selector: "s-card", inputs: ["padding", "elevation"] }, { kind: "directive", type: SCardContentDirective, selector: "[sCardContent]" }, { kind: "directive", type: SCardFooterDirective, selector: "[sCardFooter]" }, { kind: "directive", type: SCardHeaderDirective, selector: "[sCardHeader]" }, { kind: "component", type: SPageHeaderComponent, selector: "s-page-header", inputs: ["breadcrumbs", "breadcrumbsFromRoute", "homeLink", "status", "statusTone", "statusIcon", "title", "description", "subtitleIcon", "showBack"], outputs: ["back"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCrudFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-crud-form', imports: [
                        ReactiveFormsModule,
                        SButtonComponent,
                        SCardComponent,
                        SCardContentDirective,
                        SCardFooterDirective,
                        SCardHeaderDirective,
                        SPageHeaderComponent,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, providers: [FormGroupDirective, { provide: ControlContainer, useExisting: FormGroupDirective }], host: {
                        class: 's-crud-form',
                    }, template: "<s-page-header\n  [breadcrumbs]=\"breadcrumbs()\"\n  [title]=\"title()\"\n  [description]=\"description()\"\n  [showBack]=\"showBack()\"\n  (back)=\"back.emit()\"\n/>\n\n@if (currentForm(); as currentForm) {\n  <form\n    [formGroup]=\"currentForm\"\n    (submit)=\"$event.stopPropagation()\"\n    (ngSubmit)=\"onSubmit()\"\n    novalidate\n  >\n    <s-card [padding]=\"0\">\n      <header sCardHeader class=\"s-crud-form__card-header\">\n        <span>{{ cardTitle() }}</span>\n        <ng-content select=\"[sCrudFormMeta]\" />\n      </header>\n\n      <section sCardContent class=\"s-crud-form__content\">\n        <ng-content />\n      </section>\n\n      <footer sCardFooter class=\"s-crud-form__actions\">\n        @if (canDelete()) {\n          <s-button type=\"button\" variant=\"destructive\" outlined icon=\"delete\" (click)=\"onDelete()\">\n            {{ deleteLabel() }}\n          </s-button>\n        }\n\n        <span class=\"s-crud-form__spacer\"></span>\n\n        <s-button type=\"button\" variant=\"secondary\" outlined (click)=\"onCancel()\">\n          {{ cancelLabel() }}\n        </s-button>\n\n        @if (canEdit()) {\n          <s-button type=\"button\" variant=\"primary\" icon=\"edit\" (click)=\"onEditRequest()\">\n            {{ editLabel() }}\n          </s-button>\n        }\n\n        @if (canSave()) {\n          <s-button\n            type=\"submit\"\n            variant=\"primary\"\n            icon=\"save\"\n            [loading]=\"saving()\"\n            [disabled]=\"saving()\"\n          >\n            {{ submitLabel() }}\n          </s-button>\n        }\n      </footer>\n    </s-card>\n  </form>\n}\n", styles: [":host{display:flex;flex-direction:column;gap:var(--space-24)}.s-crud-form__card-header{justify-content:space-between}.s-crud-form__content{display:grid;gap:var(--space-16)}.s-crud-form__actions{gap:var(--space-8)}.s-crud-form__spacer{flex:1 1 auto}:host ::ng-deep .s-crud-form__meta{color:var(--text-secondary);font-size:var(--text-caption);font-weight:var(--weight-regular)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { form: [{
                type: Input,
                args: [{ required: true }]
            }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], breadcrumbs: [{ type: i0.Input, args: [{ isSignal: true, alias: "breadcrumbs", required: false }] }], showBack: [{ type: i0.Input, args: [{ isSignal: true, alias: "showBack", required: false }] }], mode: [{ type: i0.Input, args: [{ isSignal: true, alias: "mode", required: false }] }], saving: [{ type: i0.Input, args: [{ isSignal: true, alias: "saving", required: false }] }], permissions: [{ type: i0.Input, args: [{ isSignal: true, alias: "permissions", required: false }] }], submitLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "submitLabel", required: false }] }], cancelLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "cancelLabel", required: false }] }], editLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "editLabel", required: false }] }], deleteLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "deleteLabel", required: false }] }], entityName: [{ type: i0.Input, args: [{ isSignal: true, alias: "entityName", required: false }] }], back: [{ type: i0.Output, args: ["back"] }], save: [{ type: i0.Output, args: ["save"] }], cancelRequest: [{ type: i0.Output, args: ["cancelRequest"] }], editRequest: [{ type: i0.Output, args: ["editRequest"] }], remove: [{ type: i0.Output, args: ["delete"] }] } });

/**
 * Marca o conteudo de metadados do formulario.
 *
 * A ultima edicao fica como slot, e nao como input formatado, porque cada
 * sistema tem regras diferentes de autoria, fuso e auditoria. A casca so
 * reserva o lugar visual; a aplicacao decide o texto exato e pode incluir link,
 * badge ou data ja formatada em pt-BR.
 *
 * @example
 * ```html
 * <span sCrudFormMeta>Ultima edicao por Ana, em 02/10/2026.</span>
 * ```
 */
class SCrudFormMetaDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCrudFormMetaDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.34", type: SCrudFormMetaDirective, isStandalone: true, selector: "[sCrudFormMeta]", host: { classAttribute: "s-crud-form__meta" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCrudFormMetaDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[sCrudFormMeta]',
                    host: { class: 's-crud-form__meta' },
                }]
        }] });

/**
 * Converte um valor de filtro em texto de query string.
 *
 * `Date` vira ISO e booleano vira `true`/`false` — as duas conversoes que todo
 * filtro acaba precisando e que, feitas na tela, ficam diferentes em cada uma.
 */
function comoTexto(valor) {
    if (valor instanceof Date) {
        return valor.toISOString();
    }
    return String(valor);
}
/** Monta a query string no formato que as APIs do SIAGE esperam. */
function montarParametros(query, opcoes) {
    const params = new URLSearchParams();
    for (const [chave, valor] of Object.entries(query.filters)) {
        if (Array.isArray(valor)) {
            for (const item of valor) {
                params.append(chave, comoTexto(item));
            }
            continue;
        }
        params.append(chave, comoTexto(valor));
    }
    params.append(opcoes.pageParam ?? 'page', String(query.page));
    params.append(opcoes.pageSizeParam ?? 'pageSize', String(query.pageSize));
    if (query.sort) {
        params.append(opcoes.sortParam ?? 'sort', query.sort.key);
        params.append(opcoes.sortDirectionParam ?? 'sortDirection', query.sort.direction);
    }
    return params;
}
/**
 * Adapta um service de listagem do SIAGE a `SCrudDataSource`, sem escrever a
 * classe a mao.
 *
 * E o caminho para as telas que estao migrando: o service continua o mesmo —
 * `getByFilterPaginated`, `delete`, `activate`/`inactivate` —, e o adaptador
 * traduz `SCrudQuery` em `URLSearchParams` e `PagedResult` em `SCrudPage`.
 *
 * Quando a API de um sistema novo nao seguir esse contrato, escreva a fonte
 * estendendo `SCrudDataSource` — este adaptador e conveniencia, nao regra.
 *
 * Sem `getByFilterPaginated`, cai em `getByFilter`: a API devolve a lista
 * inteira, o total passa a ser o tamanho dela e a pagina e recortada aqui, em
 * memoria. Serve para cadastros pequenos; lista grande pede o endpoint
 * paginado.
 *
 * @example
 * ```ts
 * protected readonly crud = injectCrudList<TipoFaltaListDto>({
 *   dataSource: siageCrudDataSource(inject(TipoFaltaService)),
 *   // ...
 * });
 * ```
 */
function siageCrudDataSource(service, options = {}) {
    const paginado = service.getByFilterPaginated?.bind(service);
    const simples = service.getByFilter?.bind(service);
    const excluir = service.delete?.bind(service);
    const ativar = service.activate?.bind(service);
    const inativar = service.inactivate?.bind(service);
    return {
        list(query) {
            const params = montarParametros(query, options);
            if (paginado) {
                return paginado(params).pipe(map((resultado) => ({
                    items: resultado.items ?? [],
                    total: resultado.totalCount ?? 0,
                })));
            }
            if (simples) {
                // A API devolve tudo: a pagina sai daqui, para o paginador mostrar o
                // que promete em vez de repetir a lista inteira em cada pagina.
                const inicio = (query.page - 1) * query.pageSize;
                return simples(params).pipe(map((itens) => ({
                    items: query.pageSize > 0 ? itens.slice(inicio, inicio + query.pageSize) : itens,
                    total: itens.length,
                })));
            }
            throw new Error('[siageCrudDataSource] O service precisa de getByFilterPaginated() ou getByFilter().');
        },
        remove: excluir ? (row) => excluir(String(row[options.idKey ?? 'id'])) : undefined,
        setActive: ativar && inativar
            ? (row, active) => (active ? ativar(row) : inativar(row))
            : undefined,
    };
}

/*
 * API publica de @siage/siage-ui/crud.
 *
 * A camada de tela do CRUD: o estado e o comportamento de uma listagem
 * (`injectCrudList`), a casca visual (`<s-crud-list>`) e o contrato de dados
 * que a aplicacao implementa (`SCrudDataSource`).
 *
 * Fica fora do pacote principal de proposito: `@siage/siage-ui` e o design
 * system — componentes que so desenham. Aqui ha navegacao, consulta e decisao,
 * que e arquitetura de tela. Quem quer so a tabela nao precisa importar nada
 * disto.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { SCrudDataSource, SCrudFormComponent, SCrudFormMetaDirective, SCrudList, SCrudListComponent, injectCrudList, siageCrudDataSource };
//# sourceMappingURL=siage-siage-ui-crud.mjs.map
