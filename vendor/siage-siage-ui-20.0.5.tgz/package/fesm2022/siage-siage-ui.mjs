import * as i0 from '@angular/core';
import { inject, TemplateRef, input, Directive, InjectionToken, makeEnvironmentProviders, signal, effect, DestroyRef, booleanAttribute, computed, ChangeDetectionStrategy, Component, numberAttribute, ElementRef, afterRenderEffect, HostAttributeToken, contentChildren, contentChild, afterEveryRender, forwardRef, Injector, viewChild, output, Injectable, ViewEncapsulation, untracked, viewChildren, isDevMode, model, afterNextRender, ViewContainerRef, linkedSignal, DOCUMENT as DOCUMENT$1 } from '@angular/core';
import * as i1 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i1$1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i1$6 from '@angular/cdk/a11y';
import { AriaDescriber, FocusMonitor, LiveAnnouncer, CdkTrapFocus } from '@angular/cdk/a11y';
import * as i1$2 from '@angular/material/tooltip';
import { MatTooltip } from '@angular/material/tooltip';
import * as i1$5 from '@angular/forms';
import { NgControl, NG_VALUE_ACCESSOR, NG_VALIDATORS, FormControl, ReactiveFormsModule, FormsModule, FormGroupDirective } from '@angular/forms';
import { NgTemplateOutlet, DOCUMENT } from '@angular/common';
import * as i1$3 from '@angular/material/select';
import { MatSelect, MatSelectModule } from '@angular/material/select';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { MatPseudoCheckbox, NativeDateAdapter, MAT_DATE_LOCALE, DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { Subject, of, timer, EMPTY, merge, firstValueFrom, filter as filter$1, takeUntil, finalize as finalize$1, Subscription, isObservable } from 'rxjs';
import { debounce, switchMap, catchError, tap, map, finalize, filter, mergeMap } from 'rxjs/operators';
import * as i1$4 from '@angular/material/datepicker';
import { MatDatepickerIntl, MatCalendarHeader, MatDatepickerModule } from '@angular/material/datepicker';
import * as i2 from '@angular/material/autocomplete';
import { MatAutocompleteTrigger, MatAutocompleteModule } from '@angular/material/autocomplete';
import * as i4 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Router, NavigationEnd, RouterLink, ROUTES, RouterLinkActive } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog, MatDialogTitle } from '@angular/material/dialog';
import { BreakpointObserver } from '@angular/cdk/layout';
import { Overlay } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import { CdkMenu, PARENT_OR_NEW_MENU_STACK_PROVIDER, CdkMenuItem } from '@angular/cdk/menu';
import * as i1$7 from '@angular/material/radio';
import { MatRadioModule } from '@angular/material/radio';
import * as i1$8 from '@angular/cdk/accordion';
import { CdkAccordion, CdkAccordionItem } from '@angular/cdk/accordion';

/**
 * Desenho proprio para cada opcao de `<s-select>`, `<s-multiselect>` e
 * `<s-autocomplete>`.
 *
 * Sem ele a opcao mostra so o `label`. Use quando a lista precisa de uma segunda
 * linha (matricula abaixo do nome), um badge de situacao ou um icone - o painel,
 * o teclado e a selecao continuam sendo do componente.
 *
 * O `label` continua obrigatorio na `SOption`: e ele que vai para o gatilho
 * fechado, para o filtro e para o leitor de tela.
 *
 * @example
 * ```html
 * <s-select [options]="alunos" formControlName="aluno">
 *   <ng-template sOption let-opcao>
 *     <strong>{{ opcao.label }}</strong>
 *     <small>Matrícula {{ opcao.value }}</small>
 *   </ng-template>
 * </s-select>
 * ```
 */
class SOptionTemplateDirective {
    template = inject(TemplateRef);
    /**
     * Tipo das opcoes, so para o template ganhar checagem de tipo:
     * `<ng-template sOption [sOptionOf]="alunos" let-opcao>`.
     */
    sOptionOf = input(null, ...(ngDevMode ? [{ debugName: "sOptionOf" }] : []));
    static ngTemplateContextGuard(_diretiva, contexto) {
        return true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SOptionTemplateDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "20.3.34", type: SOptionTemplateDirective, isStandalone: true, selector: "ng-template[sOption]", inputs: { sOptionOf: { classPropertyName: "sOptionOf", publicName: "sOptionOf", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SOptionTemplateDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ng-template[sOption]',
                }]
        }], propDecorators: { sOptionOf: [{ type: i0.Input, args: [{ isSignal: true, alias: "sOptionOf", required: false }] }] } });

/**
 * Quanto tempo um carregamento precisa durar antes de aparecer na tela, em ms.
 *
 * O guia **nao** define esse limiar — diz o que mostrar (esqueleto no formato do
 * conteudo final, nunca spinner central) e deixa o "a partir de quando" em
 * aberto. O valor foi decidido pela equipe.
 *
 * Ele existe porque uma resposta rapida que pisca o esqueleto por 80ms incomoda
 * mais do que a espera em si: a tela salta duas vezes em vez de uma.
 *
 * Para ajustar, registre outro valor uma unica vez na aplicacao:
 *
 * ```ts
 * providers: [provideSiageLoadingDelay(1500)]
 * ```
 */
const S_LOADING_DELAY = new InjectionToken('s-loading-delay', {
    providedIn: 'root',
    factory: () => 800,
});
/** Troca o limiar de exibicao do estado de carregamento em toda a aplicacao. */
function provideSiageLoadingDelay(delayMs) {
    return makeEnvironmentProviders([{ provide: S_LOADING_DELAY, useValue: delayMs }]);
}
/**
 * Adia a exibicao do carregamento pelo limiar configurado.
 *
 * Devolve um sinal que so fica `true` depois que `carregando` permanece `true`
 * pelo tempo de `S_LOADING_DELAY`. Voltar para `false` cancela o relogio, entao
 * uma resposta rapida nunca chega a piscar o esqueleto.
 *
 * Chame de um campo de classe ou do construtor — precisa de contexto de
 * injecao, como qualquer `inject()`.
 *
 * @param carregando Sinal com o estado bruto da requisicao.
 */
function adiarCarregamento(carregando) {
    const delay = inject(S_LOADING_DELAY);
    const visivel = signal(false, ...(ngDevMode ? [{ debugName: "visivel" }] : []));
    let relogio;
    const limpar = () => {
        if (relogio !== undefined) {
            clearTimeout(relogio);
            relogio = undefined;
        }
    };
    effect(() => {
        const ativo = carregando();
        // Cada mudanca reinicia a contagem: um segundo carregamento nao herda o
        // relogio do primeiro.
        limpar();
        if (!ativo) {
            visivel.set(false);
            return;
        }
        relogio = setTimeout(() => visivel.set(true), delay);
    });
    inject(DestroyRef).onDestroy(limpar);
    return visivel.asReadonly();
}

const PIXELS = {
    xs: 16,
    sm: 20,
    md: 24,
    lg: 48,
};
const POR_NUMERO = {
    16: 'xs',
    20: 'sm',
    24: 'md',
    48: 'lg',
};
/** O tamanho em pixels de um passo da escala. */
function pixelsDoTamanho(tamanho) {
    return PIXELS[tamanho];
}
/**
 * O token CSS de um passo da escala.
 *
 * O componente escreve a referencia ao token, e nao o numero: assim a medida
 * continua saindo do tema, e um sistema que precise redefinir a escala redefine
 * `--icon-md` uma vez em vez de caçar `24px` em cada componente.
 */
function variavelDoTamanho(tamanho) {
    return `var(--icon-${tamanho})`;
}
/**
 * Transform de input: aceita o nome ou o numero, devolve sempre o nome.
 *
 * Recebe o padrao do componente porque cada um tem o seu — o badge nasce `xs`, o
 * botao so-icone nasce `md`. Um valor fora da escala cai no padrao, com aviso em
 * desenvolvimento: o componente continua desenhando, e quem escreveu fica
 * sabendo.
 */
function tamanhoDeIcone(padrao) {
    return (valor) => {
        if (valor === 'xs' || valor === 'sm' || valor === 'md' || valor === 'lg') {
            return valor;
        }
        const numero = typeof valor === 'number' ? valor : Number(valor);
        const nome = POR_NUMERO[numero];
        if (nome) {
            return nome;
        }
        if (typeof ngDevMode !== 'undefined' && ngDevMode) {
            console.warn(`[siage-ui] Tamanho de ícone inválido: ${String(valor)}. ` +
                `A escala tem quatro passos — xs (16), sm (20), md (24) e lg (48). Usando ${padrao}.`);
        }
        return padrao;
    };
}

/**
 * As mensagens que a biblioteca ja traz.
 *
 * Cobrem os validadores do Angular e os do datepicker do Material, que sao os
 * que aparecem sem ninguem escrever validador nenhum.
 */
const S_MENSAGENS_PADRAO = {
    required: 'Campo obrigatório.',
    email: 'Informe um e-mail válido.',
    min: (erro) => `O valor mínimo é ${erro.min}.`,
    max: (erro) => `O valor máximo é ${erro.max}.`,
    minlength: (erro) => `Informe pelo menos ${erro.requiredLength} caracteres.`,
    maxlength: (erro) => `Informe no máximo ${erro.requiredLength} caracteres.`,
    pattern: 'Formato inválido.',
    matDatepickerParse: 'Data inválida. Use o formato dd/mm/aaaa.',
    matDatepickerMin: 'Data anterior ao permitido.',
    matDatepickerMax: 'Data posterior ao permitido.',
    sDateRangeIncomplete: 'Informe a data final do período.',
    sMaskIncomplete: 'Preencha o campo por completo.',
};
/**
 * Mensagens de validacao da aplicacao.
 *
 * Existe para que "campo obrigatorio" seja a **mesma frase** nas 87 telas do
 * Professores. Sem isso, cada uma escreve a sua — e o usuario aprende que o
 * sistema fala de tres jeitos diferentes sobre a mesma coisa.
 *
 * O que a aplicacao registra e mesclado com os padroes: informe so o que quiser
 * trocar ou acrescentar.
 *
 * ```ts
 * providers: [
 *   provideSiageValidationMessages({
 *     required: 'Preencha este campo.',
 *     cpfInvalido: 'CPF inválido.',
 *   }),
 * ]
 * ```
 */
const S_VALIDATION_MESSAGES = new InjectionToken('s-validation-messages', { providedIn: 'root', factory: () => S_MENSAGENS_PADRAO });
/** Registra ou sobrescreve mensagens de validacao em toda a aplicacao. */
function provideSiageValidationMessages(messages) {
    return makeEnvironmentProviders([
        { provide: S_VALIDATION_MESSAGES, useValue: { ...S_MENSAGENS_PADRAO, ...messages } },
    ]);
}
/**
 * Escolhe a mensagem do primeiro erro que tiver uma.
 *
 * Um controle pode falhar em varios validadores ao mesmo tempo; mostrar todos
 * empilhados so aumenta o ruido. O primeiro basta — resolvido ele, o proximo
 * aparece.
 */
/**
 * Todas as mensagens de um objeto de erros, na ordem em que os validadores as
 * registraram.
 *
 * Erro sem mensagem mapeada e ignorado, e nao vira uma linha em branco: quando
 * nenhum tem mapeamento, a lista volta vazia e a faixa fica reservada, sem
 * texto.
 */
function todasAsMensagens(erros, controle, mensagens) {
    if (!erros) {
        return [];
    }
    const lista = [];
    for (const [nome, valor] of Object.entries(erros)) {
        const mensagem = mensagens[nome];
        if (mensagem === undefined) {
            continue;
        }
        lista.push(typeof mensagem === 'function' ? mensagem(valor, controle) : mensagem);
    }
    return lista;
}
function primeiraMensagem(erros, controle, mensagens) {
    if (!erros) {
        return '';
    }
    for (const [nome, valor] of Object.entries(erros)) {
        const mensagem = mensagens[nome];
        if (mensagem !== undefined) {
            return typeof mensagem === 'function' ? mensagem(valor, controle) : mensagem;
        }
    }
    return '';
}

/**
 * Glifo do Material Symbols Rounded, sobre o `mat-icon`.
 *
 * Decorativo por padrao; com `label`, e anunciado. `iconFilled` preenche o
 * glifo e `filled` poe o fundo da `variant` — os dois combinam.
 */
class SIconComponent {
    /** Nome do glifo no Material Symbols */
    name = input.required(...(ngDevMode ? [{ debugName: "name" }] : []));
    /**
     * Passo da escala do guia: `xs` (16), `sm` (20), `md` (24) ou `lg` (48).
     */
    size = input('sm', ...(ngDevMode ? [{ debugName: "size", transform: tamanhoDeIcone('sm') }] : [{ transform: tamanhoDeIcone('sm') }]));
    /** Preenche o glifo (eixo `FILL`). No guia, so o item ativo da navegacao. */
    iconFilled = input(false, ...(ngDevMode ? [{ debugName: "iconFilled", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Poe o fundo na cor da `variant`. Sem `variant`, nao tem efeito. */
    filled = input(false, ...(ngDevMode ? [{ debugName: "filled", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Cor explicita. Por padrao o icone herda a cor do texto ao redor. */
    color = input('', ...(ngDevMode ? [{ debugName: "color" }] : []));
    /** Torna o icone anunciavel. Use apenas quando ele for o unico conteudo com significado. */
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
    /** Cor do papel (`text-*`). Requer `@siage/siage-ui/styles/utilities`. */
    variant = input('default', ...(ngDevMode ? [{ debugName: "variant" }] : []));
    tamanho = computed(() => variavelDoTamanho(this.size()), ...(ngDevMode ? [{ debugName: "tamanho" }] : []));
    hostClasses = computed(() => {
        const classes = [];
        if (this.variant() === 'default') {
            return '';
        }
        if (this.filled()) {
            // `secondary` nao e cor semantica, entao nao tem tinta de container: o
            // proprio `--secondary` ja e o cinza claro de fundo.
            const fundo = this.variant() === 'secondary' ? 'bg-secondary' : `bg-${this.variant()}-container`;
            classes.push('s-icon--filled', fundo);
        }
        classes.push(`text-${this.variant()}`);
        return classes.join(' ');
    }, ...(ngDevMode ? [{ debugName: "hostClasses" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.34", type: SIconComponent, isStandalone: true, selector: "s-icon", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, iconFilled: { classPropertyName: "iconFilled", publicName: "iconFilled", isSignal: true, isRequired: false, transformFunction: null }, filled: { classPropertyName: "filled", publicName: "filled", isSignal: true, isRequired: false, transformFunction: null }, color: { classPropertyName: "color", publicName: "color", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.s-icon--icon-filled": "iconFilled()", "style.--s-icon-size": "tamanho()", "style.color": "color() || null", "class": "hostClasses()" }, classAttribute: "s-icon" }, ngImport: i0, template: `<mat-icon
    [attr.aria-label]="label() || null"
    [attr.aria-hidden]="label() ? 'false' : 'true'"
    fontSet="material-symbols-rounded"
    >{{ name() }}</mat-icon
  >`, isInline: true, styles: [":host{display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;width:var(--s-icon-size, 20px);height:var(--s-icon-size, 20px);line-height:1}.mat-icon{width:var(--s-icon-size, 20px);height:var(--s-icon-size, 20px);font-size:var(--s-icon-size, 20px);line-height:var(--s-icon-size, 20px);font-family:var(--font-icon, \"Material Symbols Rounded\");font-variation-settings:\"FILL\" 0,\"wght\" 400,\"GRAD\" 0,\"opsz\" 24;overflow:visible}:host(.s-icon--icon-filled) .mat-icon{font-variation-settings:\"FILL\" 1,\"wght\" 400,\"GRAD\" 0,\"opsz\" 24}:host(.s-icon--filled){padding:calc((var(--mat-icon-button-state-layer-size, 40px) - var(--mat-icon-button-icon-size, 24px)) / 2);border-radius:var(--radius-control, 8px)}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-icon', imports: [MatIconModule], template: `<mat-icon
    [attr.aria-label]="label() || null"
    [attr.aria-hidden]="label() ? 'false' : 'true'"
    fontSet="material-symbols-rounded"
    >{{ name() }}</mat-icon
  >`, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-icon',
                        '[class.s-icon--icon-filled]': 'iconFilled()',
                        '[style.--s-icon-size]': 'tamanho()',
                        '[style.color]': 'color() || null',
                        '[class]': 'hostClasses()',
                    }, styles: [":host{display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;width:var(--s-icon-size, 20px);height:var(--s-icon-size, 20px);line-height:1}.mat-icon{width:var(--s-icon-size, 20px);height:var(--s-icon-size, 20px);font-size:var(--s-icon-size, 20px);line-height:var(--s-icon-size, 20px);font-family:var(--font-icon, \"Material Symbols Rounded\");font-variation-settings:\"FILL\" 0,\"wght\" 400,\"GRAD\" 0,\"opsz\" 24;overflow:visible}:host(.s-icon--icon-filled) .mat-icon{font-variation-settings:\"FILL\" 1,\"wght\" 400,\"GRAD\" 0,\"opsz\" 24}:host(.s-icon--filled){padding:calc((var(--mat-icon-button-state-layer-size, 40px) - var(--mat-icon-button-icon-size, 24px)) / 2);border-radius:var(--radius-control, 8px)}\n"] }]
        }], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: true }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], iconFilled: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconFilled", required: false }] }], filled: [{ type: i0.Input, args: [{ isSignal: true, alias: "filled", required: false }] }], color: [{ type: i0.Input, args: [{ isSignal: true, alias: "color", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }] } });

/**
 * Aparencia do Material que serve de base a cada variante do guia.
 *
 * As cores nao vem daqui: cada variante repinta os tokens `--mat-button-*` no
 * SCSS com os tokens do design system. A aparencia escolhe apenas a *estrutura*
 * do botao (preenchido, contornado ou plano), que e o que o Material entrega —
 * junto com ripple, foco e semantica de desabilitado.
 */
const APARENCIA = {
    primary: 'filled',
    secondary: 'filled',
    success: 'filled',
    warning: 'filled',
    info: 'filled',
    destructive: 'filled',
    ghost: 'text',
    link: 'text',
};
/**
 * Variantes em que `outlined` faz sentido: as preenchidas.
 *
 * `ghost` e `link` existem justamente para nao ter moldura — contorna-las
 * apagaria a diferenca entre elas e as demais. Nesses dois casos o input e
 * ignorado, em vez de gerar um estado sem significado.
 */
const CONTORNAVEIS$1 = [
    'primary',
    'secondary',
    'success',
    'warning',
    'info',
    'destructive',
];
/**
 * Botao de acao, sobre o `matButton`. A `variant` e o papel da acao na tela.
 *
 * Em `loading` continua focavel, mas ignora o clique e anuncia `aria-busy`.
 */
class SButtonComponent {
    /** Papel da acao na tela. Ver `SButtonVariant`. */
    variant = input('primary', ...(ngDevMode ? [{ debugName: "variant" }] : []));
    /** Troca o preenchimento por um contorno. Ignorado em `ghost` e `link`. */
    outlined = input(false, ...(ngDevMode ? [{ debugName: "outlined", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Ocupa toda a largura disponivel e ganha a altura maior do guia. */
    fullWidth = input(false, ...(ngDevMode ? [{ debugName: "fullWidth", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Botao de alternancia: `true`/`false` viram `aria-pressed` no botao nativo,
     * que e quem recebe o foco. `null` (padrao) e um botao comum.
     */
    pressed = input(null, ...(ngDevMode ? [{ debugName: "pressed" }] : []));
    /**
     * Papel ARIA do botao nativo, para quando ele e a opcao de um composto (ex.:
     * `radio` num `radiogroup`). `null` (padrao) mantem o papel de botao. Quem usa
     * `radio` deve passar `checked` e deixar `pressed` em `null`.
     */
    buttonRole = input(null, ...(ngDevMode ? [{ debugName: "buttonRole" }] : []));
    /** `aria-checked` do botao nativo, para `buttonRole="radio"`. `null` (padrao) nao escreve nada. */
    checked = input(null, ...(ngDevMode ? [{ debugName: "checked" }] : []));
    /**
     * `tabindex` do botao nativo, para o "roving tabindex" de um composto: `0` na
     * opcao que entra no Tab e `-1` nas demais. `null` (padrao) nao escreve nada.
     */
    focusIndex = input(null, ...(ngDevMode ? [{ debugName: "focusIndex" }] : []));
    /** Exibe o glifo de progresso e bloqueia o clique, sem desabilitar o botao. */
    loading = input(false, ...(ngDevMode ? [{ debugName: "loading", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Texto exibido no lugar do rotulo enquanto `loading` e `true` ("Salvando...").
     *
     * Sem ele (padrao) o rotulo nao muda, como sempre. Com ele, a troca e anunciada
     * ao leitor de tela (`aria-live="polite"`) e o foco fica no botao. O botao
     * continua habilitado durante o `loading`: para travar os demais botoes da
     * barra, use `[disabled]` neles com o mesmo estado da tela.
     */
    loadingText = input(undefined, ...(ngDevMode ? [{ debugName: "loadingText" }] : []));
    /** Desabilita o botao. Indica indisponibilidade da acao, nao carregamento. */
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Glifo a esquerda do texto, em 20px. */
    icon = input('', ...(ngDevMode ? [{ debugName: "icon" }] : []));
    /** Glifo a direita do texto, em 20px. Escondido enquanto `loading`. */
    iconRight = input('', ...(ngDevMode ? [{ debugName: "iconRight" }] : []));
    /** Atributo `type` do botao nativo. */
    type = input('button', ...(ngDevMode ? [{ debugName: "type" }] : []));
    /** Nome acessivel, quando o texto visivel nao basta (ex.: "Ver" numa tabela). */
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
    /** `true` quando `outlined` foi pedido numa variante que o suporta. */
    isOutlined = computed(() => this.outlined() && CONTORNAVEIS$1.includes(this.variant()), ...(ngDevMode ? [{ debugName: "isOutlined" }] : []));
    appearance = computed(() => this.isOutlined() ? 'outlined' : APARENCIA[this.variant()], ...(ngDevMode ? [{ debugName: "appearance" }] : []));
    hostClasses = computed(() => {
        const classes = [`s-button--${this.variant()}`];
        if (this.isOutlined()) {
            classes.push('s-button--outlined');
        }
        if (this.fullWidth()) {
            classes.push('s-button--full');
        }
        if (this.loading()) {
            classes.push('s-button--loading');
        }
        return classes.join(' ');
    }, ...(ngDevMode ? [{ debugName: "hostClasses" }] : []));
    /**
     * Barra o clique enquanto `loading`, venha do mouse ou do teclado (Enter e
     * Espaco tambem geram `click` no botao nativo).
     *
     * `preventDefault` impede o envio do formulario em `type="submit"`;
     * `stopPropagation` impede que o evento suba ate o `<s-button>`, onde a tela
     * liga o `(click)`.
     */
    aoClicar(evento) {
        if (this.loading()) {
            evento.preventDefault();
            evento.stopPropagation();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SButtonComponent, isStandalone: true, selector: "s-button", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, outlined: { classPropertyName: "outlined", publicName: "outlined", isSignal: true, isRequired: false, transformFunction: null }, fullWidth: { classPropertyName: "fullWidth", publicName: "fullWidth", isSignal: true, isRequired: false, transformFunction: null }, pressed: { classPropertyName: "pressed", publicName: "pressed", isSignal: true, isRequired: false, transformFunction: null }, buttonRole: { classPropertyName: "buttonRole", publicName: "buttonRole", isSignal: true, isRequired: false, transformFunction: null }, checked: { classPropertyName: "checked", publicName: "checked", isSignal: true, isRequired: false, transformFunction: null }, focusIndex: { classPropertyName: "focusIndex", publicName: "focusIndex", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, loadingText: { classPropertyName: "loadingText", publicName: "loadingText", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, iconRight: { classPropertyName: "iconRight", publicName: "iconRight", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" }, classAttribute: "s-button" }, ngImport: i0, template: "<button\n  class=\"s-button__native\"\n  [matButton]=\"appearance()\"\n  [type]=\"type()\"\n  [disabled]=\"disabled()\"\n  [attr.aria-busy]=\"loading() ? 'true' : null\"\n  [attr.aria-pressed]=\"pressed()\"\n  [attr.role]=\"buttonRole()\"\n  [attr.aria-checked]=\"checked()\"\n  [tabIndex]=\"focusIndex() ?? undefined\"\n  [attr.aria-label]=\"label() || null\"\n  (click)=\"aoClicar($event)\"\n>\n  @if (loading()) {\n    <s-icon matButtonIcon class=\"s-button__spinner\" name=\"progress_activity\" size=\"sm\" />\n  } @else if (icon()) {\n    <s-icon matButtonIcon [name]=\"icon()\" size=\"sm\" />\n  }\n\n  <span class=\"s-button__label\" [attr.aria-live]=\"loadingText() ? 'polite' : null\">\n    @if (loading() && loadingText()) {\n      {{ loadingText() }}\n    } @else {\n      <ng-content />\n    }\n  </span>\n\n  @if (iconRight() && !loading()) {\n    <s-icon matButtonIcon iconPositionEnd [name]=\"iconRight()\" size=\"sm\" />\n  }\n</button>\n", styles: [":host{display:inline-flex;max-width:100%;vertical-align:middle;--s-button-h: var(--control-h, 40px)}:host(.s-button--full){display:flex;width:100%;--s-button-h: var(--control-h-primary-full, 48px)}:host(.s-button--full) .s-button__native{width:100%}.s-button__native{--mat-button-filled-container-height: var(--s-button-h);--mat-button-filled-container-shape: var(--radius-control, 8px);--mat-button-filled-horizontal-padding: var(--control-px, 24px);--mat-button-filled-icon-spacing: var(--space-8, 8px);--mat-button-filled-icon-offset: 0;--mat-button-filled-label-text-font: var(--font-ui);--mat-button-filled-label-text-size: var(--text-label, 14px);--mat-button-filled-label-text-weight: var(--weight-medium, 500);--mat-button-filled-label-text-transform: none;--mat-button-filled-label-text-tracking: normal;--mat-button-outlined-container-height: var(--s-button-h);--mat-button-outlined-container-shape: var(--radius-control, 8px);--mat-button-outlined-horizontal-padding: var(--control-px, 24px);--mat-button-outlined-icon-spacing: var(--space-8, 8px);--mat-button-outlined-icon-offset: 0;--mat-button-outlined-label-text-font: var(--font-ui);--mat-button-outlined-label-text-size: var(--text-label, 14px);--mat-button-outlined-label-text-weight: var(--weight-medium, 500);--mat-button-outlined-label-text-transform: none;--mat-button-outlined-label-text-tracking: normal;--mat-button-text-container-height: var(--s-button-h);--mat-button-text-container-shape: var(--radius-control, 8px);--mat-button-text-horizontal-padding: var(--control-px, 24px);--mat-button-text-icon-spacing: var(--space-8, 8px);--mat-button-text-icon-offset: 0;--mat-button-text-label-text-font: var(--font-ui);--mat-button-text-label-text-size: var(--text-label, 14px);--mat-button-text-label-text-weight: var(--weight-medium, 500);--mat-button-text-label-text-transform: none;--mat-button-text-label-text-tracking: normal;--mat-button-text-with-icon-horizontal-padding: var(--control-px, 24px);--mat-button-filled-container-color: var(--s-button-bg);--mat-button-filled-disabled-container-color: var(--s-button-bg);--mat-button-filled-label-text-color: var(--s-button-fg);--mat-button-filled-disabled-label-text-color: var(--s-button-fg);--mat-button-filled-ripple-color: color-mix(in srgb, var(--s-button-fg) 20%, transparent);--mat-button-filled-hover-state-layer-opacity: 0;--mat-button-filled-focus-state-layer-opacity: 0;--mat-button-outlined-label-text-color: var(--s-button-fg);--mat-button-outlined-disabled-label-text-color: var(--s-button-fg);--mat-button-outlined-outline-color: var(--border);--mat-button-outlined-disabled-outline-color: var(--border);--mat-button-outlined-outline-width: 1px;--mat-button-outlined-state-layer-color: var(--text-primary);--mat-button-outlined-ripple-color: color-mix(in srgb, var(--text-primary) 12%, transparent);--mat-button-outlined-hover-state-layer-opacity: .06;--mat-button-outlined-focus-state-layer-opacity: .06;--mat-button-text-label-text-color: var(--s-button-fg);--mat-button-text-disabled-label-text-color: var(--s-button-fg);--mat-button-text-state-layer-color: var(--text-primary);--mat-button-text-ripple-color: color-mix(in srgb, var(--text-primary) 12%, transparent);--mat-button-text-hover-state-layer-opacity: .06;--mat-button-text-focus-state-layer-opacity: .06;transition:background-color .15s ease,border-color .15s ease,color .15s ease}.s-button__native:disabled{opacity:.4;cursor:default}.s-button__native:focus-visible{outline:none;box-shadow:0 0 0 2px var(--card),0 0 0 5px var(--focus-ring)}.s-button__label{display:inline-flex;align-items:center;min-width:0}.s-button__native s-icon{margin-right:var(--space-8, 8px);margin-top:1px}.s-button__native s-icon[iconPositionEnd]{margin-right:0;margin-left:var(--space-8, 8px)}:host(.s-button--primary) .s-button__native{--s-button-bg: var(--primary);--s-button-fg: var(--on-filled);--s-button-line: var(--primary);--s-button-ink: var(--primary)}:host(.s-button--primary) .s-button__native:hover:not(:disabled){--s-button-bg: var(--primary-hover)}:host(.s-button--secondary) .s-button__native{--s-button-bg: var(--secondary);--s-button-fg: var(--text-primary);--s-button-line: var(--border);--s-button-ink: var(--text-primary);--s-button-veil: var(--text-primary);--s-button-veil-opacity: .06}:host(.s-button--secondary) .s-button__native:hover:not(:disabled){--s-button-bg: var(--secondary-hover)}:host(.s-button--destructive) .s-button__native{--s-button-bg: var(--destructive);--s-button-fg: var(--on-filled);--s-button-line: var(--destructive);--s-button-ink: var(--destructive-on-surface)}:host(.s-button--destructive) .s-button__native:hover:not(:disabled){--s-button-bg: var(--destructive-hover)}:host(.s-button--success) .s-button__native{--s-button-bg: var(--success);--s-button-fg: var(--on-filled);--s-button-line: var(--success);--s-button-ink: var(--success-on-surface)}:host(.s-button--success) .s-button__native:hover:not(:disabled){--s-button-bg: var(--success-hover)}:host(.s-button--warning) .s-button__native{--s-button-bg: var(--warning);--s-button-fg: var(--on-filled);--s-button-line: var(--warning);--s-button-ink: var(--warning-on-surface)}:host(.s-button--warning) .s-button__native:hover:not(:disabled){--s-button-bg: color-mix(in srgb, var(--warning) 90%, #000)}:host(.s-button--info) .s-button__native{--s-button-bg: var(--info);--s-button-fg: var(--on-filled);--s-button-line: var(--info);--s-button-ink: var(--info-on-surface)}:host(.s-button--info) .s-button__native:hover:not(:disabled){--s-button-bg: color-mix(in srgb, var(--info) 90%, #000)}:host(.s-button--outlined) .s-button__native{--mat-button-outlined-outline-color: var(--s-button-line);--mat-button-outlined-disabled-outline-color: var(--s-button-line);--mat-button-outlined-label-text-color: var(--s-button-ink);--mat-button-outlined-disabled-label-text-color: var(--s-button-ink);--mat-button-outlined-state-layer-color: var(--s-button-veil, var(--s-button-line));--mat-button-outlined-ripple-color: color-mix( in srgb, var(--s-button-veil, var(--s-button-line)) 20%, transparent );--mat-button-outlined-hover-state-layer-opacity: var( --s-button-veil-opacity, var(--tint-container, .12) );--mat-button-outlined-focus-state-layer-opacity: var( --s-button-veil-opacity, var(--tint-container, .12) )}:host(.s-button--ghost) .s-button__native{--s-button-fg: var(--text-primary)}:host(.s-button--link){--s-button-h: auto}:host(.s-button--link) .s-button__native{--s-button-fg: var(--primary);--mat-button-text-horizontal-padding: 0;--mat-button-text-with-icon-horizontal-padding: 0;--mat-button-text-hover-state-layer-opacity: 0;--mat-button-text-focus-state-layer-opacity: 0;height:auto;min-width:0}:host(.s-button--link) .s-button__native:hover:not(:disabled){--s-button-fg: var(--primary-hover)}:host(.s-button--link) .s-button__label{text-decoration:underline;text-underline-offset:3px}:host(.s-button--loading) .s-button__native{cursor:progress}.s-button__spinner{animation:s-button-spin .9s linear infinite}@keyframes s-button-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.s-button__spinner{animation-duration:3s}}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1$1.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-button', imports: [MatButtonModule, SIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-button',
                        '[class]': 'hostClasses()',
                    }, template: "<button\n  class=\"s-button__native\"\n  [matButton]=\"appearance()\"\n  [type]=\"type()\"\n  [disabled]=\"disabled()\"\n  [attr.aria-busy]=\"loading() ? 'true' : null\"\n  [attr.aria-pressed]=\"pressed()\"\n  [attr.role]=\"buttonRole()\"\n  [attr.aria-checked]=\"checked()\"\n  [tabIndex]=\"focusIndex() ?? undefined\"\n  [attr.aria-label]=\"label() || null\"\n  (click)=\"aoClicar($event)\"\n>\n  @if (loading()) {\n    <s-icon matButtonIcon class=\"s-button__spinner\" name=\"progress_activity\" size=\"sm\" />\n  } @else if (icon()) {\n    <s-icon matButtonIcon [name]=\"icon()\" size=\"sm\" />\n  }\n\n  <span class=\"s-button__label\" [attr.aria-live]=\"loadingText() ? 'polite' : null\">\n    @if (loading() && loadingText()) {\n      {{ loadingText() }}\n    } @else {\n      <ng-content />\n    }\n  </span>\n\n  @if (iconRight() && !loading()) {\n    <s-icon matButtonIcon iconPositionEnd [name]=\"iconRight()\" size=\"sm\" />\n  }\n</button>\n", styles: [":host{display:inline-flex;max-width:100%;vertical-align:middle;--s-button-h: var(--control-h, 40px)}:host(.s-button--full){display:flex;width:100%;--s-button-h: var(--control-h-primary-full, 48px)}:host(.s-button--full) .s-button__native{width:100%}.s-button__native{--mat-button-filled-container-height: var(--s-button-h);--mat-button-filled-container-shape: var(--radius-control, 8px);--mat-button-filled-horizontal-padding: var(--control-px, 24px);--mat-button-filled-icon-spacing: var(--space-8, 8px);--mat-button-filled-icon-offset: 0;--mat-button-filled-label-text-font: var(--font-ui);--mat-button-filled-label-text-size: var(--text-label, 14px);--mat-button-filled-label-text-weight: var(--weight-medium, 500);--mat-button-filled-label-text-transform: none;--mat-button-filled-label-text-tracking: normal;--mat-button-outlined-container-height: var(--s-button-h);--mat-button-outlined-container-shape: var(--radius-control, 8px);--mat-button-outlined-horizontal-padding: var(--control-px, 24px);--mat-button-outlined-icon-spacing: var(--space-8, 8px);--mat-button-outlined-icon-offset: 0;--mat-button-outlined-label-text-font: var(--font-ui);--mat-button-outlined-label-text-size: var(--text-label, 14px);--mat-button-outlined-label-text-weight: var(--weight-medium, 500);--mat-button-outlined-label-text-transform: none;--mat-button-outlined-label-text-tracking: normal;--mat-button-text-container-height: var(--s-button-h);--mat-button-text-container-shape: var(--radius-control, 8px);--mat-button-text-horizontal-padding: var(--control-px, 24px);--mat-button-text-icon-spacing: var(--space-8, 8px);--mat-button-text-icon-offset: 0;--mat-button-text-label-text-font: var(--font-ui);--mat-button-text-label-text-size: var(--text-label, 14px);--mat-button-text-label-text-weight: var(--weight-medium, 500);--mat-button-text-label-text-transform: none;--mat-button-text-label-text-tracking: normal;--mat-button-text-with-icon-horizontal-padding: var(--control-px, 24px);--mat-button-filled-container-color: var(--s-button-bg);--mat-button-filled-disabled-container-color: var(--s-button-bg);--mat-button-filled-label-text-color: var(--s-button-fg);--mat-button-filled-disabled-label-text-color: var(--s-button-fg);--mat-button-filled-ripple-color: color-mix(in srgb, var(--s-button-fg) 20%, transparent);--mat-button-filled-hover-state-layer-opacity: 0;--mat-button-filled-focus-state-layer-opacity: 0;--mat-button-outlined-label-text-color: var(--s-button-fg);--mat-button-outlined-disabled-label-text-color: var(--s-button-fg);--mat-button-outlined-outline-color: var(--border);--mat-button-outlined-disabled-outline-color: var(--border);--mat-button-outlined-outline-width: 1px;--mat-button-outlined-state-layer-color: var(--text-primary);--mat-button-outlined-ripple-color: color-mix(in srgb, var(--text-primary) 12%, transparent);--mat-button-outlined-hover-state-layer-opacity: .06;--mat-button-outlined-focus-state-layer-opacity: .06;--mat-button-text-label-text-color: var(--s-button-fg);--mat-button-text-disabled-label-text-color: var(--s-button-fg);--mat-button-text-state-layer-color: var(--text-primary);--mat-button-text-ripple-color: color-mix(in srgb, var(--text-primary) 12%, transparent);--mat-button-text-hover-state-layer-opacity: .06;--mat-button-text-focus-state-layer-opacity: .06;transition:background-color .15s ease,border-color .15s ease,color .15s ease}.s-button__native:disabled{opacity:.4;cursor:default}.s-button__native:focus-visible{outline:none;box-shadow:0 0 0 2px var(--card),0 0 0 5px var(--focus-ring)}.s-button__label{display:inline-flex;align-items:center;min-width:0}.s-button__native s-icon{margin-right:var(--space-8, 8px);margin-top:1px}.s-button__native s-icon[iconPositionEnd]{margin-right:0;margin-left:var(--space-8, 8px)}:host(.s-button--primary) .s-button__native{--s-button-bg: var(--primary);--s-button-fg: var(--on-filled);--s-button-line: var(--primary);--s-button-ink: var(--primary)}:host(.s-button--primary) .s-button__native:hover:not(:disabled){--s-button-bg: var(--primary-hover)}:host(.s-button--secondary) .s-button__native{--s-button-bg: var(--secondary);--s-button-fg: var(--text-primary);--s-button-line: var(--border);--s-button-ink: var(--text-primary);--s-button-veil: var(--text-primary);--s-button-veil-opacity: .06}:host(.s-button--secondary) .s-button__native:hover:not(:disabled){--s-button-bg: var(--secondary-hover)}:host(.s-button--destructive) .s-button__native{--s-button-bg: var(--destructive);--s-button-fg: var(--on-filled);--s-button-line: var(--destructive);--s-button-ink: var(--destructive-on-surface)}:host(.s-button--destructive) .s-button__native:hover:not(:disabled){--s-button-bg: var(--destructive-hover)}:host(.s-button--success) .s-button__native{--s-button-bg: var(--success);--s-button-fg: var(--on-filled);--s-button-line: var(--success);--s-button-ink: var(--success-on-surface)}:host(.s-button--success) .s-button__native:hover:not(:disabled){--s-button-bg: var(--success-hover)}:host(.s-button--warning) .s-button__native{--s-button-bg: var(--warning);--s-button-fg: var(--on-filled);--s-button-line: var(--warning);--s-button-ink: var(--warning-on-surface)}:host(.s-button--warning) .s-button__native:hover:not(:disabled){--s-button-bg: color-mix(in srgb, var(--warning) 90%, #000)}:host(.s-button--info) .s-button__native{--s-button-bg: var(--info);--s-button-fg: var(--on-filled);--s-button-line: var(--info);--s-button-ink: var(--info-on-surface)}:host(.s-button--info) .s-button__native:hover:not(:disabled){--s-button-bg: color-mix(in srgb, var(--info) 90%, #000)}:host(.s-button--outlined) .s-button__native{--mat-button-outlined-outline-color: var(--s-button-line);--mat-button-outlined-disabled-outline-color: var(--s-button-line);--mat-button-outlined-label-text-color: var(--s-button-ink);--mat-button-outlined-disabled-label-text-color: var(--s-button-ink);--mat-button-outlined-state-layer-color: var(--s-button-veil, var(--s-button-line));--mat-button-outlined-ripple-color: color-mix( in srgb, var(--s-button-veil, var(--s-button-line)) 20%, transparent );--mat-button-outlined-hover-state-layer-opacity: var( --s-button-veil-opacity, var(--tint-container, .12) );--mat-button-outlined-focus-state-layer-opacity: var( --s-button-veil-opacity, var(--tint-container, .12) )}:host(.s-button--ghost) .s-button__native{--s-button-fg: var(--text-primary)}:host(.s-button--link){--s-button-h: auto}:host(.s-button--link) .s-button__native{--s-button-fg: var(--primary);--mat-button-text-horizontal-padding: 0;--mat-button-text-with-icon-horizontal-padding: 0;--mat-button-text-hover-state-layer-opacity: 0;--mat-button-text-focus-state-layer-opacity: 0;height:auto;min-width:0}:host(.s-button--link) .s-button__native:hover:not(:disabled){--s-button-fg: var(--primary-hover)}:host(.s-button--link) .s-button__label{text-decoration:underline;text-underline-offset:3px}:host(.s-button--loading) .s-button__native{cursor:progress}.s-button__spinner{animation:s-button-spin .9s linear infinite}@keyframes s-button-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.s-button__spinner{animation-duration:3s}}\n"] }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], outlined: [{ type: i0.Input, args: [{ isSignal: true, alias: "outlined", required: false }] }], fullWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "fullWidth", required: false }] }], pressed: [{ type: i0.Input, args: [{ isSignal: true, alias: "pressed", required: false }] }], buttonRole: [{ type: i0.Input, args: [{ isSignal: true, alias: "buttonRole", required: false }] }], checked: [{ type: i0.Input, args: [{ isSignal: true, alias: "checked", required: false }] }], focusIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "focusIndex", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], loadingText: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingText", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], iconRight: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconRight", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

/** Traducao para o vocabulario de posicao do Material. */
const POSICAO = {
    top: 'above',
    bottom: 'below',
    left: 'left',
    right: 'right',
    // O CDK overlay do Material ja reposiciona para caber na tela; 'below' e um
    // ponto de partida seguro para o caso em que a aplicacao nao tem preferencia.
    auto: 'below',
};
/**
 * Dica curta no hover e no foco por teclado, sobre o `matTooltip`.
 *
 * E apoio, nunca instrucao obrigatoria. Use em elemento focavel (botao, link,
 * `s-button`, `s-icon-button`): fora deles a dica so existe para o mouse.
 * Enquanto ligada, o elemento mostra o cursor de mao (`s-tooltip-alvo`).
 *
 * @example
 * ```html
 * <s-icon-button
 *   icon="history"
 *   label="Histórico"
 *   sTooltip="Alteração aguardando aprovação da gerência regional."
 * />
 * ```
 */
class STooltipDirective {
    /** Texto exibido. Uma a duas linhas. */
    text = input.required(...(ngDevMode ? [{ debugName: "text", alias: 'sTooltip' }] : [{ alias: 'sTooltip' }]));
    /** Posicao em relacao ao elemento. */
    position = input('top', ...(ngDevMode ? [{ debugName: "position", alias: 'sTooltipPosition' }] : [{ alias: 'sTooltipPosition' }]));
    /** Desliga o tooltip sem remover a diretiva do template. */
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled", alias: 'sTooltipDisabled',
            transform: booleanAttribute }] : [{
            alias: 'sTooltipDisabled',
            transform: booleanAttribute,
        }]));
    /** Atraso do hover em ms. O guia define a faixa 300–500. */
    delay = input(400, ...(ngDevMode ? [{ debugName: "delay", alias: 'sTooltipDelay',
            transform: numberAttribute }] : [{
            alias: 'sTooltipDelay',
            transform: numberAttribute,
        }]));
    tooltip = inject(MatTooltip);
    host = inject(ElementRef).nativeElement;
    descritor = inject(AriaDescriber);
    foco = inject(FocusMonitor);
    /** O focavel de dentro do host que recebeu a descricao. Ver `ligarAoFocavelInterno`. */
    descrito = null;
    monitorando = false;
    constructor() {
        effect(() => {
            this.tooltip.message = this.text();
            this.tooltip.position = POSICAO[this.position()];
            this.tooltip.disabled = this.disabled();
            this.tooltip.showDelay = this.delay();
        });
        afterRenderEffect(() => this.ligarAoFocavelInterno(this.text(), this.disabled()));
        inject(DestroyRef).onDestroy(() => {
            this.descrever(null, '');
            this.foco.stopMonitoring(this.host);
        });
    }
    /**
     * Quando o host e um componente - `<s-button sTooltip>`, `<s-icon-button
     * sTooltip>` -, quem recebe o foco e o `<button>` de dentro, e nao o host.
     * O `matTooltip` so olha o host: o `aria-describedby` ficava num elemento que
     * o leitor de tela nunca visita, e o foco por teclado no botao nao abria a
     * dica. Aqui as duas coisas sao levadas ao focavel interno.
     */
    ligarAoFocavelInterno(texto, desligado) {
        if (ehFocavel(this.host)) {
            return;
        }
        const alvo = this.host.querySelector(FOCAVEIS);
        this.descrever(alvo && !desligado ? alvo : null, texto);
        if (alvo && !this.monitorando) {
            this.monitorando = true;
            this.foco.monitor(this.host, true).subscribe((origem) => {
                if (origem === 'keyboard') {
                    this.tooltip.show(0);
                }
                else if (origem === null) {
                    this.tooltip.hide(0);
                }
            });
        }
    }
    descrever(alvo, texto) {
        // O efeito so roda de novo quando o texto ou o `disabled` mudam: a
        // descricao anterior sempre sai antes da nova entrar.
        const anterior = this.descrito;
        if (anterior) {
            this.descritor.removeDescription(anterior.alvo, anterior.texto, 'tooltip');
        }
        this.descrito = alvo && texto ? { alvo, texto } : null;
        if (this.descrito) {
            this.descritor.describe(alvo, texto, 'tooltip');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: STooltipDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "20.3.34", type: STooltipDirective, isStandalone: true, selector: "[sTooltip]", inputs: { text: { classPropertyName: "text", publicName: "sTooltip", isSignal: true, isRequired: true, transformFunction: null }, position: { classPropertyName: "position", publicName: "sTooltipPosition", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "sTooltipDisabled", isSignal: true, isRequired: false, transformFunction: null }, delay: { classPropertyName: "delay", publicName: "sTooltipDelay", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.s-tooltip-alvo": "!disabled() && !!text()" } }, hostDirectives: [{ directive: i1$2.MatTooltip }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: STooltipDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[sTooltip]',
                    hostDirectives: [MatTooltip],
                    host: {
                        // Cursor de mao enquanto ha dica — a regra mora no tema, com especificidade
                        // zero, para nao brigar com o cursor do proprio elemento.
                        '[class.s-tooltip-alvo]': '!disabled() && !!text()',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { text: [{ type: i0.Input, args: [{ isSignal: true, alias: "sTooltip", required: true }] }], position: [{ type: i0.Input, args: [{ isSignal: true, alias: "sTooltipPosition", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "sTooltipDisabled", required: false }] }], delay: [{ type: i0.Input, args: [{ isSignal: true, alias: "sTooltipDelay", required: false }] }] } });
/** O que recebe foco por natureza. */
const FOCAVEIS = 'button, a[href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
function ehFocavel(elemento) {
    return elemento.matches(FOCAVEIS);
}

/**
 * Variantes em que `outlined` faz sentido: as preenchidas.
 *
 * A lista e a mesma do `s-button`, e por isso e repetida aqui: sao dois
 * componentes com o mesmo vocabulario, nao um herdando do outro.
 */
const CONTORNAVEIS = [
    'primary',
    'secondary',
    'success',
    'warning',
    'info',
    'destructive',
];
/**
 * Botao so com icone, sobre o `matIconButton`.
 *
 * `label` e obrigatorio: vira o `aria-label` e a dica do hover. Escreva a acao
 * ("Excluir jornada"), nunca o nome do glifo.
 */
class SIconButtonComponent {
    /** Nome do glifo no Material Symbols. */
    icon = input.required(...(ngDevMode ? [{ debugName: "icon" }] : []));
    /** Texto que descreve a acao. Vira `aria-label` e `title`. */
    label = input.required(...(ngDevMode ? [{ debugName: "label" }] : []));
    /** Papel da acao na tela. Ver `SButtonVariant`. */
    variant = input('ghost', ...(ngDevMode ? [{ debugName: "variant" }] : []));
    /** Contorno na cor da variante. Ignorado em `ghost` e `link`. */
    outlined = input(false, ...(ngDevMode ? [{ debugName: "outlined", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Sem fundo nem moldura: so o glifo, com a cor da variante no hover. */
    text = input(false, ...(ngDevMode ? [{ debugName: "text", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Passo da escala do guia: `xs` (16), `sm` (20), `md` (24) ou `lg` (48).
     */
    size = input('md', ...(ngDevMode ? [{ debugName: "size", transform: tamanhoDeIcone('md') }] : [{ transform: tamanhoDeIcone('md') }]));
    /** Preenche o glifo (eixo `FILL`), como no `<s-icon>`. */
    iconFilled = input(false, ...(ngDevMode ? [{ debugName: "iconFilled", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Desabilita o botao. */
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Mostra o progresso e ignora o clique, mas continua focavel (`aria-busy`). */
    loading = input(false, ...(ngDevMode ? [{ debugName: "loading", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Atributo `type` do botao nativo. */
    type = input('button', ...(ngDevMode ? [{ debugName: "type" }] : []));
    /**
     * Com `sTooltip` no mesmo elemento, a dica e dele: o `title` nativo abriria
     * uma segunda, a do navegador, por cima.
     */
    comDica = !!inject(STooltipDirective, { self: true, optional: true });
    /** `true` quando `outlined` foi pedido numa variante que o suporta. */
    isOutlined = computed(() => this.outlined() && CONTORNAVEIS.includes(this.variant()), ...(ngDevMode ? [{ debugName: "isOutlined" }] : []));
    /** `true` quando `text` foi pedido numa variante que o suporta. */
    isText = computed(() => this.text() && CONTORNAVEIS.includes(this.variant()), ...(ngDevMode ? [{ debugName: "isText" }] : []));
    hostClasses = computed(() => {
        const classes = [`s-icon-button--${this.variant()}`];
        if (this.isOutlined()) {
            classes.push('s-icon-button--outlined');
        }
        if (this.isText()) {
            classes.push('s-icon-button--text');
        }
        return classes.join(' ');
    }, ...(ngDevMode ? [{ debugName: "hostClasses" }] : []));
    /**
     * Lado da area clicavel, derivado do tamanho do glifo.
     *
     * Sem isto a area ficava fixa em 40px: com `size="lg"` o icone de 48px
     * transbordava o proprio hover, que aparecia menor que o desenho. Os 16px de
     * folga sao os que levam o glifo de 24px a area de 40px que o guia fixa.
     */
    area = computed(() => `calc(${variavelDoTamanho(this.size())} + var(--space-16, 16px))`, ...(ngDevMode ? [{ debugName: "area" }] : []));
    /** Ver `SButtonComponent.aoClicar`: barra o clique durante `loading`. */
    aoClicar(evento) {
        if (this.loading()) {
            evento.preventDefault();
            evento.stopPropagation();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SIconButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SIconButtonComponent, isStandalone: true, selector: "s-icon-button", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: true, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, outlined: { classPropertyName: "outlined", publicName: "outlined", isSignal: true, isRequired: false, transformFunction: null }, text: { classPropertyName: "text", publicName: "text", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, iconFilled: { classPropertyName: "iconFilled", publicName: "iconFilled", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()", "style.--s-icon-button-size": "area()" }, classAttribute: "s-icon-button" }, ngImport: i0, template: `
    <button
      matIconButton
      class="s-icon-button__native"
      [type]="type()"
      [disabled]="disabled()"
      [attr.aria-label]="label()"
      [attr.aria-busy]="loading() ? 'true' : null"
      [attr.title]="comDica ? null : label()"
      (click)="aoClicar($event)"
    >
      @if (loading()) {
        <s-icon class="s-icon-button__spinner" name="progress_activity" [size]="size()" />
      } @else {
        <s-icon [name]="icon()" [size]="size()" [iconFilled]="iconFilled()" />
      }
    </button>
  `, isInline: true, styles: [":host{display:inline-flex;vertical-align:middle;--s-icon-button-size: var(--control-h-icon, 40px);--s-icon-button-fg: var(--text-secondary)}.s-icon-button__native{--mat-icon-button-state-layer-size: var(--s-icon-button-size);--mat-icon-button-touch-target-size: var(--s-icon-button-size);--mat-icon-button-icon-size: var(--s-icon-size, var(--icon-md, 24px));--mat-icon-button-container-shape: var(--radius-control, 8px);--mat-icon-button-icon-color: var(--s-icon-button-fg);--mat-icon-button-disabled-icon-color: var(--s-icon-button-fg);--mat-icon-button-state-layer-color: var(--s-icon-button-veil, var(--text-primary));--mat-icon-button-ripple-color: color-mix( in srgb, var(--s-icon-button-veil, var(--text-primary)) 12%, transparent );--mat-icon-button-hover-state-layer-opacity: var(--s-icon-button-veil-opacity, .06);--mat-icon-button-focus-state-layer-opacity: var(--s-icon-button-veil-opacity, .06);width:var(--s-icon-button-size);height:var(--s-icon-button-size);box-sizing:border-box;border:1px solid transparent;display:flex;align-items:center;justify-content:center;transition:background-color .15s ease,color .15s ease}.s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--text-primary)}.s-icon-button__native:disabled{opacity:.4;cursor:default}.s-icon-button__native:focus-visible{outline:none;box-shadow:0 0 0 2px var(--card),0 0 0 5px var(--focus-ring)}:host(.s-icon-button--ghost) .s-icon-button__native,:host(.s-icon-button--link) .s-icon-button__native{--s-icon-button-fg: var(--text-secondary)}:host(.s-icon-button--link) .s-icon-button__native{--s-icon-button-fg: var(--primary)}:host(.s-icon-button--primary) .s-icon-button__native{--s-icon-button-veil: var(--primary);--s-icon-button-veil-opacity: var(--tint-container, .12);--s-icon-button-line: var(--primary);--s-icon-button-ink: var(--primary-on-surface, var(--primary));background:var(--primary);--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--primary) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--secondary) .s-icon-button__native{--s-icon-button-veil: var(--secondary);--s-icon-button-veil-opacity: var(--tint-container, .12);--s-icon-button-line: var(--secondary);--s-icon-button-ink: var(--secondary-on-surface, var(--secondary));background:var(--secondary);--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--secondary) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--success) .s-icon-button__native{--s-icon-button-veil: var(--success);--s-icon-button-veil-opacity: var(--tint-container, .12);--s-icon-button-line: var(--success);--s-icon-button-ink: var(--success-on-surface, var(--success));background:var(--success);--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--success) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--warning) .s-icon-button__native{--s-icon-button-veil: var(--warning);--s-icon-button-veil-opacity: var(--tint-container, .12);--s-icon-button-line: var(--warning);--s-icon-button-ink: var(--warning-on-surface, var(--warning));background:var(--warning);--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--warning) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--info) .s-icon-button__native{--s-icon-button-veil: var(--info);--s-icon-button-veil-opacity: var(--tint-container, .12);--s-icon-button-line: var(--info);--s-icon-button-ink: var(--info-on-surface, var(--info));background:var(--info);--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--info) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--destructive) .s-icon-button__native{--s-icon-button-veil: var(--destructive);--s-icon-button-veil-opacity: var(--tint-container, .12);--s-icon-button-line: var(--destructive);--s-icon-button-ink: var(--destructive-on-surface, var(--destructive));background:var(--destructive);--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--destructive) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--secondary) .s-icon-button__native{--s-icon-button-fg: var(--text-primary);--s-icon-button-veil: var(--text-primary);--s-icon-button-veil-opacity: .06;--s-icon-button-line: var(--border);--s-icon-button-ink: var(--text-primary)}:host(.s-icon-button--secondary) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--text-primary);background:var(--secondary-hover)}:host(.s-icon-button--primary) .s-icon-button__native:hover:not(:disabled){background:var(--primary-hover)}:host(.s-icon-button--success) .s-icon-button__native:hover:not(:disabled){background:var(--success-hover)}:host(.s-icon-button--destructive) .s-icon-button__native:hover:not(:disabled){background:var(--destructive-hover)}:host(.s-icon-button--warning) .s-icon-button__native:hover:not(:disabled){background:color-mix(in srgb,var(--warning) 90%,#000)}:host(.s-icon-button--info) .s-icon-button__native:hover:not(:disabled){background:color-mix(in srgb,var(--info) 90%,#000)}:host(.s-icon-button--outlined) .s-icon-button__native{background:transparent;border-color:var(--s-icon-button-line);--s-icon-button-fg: var(--s-icon-button-ink)}:host(.s-icon-button--outlined) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--s-icon-button-ink);background:color-mix(in srgb,var(--s-icon-button-veil) calc(var(--s-icon-button-veil-opacity) * 100%),transparent)}:host(.s-icon-button--text) .s-icon-button__native{background:transparent;border-color:transparent;--s-icon-button-fg: var(--text-secondary)}:host(.s-icon-button--text) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--s-icon-button-veil);background:color-mix(in srgb,var(--s-icon-button-veil) calc(var(--s-icon-button-veil-opacity) * 100%),transparent)}.s-icon-button__spinner{animation:s-icon-button-spin .9s linear infinite}@keyframes s-icon-button-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.s-icon-button__spinner{animation-duration:3s}}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1$1.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SIconButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-icon-button', imports: [MatButtonModule, SIconComponent], template: `
    <button
      matIconButton
      class="s-icon-button__native"
      [type]="type()"
      [disabled]="disabled()"
      [attr.aria-label]="label()"
      [attr.aria-busy]="loading() ? 'true' : null"
      [attr.title]="comDica ? null : label()"
      (click)="aoClicar($event)"
    >
      @if (loading()) {
        <s-icon class="s-icon-button__spinner" name="progress_activity" [size]="size()" />
      } @else {
        <s-icon [name]="icon()" [size]="size()" [iconFilled]="iconFilled()" />
      }
    </button>
  `, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-icon-button',
                        '[class]': 'hostClasses()',
                        '[style.--s-icon-button-size]': 'area()',
                    }, styles: [":host{display:inline-flex;vertical-align:middle;--s-icon-button-size: var(--control-h-icon, 40px);--s-icon-button-fg: var(--text-secondary)}.s-icon-button__native{--mat-icon-button-state-layer-size: var(--s-icon-button-size);--mat-icon-button-touch-target-size: var(--s-icon-button-size);--mat-icon-button-icon-size: var(--s-icon-size, var(--icon-md, 24px));--mat-icon-button-container-shape: var(--radius-control, 8px);--mat-icon-button-icon-color: var(--s-icon-button-fg);--mat-icon-button-disabled-icon-color: var(--s-icon-button-fg);--mat-icon-button-state-layer-color: var(--s-icon-button-veil, var(--text-primary));--mat-icon-button-ripple-color: color-mix( in srgb, var(--s-icon-button-veil, var(--text-primary)) 12%, transparent );--mat-icon-button-hover-state-layer-opacity: var(--s-icon-button-veil-opacity, .06);--mat-icon-button-focus-state-layer-opacity: var(--s-icon-button-veil-opacity, .06);width:var(--s-icon-button-size);height:var(--s-icon-button-size);box-sizing:border-box;border:1px solid transparent;display:flex;align-items:center;justify-content:center;transition:background-color .15s ease,color .15s ease}.s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--text-primary)}.s-icon-button__native:disabled{opacity:.4;cursor:default}.s-icon-button__native:focus-visible{outline:none;box-shadow:0 0 0 2px var(--card),0 0 0 5px var(--focus-ring)}:host(.s-icon-button--ghost) .s-icon-button__native,:host(.s-icon-button--link) .s-icon-button__native{--s-icon-button-fg: var(--text-secondary)}:host(.s-icon-button--link) .s-icon-button__native{--s-icon-button-fg: var(--primary)}:host(.s-icon-button--primary) .s-icon-button__native{--s-icon-button-veil: var(--primary);--s-icon-button-veil-opacity: var(--tint-container, .12);--s-icon-button-line: var(--primary);--s-icon-button-ink: var(--primary-on-surface, var(--primary));background:var(--primary);--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--primary) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--secondary) .s-icon-button__native{--s-icon-button-veil: var(--secondary);--s-icon-button-veil-opacity: var(--tint-container, .12);--s-icon-button-line: var(--secondary);--s-icon-button-ink: var(--secondary-on-surface, var(--secondary));background:var(--secondary);--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--secondary) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--success) .s-icon-button__native{--s-icon-button-veil: var(--success);--s-icon-button-veil-opacity: var(--tint-container, .12);--s-icon-button-line: var(--success);--s-icon-button-ink: var(--success-on-surface, var(--success));background:var(--success);--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--success) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--warning) .s-icon-button__native{--s-icon-button-veil: var(--warning);--s-icon-button-veil-opacity: var(--tint-container, .12);--s-icon-button-line: var(--warning);--s-icon-button-ink: var(--warning-on-surface, var(--warning));background:var(--warning);--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--warning) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--info) .s-icon-button__native{--s-icon-button-veil: var(--info);--s-icon-button-veil-opacity: var(--tint-container, .12);--s-icon-button-line: var(--info);--s-icon-button-ink: var(--info-on-surface, var(--info));background:var(--info);--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--info) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--destructive) .s-icon-button__native{--s-icon-button-veil: var(--destructive);--s-icon-button-veil-opacity: var(--tint-container, .12);--s-icon-button-line: var(--destructive);--s-icon-button-ink: var(--destructive-on-surface, var(--destructive));background:var(--destructive);--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--destructive) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--on-filled)}:host(.s-icon-button--secondary) .s-icon-button__native{--s-icon-button-fg: var(--text-primary);--s-icon-button-veil: var(--text-primary);--s-icon-button-veil-opacity: .06;--s-icon-button-line: var(--border);--s-icon-button-ink: var(--text-primary)}:host(.s-icon-button--secondary) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--text-primary);background:var(--secondary-hover)}:host(.s-icon-button--primary) .s-icon-button__native:hover:not(:disabled){background:var(--primary-hover)}:host(.s-icon-button--success) .s-icon-button__native:hover:not(:disabled){background:var(--success-hover)}:host(.s-icon-button--destructive) .s-icon-button__native:hover:not(:disabled){background:var(--destructive-hover)}:host(.s-icon-button--warning) .s-icon-button__native:hover:not(:disabled){background:color-mix(in srgb,var(--warning) 90%,#000)}:host(.s-icon-button--info) .s-icon-button__native:hover:not(:disabled){background:color-mix(in srgb,var(--info) 90%,#000)}:host(.s-icon-button--outlined) .s-icon-button__native{background:transparent;border-color:var(--s-icon-button-line);--s-icon-button-fg: var(--s-icon-button-ink)}:host(.s-icon-button--outlined) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--s-icon-button-ink);background:color-mix(in srgb,var(--s-icon-button-veil) calc(var(--s-icon-button-veil-opacity) * 100%),transparent)}:host(.s-icon-button--text) .s-icon-button__native{background:transparent;border-color:transparent;--s-icon-button-fg: var(--text-secondary)}:host(.s-icon-button--text) .s-icon-button__native:hover:not(:disabled){--s-icon-button-fg: var(--s-icon-button-veil);background:color-mix(in srgb,var(--s-icon-button-veil) calc(var(--s-icon-button-veil-opacity) * 100%),transparent)}.s-icon-button__spinner{animation:s-icon-button-spin .9s linear infinite}@keyframes s-icon-button-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.s-icon-button__spinner{animation-duration:3s}}\n"] }]
        }], propDecorators: { icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: true }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], outlined: [{ type: i0.Input, args: [{ isSignal: true, alias: "outlined", required: false }] }], text: [{ type: i0.Input, args: [{ isSignal: true, alias: "text", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], iconFilled: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconFilled", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }] } });

/**
 * Papel que tira o `<header>`/`<footer>` do card da lista de marcos da pagina.
 *
 * Fora de `<article>` e `<section>`, `<header>` e `<footer>` sao o "banner" e o
 * "contentinfo" da pagina inteira: uma tela com tres cards anunciava tres
 * cabecalhos de pagina ao leitor de tela. O card e um bloco, nao a pagina.
 * Em outro elemento, ou com `role` escrito pela tela, nada muda.
 */
function papelForaDosMarcos() {
    const escrito = inject(new HostAttributeToken('role'), { optional: true });
    const tag = inject(ElementRef).nativeElement.tagName;
    return escrito ?? (tag === 'HEADER' || tag === 'FOOTER' ? 'none' : null);
}
/**
 * Cabecalho do `<s-card>`: uma linha com o titulo e o que mais vier — badge,
 * acoes. Com `sCardTitle` no titulo, o resto vai para a direita.
 *
 * @example
 * ```html
 * <s-card>
 *   <header sCardHeader>
 *     <h2 sCardTitle>Jornadas pendentes</h2>
 *     <s-badge tone="warning">3</s-badge>
 *   </header>
 *   <div sCardContent>Corpo do conteudo</div>
 *   <footer sCardFooter>Acoes</footer>
 * </s-card>
 * ```
 */
class SCardHeaderDirective {
    papel = papelForaDosMarcos();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCardHeaderDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.34", type: SCardHeaderDirective, isStandalone: true, selector: "[sCardHeader]", host: { properties: { "attr.role": "papel" }, classAttribute: "s-card__header" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCardHeaderDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[sCardHeader]',
                    host: { class: 's-card__header', '[attr.role]': 'papel' },
                }]
        }] });
/**
 * Titulo do card, dentro do `sCardHeader`.
 *
 * Use num titulo de verdade (`<h2>`, `<h3>`…), no nivel que a pagina pede: e o
 * que leva o card para a lista de titulos do leitor de tela. A diretiva tira a
 * margem do navegador e aplica a tipografia de titulo de card, entao o nivel
 * nao muda o tamanho.
 */
class SCardTitleDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCardTitleDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.34", type: SCardTitleDirective, isStandalone: true, selector: "[sCardTitle]", host: { classAttribute: "s-card__title" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCardTitleDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[sCardTitle]',
                    host: { class: 's-card__title' },
                }]
        }] });
/**
 * Corpo do `<s-card>`.
 *
 * Aplica o espacamento da escala do card. Se o card nao usa secoes, o conteudo
 * projetado direto (sem diretiva) continua funcionando como antes.
 */
class SCardContentDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCardContentDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.34", type: SCardContentDirective, isStandalone: true, selector: "[sCardContent]", host: { classAttribute: "s-card__content" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCardContentDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[sCardContent]',
                    host: { class: 's-card__content' },
                }]
        }] });
/**
 * Rodape (acoes) do `<s-card>`.
 *
 * As acoes ficam numa linha, alinhadas a direita, como no modal — a principal
 * por ultimo. Vem sempre por ultimo no card, mesmo que haja conteudo solto.
 */
class SCardFooterDirective {
    papel = papelForaDosMarcos();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCardFooterDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.34", type: SCardFooterDirective, isStandalone: true, selector: "[sCardFooter]", host: { properties: { "attr.role": "papel" }, classAttribute: "s-card__footer" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCardFooterDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[sCardFooter]',
                    host: { class: 's-card__footer', '[attr.role]': 'papel' },
                }]
        }] });

const PADDINGS = [0, 12, 16, 24, 32];
const ELEVACOES = [0, 1, 2, 3];
/**
 * Transform de input para lista fechada: aceita numero ou texto, e um valor
 * fora da lista cai no padrao com aviso em desenvolvimento — o card continua
 * desenhando, e quem escreveu `padding="20"` fica sabendo.
 */
function daEscala(nome, validos, padrao) {
    return (valor) => {
        if (valor === undefined || valor === null || valor === '') {
            return padrao;
        }
        const numero = Number(valor);
        if (validos.includes(numero)) {
            return numero;
        }
        if (typeof ngDevMode !== 'undefined' && ngDevMode) {
            console.warn(`[siage-ui] ${nome} do s-card fora da escala: ${String(valor)}. ` +
                `Use ${validos.join(', ')}.`);
        }
        return padrao;
    };
}
/**
 * Superficie de conteudo: fundo, borda e raio de container. No tema escuro a
 * sombra some e a hierarquia fica com a borda (ja resolvido nos tokens).
 *
 * Com `sCardHeader`, `sCardContent` ou `sCardFooter`, o espacamento passa a ser
 * das secoes. `sCardTitle` marca o titulo do cabecalho.
 *
 * ```html
 * <s-card>
 *   <header sCardHeader><h2 sCardTitle>Jornadas</h2></header>
 *   <div sCardContent>Corpo</div>
 *   <footer sCardFooter><s-button>Salvar</s-button></footer>
 * </s-card>
 * ```
 */
class SCardComponent {
    /**
     * Espacamento interno, em passos da escala de 4px. Sem valor, e 16 — ou 0
     * quando o card usa secoes, que trazem o proprio espacamento.
     */
    padding = input(undefined, ...(ngDevMode ? [{ debugName: "padding", transform: daEscala('padding', PADDINGS, undefined) }] : [{
            transform: daEscala('padding', PADDINGS, undefined),
        }]));
    /** Nivel de sombra. `0` deixa o card sem elevacao, apoiado apenas na borda. */
    elevation = input(1, ...(ngDevMode ? [{ debugName: "elevation", transform: daEscala('elevation', ELEVACOES, 1) }] : [{
            transform: daEscala('elevation', ELEVACOES, 1),
        }]));
    cabecalhos = contentChildren(SCardHeaderDirective, ...(ngDevMode ? [{ debugName: "cabecalhos" }] : []));
    conteudos = contentChildren(SCardContentDirective, ...(ngDevMode ? [{ debugName: "conteudos" }] : []));
    rodapes = contentChildren(SCardFooterDirective, ...(ngDevMode ? [{ debugName: "rodapes" }] : []));
    temSecoes = computed(() => this.cabecalhos().length + this.conteudos().length + this.rodapes().length > 0, ...(ngDevMode ? [{ debugName: "temSecoes" }] : []));
    paddingValue = computed(() => {
        const padding = this.padding() ?? (this.temSecoes() ? 0 : 16);
        return padding === 0 ? '0' : `var(--space-${padding})`;
    }, ...(ngDevMode ? [{ debugName: "paddingValue" }] : []));
    shadow = computed(() => {
        const elevation = this.elevation();
        return elevation === 0 ? 'none' : `var(--elevation-${elevation})`;
    }, ...(ngDevMode ? [{ debugName: "shadow" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "20.3.34", type: SCardComponent, isStandalone: true, selector: "s-card", inputs: { padding: { classPropertyName: "padding", publicName: "padding", isSignal: true, isRequired: false, transformFunction: null }, elevation: { classPropertyName: "elevation", publicName: "elevation", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "style.padding": "paddingValue()", "style.box-shadow": "shadow()" }, classAttribute: "s-card" }, queries: [{ propertyName: "cabecalhos", predicate: SCardHeaderDirective, isSignal: true }, { propertyName: "conteudos", predicate: SCardContentDirective, isSignal: true }, { propertyName: "rodapes", predicate: SCardFooterDirective, isSignal: true }], ngImport: i0, template: `
    <ng-content select="[sCardHeader]" />
    <ng-content select="[sCardContent]" />
    <ng-content />
    <ng-content select="[sCardFooter]" />
  `, isInline: true, styles: [":host{display:block;background:var(--card);border:1px solid var(--card-border);border-radius:var(--radius-container, 12px);color:var(--text-primary)}:host ::ng-deep .s-card__header,:host ::ng-deep .s-card__content,:host ::ng-deep .s-card__footer{padding:var(--space-16, 16px)}:host ::ng-deep .s-card__header+.s-card__content,:host ::ng-deep .s-card__header+.s-card__footer,:host ::ng-deep .s-card__content+.s-card__content,:host ::ng-deep .s-card__content+.s-card__footer{padding-top:0}:host ::ng-deep .s-card__header{display:flex;flex-wrap:wrap;align-items:center;gap:var(--space-8, 8px);font-weight:var(--weight-semibold, 600)}:host ::ng-deep .s-card__title{flex:1 1 auto;min-width:0;margin:0;font-family:var(--font-display);font-size:var(--text-h6, 16px);font-weight:var(--weight-semibold, 600);line-height:var(--leading-tight, 1.2);color:var(--text-primary)}:host ::ng-deep .s-card__content{display:block}:host ::ng-deep .s-card__footer{display:flex;flex-wrap:wrap;align-items:center;justify-content:flex-end;gap:var(--space-8, 8px)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-card', template: `
    <ng-content select="[sCardHeader]" />
    <ng-content select="[sCardContent]" />
    <ng-content />
    <ng-content select="[sCardFooter]" />
  `, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-card',
                        '[style.padding]': 'paddingValue()',
                        '[style.box-shadow]': 'shadow()',
                    }, styles: [":host{display:block;background:var(--card);border:1px solid var(--card-border);border-radius:var(--radius-container, 12px);color:var(--text-primary)}:host ::ng-deep .s-card__header,:host ::ng-deep .s-card__content,:host ::ng-deep .s-card__footer{padding:var(--space-16, 16px)}:host ::ng-deep .s-card__header+.s-card__content,:host ::ng-deep .s-card__header+.s-card__footer,:host ::ng-deep .s-card__content+.s-card__content,:host ::ng-deep .s-card__content+.s-card__footer{padding-top:0}:host ::ng-deep .s-card__header{display:flex;flex-wrap:wrap;align-items:center;gap:var(--space-8, 8px);font-weight:var(--weight-semibold, 600)}:host ::ng-deep .s-card__title{flex:1 1 auto;min-width:0;margin:0;font-family:var(--font-display);font-size:var(--text-h6, 16px);font-weight:var(--weight-semibold, 600);line-height:var(--leading-tight, 1.2);color:var(--text-primary)}:host ::ng-deep .s-card__content{display:block}:host ::ng-deep .s-card__footer{display:flex;flex-wrap:wrap;align-items:center;justify-content:flex-end;gap:var(--space-8, 8px)}\n"] }]
        }], propDecorators: { padding: [{ type: i0.Input, args: [{ isSignal: true, alias: "padding", required: false }] }], elevation: [{ type: i0.Input, args: [{ isSignal: true, alias: "elevation", required: false }] }], cabecalhos: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => SCardHeaderDirective), { isSignal: true }] }], conteudos: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => SCardContentDirective), { isSignal: true }] }], rodapes: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => SCardFooterDirective), { isSignal: true }] }] } });

/**
 * Rotulo curto de estado — "Ativo", "Pendente". Nao e clicavel.
 *
 * Nao usa o `mat-badge`, que e um contador sobreposto a outro elemento.
 */
class SBadgeComponent {
    /** Tom do badge. Ver `SBadgeTone`. */
    tone = input('default', ...(ngDevMode ? [{ debugName: "tone" }] : []));
    /**
     * Permite que o rotulo quebre em varias linhas em area estreita. Padrao
     * `false`: uma linha so, 24px de altura. Ligado, os 24px viram altura minima
     * e o badge cresce com o texto.
     */
    wrap = input(false, ...(ngDevMode ? [{ debugName: "wrap", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Glifo a esquerda, sempre em 16px: com a altura de 24px (ou minima, em
     * `wrap`), glifo maior desalinharia o texto. Obrigatorio em `warning` e
     * `destructive`: avisa no console sem ele.
     */
    icon = input('', ...(ngDevMode ? [{ debugName: "icon" }] : []));
    constructor() {
        effect(() => {
            const tom = this.tone();
            const icone = this.icon();
            if (typeof ngDevMode !== 'undefined' &&
                ngDevMode &&
                !icone &&
                (tom === 'warning' || tom === 'destructive')) {
                console.warn(`[SBadgeComponent] Badges de tom "${tom}" devem ter um ícone — atenção não deve depender só de cor.`);
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SBadgeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SBadgeComponent, isStandalone: true, selector: "s-badge", inputs: { tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, wrap: { classPropertyName: "wrap", publicName: "wrap", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "\"s-badge--\" + tone()", "class.s-badge--wrap": "wrap()" }, classAttribute: "s-badge" }, ngImport: i0, template: `
    @if (icon()) {
      <s-icon [name]="icon()" size="xs" />
    }
    <ng-content />
  `, isInline: true, styles: [":host{display:inline-flex;align-items:center;gap:var(--space-4, 4px);height:var(--badge-h, 24px);padding:0 var(--badge-px, 8px);border:1px solid transparent;border-radius:var(--radius-control, 8px);font-family:var(--font-ui);font-size:var(--text-badge, 12px);font-weight:var(--weight-medium, 500);line-height:1;white-space:nowrap;vertical-align:middle}:host(.s-badge--wrap){max-width:100%;height:auto;min-height:var(--badge-h, 24px);padding-block:var(--space-4, 4px);box-sizing:border-box;line-height:var(--leading-tight, 1.2);white-space:normal}:host(.s-badge--default){background:color-mix(in srgb,var(--primary) calc(var(--tint-container, .12) * 100%),transparent);color:var(--primary-on-surface)}:host(.s-badge--success){background:color-mix(in srgb,var(--success) calc(var(--tint-container, .12) * 100%),transparent);color:var(--success-on-surface)}:host(.s-badge--warning){background:color-mix(in srgb,var(--warning) calc(var(--tint-container, .12) * 100%),transparent);color:var(--warning-on-surface)}:host(.s-badge--destructive){background:color-mix(in srgb,var(--destructive) calc(var(--tint-container, .12) * 100%),transparent);color:var(--destructive-on-surface)}:host(.s-badge--info){background:color-mix(in srgb,var(--info) calc(var(--tint-container, .12) * 100%),transparent);color:var(--info-on-surface)}:host(.s-badge--secondary){background:var(--secondary);color:var(--text-primary)}:host(.s-badge--outline){background:transparent;border-color:var(--border);color:var(--text-secondary)}\n"], dependencies: [{ kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SBadgeComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-badge', imports: [SIconComponent], template: `
    @if (icon()) {
      <s-icon [name]="icon()" size="xs" />
    }
    <ng-content />
  `, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-badge',
                        // Sem `role="status"`: o badge e um rotulo estatico, nao um aviso. Como
                        // regiao viva, cada badge de uma tabela de 50 linhas era anunciado a cada
                        // troca de pagina.
                        '[class]': '"s-badge--" + tone()',
                        '[class.s-badge--wrap]': 'wrap()',
                    }, styles: [":host{display:inline-flex;align-items:center;gap:var(--space-4, 4px);height:var(--badge-h, 24px);padding:0 var(--badge-px, 8px);border:1px solid transparent;border-radius:var(--radius-control, 8px);font-family:var(--font-ui);font-size:var(--text-badge, 12px);font-weight:var(--weight-medium, 500);line-height:1;white-space:nowrap;vertical-align:middle}:host(.s-badge--wrap){max-width:100%;height:auto;min-height:var(--badge-h, 24px);padding-block:var(--space-4, 4px);box-sizing:border-box;line-height:var(--leading-tight, 1.2);white-space:normal}:host(.s-badge--default){background:color-mix(in srgb,var(--primary) calc(var(--tint-container, .12) * 100%),transparent);color:var(--primary-on-surface)}:host(.s-badge--success){background:color-mix(in srgb,var(--success) calc(var(--tint-container, .12) * 100%),transparent);color:var(--success-on-surface)}:host(.s-badge--warning){background:color-mix(in srgb,var(--warning) calc(var(--tint-container, .12) * 100%),transparent);color:var(--warning-on-surface)}:host(.s-badge--destructive){background:color-mix(in srgb,var(--destructive) calc(var(--tint-container, .12) * 100%),transparent);color:var(--destructive-on-surface)}:host(.s-badge--info){background:color-mix(in srgb,var(--info) calc(var(--tint-container, .12) * 100%),transparent);color:var(--info-on-surface)}:host(.s-badge--secondary){background:var(--secondary);color:var(--text-primary)}:host(.s-badge--outline){background:transparent;border-color:var(--border);color:var(--text-secondary)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { tone: [{ type: i0.Input, args: [{ isSignal: true, alias: "tone", required: false }] }], wrap: [{ type: i0.Input, args: [{ isSignal: true, alias: "wrap", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }] } });

let sequencia = 0;
/** Gera um id unico e estavel para ligar rotulo, controle e mensagem de erro. */
function proximoId(prefixo) {
    sequencia += 1;
    return `${prefixo}-${sequencia}`;
}
/**
 * Base dos controles de formulario da biblioteca.
 *
 * Reune o que todo controle repete: o valor, os dois estados de desabilitado
 * (o input do template e o do Reactive Forms) e os callbacks do
 * `ControlValueAccessor`.
 *
 * Nao tem relacao com o Angular Material — a regra de encapsular o Material por
 * composicao continua valendo; isto e apenas o denominador comum dos nossos
 * proprios controles, para que `s-input`, `s-select` e os demais se comportem
 * igual diante de um formulario.
 */
class SControlBase {
    /**
     * Nome acessivel do controle quando ele esta **fora** de um `<s-field>` -
     * um filtro solto numa barra de ferramentas, por exemplo. Vira
     * `aria-label`. Dentro de um campo, o rotulo do campo prevalece.
     */
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
    /** Texto de exemplo. Nunca substitui o rotulo. */
    placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : []));
    /** Exibe o valor sem permitir edicao. Fundo neutro, sem moldura. Nao e `disabled`. */
    readOnly = input(false, ...(ngDevMode ? [{ debugName: "readOnly", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Marca o campo como invalido mesmo sem `<s-field error>`. */
    invalid = input(false, ...(ngDevMode ? [{ debugName: "invalid", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Erros processados de validacao, por nome de campo.
     *
     * @deprecated Sem efeito: nenhum controle le este input. A mensagem de erro e
     * do `<s-field>` (`error`, ou as mensagens do proprio controle do
     * formulario). Sai na proxima major.
     */
    errors = input({}, ...(ngDevMode ? [{ debugName: "errors" }] : []));
    /**
     * Desabilita o controle. Tambem pode vir do Reactive Forms.
     *
     * `booleanAttribute`, como nos demais booleanos: `disabled="false"` e falso.
     */
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    value = signal(null, ...(ngDevMode ? [{ debugName: "value" }] : []));
    disabledByForm = signal(false, ...(ngDevMode ? [{ debugName: "disabledByForm" }] : []));
    /** `true` quando desabilitado pelo template ou pelo formulario. */
    isDisabled = computed(() => this.disabled() || this.disabledByForm(), ...(ngDevMode ? [{ debugName: "isDisabled" }] : []));
    onChange = () => { };
    onTouched = () => { };
    /** Grava o valor e avisa o formulario. Use sempre que o usuario alterar algo. */
    setValue(valor) {
        this.value.set(valor);
        this.onChange(valor);
    }
    /**
     * Somente-leitura num controle que nao tem esse estado nativo - checkbox e
     * switch: o clique (mouse, ou Espaco, que tambem gera `click`) nao muda o
     * valor. O controle continua focavel e anunciado, com `aria-readonly`.
     */
    barrarSeSomenteLeitura(evento) {
        if (this.readOnly()) {
            evento.preventDefault();
        }
    }
    /**
     * Marca como tocado quando o foco **sai** de um grupo de opcoes.
     *
     * Para controles feitos de varios elementos focaveis (radios, botoes de
     * selecao). `(blur)` no elemento do grupo nao serve: o grupo nunca recebe o
     * foco - quem recebe sao as opcoes - e `blur` nao borbulha. `focusout`
     * borbulha, mas dispara tambem ao passar de uma opcao para a outra; por isso
     * a conferencia de para onde o foco foi.
     */
    onGroupFocusOut(evento) {
        const grupo = evento.currentTarget;
        const destino = evento.relatedTarget;
        if (!destino || !grupo.contains(destino)) {
            this.onTouched();
        }
    }
    writeValue(valor) {
        this.value.set(valor ?? null);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabledByForm.set(isDisabled);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SControlBase, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "20.3.34", type: SControlBase, isStandalone: true, inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, readOnly: { classPropertyName: "readOnly", publicName: "readOnly", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, errors: { classPropertyName: "errors", publicName: "errors", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SControlBase, decorators: [{
            type: Directive
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], readOnly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readOnly", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], errors: [{ type: i0.Input, args: [{ isSignal: true, alias: "errors", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }] } });
/**
 * Contrato que o `<s-field>` oferece aos controles projetados dentro dele.
 *
 * O campo e quem gera os ids; o controle apenas os consome. E assim que o
 * rotulo aponta para o controle certo e que a mensagem de erro chega ao leitor
 * de tela sem a aplicacao amarrar nada a mao.
 */
class SFieldContext {
}
/**
 * Liga um controle ao `<s-field>` que o envolve, quando existe um.
 *
 * Fora de um campo, o controle gera o proprio id e segue funcionando — e o caso
 * de um filtro solto numa barra de ferramentas.
 */
function usarCampo(prefixo) {
    const campo = inject(SFieldContext, { optional: true });
    const idProprio = proximoId(prefixo);
    return {
        campo,
        /**
         * `aria-label` do controle: o `label` do proprio controle, so quando nao ha
         * `<s-field>` em volta - dentro de um, quem nomeia e o rotulo do campo.
         */
        rotuloAvulso: (label) => computed(() => (campo ? null : label() || null)),
        id: computed(() => campo?.controlId() ?? idProprio),
        describedBy: computed(() => campo?.errorId() ?? null),
        invalido: computed(() => campo?.hasError() ?? false),
        obrigatorio: computed(() => campo?.isRequired() ?? false),
        rotuladoPor: computed(() => campo?.labelId() ?? null),
    };
}

/**
 * Envelope de qualquer controle de formulario.
 *
 * Reune o que o guia exige em volta de um campo: rotulo sempre visivel,
 * asterisco de obrigatoriedade, icone de ajuda e faixa de erro.
 *
 * A faixa de erro **existe mesmo quando vazia**. E o detalhe que faz a validacao
 * nao mudar a altura do formulario: sem ela, a tela inteira salta quando a
 * primeira mensagem aparece.
 *
 * O campo tambem cuida da amarracao acessivel. Ele gera o id, o rotulo aponta
 * para ele com `for`, e o controle projetado dentro o consome — junto com
 * `aria-invalid` e `aria-describedby` — sem a aplicacao ligar nada a mao.
 * A ajuda entra nessa descricao do controle, porque ela explica o criterio do
 * preenchimento sem virar parte do nome do campo.
 *
 * Prefixo e icone ficam no controle que desenha a superficie. O `<s-field>` nao
 * injeta conteudo dentro da moldura para nao quebrar textarea, select e outros
 * formatos; para busca e campos de linha unica, use `s-input icon="search"`.
 *
 * @example
 * ```html
 * <s-field label="Nome da Jornada de Trabalho" required [error]="erro()">
 *   <s-input placeholder="Buscar por nome" formControlName="nome" />
 * </s-field>
 * ```
 */
class SFieldComponent {
    /** Rotulo do campo. Sempre visivel, alinhado a esquerda, com altura minima fixa. */
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
    /** Marca o campo como obrigatorio. Opcional nao recebe marcacao nenhuma. */
    required = input(false, ...(ngDevMode ? [{ debugName: "required", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Texto do icone "i" de 16px — apoio nao essencial, uma a duas linhas. */
    help = input('', ...(ngDevMode ? [{ debugName: "help" }] : []));
    /**
     * Exibe o contador `n/max` quando o controle tem limite de caracteres.
     *
     * O limite vem primeiro deste input, para os casos em que o controle esta fora
     * do conteudo projetado, e depois do `maxlength` do `input`/`textarea` nativo
     * dentro do campo. Assim o contador acompanha `formControlName`,
     * `[formControl]`, `[(ngModel)]` e tambem o uso avulso sem formulario.
     */
    showCharCounter = input(false, ...(ngDevMode ? [{ debugName: "showCharCounter", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Limite usado pelo contador quando nao ha como ler o `maxlength` do controle.
     *
     * Prefira manter o mesmo valor no controle (`<s-input maxlength="120">` ou
     * `<s-textarea maxlength="120">`), porque e o nativo que bloqueia a digitacao;
     * este input existe para composicoes em que o campo recebe o `control` por fora.
     */
    maxlength = input(null, ...(ngDevMode ? [{ debugName: "maxlength", transform: (value) => {
                if (value === null || value === undefined || value === '') {
                    return null;
                }
                return numberAttribute(value);
            } }] : [{
            transform: (value) => {
                if (value === null || value === undefined || value === '') {
                    return null;
                }
                return numberAttribute(value);
            },
        }]));
    /**
     * Erro escrito pela tela. Vence a mensagem automatica.
     *
     * Aceita tres formas, e a escolha depende do que a tela ja tem em maos:
     *
     * - **texto** — `error="Informe a matrícula."`, para uma mensagem so;
     * - **lista** — `[error]="['Informe a matrícula.', 'Use 7 dígitos.']"`, para
     *   varias, uma por linha;
     * - **`ValidationErrors`** — `[error]="form.controls.nome.errors"`, e cada
     *   erro vira a frase mapeada em `provideSiageValidationMessages()`. E o
     *   caminho para quem ja calcula os erros fora do campo.
     *
     * A faixa continua reservada quando esta vazia — o formulario nao salta
     * quando a validacao dispara.
     */
    error = input('', ...(ngDevMode ? [{ debugName: "error" }] : []));
    /**
     * Mensagens ja calculadas pela tela para o formulario inteiro, por nome de
     * campo — o `validatorErrors` do `FormBaseComponent`. O campo mostra a do
     * seu nome (`name`, ou o do `formControlName` projetado), uma linha por
     * `<br />`.
     *
     * Informado, a tela decide quando a mensagem aparece: a automatica fica
     * desligada, para nao acusar o erro antes da tela pedir.
     */
    validationErrors = input(undefined, ...(ngDevMode ? [{ debugName: "validationErrors" }] : []));
    /** Chave deste campo em `validationErrors`. Sem ela, vale o nome do controle projetado. */
    name = input('', ...(ngDevMode ? [{ debugName: "name" }] : []));
    /**
     * Controle de formulario deste campo.
     *
     * So e preciso informar quando o controle nao esta projetado aqui dentro —
     * um `<s-input formControlName="...">` se registra sozinho.
     */
    control = input(null, ...(ngDevMode ? [{ debugName: "control" }] : []));
    /**
     * Quando a mensagem automatica aparece.
     *
     * O padrao e `touched`, que e o momento em que o guia manda validar: acusar
     * "campo obrigatorio" antes de a pessoa chegar no campo e cobrar por algo
     * que ela ainda ia fazer.
     */
    showErrorsWhen = input('touched', ...(ngDevMode ? [{ debugName: "showErrorsWhen" }] : []));
    /** Id do controle. Informe apenas para reaproveitar um id que ja existe. */
    controlIdInput = input('', ...(ngDevMode ? [{ debugName: "controlIdInput", alias: 'controlId' }] : [{ alias: 'controlId' }]));
    idGerado = proximoId('s-field');
    element = inject(ElementRef);
    mensagens_ = inject(S_VALIDATION_MESSAGES);
    /**
     * O controle de formulario do campo projetado aqui dentro.
     *
     * A consulta de conteudo acha a diretiva `NgControl` — `formControlName`,
     * `formControl` ou `ngModel` — sem que o controle precise se registrar. O
     * caminho inverso (o controle pedir `NgControl` por injecao) fecharia um
     * ciclo, porque ele mesmo fornece o `NG_VALUE_ACCESSOR`.
     */
    ngControl = contentChild(NgControl, ...(ngDevMode ? [{ debugName: "ngControl" }] : []));
    /** Muda a cada evento do controle, para as mensagens recalcularem. */
    versao = signal(0, ...(ngDevMode ? [{ debugName: "versao" }] : []));
    detectedMaxlength = signal(null, ...(ngDevMode ? [{ debugName: "detectedMaxlength" }] : []));
    controle = computed(() => this.control() ?? this.ngControl()?.control ?? null, ...(ngDevMode ? [{ debugName: "controle" }] : []));
    constructor() {
        afterRenderEffect(() => this.updateDetectedMaxlength());
        effect((onCleanup) => {
            const controle = this.controle();
            if (!controle) {
                return;
            }
            // `events` cobre estado, valor e o toque — o `statusChanges` sozinho nao
            // avisa quando o campo e apenas tocado, que e o gatilho padrao daqui.
            const inscricao = controle.events.subscribe(() => this.versao.update((v) => v + 1));
            onCleanup(() => inscricao.unsubscribe());
        });
    }
    onProjectedInput() {
        this.versao.update((v) => v + 1);
        this.updateDetectedMaxlength();
    }
    /** As mensagens que vem dos validadores do proprio controle. */
    errosAutomaticos = computed(() => {
        this.versao();
        const controle = this.controle();
        if (!controle || controle.valid || controle.disabled || this.validationErrors() !== undefined) {
            return [];
        }
        const quando = this.showErrorsWhen();
        const podeMostrar = quando === 'always' ||
            (quando === 'touched' && controle.touched) ||
            (quando === 'dirty' && controle.dirty);
        if (!podeMostrar) {
            return [];
        }
        if (this.showAllErrors()) {
            return todasAsMensagens(controle.errors, controle, this.mensagens_);
        }
        const primeira = primeiraMensagem(controle.errors, controle, this.mensagens_);
        return primeira ? [primeira] : [];
    }, ...(ngDevMode ? [{ debugName: "errosAutomaticos" }] : []));
    /**
     * Quando a mensagem automatica mostra todos os erros do controle.
     *
     * O padrao e so o primeiro, que e o que o guia pede: uma frase por vez, a que
     * a pessoa precisa resolver agora. Ligue quando o campo tiver validadores
     * independentes — formato **e** intervalo —, e corrigir um de cada vez
     * significaria enviar o formulario tres vezes para descobrir os tres.
     */
    showAllErrors = input(false, ...(ngDevMode ? [{ debugName: "showAllErrors", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** A mensagem deste campo em `validationErrors`, quebrada nas linhas. */
    mensagensDoMapa = computed(() => {
        const mapa = this.validationErrors();
        const chave = this.name() || String(this.ngControl()?.name ?? '');
        if (!mapa || !chave) {
            return [];
        }
        return (mapa[chave] ?? '')
            .split(/<br\s*\/?>/i)
            .map((linha) => linha.trim())
            .filter(Boolean);
    }, ...(ngDevMode ? [{ debugName: "mensagensDoMapa" }] : []));
    /** As linhas da faixa. A da tela vence a automatica. */
    mensagens = computed(() => {
        const daTela = this.mensagensDaTela();
        if (daTela.length) {
            return daTela;
        }
        const doMapa = this.mensagensDoMapa();
        return doMapa.length ? doMapa : this.errosAutomaticos();
    }, ...(ngDevMode ? [{ debugName: "mensagens" }] : []));
    /** A primeira linha. Existe para o contrato do campo e para os testes. */
    mensagem = computed(() => this.mensagens()[0] ?? '', ...(ngDevMode ? [{ debugName: "mensagem" }] : []));
    /** Normaliza as tres formas aceitas pelo input `error` em uma lista. */
    mensagensDaTela = computed(() => {
        const valor = this.error();
        if (!valor) {
            return [];
        }
        if (typeof valor === 'string') {
            return [valor];
        }
        if (Array.isArray(valor)) {
            return valor.filter((linha) => typeof linha === 'string' && linha !== '');
        }
        // Sobrou `ValidationErrors`: o mesmo mapeamento que a mensagem automatica
        // usa, para a frase ser a mesma venha ela do campo ou da tela.
        return todasAsMensagens(valor, this.controle(), this.mensagens_);
    }, ...(ngDevMode ? [{ debugName: "mensagensDaTela" }] : []));
    controlId = computed(() => this.controlIdInput() || this.idGerado, ...(ngDevMode ? [{ debugName: "controlId" }] : []));
    hasError = computed(() => this.mensagens().length > 0, ...(ngDevMode ? [{ debugName: "hasError" }] : []));
    isRequired = computed(() => this.required(), ...(ngDevMode ? [{ debugName: "isRequired" }] : []));
    errorMessageId = computed(() => (this.hasError() ? `${this.controlId()}-erro` : null), ...(ngDevMode ? [{ debugName: "errorMessageId" }] : []));
    helpId = computed(() => this.label() && this.help() ? `${this.controlId()}-ajuda` : null, ...(ngDevMode ? [{ debugName: "helpId" }] : []));
    errorId = computed(() => {
        const ids = [this.helpId(), this.errorMessageId()].filter((id) => !!id);
        return ids.length ? ids.join(' ') : null;
    }, ...(ngDevMode ? [{ debugName: "errorId" }] : []));
    labelId = computed(() => (this.label() ? `${this.controlId()}-rotulo` : null), ...(ngDevMode ? [{ debugName: "labelId" }] : []));
    counterLimit = computed(() => {
        return this.maxlength() ?? this.detectedMaxlength();
    }, ...(ngDevMode ? [{ debugName: "counterLimit" }] : []));
    currentLength = computed(() => {
        this.versao();
        const control = this.controle();
        const value = control ? control.value : this.nativeControl()?.value;
        return typeof value === 'string' ? value.length : String(value ?? '').length;
    }, ...(ngDevMode ? [{ debugName: "currentLength" }] : []));
    showCounter = computed(() => {
        const limit = this.counterLimit();
        return this.showCharCounter() && limit !== null && limit > 0;
    }, ...(ngDevMode ? [{ debugName: "showCounter" }] : []));
    counterText = computed(() => {
        const limit = this.counterLimit();
        return limit ? `${this.currentLength()}/${limit}` : '';
    }, ...(ngDevMode ? [{ debugName: "counterText" }] : []));
    counterAriaLive = computed(() => {
        const limit = this.counterLimit();
        if (!this.showCounter() || !limit) {
            return null;
        }
        return this.currentLength() / limit >= 0.9 ? 'polite' : null;
    }, ...(ngDevMode ? [{ debugName: "counterAriaLive" }] : []));
    updateDetectedMaxlength() {
        const attribute = this.nativeControl()?.getAttribute('maxlength');
        const next = attribute ? Number(attribute) : null;
        const normalized = next !== null && Number.isFinite(next) ? next : null;
        if (this.detectedMaxlength() !== normalized) {
            this.detectedMaxlength.set(normalized);
        }
    }
    nativeControl() {
        return this.element.nativeElement.querySelector('input, textarea');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SFieldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SFieldComponent, isStandalone: true, selector: "s-field", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, help: { classPropertyName: "help", publicName: "help", isSignal: true, isRequired: false, transformFunction: null }, showCharCounter: { classPropertyName: "showCharCounter", publicName: "showCharCounter", isSignal: true, isRequired: false, transformFunction: null }, maxlength: { classPropertyName: "maxlength", publicName: "maxlength", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, validationErrors: { classPropertyName: "validationErrors", publicName: "validationErrors", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: false, transformFunction: null }, showErrorsWhen: { classPropertyName: "showErrorsWhen", publicName: "showErrorsWhen", isSignal: true, isRequired: false, transformFunction: null }, controlIdInput: { classPropertyName: "controlIdInput", publicName: "controlId", isSignal: true, isRequired: false, transformFunction: null }, showAllErrors: { classPropertyName: "showAllErrors", publicName: "showAllErrors", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "input": "onProjectedInput()" }, classAttribute: "s-field" }, providers: [{ provide: SFieldContext, useExisting: SFieldComponent }], queries: [{ propertyName: "ngControl", first: true, predicate: NgControl, descendants: true, isSignal: true }], ngImport: i0, template: "@if (label()) {\n  <div class=\"s-field__cabecalho\">\n    <label class=\"s-field__label\" [attr.id]=\"labelId()\" [attr.for]=\"controlId()\">\n      {{ label() }}\n\n      @if (required()) {\n        <!-- A obrigatoriedade chega ao leitor de tela pelo `aria-required` do\n             controle; aqui o asterisco e apenas a pista visual. -->\n        <span class=\"s-field__required\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n\n    @if (help()) {\n      <!-- Fora do <label>: dentro dele, \"Ajuda sobre...\" entrava no nome do\n           controle, e clicar no icone focava o campo. E um botao para a dica\n           abrir tambem pelo teclado - o tooltip aparece no foco. -->\n      <button\n        type=\"button\"\n        class=\"s-field__help\"\n        [attr.aria-label]=\"'Ajuda sobre ' + label()\"\n        [sTooltip]=\"help()\"\n      >\n        <s-icon name=\"info\" size=\"xs\" />\n      </button>\n      <span class=\"s-field__help-description\" [attr.id]=\"helpId()\">{{ help() }}</span>\n    }\n  </div>\n}\n\n<ng-content />\n\n<!-- A faixa e sempre renderizada: sem ela, o formulario mudaria de altura na\n     primeira mensagem de erro. -->\n<span class=\"s-field__support\">\n  <span\n    class=\"s-field__error\"\n    [attr.id]=\"errorMessageId()\"\n    [attr.role]=\"hasError() ? 'alert' : null\"\n  >\n    @if (hasError()) {\n      <s-icon name=\"error\" size=\"xs\" />\n      <span class=\"s-field__error-texto\">\n        @for (linha of mensagens(); track linha) {\n          <span class=\"s-field__error-linha\">{{ linha }}</span>\n        }\n      </span>\n    }\n  </span>\n\n  @if (showCounter()) {\n    <span class=\"s-field__counter\" [attr.aria-live]=\"counterAriaLive()\">\n      {{ counterText() }}\n    </span>\n  }\n</span>\n", styles: [":host{display:flex;flex-direction:column;gap:var(--space-4, 4px);width:100%}.s-field__label{min-height:20px;display:flex;align-items:center;gap:var(--space-4, 4px);font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);color:var(--text-primary)}.s-field__required{color:var(--destructive-on-surface)}.s-field__cabecalho{display:flex;align-items:center;gap:var(--space-4, 4px)}.s-field__help{display:inline-flex;padding:0;border:0;border-radius:var(--radius-full, 999px);background:none;color:var(--text-secondary);cursor:help}.s-field__help:focus-visible{outline:none;box-shadow:0 0 0 2px var(--focus-ring)}.s-field__help-description{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}.s-field__support{min-height:18px;display:flex;align-items:flex-start;gap:var(--space-8, 8px)}.s-field__error{display:flex;flex:1;align-items:flex-start;gap:var(--space-4, 4px);font-size:var(--text-caption, 12px);line-height:1.4;color:var(--destructive-on-surface)}.s-field__error-texto{display:flex;flex-direction:column;gap:2px;min-width:0;overflow-wrap:anywhere}.s-field__counter{margin-left:auto;white-space:nowrap;font-size:var(--text-caption, 12px);line-height:1.4;color:var(--text-secondary)}\n"], dependencies: [{ kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }, { kind: "directive", type: STooltipDirective, selector: "[sTooltip]", inputs: ["sTooltip", "sTooltipPosition", "sTooltipDisabled", "sTooltipDelay"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-field', imports: [SIconComponent, STooltipDirective], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-field',
                        '(input)': 'onProjectedInput()',
                    }, providers: [{ provide: SFieldContext, useExisting: SFieldComponent }], template: "@if (label()) {\n  <div class=\"s-field__cabecalho\">\n    <label class=\"s-field__label\" [attr.id]=\"labelId()\" [attr.for]=\"controlId()\">\n      {{ label() }}\n\n      @if (required()) {\n        <!-- A obrigatoriedade chega ao leitor de tela pelo `aria-required` do\n             controle; aqui o asterisco e apenas a pista visual. -->\n        <span class=\"s-field__required\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n\n    @if (help()) {\n      <!-- Fora do <label>: dentro dele, \"Ajuda sobre...\" entrava no nome do\n           controle, e clicar no icone focava o campo. E um botao para a dica\n           abrir tambem pelo teclado - o tooltip aparece no foco. -->\n      <button\n        type=\"button\"\n        class=\"s-field__help\"\n        [attr.aria-label]=\"'Ajuda sobre ' + label()\"\n        [sTooltip]=\"help()\"\n      >\n        <s-icon name=\"info\" size=\"xs\" />\n      </button>\n      <span class=\"s-field__help-description\" [attr.id]=\"helpId()\">{{ help() }}</span>\n    }\n  </div>\n}\n\n<ng-content />\n\n<!-- A faixa e sempre renderizada: sem ela, o formulario mudaria de altura na\n     primeira mensagem de erro. -->\n<span class=\"s-field__support\">\n  <span\n    class=\"s-field__error\"\n    [attr.id]=\"errorMessageId()\"\n    [attr.role]=\"hasError() ? 'alert' : null\"\n  >\n    @if (hasError()) {\n      <s-icon name=\"error\" size=\"xs\" />\n      <span class=\"s-field__error-texto\">\n        @for (linha of mensagens(); track linha) {\n          <span class=\"s-field__error-linha\">{{ linha }}</span>\n        }\n      </span>\n    }\n  </span>\n\n  @if (showCounter()) {\n    <span class=\"s-field__counter\" [attr.aria-live]=\"counterAriaLive()\">\n      {{ counterText() }}\n    </span>\n  }\n</span>\n", styles: [":host{display:flex;flex-direction:column;gap:var(--space-4, 4px);width:100%}.s-field__label{min-height:20px;display:flex;align-items:center;gap:var(--space-4, 4px);font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);color:var(--text-primary)}.s-field__required{color:var(--destructive-on-surface)}.s-field__cabecalho{display:flex;align-items:center;gap:var(--space-4, 4px)}.s-field__help{display:inline-flex;padding:0;border:0;border-radius:var(--radius-full, 999px);background:none;color:var(--text-secondary);cursor:help}.s-field__help:focus-visible{outline:none;box-shadow:0 0 0 2px var(--focus-ring)}.s-field__help-description{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}.s-field__support{min-height:18px;display:flex;align-items:flex-start;gap:var(--space-8, 8px)}.s-field__error{display:flex;flex:1;align-items:flex-start;gap:var(--space-4, 4px);font-size:var(--text-caption, 12px);line-height:1.4;color:var(--destructive-on-surface)}.s-field__error-texto{display:flex;flex-direction:column;gap:2px;min-width:0;overflow-wrap:anywhere}.s-field__counter{margin-left:auto;white-space:nowrap;font-size:var(--text-caption, 12px);line-height:1.4;color:var(--text-secondary)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], help: [{ type: i0.Input, args: [{ isSignal: true, alias: "help", required: false }] }], showCharCounter: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCharCounter", required: false }] }], maxlength: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxlength", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], validationErrors: [{ type: i0.Input, args: [{ isSignal: true, alias: "validationErrors", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], control: [{ type: i0.Input, args: [{ isSignal: true, alias: "control", required: false }] }], showErrorsWhen: [{ type: i0.Input, args: [{ isSignal: true, alias: "showErrorsWhen", required: false }] }], controlIdInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "controlId", required: false }] }], ngControl: [{ type: i0.ContentChild, args: [i0.forwardRef(() => NgControl), { isSignal: true }] }], showAllErrors: [{ type: i0.Input, args: [{ isSignal: true, alias: "showAllErrors", required: false }] }] } });

/**
 * Escreve o texto no `<input>`/`<textarea>` nativo so quando ele mudou.
 *
 * Com `[value]`, o Angular regrava o campo a cada digitacao com o mesmo texto
 * que o navegador acabou de colocar ali, e o Chrome trata qualquer escrita em
 * `value` como troca de conteudo: o cursor vai para o fim. Apagar um digito no
 * meio jogava o cursor para o final. Comparando antes de escrever, so mudancas
 * vindas de fora (formulario, formatacao no blur) chegam ao DOM.
 *
 * Uso interno da biblioteca; nao faz parte da API publica.
 */
class SNativeValueDirective {
    text = input('', ...(ngDevMode ? [{ debugName: "text", alias: 'sNativeValue' }] : [{ alias: 'sNativeValue' }]));
    constructor() {
        const element = inject(ElementRef).nativeElement;
        effect(() => {
            const text = this.text() ?? '';
            if (element.value !== text) {
                element.value = text;
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SNativeValueDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "20.3.34", type: SNativeValueDirective, isStandalone: true, selector: "input[sNativeValue], textarea[sNativeValue]", inputs: { text: { classPropertyName: "text", publicName: "sNativeValue", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SNativeValueDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[sNativeValue], textarea[sNativeValue]',
                }]
        }], ctorParameters: () => [], propDecorators: { text: [{ type: i0.Input, args: [{ isSignal: true, alias: "sNativeValue", required: false }] }] } });

/**
 * Campo de linha unica da biblioteca `@siage/siage-ui`.
 *
 * Tambem e o campo de busca do sistema: com `icon="search"` ele ganha o glifo de
 * 20px a esquerda que o guia descreve.
 *
 * Nao envolve o `matInput`, que so funciona dentro de um `mat-form-field` — e o
 * `mat-form-field` traz o rotulo flutuante dentro da moldura, que nao e o que o
 * guia define. Aqui o rotulo fica acima, no `<s-field>`, e o controle e um
 * `<input>` nativo com a superficie do design system.
 *
 * `readOnly` **nao** e `disabled`: o guia trata os dois como estados
 * diferentes. Somente-leitura mostra o dado em fundo neutro, sem moldura e sem
 * aparencia de bloqueado; desabilitado indica que a acao esta indisponivel.
 *
 * @example
 * ```html
 * <s-field label="Nome" required>
 *   <s-input icon="search" placeholder="Buscar por nome" formControlName="nome" />
 * </s-field>
 * ```
 */
class SInputComponent extends SControlBase {
    /**
     * Tipo do campo. Ver `SInputType`.
     *
     * Com `type="time"` o campo so aceita horario (`"HH:mm"`); o `placeholder`
     * nao aparece, porque o navegador desenha a propria mascara (`--:--`).
     */
    type = input('text', ...(ngDevMode ? [{ debugName: "type" }] : []));
    /** Glifo de 20px a esquerda, ex. `search`. */
    icon = input('', ...(ngDevMode ? [{ debugName: "icon" }] : []));
    /** Liga o eixo FILL do glifo. No guia so o item ativo da navegacao usa. */
    iconFilled = input(false, ...(ngDevMode ? [{ debugName: "iconFilled", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Limite de caracteres, quando houver. Vazio remove o limite. */
    maxlength = input(null, ...(ngDevMode ? [{ debugName: "maxlength", transform: (value) => {
                if (value === null || value === undefined || value === '') {
                    return null;
                }
                return numberAttribute(value);
            } }] : [{
            transform: (value) => {
                if (value === null || value === undefined || value === '') {
                    return null;
                }
                return numberAttribute(value);
            },
        }]));
    /** Valor de `autocomplete` do navegador. */
    autocomplete = input('off', ...(ngDevMode ? [{ debugName: "autocomplete" }] : []));
    campo = usarCampo('s-input');
    host = inject(ElementRef);
    controlId = this.campo.id;
    ariaLabel = this.campo.rotuloAvulso(this.label);
    describedBy = this.campo.describedBy;
    required = this.campo.obrigatorio;
    /** Invalido pelo input proprio ou pelo `<s-field>` que envolve o controle. */
    isInvalid = computed(() => this.invalid() || this.campo.invalido(), ...(ngDevMode ? [{ debugName: "isInvalid" }] : []));
    texto = computed(() => this.value() ?? '', ...(ngDevMode ? [{ debugName: "texto" }] : []));
    passwordVisible = signal(false, ...(ngDevMode ? [{ debugName: "passwordVisible" }] : []));
    /**
     * Senha sempre tem o botao de mostrar/ocultar, como o `p-password toggleMask`
     * que as telas ja usam; nos outros tipos nao ha o que revelar. Some em
     * `disabled` (e o `readOnly` nem desenha o campo), porque ali ofereceria uma
     * acao que nao existe.
     */
    showReveal = computed(() => this.type() === 'password' && !this.isDisabled(), ...(ngDevMode ? [{ debugName: "showReveal" }] : []));
    nativeType = computed(() => this.type() === 'password' && this.passwordVisible() ? 'text' : this.type(), ...(ngDevMode ? [{ debugName: "nativeType" }] : []));
    revealIcon = computed(() => this.passwordVisible() ? 'visibility_off' : 'visibility', ...(ngDevMode ? [{ debugName: "revealIcon" }] : []));
    revealLabel = computed(() => this.passwordVisible() ? 'Ocultar senha' : 'Mostrar senha', ...(ngDevMode ? [{ debugName: "revealLabel" }] : []));
    constructor() {
        super();
        afterEveryRender({
            write: () => this.updateAriaPressed(),
        });
        effect(() => {
            this.passwordVisible();
            this.showReveal();
            queueMicrotask(() => this.updateAriaPressed());
        });
    }
    onInput(event) {
        this.setValue(event.target.value);
    }
    onBlur() {
        this.onTouched();
    }
    toggleReveal() {
        this.passwordVisible.update((value) => !value);
    }
    updateAriaPressed() {
        this.host.nativeElement
            .querySelector('.s-input__reveal button')
            ?.setAttribute('aria-pressed', this.passwordVisible() ? 'true' : 'false');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SInputComponent, isStandalone: true, selector: "s-input", inputs: { type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, iconFilled: { classPropertyName: "iconFilled", publicName: "iconFilled", isSignal: true, isRequired: false, transformFunction: null }, maxlength: { classPropertyName: "maxlength", publicName: "maxlength", isSignal: true, isRequired: false, transformFunction: null }, autocomplete: { classPropertyName: "autocomplete", publicName: "autocomplete", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "s-input" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SInputComponent),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: "@if (readOnly()) {\n  <!-- Somente-leitura nao e um campo desabilitado: e o dado exibido em fundo\n       neutro. Por isso nem sequer usa <input>. -->\n  <div class=\"s-input__readonly\" [attr.id]=\"controlId()\">{{ texto() }}</div>\n} @else {\n  <div\n    class=\"s-input__campo\"\n    [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.data-disabled]=\"isDisabled() ? 'true' : null\"\n  >\n    @if (icon()) {\n      <s-icon class=\"s-input__icone\" [iconFilled]=\"iconFilled()\" [name]=\"icon()\" size=\"sm\" />\n    }\n\n    <input\n      class=\"s-input__nativo\"\n      [id]=\"controlId()\"\n      [attr.aria-label]=\"ariaLabel()\"\n      [type]=\"nativeType()\"\n      [sNativeValue]=\"texto()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"isDisabled()\"\n      [attr.maxlength]=\"maxlength()\"\n      [attr.autocomplete]=\"autocomplete()\"\n      [attr.aria-required]=\"required() ? 'true' : null\"\n      [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      (input)=\"onInput($event)\"\n      (blur)=\"onBlur()\"\n    />\n\n    @if (showReveal()) {\n      <s-icon-button\n        class=\"s-input__reveal\"\n        size=\"sm\"\n        variant=\"ghost\"\n        [attr.aria-pressed]=\"passwordVisible() ? 'true' : 'false'\"\n        [icon]=\"revealIcon()\"\n        [label]=\"revealLabel()\"\n        (click)=\"toggleReveal()\"\n      />\n    }\n  </div>\n}\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%;--s-field-h: var(--field-h, 48px)}.s-input__campo{box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;display:flex;align-items:center;gap:var(--space-8, 8px)}.s-input__campo:hover:not([data-disabled=true]){border-color:var(--border);background:var(--card)}.s-input__campo:focus-within{border:2px solid var(--primary);background:var(--card);padding:0 15px}.s-input__campo[data-invalid=true]{border-color:var(--destructive)}.s-input__campo[data-disabled=true]{opacity:.4}.s-input__icone{color:var(--text-secondary)}.s-input__reveal{flex:0 0 auto;--s-icon-button-size: var(--control-h-icon, 40px);--s-icon-button-fg: var(--text-secondary)}.s-input__nativo{flex:1;min-width:0;height:var(--s-field-h, var(--field-h, 48px));padding:0;border:none;background:transparent;font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary)}.s-input__nativo::placeholder{color:var(--text-secondary)}.s-input__nativo:focus{outline:none}.s-input__nativo::-webkit-calendar-picker-indicator{cursor:pointer;opacity:.7}.s-input__nativo:disabled{cursor:default;opacity:1}.s-input__readonly{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary)}\n"], dependencies: [{ kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }, { kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }, { kind: "directive", type: SNativeValueDirective, selector: "input[sNativeValue], textarea[sNativeValue]", inputs: ["sNativeValue"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-input', imports: [SIconButtonComponent, SIconComponent, SNativeValueDirective], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SInputComponent),
                            multi: true,
                        },
                    ], host: {
                        class: 's-input',
                    }, template: "@if (readOnly()) {\n  <!-- Somente-leitura nao e um campo desabilitado: e o dado exibido em fundo\n       neutro. Por isso nem sequer usa <input>. -->\n  <div class=\"s-input__readonly\" [attr.id]=\"controlId()\">{{ texto() }}</div>\n} @else {\n  <div\n    class=\"s-input__campo\"\n    [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.data-disabled]=\"isDisabled() ? 'true' : null\"\n  >\n    @if (icon()) {\n      <s-icon class=\"s-input__icone\" [iconFilled]=\"iconFilled()\" [name]=\"icon()\" size=\"sm\" />\n    }\n\n    <input\n      class=\"s-input__nativo\"\n      [id]=\"controlId()\"\n      [attr.aria-label]=\"ariaLabel()\"\n      [type]=\"nativeType()\"\n      [sNativeValue]=\"texto()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"isDisabled()\"\n      [attr.maxlength]=\"maxlength()\"\n      [attr.autocomplete]=\"autocomplete()\"\n      [attr.aria-required]=\"required() ? 'true' : null\"\n      [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      (input)=\"onInput($event)\"\n      (blur)=\"onBlur()\"\n    />\n\n    @if (showReveal()) {\n      <s-icon-button\n        class=\"s-input__reveal\"\n        size=\"sm\"\n        variant=\"ghost\"\n        [attr.aria-pressed]=\"passwordVisible() ? 'true' : 'false'\"\n        [icon]=\"revealIcon()\"\n        [label]=\"revealLabel()\"\n        (click)=\"toggleReveal()\"\n      />\n    }\n  </div>\n}\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%;--s-field-h: var(--field-h, 48px)}.s-input__campo{box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;display:flex;align-items:center;gap:var(--space-8, 8px)}.s-input__campo:hover:not([data-disabled=true]){border-color:var(--border);background:var(--card)}.s-input__campo:focus-within{border:2px solid var(--primary);background:var(--card);padding:0 15px}.s-input__campo[data-invalid=true]{border-color:var(--destructive)}.s-input__campo[data-disabled=true]{opacity:.4}.s-input__icone{color:var(--text-secondary)}.s-input__reveal{flex:0 0 auto;--s-icon-button-size: var(--control-h-icon, 40px);--s-icon-button-fg: var(--text-secondary)}.s-input__nativo{flex:1;min-width:0;height:var(--s-field-h, var(--field-h, 48px));padding:0;border:none;background:transparent;font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary)}.s-input__nativo::placeholder{color:var(--text-secondary)}.s-input__nativo:focus{outline:none}.s-input__nativo::-webkit-calendar-picker-indicator{cursor:pointer;opacity:.7}.s-input__nativo:disabled{cursor:default;opacity:1}.s-input__readonly{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], iconFilled: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconFilled", required: false }] }], maxlength: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxlength", required: false }] }], autocomplete: [{ type: i0.Input, args: [{ isSignal: true, alias: "autocomplete", required: false }] }] } });

const PT_BR = 'pt-BR';
function validFractionDigits(options) {
    const minFractionDigits = Math.max(0, Math.trunc(options.minFractionDigits));
    const maxFractionDigits = Math.max(minFractionDigits, Math.trunc(options.maxFractionDigits));
    return { minFractionDigits, maxFractionDigits };
}
function escapeRegex(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
function stripAffixes(text, options) {
    let cleanText = text.trim();
    if (options.prefix) {
        cleanText = cleanText.replace(new RegExp(`^${escapeRegex(options.prefix)}\\s*`), '');
    }
    if (options.suffix) {
        cleanText = cleanText.replace(new RegExp(`\\s*${escapeRegex(options.suffix)}$`), '');
    }
    return cleanText.trim();
}
/** Aceita digitacao e colagem em pt-BR, incluindo `1.234,56`. */
function parsePtBrNumber(text, options) {
    const strippedText = stripAffixes(text, options);
    const normalizedText = strippedText.replace(/\s/g, '');
    if (!normalizedText) {
        return { value: null, invalid: false };
    }
    if (!/^-?[\d.,]+$/.test(normalizedText) ||
        normalizedText === '-' ||
        normalizedText === ',' ||
        normalizedText === '.') {
        return { value: null, invalid: true };
    }
    const { maxFractionDigits } = validFractionDigits(options);
    const commaCount = (normalizedText.match(/,/g) ?? []).length;
    if (commaCount > 1) {
        return { value: null, invalid: true };
    }
    let decimalPart = '';
    let integerPart = normalizedText;
    if (commaCount === 1) {
        const parts = normalizedText.split(',');
        integerPart = parts[0];
        decimalPart = parts[1] ?? '';
    }
    else if (maxFractionDigits > 0 && /^-?\d+\.\d+$/.test(normalizedText)) {
        const parts = normalizedText.split('.');
        const possibleDecimalPart = parts[parts.length - 1] ?? '';
        if (possibleDecimalPart.length <= maxFractionDigits) {
            integerPart = parts.slice(0, -1).join('');
            decimalPart = possibleDecimalPart;
        }
    }
    if (decimalPart && decimalPart.length > maxFractionDigits) {
        return { value: null, invalid: true };
    }
    const sign = integerPart.startsWith('-') ? '-' : '';
    const integerDigits = integerPart.replace(/^-/, '').replace(/\./g, '');
    if (!/^\d+$/.test(integerDigits) || (decimalPart && !/^\d+$/.test(decimalPart))) {
        return { value: null, invalid: true };
    }
    const number = Number(`${sign}${integerDigits}${decimalPart ? `.${decimalPart}` : ''}`);
    return Number.isFinite(number)
        ? { value: number, invalid: false }
        : { value: null, invalid: true };
}
/** Formata `number | null` para exibicao; vazio continua vazio. */
function formatPtBrNumber(value, options) {
    if (value === null || !Number.isFinite(value)) {
        return '';
    }
    const { minFractionDigits, maxFractionDigits } = validFractionDigits(options);
    const minIntegerDigits = Math.min(21, Math.max(1, Math.trunc(options.minIntegerDigits ?? 1)));
    const formattedText = new Intl.NumberFormat(PT_BR, {
        useGrouping: options.useGrouping,
        minimumIntegerDigits: minIntegerDigits,
        minimumFractionDigits: minFractionDigits,
        maximumFractionDigits: maxFractionDigits,
    }).format(value);
    return `${options.prefix ?? ''}${formattedText}${options.suffix ?? ''}`;
}
/**
 * Aplica a mascara pt-BR enquanto a pessoa digita.
 *
 * Fica so com sinal, digitos e a primeira virgula; descarta o resto, agrupa o
 * milhar e corta as casas que passam de `maxFractionDigits`. Nao completa casas
 * minimas: isso fica para o blur, senao `1` viraria `1,00` no primeiro toque.
 *
 * No campo inteiro (`maxFractionDigits` 0) a virgula tambem marca o fim da parte
 * inteira: o que vem depois dela e casa decimal, e sai inteiro. `1234,56` vira
 * `1234`, e nao `123456`.
 *
 * O cursor e contado pelos digitos, e nao pela posicao: na parte inteira, pelos
 * digitos a direita (o ponto de milhar entra a esquerda); na decimal, pelos
 * digitos a esquerda da virgula.
 */
function maskPtBrNumber(rawText, rawCaret, options, keepLeadingZeros = false) {
    const { maxFractionDigits } = validFractionDigits(options);
    let negative = false;
    let hasComma = false;
    let caretInFraction = false;
    let integerDigits = '';
    let fractionDigits = '';
    let integerDigitsAfterCaret = 0;
    let fractionDigitsBeforeCaret = 0;
    for (let index = 0; index < rawText.length; index++) {
        const character = rawText[index];
        if (character === '-' && !negative && !integerDigits && !hasComma) {
            negative = true;
        }
        else if (character === ',' && maxFractionDigits > 0 && !hasComma) {
            hasComma = true;
            caretInFraction = index < rawCaret;
        }
        else if (character === ',' && maxFractionDigits === 0) {
            break;
        }
        else if (/\d/.test(character)) {
            if (hasComma) {
                fractionDigits += character;
                fractionDigitsBeforeCaret += index < rawCaret ? 1 : 0;
            }
            else {
                integerDigits += character;
                integerDigitsAfterCaret += index >= rawCaret ? 1 : 0;
            }
        }
    }
    fractionDigits = fractionDigits.slice(0, maxFractionDigits);
    fractionDigitsBeforeCaret = Math.min(fractionDigitsBeforeCaret, fractionDigits.length);
    if (!keepLeadingZeros) {
        integerDigits = integerDigits.replace(/^0+(?=\d)/, '');
        integerDigitsAfterCaret = Math.min(integerDigitsAfterCaret, integerDigits.length);
    }
    if (hasComma && !integerDigits) {
        integerDigits = '0';
    }
    const groupedInteger = options.useGrouping
        ? integerDigits.replace(/\B(?=(\d{3})+(?!\d))/g, '.')
        : integerDigits;
    const sign = negative ? '-' : '';
    const text = `${sign}${groupedInteger}${hasComma ? `,${fractionDigits}` : ''}`;
    let caret;
    if (caretInFraction) {
        caret = sign.length + groupedInteger.length + 1 + fractionDigitsBeforeCaret;
    }
    else {
        let position = groupedInteger.length;
        for (let counted = 0; counted < integerDigitsAfterCaret; position--) {
            counted += /\d/.test(groupedInteger[position - 1]) ? 1 : 0;
        }
        // Colado no digito digitado, e nao depois do ponto de milhar que o segue.
        if (groupedInteger[position - 1] === '.') {
            position--;
        }
        caret = sign.length + position;
    }
    const hasDigits = Boolean(integerDigits || fractionDigits);
    const number = hasDigits
        ? Number(`${sign}${integerDigits || '0'}.${fractionDigits || '0'}`)
        : null;
    return {
        text,
        caret,
        // `-0` vira `0`: o formulario nao precisa distinguir os dois.
        value: number === null || !Number.isFinite(number) ? null : number || 0,
        leadingDigits: keepLeadingZeros && /^0\d/.test(integerDigits) ? integerDigits.length : 0,
    };
}
/**
 * Quantos digitos inteiros o texto tem, contando zeros a esquerda. Devolve `0`
 * quando o texto nao comeca com zero seguido de digito: sem zero a esquerda nao
 * ha o que preservar.
 */
function integerDigitCount(text, options) {
    const normalizedText = stripAffixes(text, options).replace(/\s/g, '');
    if (!/^-?0\d/.test(normalizedText)) {
        return 0;
    }
    let integerPart = normalizedText.split(',')[0] ?? '';
    if (!normalizedText.includes(',') &&
        validFractionDigits(options).maxFractionDigits > 0 &&
        /^-?\d+\.\d+$/.test(normalizedText)) {
        integerPart = normalizedText.slice(0, normalizedText.lastIndexOf('.'));
    }
    return integerPart.replace(/\D/g, '').length;
}
/** Erro compatível com `Validators.min`/`Validators.max`. */
function validateMinMax(value, min, max) {
    if (value === null) {
        return null;
    }
    if (min !== null && value < min) {
        return { min: { min, actual: value } };
    }
    if (max !== null && value > max) {
        return { max: { max, actual: value } };
    }
    return null;
}

function numberOrNull(value) {
    if (value === null || value === undefined || value === '') {
        return null;
    }
    const number = numberAttribute(value);
    return Number.isFinite(number) ? number : null;
}
function numberWithDefault(defaultValue) {
    return (value) => {
        if (value === null || value === undefined || value === '') {
            return defaultValue;
        }
        const number = numberAttribute(value);
        return Number.isFinite(number) ? number : defaultValue;
    };
}
/**
 * Campo numerico da biblioteca `@siage/siage-ui`.
 *
 * O valor entregue ao formulario e sempre `number | null`: vazio vira `null`, e
 * nunca a string que o `<input type="number">` nativo devolveria. A digitacao
 * fica em `type="text"` com `inputmode`, porque o formato pt-BR (`1.234,56`)
 * nao e aceito pelo controle numerico nativo dos navegadores.
 *
 * A mascara e aplicada durante a digitacao: o milhar entra conforme os digitos
 * chegam, a virgula (ou o ponto do teclado numerico) abre as casas decimais e o
 * cursor fica onde estava. O `blur` so completa as casas minimas. A colagem de
 * valores como `1.234,56` ou `1234.56` leva `1234.56` ao formulario.
 *
 * `min` e `max` validam, mas nao fazem clamp: corrigir silenciosamente no blur
 * esconderia que a tela recebeu um valor fora da regra. O erro gerado segue o
 * mesmo formato de `Validators.min`/`Validators.max`, entao o `<s-field>` usa a
 * mensagem padrao da biblioteca.
 *
 * `prefix` e `suffix` cobrem moeda e percentual sem acoplar o componente a uma
 * lista de moedas. Ficam fora do `<input>`, fixos na moldura: nao da para
 * selecionar nem apagar, e o texto editado e so o numero. Se a aplicacao precisar de regras fiscais de moeda, elas
 * continuam no dominio da tela.
 *
 * @example
 * ```html
 * <s-field label="Valor" [error]="form.controls.value.errors">
 *   <s-input-number formControlName="value" prefix="R$" useGrouping [minFractionDigits]="2" [maxFractionDigits]="2" />
 * </s-field>
 * ```
 */
class SInputNumberComponent extends SControlBase {
    /**
     * Desenha separador de milhar ao formatar.
     *
     * Desligado por padrao: a maior parte dos numeros das telas e codigo, ano,
     * carga horaria ou quantidade pequena, em que `2.026` le como erro. Ligue em
     * valores monetarios e contagens grandes. Colar `1.234,56` funciona nos dois
     * casos.
     */
    useGrouping = input(false, ...(ngDevMode ? [{ debugName: "useGrouping", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Casas minimas exibidas no blur. Use `2` para decimal monetario. */
    minFractionDigits = input(0, ...(ngDevMode ? [{ debugName: "minFractionDigits", transform: numberWithDefault(0) }] : [{ transform: numberWithDefault(0) }]));
    /** Casas maximas aceitas e exibidas. `0` mantem o campo inteiro. */
    maxFractionDigits = input(0, ...(ngDevMode ? [{ debugName: "maxFractionDigits", transform: numberWithDefault(0) }] : [{ transform: numberWithDefault(0) }]));
    /** Menor valor aceito; gera erro `min` em vez de alterar o valor digitado. */
    min = input(null, ...(ngDevMode ? [{ debugName: "min", transform: numberOrNull }] : [{ transform: numberOrNull }]));
    /** Maior valor aceito; gera erro `max` em vez de alterar o valor digitado. */
    max = input(null, ...(ngDevMode ? [{ debugName: "max", transform: numberOrNull }] : [{ transform: numberOrNull }]));
    /** Incremento usado por ArrowUp/ArrowDown. */
    step = input(1, ...(ngDevMode ? [{ debugName: "step", transform: numberWithDefault(1) }] : [{ transform: numberWithDefault(1) }]));
    /** Texto fixo antes do numero, como `R$`. Nao participa do valor do formulario. */
    prefix = input('', ...(ngDevMode ? [{ debugName: "prefix" }] : []));
    /** Texto fixo depois do numero, como `%`. Nao participa do valor do formulario. */
    suffix = input('', ...(ngDevMode ? [{ debugName: "suffix" }] : []));
    /**
     * Mantem na tela os zeros a esquerda digitados: `0001` continua `0001` no
     * blur e nas setas.
     *
     * O formulario continua recebendo `number` (`1`), porque numero nao carrega
     * zero a esquerda. Quando o zero faz parte do dado (matricula, codigo INEP),
     * use `<s-input sOnlyDigits>`, que entrega a string. Com `useGrouping`, o
     * separador de milhar tambem entra entre os zeros (`0.001`).
     */
    keepLeadingZeros = input(false, ...(ngDevMode ? [{ debugName: "keepLeadingZeros", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    fieldBinding = usarCampo('s-input-number');
    editableText = signal('', ...(ngDevMode ? [{ debugName: "editableText" }] : []));
    editing = signal(false, ...(ngDevMode ? [{ debugName: "editing" }] : []));
    leadingDigits = signal(0, ...(ngDevMode ? [{ debugName: "leadingDigits" }] : []));
    onValidatorChange = () => { };
    inputId = this.fieldBinding.id;
    ariaLabel = this.fieldBinding.rotuloAvulso(this.label);
    prefixText = computed(() => this.prefix().trim(), ...(ngDevMode ? [{ debugName: "prefixText" }] : []));
    suffixText = computed(() => this.suffix().trim(), ...(ngDevMode ? [{ debugName: "suffixText" }] : []));
    prefixId = computed(() => `${this.inputId()}-prefixo`, ...(ngDevMode ? [{ debugName: "prefixId" }] : []));
    suffixId = computed(() => `${this.inputId()}-sufixo`, ...(ngDevMode ? [{ debugName: "suffixId" }] : []));
    // O leitor de tela ouve so o rotulo e o numero; o prefixo e o sufixo entram
    // como descricao, para `1.234,50` nao chegar sem o `R$`.
    describedBy = computed(() => {
        const ids = [
            this.prefixText() ? this.prefixId() : null,
            this.suffixText() ? this.suffixId() : null,
            this.fieldBinding.describedBy(),
        ].filter(Boolean);
        return ids.length ? ids.join(' ') : null;
    }, ...(ngDevMode ? [{ debugName: "describedBy" }] : []));
    required = this.fieldBinding.obrigatorio;
    isInvalid = computed(() => this.invalid() || this.fieldBinding.invalido(), ...(ngDevMode ? [{ debugName: "isInvalid" }] : []));
    inputMode = computed(() => this.maxFractionDigits() > 0 ? 'decimal' : 'numeric', ...(ngDevMode ? [{ debugName: "inputMode" }] : []));
    displayText = computed(() => this.editableText(), ...(ngDevMode ? [{ debugName: "displayText" }] : []));
    readOnlyText = computed(() => {
        const text = formatPtBrNumber(this.value(), this.formatOptions());
        return text ? [this.prefixText(), text, this.suffixText()].filter(Boolean).join(' ') : '';
    }, ...(ngDevMode ? [{ debugName: "readOnlyText" }] : []));
    /** Formato do texto editavel: so o numero, sem prefixo e sufixo. */
    formatOptions = computed(() => ({
        useGrouping: this.useGrouping(),
        minFractionDigits: this.minFractionDigits(),
        maxFractionDigits: this.maxFractionDigits(),
        minIntegerDigits: this.keepLeadingZeros() ? this.leadingDigits() : 0,
    }), ...(ngDevMode ? [{ debugName: "formatOptions" }] : []));
    constructor() {
        super();
        effect(() => {
            this.min();
            this.max();
            this.onValidatorChange();
        });
        effect(() => {
            const value = this.value();
            const options = this.formatOptions();
            if (!this.editing()) {
                this.editableText.set(formatPtBrNumber(value, options));
            }
        });
    }
    writeValue(value) {
        const normalizedValue = typeof value === 'number' && Number.isFinite(value) ? value : null;
        this.value.set(normalizedValue);
        this.leadingDigits.set(0);
        this.editableText.set(formatPtBrNumber(normalizedValue, this.formatOptions()));
    }
    validate(control) {
        return validateMinMax(control.value, this.min(), this.max());
    }
    registerOnValidatorChange(fn) {
        this.onValidatorChange = fn;
    }
    onBeforeInput(event) {
        const text = event.data ?? event.dataTransfer?.getData('text') ?? '';
        const affixes = `${this.prefix()}${this.suffix()}`;
        const allowed = (character) => /^[\d.,\-\s]$/.test(character) || affixes.includes(character);
        if (text && ![...text].every(allowed)) {
            event.preventDefault();
        }
        else if (text === ',' && Math.max(this.minFractionDigits(), this.maxFractionDigits()) === 0) {
            // Campo inteiro: a virgula sumiria na mascara e o proximo digito colaria
            // na parte inteira (`10,5` viraria `105`). Recusar a tecla deixa claro
            // que o campo nao aceita casas.
            event.preventDefault();
        }
    }
    onInput(event) {
        this.editing.set(true);
        const inputElement = event.target;
        const { inputType = '', data = null } = event;
        const previousText = this.editableText();
        const options = this.formatOptions();
        let text = inputElement.value;
        let caret = inputElement.selectionStart ?? text.length;
        if (!inputType || inputType.startsWith('insertFrom')) {
            // Colagem, arrasto ou preenchimento automatico: o texto chega inteiro e
            // pode trazer o ponto como decimal (`1234.56`) ou o proprio `R$`.
            const pasted = parsePtBrNumber(text, {
                ...options,
                prefix: this.prefix(),
                suffix: this.suffix(),
            });
            if (!pasted.invalid) {
                text = formatPtBrNumber(pasted.value, {
                    ...options,
                    useGrouping: false,
                    minFractionDigits: 0,
                    minIntegerDigits: this.keepLeadingZeros() ? integerDigitCount(text, options) : 0,
                });
                caret = text.length;
            }
        }
        else if (data === '.' && options.maxFractionDigits > 0 && !previousText.includes(',')) {
            // O ponto do teclado numerico vira a virgula decimal.
            text = `${text.slice(0, caret - 1)},${text.slice(caret)}`;
        }
        else if (text.length === previousText.length - 1) {
            // Apagar o ponto de milhar apaga o digito vizinho; senao a mascara
            // devolveria o ponto e a tecla pareceria nao funcionar.
            if (inputType === 'deleteContentBackward' && previousText[caret] === '.') {
                text = `${text.slice(0, caret - 1)}${text.slice(caret)}`;
                caret -= 1;
            }
            else if (inputType === 'deleteContentForward' && previousText[caret] === '.') {
                text = `${text.slice(0, caret)}${text.slice(caret + 1)}`;
            }
        }
        const masked = maskPtBrNumber(text, caret, options, this.keepLeadingZeros());
        if (inputElement.value !== masked.text) {
            inputElement.value = masked.text;
        }
        if (inputElement.ownerDocument.activeElement === inputElement) {
            inputElement.setSelectionRange(masked.caret, masked.caret);
        }
        this.editableText.set(masked.text);
        this.leadingDigits.set(masked.leadingDigits);
        this.setValue(masked.value);
    }
    /** Clicar no prefixo ou no sufixo leva o foco ao campo, sem selecionar o texto fixo. */
    focusNative(event, inputElement) {
        event.preventDefault();
        inputElement.focus();
    }
    onBlur() {
        this.editing.set(false);
        this.editableText.set(formatPtBrNumber(this.value(), this.formatOptions()));
        this.onTouched();
    }
    onFocus() {
        this.editing.set(true);
    }
    onKeyDown(event) {
        if (event.key !== 'ArrowUp' && event.key !== 'ArrowDown') {
            return;
        }
        if (this.isDisabled() || this.readOnly()) {
            return;
        }
        event.preventDefault();
        const step = this.step() || 1;
        const direction = event.key === 'ArrowUp' ? 1 : -1;
        const baseValue = this.value() ?? 0;
        const nextValue = baseValue + step * direction;
        this.setValue(nextValue);
        this.editableText.set(formatPtBrNumber(nextValue, this.formatOptions()));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SInputNumberComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SInputNumberComponent, isStandalone: true, selector: "s-input-number", inputs: { useGrouping: { classPropertyName: "useGrouping", publicName: "useGrouping", isSignal: true, isRequired: false, transformFunction: null }, minFractionDigits: { classPropertyName: "minFractionDigits", publicName: "minFractionDigits", isSignal: true, isRequired: false, transformFunction: null }, maxFractionDigits: { classPropertyName: "maxFractionDigits", publicName: "maxFractionDigits", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, step: { classPropertyName: "step", publicName: "step", isSignal: true, isRequired: false, transformFunction: null }, prefix: { classPropertyName: "prefix", publicName: "prefix", isSignal: true, isRequired: false, transformFunction: null }, suffix: { classPropertyName: "suffix", publicName: "suffix", isSignal: true, isRequired: false, transformFunction: null }, keepLeadingZeros: { classPropertyName: "keepLeadingZeros", publicName: "keepLeadingZeros", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "s-input-number" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SInputNumberComponent),
                multi: true,
            },
            {
                provide: NG_VALIDATORS,
                useExisting: forwardRef(() => SInputNumberComponent),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: "@if (readOnly()) {\n  <div class=\"s-input-number__read-only\" [attr.id]=\"inputId()\">{{ readOnlyText() }}</div>\n} @else {\n  <div\n    class=\"s-input-number__field\"\n    [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.data-disabled]=\"isDisabled() ? 'true' : null\"\n  >\n    @if (prefixText()) {\n      <span\n        class=\"s-input-number__affix\"\n        [id]=\"prefixId()\"\n        (mousedown)=\"focusNative($event, native)\"\n        >{{ prefixText() }}</span\n      >\n    }\n    <input\n      #native\n      class=\"s-input-number__native\"\n      type=\"text\"\n      [id]=\"inputId()\"\n      [attr.aria-label]=\"ariaLabel()\"\n      [attr.inputmode]=\"inputMode()\"\n      [sNativeValue]=\"displayText()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"isDisabled()\"\n      [attr.aria-required]=\"required() ? 'true' : null\"\n      [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      (beforeinput)=\"onBeforeInput($any($event))\"\n      (input)=\"onInput($event)\"\n      (keydown)=\"onKeyDown($event)\"\n      (focus)=\"onFocus()\"\n      (blur)=\"onBlur()\"\n    />\n    @if (suffixText()) {\n      <span\n        class=\"s-input-number__affix\"\n        [id]=\"suffixId()\"\n        (mousedown)=\"focusNative($event, native)\"\n        >{{ suffixText() }}</span\n      >\n    }\n  </div>\n}\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%;--s-field-h: var(--field-h, 48px)}.s-input-number__field{box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;display:flex;align-items:center;gap:8px}.s-input-number__field:hover:not([data-disabled=true]){border-color:var(--border);background:var(--card)}.s-input-number__field:focus-within{border:2px solid var(--primary);background:var(--card);padding:0 15px}.s-input-number__field[data-invalid=true]{border-color:var(--destructive)}.s-input-number__field[data-disabled=true]{opacity:.4}.s-input-number__field[data-disabled=true] .s-input-number__affix{cursor:default}.s-input-number__affix{flex:none;color:var(--text-secondary);-webkit-user-select:none;user-select:none;cursor:text}.s-input-number__native{flex:1;min-width:0;width:100%;height:100%;padding:0;border:none;background:transparent;font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary)}.s-input-number__native::placeholder{color:var(--text-secondary)}.s-input-number__native:focus{outline:none}.s-input-number__native:disabled{cursor:default;opacity:1}.s-input-number__read-only{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary)}\n"], dependencies: [{ kind: "directive", type: SNativeValueDirective, selector: "input[sNativeValue], textarea[sNativeValue]", inputs: ["sNativeValue"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SInputNumberComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-input-number', imports: [SNativeValueDirective], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SInputNumberComponent),
                            multi: true,
                        },
                        {
                            provide: NG_VALIDATORS,
                            useExisting: forwardRef(() => SInputNumberComponent),
                            multi: true,
                        },
                    ], host: {
                        class: 's-input-number',
                    }, template: "@if (readOnly()) {\n  <div class=\"s-input-number__read-only\" [attr.id]=\"inputId()\">{{ readOnlyText() }}</div>\n} @else {\n  <div\n    class=\"s-input-number__field\"\n    [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.data-disabled]=\"isDisabled() ? 'true' : null\"\n  >\n    @if (prefixText()) {\n      <span\n        class=\"s-input-number__affix\"\n        [id]=\"prefixId()\"\n        (mousedown)=\"focusNative($event, native)\"\n        >{{ prefixText() }}</span\n      >\n    }\n    <input\n      #native\n      class=\"s-input-number__native\"\n      type=\"text\"\n      [id]=\"inputId()\"\n      [attr.aria-label]=\"ariaLabel()\"\n      [attr.inputmode]=\"inputMode()\"\n      [sNativeValue]=\"displayText()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"isDisabled()\"\n      [attr.aria-required]=\"required() ? 'true' : null\"\n      [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      (beforeinput)=\"onBeforeInput($any($event))\"\n      (input)=\"onInput($event)\"\n      (keydown)=\"onKeyDown($event)\"\n      (focus)=\"onFocus()\"\n      (blur)=\"onBlur()\"\n    />\n    @if (suffixText()) {\n      <span\n        class=\"s-input-number__affix\"\n        [id]=\"suffixId()\"\n        (mousedown)=\"focusNative($event, native)\"\n        >{{ suffixText() }}</span\n      >\n    }\n  </div>\n}\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%;--s-field-h: var(--field-h, 48px)}.s-input-number__field{box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;display:flex;align-items:center;gap:8px}.s-input-number__field:hover:not([data-disabled=true]){border-color:var(--border);background:var(--card)}.s-input-number__field:focus-within{border:2px solid var(--primary);background:var(--card);padding:0 15px}.s-input-number__field[data-invalid=true]{border-color:var(--destructive)}.s-input-number__field[data-disabled=true]{opacity:.4}.s-input-number__field[data-disabled=true] .s-input-number__affix{cursor:default}.s-input-number__affix{flex:none;color:var(--text-secondary);-webkit-user-select:none;user-select:none;cursor:text}.s-input-number__native{flex:1;min-width:0;width:100%;height:100%;padding:0;border:none;background:transparent;font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary)}.s-input-number__native::placeholder{color:var(--text-secondary)}.s-input-number__native:focus{outline:none}.s-input-number__native:disabled{cursor:default;opacity:1}.s-input-number__read-only{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { useGrouping: [{ type: i0.Input, args: [{ isSignal: true, alias: "useGrouping", required: false }] }], minFractionDigits: [{ type: i0.Input, args: [{ isSignal: true, alias: "minFractionDigits", required: false }] }], maxFractionDigits: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxFractionDigits", required: false }] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], step: [{ type: i0.Input, args: [{ isSignal: true, alias: "step", required: false }] }], prefix: [{ type: i0.Input, args: [{ isSignal: true, alias: "prefix", required: false }] }], suffix: [{ type: i0.Input, args: [{ isSignal: true, alias: "suffix", required: false }] }], keepLeadingZeros: [{ type: i0.Input, args: [{ isSignal: true, alias: "keepLeadingZeros", required: false }] }] } });

const PRESET_PATTERNS = {
    cpf: '000.000.000-00',
    cnpj: '00.000.000/0000-00',
    cep: '00000-000',
};
function isDigit(char) {
    return /\d/.test(char);
}
function isLetter(char) {
    return /\p{L}/u.test(char);
}
function isAlphanumeric(char) {
    return isDigit(char) || isLetter(char);
}
function isToken(char) {
    return char === '0' || char === 'A' || char === '*';
}
function accepts(token, char) {
    if (token === '0') {
        return isDigit(char);
    }
    if (token === 'A') {
        return isLetter(char);
    }
    return isAlphanumeric(char);
}
function rawChars(value, pattern) {
    const tokens = [...pattern].filter(isToken);
    const result = [];
    for (const char of value) {
        const token = tokens[result.length];
        if (!token) {
            break;
        }
        if (accepts(token, char)) {
            result.push(char);
        }
    }
    return result;
}
/** Formata um texto conforme uma mascara livre: `0`, `A`, `*` e literais. */
function formatPattern(value, pattern) {
    const raw = rawChars(value, pattern);
    let index = 0;
    let formatted = '';
    for (const maskChar of pattern) {
        if (!isToken(maskChar)) {
            if (index < raw.length) {
                formatted += maskChar;
            }
            continue;
        }
        const char = raw[index];
        if (!char) {
            break;
        }
        formatted += char;
        index += 1;
    }
    const expected = [...pattern].filter(isToken).length;
    return {
        formatted,
        raw: raw.join(''),
        complete: raw.length === expected,
    };
}
/** Formata telefone brasileiro, alternando fixo e celular pelo total de digitos. */
function formatPhone(value) {
    const digits = value.replace(/\D/g, '').slice(0, 11);
    const pattern = digits.length > 10 ? '(00) 00000-0000' : '(00) 0000-0000';
    const result = formatPattern(digits, pattern);
    return {
        ...result,
        complete: digits.length === 10 || digits.length === 11,
    };
}
/** Formata pelos presets conhecidos ou por uma mascara livre. */
function formatMask(value, mask) {
    if (mask === 'phone') {
        return formatPhone(value);
    }
    if (mask === 'cpf' || mask === 'cnpj' || mask === 'cep') {
        return formatPattern(value, PRESET_PATTERNS[mask]);
    }
    return formatPattern(value, mask);
}
/** Conta caracteres que preenchem tokens antes do cursor atual. */
function rawCountBeforeCursor(value, cursor, mask) {
    return formatMask(value.slice(0, cursor), mask).raw.length;
}
/** Indice logo depois do `n`-esimo caractere util do texto formatado. */
function positionAfterRaw(formatted, rawCount) {
    if (rawCount <= 0) {
        return 0;
    }
    let count = 0;
    for (let index = 0; index < formatted.length; index += 1) {
        if (/[\p{L}\d]/u.test(formatted[index])) {
            count += 1;
        }
        if (count === rawCount) {
            return index + 1;
        }
    }
    return formatted.length;
}

/**
 * Mascara de digitacao para `<s-input>` e `<input>` nativo.
 *
 * O valor padrao do formulario e `raw`: nos presets de documento ele fica so
 * com digitos, sem ponto, barra ou hifen. Essa escolha evita que cada tela
 * limpe o valor antes de chamar a API. Em mascara livre, `raw` preserva os
 * caracteres que preencheram `0`, `A` e `*`. Quando a API legada espera a
 * mascara pronta, use `maskValue="formatted"`.
 *
 * A mascara nao substitui validacao de dominio. `sMaskValidate` so adiciona o
 * erro `sMaskIncomplete` quando o texto ainda nao preencheu todos os tokens.
 */
class SMaskDirective {
    /** Preset (`cpf`, `cnpj`, `cep`, `phone`) ou mascara livre com `0`, `A` e `*`. */
    mask = input('', ...(ngDevMode ? [{ debugName: "mask", alias: 'sMask' }] : [{ alias: 'sMask' }]));
    /** Define se o formulario recebe o valor sem literais ou o texto formatado. */
    maskValue = input('raw', ...(ngDevMode ? [{ debugName: "maskValue" }] : []));
    /** Liga o erro `sMaskIncomplete` enquanto a mascara estiver incompleta. */
    maskValidate = input(false, ...(ngDevMode ? [{ debugName: "maskValidate", transform: booleanAttribute, alias: 'sMaskValidate' }] : [{ transform: booleanAttribute, alias: 'sMaskValidate' }]));
    host = inject(ElementRef);
    injector = inject(Injector);
    siageInput = inject(SInputComponent, { optional: true, host: true });
    ngControl = null;
    subscription = null;
    applying = false;
    onValidatorChange = () => { };
    constructor() {
        effect(() => {
            this.mask();
            this.maskValue();
            this.maskValidate();
            this.onValidatorChange();
            queueMicrotask(() => this.formatCurrentView(false));
        });
    }
    ngAfterViewInit() {
        this.ngControl = this.injector.get(NgControl, null, { self: true, optional: true });
        this.subscription =
            this.ngControl?.valueChanges?.subscribe(() => {
                if (!this.applying) {
                    queueMicrotask(() => this.formatModelValue());
                }
            }) ?? null;
        queueMicrotask(() => this.formatModelValue());
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    validate(control) {
        if (!this.maskValidate() || !control.value) {
            return null;
        }
        return formatMask(String(control.value), this.mask()).complete
            ? null
            : { sMaskIncomplete: true };
    }
    registerOnValidatorChange(fn) {
        this.onValidatorChange = fn;
    }
    onInput(event) {
        if (event.target instanceof HTMLInputElement) {
            this.formatElement(event.target, true);
        }
    }
    onBlur() {
        this.ngControl?.control?.markAsTouched();
    }
    nativeInput() {
        const element = this.host.nativeElement;
        return element instanceof HTMLInputElement ? element : element.querySelector('input');
    }
    formatCurrentView(syncControl) {
        const input = this.nativeInput();
        if (input) {
            this.formatElement(input, syncControl);
        }
    }
    /**
     * Formata o valor que veio do formulario, e nao o texto da tela.
     *
     * No `<s-input>` zoneless o texto so chega ao DOM na proxima change
     * detection: ler a tela aqui pegava o valor antigo e o devolvia ao campo,
     * apagando o que o `setValue` acabou de gravar.
     */
    formatModelValue() {
        const input = this.nativeInput();
        if (!input) {
            return;
        }
        if (!this.ngControl) {
            this.formatElement(input, false);
            return;
        }
        const value = this.ngControl.value;
        const result = formatMask(value === null || value === undefined ? '' : String(value), this.mask());
        if (input.value !== result.formatted) {
            input.value = result.formatted;
        }
        this.siageInput?.writeValue(result.formatted);
    }
    formatElement(input, syncControl) {
        const mask = this.mask();
        const cursor = input.selectionStart ?? input.value.length;
        const rawBefore = rawCountBeforeCursor(input.value, cursor, mask);
        const result = formatMask(input.value, mask);
        if (input.value !== result.formatted) {
            input.value = result.formatted;
        }
        this.siageInput?.writeValue(result.formatted);
        if (input.ownerDocument.activeElement === input) {
            const position = positionAfterRaw(result.formatted, rawBefore);
            input.setSelectionRange(position, position);
        }
        if (syncControl) {
            const value = this.maskValue() === 'formatted' ? result.formatted : result.raw;
            this.setControlValue(value);
        }
    }
    setControlValue(value) {
        const control = this.ngControl?.control;
        if (!control || control.value === value) {
            return;
        }
        this.applying = true;
        control.setValue(value, { emitModelToViewChange: false });
        this.applying = false;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SMaskDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "20.3.34", type: SMaskDirective, isStandalone: true, selector: "s-input[sMask], input[sMask]", inputs: { mask: { classPropertyName: "mask", publicName: "sMask", isSignal: true, isRequired: false, transformFunction: null }, maskValue: { classPropertyName: "maskValue", publicName: "maskValue", isSignal: true, isRequired: false, transformFunction: null }, maskValidate: { classPropertyName: "maskValidate", publicName: "sMaskValidate", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "input": "onInput($event)", "blur": "onBlur()" } }, providers: [
            { provide: NG_VALIDATORS, useExisting: forwardRef(() => SMaskDirective), multi: true },
        ], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SMaskDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 's-input[sMask], input[sMask]',
                    host: {
                        '(input)': 'onInput($event)',
                        '(blur)': 'onBlur()',
                    },
                    providers: [
                        { provide: NG_VALIDATORS, useExisting: forwardRef(() => SMaskDirective), multi: true },
                    ],
                }]
        }], ctorParameters: () => [], propDecorators: { mask: [{ type: i0.Input, args: [{ isSignal: true, alias: "sMask", required: false }] }], maskValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "maskValue", required: false }] }], maskValidate: [{ type: i0.Input, args: [{ isSignal: true, alias: "sMaskValidate", required: false }] }] } });

/**
 * Restringe o campo a digitos, inclusive em colagem.
 *
 * Serve para substituir `pKeyFilter="int"` quando nao ha mascara visual. O
 * formulario recebe sempre a string de digitos, porque zeros a esquerda podem
 * ser significativos em matricula, codigo e documento.
 */
class SOnlyDigitsDirective {
    /** Permite desligar a diretiva por binding mantendo o template estruturalmente igual. */
    onlyDigits = input(true, ...(ngDevMode ? [{ debugName: "onlyDigits", transform: booleanAttribute, alias: 'sOnlyDigits' }] : [{ transform: booleanAttribute, alias: 'sOnlyDigits' }]));
    host = inject(ElementRef);
    injector = inject(Injector);
    siageInput = inject(SInputComponent, { optional: true, host: true });
    ngControl = null;
    ngAfterViewInit() {
        this.ngControl = this.injector.get(NgControl, null, { self: true, optional: true });
        queueMicrotask(() => this.formatCurrentValue());
    }
    onBeforeInput(event) {
        if (!this.onlyDigits() || !(event instanceof InputEvent)) {
            return;
        }
        const text = event.data ?? event.dataTransfer?.getData('text') ?? '';
        if (text && /\D/.test(text)) {
            event.preventDefault();
        }
    }
    onInput(event) {
        if (!this.onlyDigits() || !(event.target instanceof HTMLInputElement)) {
            return;
        }
        const input = event.target;
        const cursor = input.selectionStart ?? input.value.length;
        const digitsBefore = input.value.slice(0, cursor).replace(/\D/g, '').length;
        const value = input.value.replace(/\D/g, '');
        if (input.value !== value) {
            input.value = value;
            // O `<s-input>` guarda o texto num signal proprio e o regravaria na tela.
            this.siageInput?.writeValue(value);
            if (input.ownerDocument.activeElement === input) {
                input.setSelectionRange(digitsBefore, digitsBefore);
            }
        }
        this.sincronizar(value);
    }
    onBlur() {
        this.ngControl?.control?.markAsTouched();
    }
    formatCurrentValue() {
        const element = this.host.nativeElement;
        const input = element instanceof HTMLInputElement ? element : element.querySelector('input');
        if (input) {
            const digits = input.value.replace(/\D/g, '');
            if (input.value !== digits) {
                input.value = digits;
                this.siageInput?.writeValue(digits);
            }
        }
        // Valor inicial com outros caracteres: o formulario tambem fica so com os digitos.
        const value = this.ngControl?.value;
        if (typeof value === 'string' && /\D/.test(value)) {
            this.sincronizar(value.replace(/\D/g, ''));
        }
    }
    sincronizar(value) {
        const control = this.ngControl?.control;
        if (control && control.value !== value) {
            control.setValue(value, { emitModelToViewChange: false });
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SOnlyDigitsDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "20.3.34", type: SOnlyDigitsDirective, isStandalone: true, selector: "s-input[sOnlyDigits], input[sOnlyDigits]", inputs: { onlyDigits: { classPropertyName: "onlyDigits", publicName: "sOnlyDigits", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "beforeinput": "onBeforeInput($event)", "input": "onInput($event)", "blur": "onBlur()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SOnlyDigitsDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 's-input[sOnlyDigits], input[sOnlyDigits]',
                    host: {
                        '(beforeinput)': 'onBeforeInput($event)',
                        '(input)': 'onInput($event)',
                        '(blur)': 'onBlur()',
                    },
                }]
        }], propDecorators: { onlyDigits: [{ type: i0.Input, args: [{ isSignal: true, alias: "sOnlyDigits", required: false }] }] } });

/**
 * Regras padrao usadas nas telas de troca de senha do SIAGE.
 *
 * Ficam exportadas para a aplicacao reutilizar a mesma politica no validador do
 * formulario. A lista visual nao substitui validacao no envio; ela so antecipa
 * o que ainda falta antes de a pessoa tentar salvar.
 */
const S_PASSWORD_RULES = [
    { label: 'No mínimo 8 caracteres', test: (value) => value.length >= 8 },
    { label: 'Uma letra maiúscula', test: (value) => /[A-ZÀ-Ý]/.test(value) },
    { label: 'Um número', test: (value) => /\d/.test(value) },
    { label: 'Um caractere especial', test: (value) => /[^\p{L}\d\s]/u.test(value) },
];

/**
 * Lista acessivel de requisitos de senha.
 *
 * O componente recebe o `value` do campo de senha e avalia cada regra. Ele nao
 * faz HTTP nem decide a politica da aplicacao: quando a tela precisa de outra
 * regra, passa `rules` e reutiliza a mesma lista no validador do formulario.
 *
 * A regiao `aria-live="polite"` anuncia apenas o resumo (quantos requisitos
 * foram atendidos), nao cada item a cada tecla. Assim a pessoa que usa leitor
 * de tela recebe progresso suficiente sem ouvir quatro frases repetidas durante
 * a digitacao.
 */
class SPasswordRequirementsComponent {
    /** Valor atual da senha. `null` e tratado como vazio para simplificar formularios. */
    value = input('', ...(ngDevMode ? [{ debugName: "value" }] : []));
    /**
     * Requisitos avaliados na ordem exibida.
     *
     * O padrao cobre a politica mais comum do SIAGE, mas fica configuravel porque
     * senha e regra de seguranca da aplicacao, nao do componente visual.
     */
    rules = input(S_PASSWORD_RULES, ...(ngDevMode ? [{ debugName: "rules" }] : []));
    currentValue = computed(() => this.value() ?? '', ...(ngDevMode ? [{ debugName: "currentValue" }] : []));
    items = computed(() => {
        const value = this.currentValue();
        return this.rules().map((rule) => ({ ...rule, valid: rule.test(value) }));
    }, ...(ngDevMode ? [{ debugName: "items" }] : []));
    validCount = computed(() => this.items().filter((item) => item.valid).length, ...(ngDevMode ? [{ debugName: "validCount" }] : []));
    summary = computed(() => `${this.validCount()} de ${this.rules().length} requisitos de senha atendidos.`, ...(ngDevMode ? [{ debugName: "summary" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SPasswordRequirementsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SPasswordRequirementsComponent, isStandalone: true, selector: "s-password-requirements", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, rules: { classPropertyName: "rules", publicName: "rules", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "s-password-requirements" }, ngImport: i0, template: "<p class=\"s-password-requirements__summary\" aria-live=\"polite\" aria-atomic=\"true\">\n  {{ summary() }}\n</p>\n\n<ul class=\"s-password-requirements__list\">\n  @for (item of items(); track item.label) {\n    <li class=\"s-password-requirements__item\" [attr.data-valid]=\"item.valid ? 'true' : 'false'\">\n      <s-icon\n        class=\"s-password-requirements__icon\"\n        [name]=\"item.valid ? 'check_circle' : 'radio_button_unchecked'\"\n        size=\"sm\"\n        [iconFilled]=\"item.valid\"\n        aria-hidden=\"true\"\n      />\n      <span>{{ item.label }}</span>\n      <span class=\"s-password-requirements__state\">\n        {{ item.valid ? 'atendido' : 'pendente' }}\n      </span>\n    </li>\n  }\n</ul>\n", styles: [":host{display:block;color:var(--text-secondary);font-family:var(--font-ui);font-size:var(--text-body-sm, 12px)}.s-password-requirements__summary{margin:0 0 var(--space-8, 8px);color:var(--text-secondary)}.s-password-requirements__list{display:grid;gap:var(--space-4, 4px);margin:0;padding:0;list-style:none}.s-password-requirements__item{display:flex;align-items:center;gap:var(--space-8, 8px)}.s-password-requirements__item[data-valid=true]{color:var(--success)}.s-password-requirements__icon{flex:0 0 auto}.s-password-requirements__state{margin-left:auto;color:var(--text-secondary)}\n"], dependencies: [{ kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SPasswordRequirementsComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-password-requirements', imports: [SIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-password-requirements',
                    }, template: "<p class=\"s-password-requirements__summary\" aria-live=\"polite\" aria-atomic=\"true\">\n  {{ summary() }}\n</p>\n\n<ul class=\"s-password-requirements__list\">\n  @for (item of items(); track item.label) {\n    <li class=\"s-password-requirements__item\" [attr.data-valid]=\"item.valid ? 'true' : 'false'\">\n      <s-icon\n        class=\"s-password-requirements__icon\"\n        [name]=\"item.valid ? 'check_circle' : 'radio_button_unchecked'\"\n        size=\"sm\"\n        [iconFilled]=\"item.valid\"\n        aria-hidden=\"true\"\n      />\n      <span>{{ item.label }}</span>\n      <span class=\"s-password-requirements__state\">\n        {{ item.valid ? 'atendido' : 'pendente' }}\n      </span>\n    </li>\n  }\n</ul>\n", styles: [":host{display:block;color:var(--text-secondary);font-family:var(--font-ui);font-size:var(--text-body-sm, 12px)}.s-password-requirements__summary{margin:0 0 var(--space-8, 8px);color:var(--text-secondary)}.s-password-requirements__list{display:grid;gap:var(--space-4, 4px);margin:0;padding:0;list-style:none}.s-password-requirements__item{display:flex;align-items:center;gap:var(--space-8, 8px)}.s-password-requirements__item[data-valid=true]{color:var(--success)}.s-password-requirements__icon{flex:0 0 auto}.s-password-requirements__state{margin-left:auto;color:var(--text-secondary)}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], rules: [{ type: i0.Input, args: [{ isSignal: true, alias: "rules", required: false }] }] } });

/**
 * Campo de texto longo da biblioteca `@siage/siage-ui`.
 *
 * 80px de altura, com redimensionamento apenas vertical.
 *
 * Na ordem do formulario, campos descritivos longos vem **depois** dos de alto
 * impacto — data, turma, periodo. Quem preenche decide se continua com base nos
 * campos que definem o registro, nao no texto livre.
 */
class STextareaComponent extends SControlBase {
    /**
     * Limite de caracteres do texto livre.
     *
     * O limite fica no `textarea` nativo para o navegador impedir excesso antes
     * da validacao, e o `<s-field showCharCounter>` le esse mesmo `maxlength`
     * para exibir `n/max` sem duplicar configuracao de formulario.
     */
    maxlength = input(null, ...(ngDevMode ? [{ debugName: "maxlength" }] : []));
    campo = usarCampo('s-textarea');
    controlId = this.campo.id;
    ariaLabel = this.campo.rotuloAvulso(this.label);
    describedBy = this.campo.describedBy;
    required = this.campo.obrigatorio;
    isInvalid = computed(() => this.invalid() || this.campo.invalido(), ...(ngDevMode ? [{ debugName: "isInvalid" }] : []));
    texto = computed(() => this.value() ?? '', ...(ngDevMode ? [{ debugName: "texto" }] : []));
    onInput(event) {
        this.setValue(event.target.value);
    }
    onBlur() {
        this.onTouched();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: STextareaComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: STextareaComponent, isStandalone: true, selector: "s-textarea", inputs: { maxlength: { classPropertyName: "maxlength", publicName: "maxlength", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "s-textarea" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => STextareaComponent),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: "@if (readOnly()) {\n  <div class=\"s-textarea__readonly\" [attr.id]=\"controlId()\">{{ texto() }}</div>\n} @else {\n  <textarea\n    class=\"s-textarea__nativo\"\n    [id]=\"controlId()\"\n    [attr.aria-label]=\"ariaLabel()\"\n    [sNativeValue]=\"texto()\"\n    [placeholder]=\"placeholder()\"\n    [disabled]=\"isDisabled()\"\n    [attr.maxlength]=\"maxlength()\"\n    [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.aria-required]=\"required() ? 'true' : null\"\n    [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy()\"\n    (input)=\"onInput($event)\"\n    (blur)=\"onBlur()\"\n  ></textarea>\n}\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%;--s-field-h: var(--textarea-h, 80px)}.s-textarea__nativo{box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;min-height:var(--s-field-h);padding:var(--space-12, 12px) var(--field-px, 16px);resize:vertical;line-height:var(--leading-normal, 1.45)}.s-textarea__nativo::placeholder{color:var(--text-secondary)}.s-textarea__nativo:hover:not(:disabled):not([aria-disabled=true]){border-color:var(--border);background:var(--card)}.s-textarea__nativo:focus,.s-textarea__nativo:focus-within{outline:none;border:2px solid var(--primary);background:var(--card);padding:0 15px}.s-textarea__nativo:disabled,.s-textarea__nativo[aria-disabled=true]{opacity:.4;cursor:default}.s-textarea__nativo[data-invalid=true]{border-color:var(--destructive)}.s-textarea__nativo:focus{padding:11px 15px}.s-textarea__readonly{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary);align-items:flex-start;padding:var(--space-12, 12px) var(--field-px, 16px);line-height:var(--leading-normal, 1.45);white-space:pre-wrap}\n"], dependencies: [{ kind: "directive", type: SNativeValueDirective, selector: "input[sNativeValue], textarea[sNativeValue]", inputs: ["sNativeValue"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: STextareaComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-textarea', imports: [SNativeValueDirective], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => STextareaComponent),
                            multi: true,
                        },
                    ], host: {
                        class: 's-textarea',
                    }, template: "@if (readOnly()) {\n  <div class=\"s-textarea__readonly\" [attr.id]=\"controlId()\">{{ texto() }}</div>\n} @else {\n  <textarea\n    class=\"s-textarea__nativo\"\n    [id]=\"controlId()\"\n    [attr.aria-label]=\"ariaLabel()\"\n    [sNativeValue]=\"texto()\"\n    [placeholder]=\"placeholder()\"\n    [disabled]=\"isDisabled()\"\n    [attr.maxlength]=\"maxlength()\"\n    [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.aria-required]=\"required() ? 'true' : null\"\n    [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy()\"\n    (input)=\"onInput($event)\"\n    (blur)=\"onBlur()\"\n  ></textarea>\n}\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%;--s-field-h: var(--textarea-h, 80px)}.s-textarea__nativo{box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;min-height:var(--s-field-h);padding:var(--space-12, 12px) var(--field-px, 16px);resize:vertical;line-height:var(--leading-normal, 1.45)}.s-textarea__nativo::placeholder{color:var(--text-secondary)}.s-textarea__nativo:hover:not(:disabled):not([aria-disabled=true]){border-color:var(--border);background:var(--card)}.s-textarea__nativo:focus,.s-textarea__nativo:focus-within{outline:none;border:2px solid var(--primary);background:var(--card);padding:0 15px}.s-textarea__nativo:disabled,.s-textarea__nativo[aria-disabled=true]{opacity:.4;cursor:default}.s-textarea__nativo[data-invalid=true]{border-color:var(--destructive)}.s-textarea__nativo:focus{padding:11px 15px}.s-textarea__readonly{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary);align-items:flex-start;padding:var(--space-12, 12px) var(--field-px, 16px);line-height:var(--leading-normal, 1.45);white-space:pre-wrap}\n"] }]
        }], propDecorators: { maxlength: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxlength", required: false }] }] } });

/**
 * Filtro de opcoes por texto, comum a select, multiselect e autocomplete.
 *
 * Ignora acento e caixa: quem digita "joao" precisa achar "João", e quem digita
 * "SAO" precisa achar "São Paulo". Busca em qualquer ponto do rotulo, nao so no
 * inicio - "silva" acha "Maria da Silva".
 */
/** Tira acento, caixa e espacos das pontas. */
function normalizarTexto(texto) {
    return texto
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .trim();
}
/** `true` quando o rotulo contem o termo, ignorando acento e caixa. */
function contemTermo(rotulo, termo) {
    const alvo = normalizarTexto(termo);
    return !alvo || normalizarTexto(rotulo).includes(alvo);
}

/**
 * Teclado do campo de busca no topo do painel de `<s-select>` e
 * `<s-multiselect>`.
 *
 * A busca fica dentro do painel do `mat-select`, e o foco fica nela. Sem
 * tratamento, o `mat-select` trata espaco como "selecionar" e letras como busca
 * por inicial - o texto nao entra. Segurar *todas* as teclas, porem, deixava o
 * painel inalcancavel pelo teclado: setas e Enter tambem nao chegavam.
 *
 * Aqui a busca fica com o texto e conduz a navegacao ela mesma:
 * - setas e PageUp/PageDown movem a opcao ativa, pulando as que o filtro
 *   escondeu;
 * - Enter escolhe a opcao ativa;
 * - Esc e Tab seguem para o `mat-select`, que fecha o painel como sempre;
 * - o resto (letras, espaco, Home/End) fica no campo de texto.
 *
 * A opcao ativa e anunciada pelo `aria-activedescendant` do proprio campo -
 * e nele que esta o foco, e nao no `mat-select`.
 */
/** Classe que o filtro poe na opcao que nao bate com o termo. */
const S_OPCAO_OCULTA = 's-painel__opcao--oculta';
const NAVEGACAO = new Set(['ArrowDown', 'ArrowUp', 'PageDown', 'PageUp']);
function oculta(opcao) {
    return opcao._getHostElement().classList.contains(S_OPCAO_OCULTA);
}
function teclaNaBusca(evento, seletor) {
    if (evento.key === 'Escape' || evento.key === 'Tab') {
        return;
    }
    evento.stopPropagation();
    const gerente = seletor?._keyManager;
    if (!seletor || !gerente) {
        return;
    }
    // Com o painel aberto, a opcao escondida pelo filtro nao pode ficar ativa -
    // Enter escolheria algo que o usuario nao ve. Desabilitadas continuam
    // alcancaveis, como o Material faz por recomendacao do padrao de listbox.
    // Fechado, vale a regra original do `mat-select`: pular as desabilitadas.
    gerente.skipPredicate((opcao) => (seletor.panelOpen ? oculta(opcao) : opcao.disabled));
    const ativa = gerente.activeItem && !oculta(gerente.activeItem) ? gerente.activeItem : null;
    if (NAVEGACAO.has(evento.key)) {
        evento.preventDefault();
        if (ativa) {
            gerente.onKeydown(evento);
        }
        else if (evento.key === 'ArrowUp' || evento.key === 'PageUp') {
            gerente.setLastItemActive();
        }
        else {
            gerente.setFirstItemActive();
        }
    }
    else if (evento.key === 'Enter') {
        evento.preventDefault();
        ativa?._selectViaInteraction();
    }
    else {
        return;
    }
    const id = gerente.activeItem && !oculta(gerente.activeItem) ? gerente.activeItem.id : null;
    const campo = evento.target;
    if (id) {
        campo.setAttribute('aria-activedescendant', id);
    }
    else {
        campo.removeAttribute('aria-activedescendant');
    }
}

/**
 * Escolha em dominio fechado, com a anatomia do input e chevron de 20px.
 *
 * Encapsula (por composicao) o `mat-select` - **sem** `mat-form-field`. O
 * `mat-select` injeta o campo do Material como opcional, entao da para ficar
 * so com o que ele tem de melhor (o painel em overlay, a navegacao por teclado,
 * a semantica de combobox) e desenhar a superficie com a regra do guia, em vez
 * de brigar com o rotulo flutuante do `mat-form-field`.
 *
 * Nunca use um campo de texto generico no lugar de uma escolha. Em card de
 * filtros, a opcao padrao e sempre "Todos".
 *
 * Opcoes com desenho proprio: `<ng-template sOption let-opcao>` dentro do
 * componente. Ver `SOptionTemplateDirective`.
 *
 * @example
 * ```html
 * <s-field label="Status">
 *   <s-select [options]="status" formControlName="status" placeholder="Todos" />
 * </s-field>
 * ```
 */
class SSelectComponent extends SControlBase {
    /** Opcoes exibidas no painel. */
    options = input([], ...(ngDevMode ? [{ debugName: "options" }] : []));
    /**
     * Compara valor selecionado com o valor da opcao.
     *
     * O padrao e igualdade estrita, que basta para id e string. Informe uma
     * funcao quando o valor for um objeto vindo de duas respostas diferentes da
     * API - sem isso, dois objetos iguais nao se reconhecem.
     */
    compareWith = input((a, b) => a === b, ...(ngDevMode ? [{ debugName: "compareWith" }] : []));
    /**
     * Mostra o botao de limpar quando ha valor.
     *
     * Sem ele, depois de escolher uma opcao nao ha como voltar ao "nada
     * escolhido" - so trocando por outra. Desligue quando o campo e obrigatorio
     * e o vazio nao e um estado valido.
     */
    clearable = input(true, ...(ngDevMode ? [{ debugName: "clearable", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Campo de busca no topo do painel.
     *
     * Ligue a partir de umas dez opcoes: rolar uma lista de 27 UFs e mais lento
     * que digitar "pa". O filtro ignora acento e caixa.
     */
    filterable = input(false, ...(ngDevMode ? [{ debugName: "filterable", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Texto de exemplo do campo de busca. */
    filterPlaceholder = input('Buscar', ...(ngDevMode ? [{ debugName: "filterPlaceholder" }] : []));
    /** Texto exibido quando a busca nao acha nenhuma opcao. */
    noResultsText = input('Nenhum resultado encontrado', ...(ngDevMode ? [{ debugName: "noResultsText" }] : []));
    /** Texto exibido quando nao ha nenhuma opcao para listar. */
    emptyText = input('Nenhum resultado foi encontrado.', ...(ngDevMode ? [{ debugName: "emptyText" }] : []));
    campo = usarCampo('s-select');
    busca = viewChild('busca', ...(ngDevMode ? [{ debugName: "busca" }] : []));
    seletor = viewChild(MatSelect, ...(ngDevMode ? [{ debugName: "seletor" }] : []));
    /** Desenho proprio da opcao, quando a aplicacao projeta um. */
    opcaoTemplate = contentChild(SOptionTemplateDirective, ...(ngDevMode ? [{ debugName: "opcaoTemplate" }] : []));
    controlId = this.campo.id;
    ariaLabel = this.campo.rotuloAvulso(this.label);
    describedBy = this.campo.describedBy;
    labelledBy = this.campo.rotuladoPor;
    required = this.campo.obrigatorio;
    isInvalid = computed(() => this.invalid() || this.campo.invalido(), ...(ngDevMode ? [{ debugName: "isInvalid" }] : []));
    /**
     * O `mat-select` escreve o proprio `aria-invalid` a partir do `errorState`,
     * que ele so recalcula quando tem um `NgControl` - aqui quem e controle de
     * formulario e este componente, entao ele ficava em `false` e vencia o
     * atributo da lib. O erro passa a ser entregue a ele.
     */
    sincronizaErro = effect(() => {
        const seletor = this.seletor();
        const invalido = this.isInvalid();
        if (seletor && seletor.errorState !== invalido) {
            seletor.errorState = invalido;
            seletor.stateChanges.next();
        }
    }, ...(ngDevMode ? [{ debugName: "sincronizaErro" }] : []));
    termo = signal('', ...(ngDevMode ? [{ debugName: "termo" }] : []));
    /** Opcoes que batem com a busca. As demais so ficam ocultas - ver o template. */
    visiveis = computed(() => {
        const termo = this.termo();
        return new Set(this.options().filter((opcao) => contemTermo(opcao.label, termo)));
    }, ...(ngDevMode ? [{ debugName: "visiveis" }] : []));
    semResultado = computed(() => this.options().length > 0 && this.visiveis().size === 0, ...(ngDevMode ? [{ debugName: "semResultado" }] : []));
    listaVazia = computed(() => this.options().length === 0, ...(ngDevMode ? [{ debugName: "listaVazia" }] : []));
    /** Valor da opcao sentinela: nunca e igual a nada que a aplicacao use. */
    sentinela = {};
    temValor = computed(() => this.value() !== null && this.value() !== undefined, ...(ngDevMode ? [{ debugName: "temValor" }] : []));
    /** Com valor, o "x" toma o lugar do chevron: os dois lado a lado competem. */
    mostraLimpar = computed(() => this.clearable() && this.temValor() && !this.isDisabled(), ...(ngDevMode ? [{ debugName: "mostraLimpar" }] : []));
    /** Rotulo da opcao selecionada, usado no modo somente-leitura. */
    textoSelecionado = computed(() => {
        const valor = this.value();
        if (valor === null || valor === undefined) {
            return '';
        }
        const comparar = this.compareWith();
        const opcao = this.options().find((o) => comparar(o.value, valor));
        return opcao?.label ?? '';
    }, ...(ngDevMode ? [{ debugName: "textoSelecionado" }] : []));
    selecionada(opcao) {
        const valor = this.value();
        return valor !== null && valor !== undefined && this.compareWith()(opcao.value, valor);
    }
    onSelectionChange(event) {
        this.setValue(event.value ?? null);
    }
    limpar(evento) {
        evento.stopPropagation();
        this.setValue(null);
        this.onTouched();
    }
    onOpenedChange(aberto) {
        if (aberto) {
            // O `mat-select` poe o foco na opcao ativa ao abrir; a busca pede o foco
            // de volta, senao o usuario abre o painel e a digitacao vai para o nada.
            // `preventScroll`: a busca fica num cabecalho fixo, e focar sem isso faz o
            // navegador rolar a lista para "mostrar" o campo, escondendo a primeira opcao.
            queueMicrotask(() => this.busca()?.nativeElement.focus({ preventScroll: true }));
            return;
        }
        this.termo.set('');
        this.onTouched();
    }
    onBusca(evento) {
        this.termo.set(evento.target.value);
    }
    /**
     * Passar pelo campo com Tab, sem abrir, tambem o marca como tocado - senao o
     * erro do `<s-field>` nunca aparecia para quem pula um obrigatorio. Com o
     * painel aberto o foco vai para a busca; ali quem marca e o fechamento.
     */
    aoSairDoCampo() {
        if (!this.seletor()?.panelOpen) {
            this.onTouched();
        }
    }
    /** Texto fica na busca; setas e Enter navegam no painel. Ver `teclaNaBusca`. */
    onBuscaKeydown(evento) {
        teclaNaBusca(evento, this.seletor());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SSelectComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SSelectComponent, isStandalone: true, selector: "s-select", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, compareWith: { classPropertyName: "compareWith", publicName: "compareWith", isSignal: true, isRequired: false, transformFunction: null }, clearable: { classPropertyName: "clearable", publicName: "clearable", isSignal: true, isRequired: false, transformFunction: null }, filterable: { classPropertyName: "filterable", publicName: "filterable", isSignal: true, isRequired: false, transformFunction: null }, filterPlaceholder: { classPropertyName: "filterPlaceholder", publicName: "filterPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, noResultsText: { classPropertyName: "noResultsText", publicName: "noResultsText", isSignal: true, isRequired: false, transformFunction: null }, emptyText: { classPropertyName: "emptyText", publicName: "emptyText", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "s-select" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SSelectComponent),
                multi: true,
            },
        ], queries: [{ propertyName: "opcaoTemplate", first: true, predicate: SOptionTemplateDirective, descendants: true, isSignal: true }], viewQueries: [{ propertyName: "busca", first: true, predicate: ["busca"], descendants: true, isSignal: true }, { propertyName: "seletor", first: true, predicate: MatSelect, descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "@if (readOnly()) {\n  <div class=\"s-select__readonly\" [attr.id]=\"controlId()\">{{ textoSelecionado() }}</div>\n} @else {\n  <div\n    class=\"s-select__campo\"\n    [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.data-disabled]=\"isDisabled() ? 'true' : null\"\n    [attr.data-limpavel]=\"mostraLimpar() ? 'true' : null\"\n  >\n    <mat-select\n      class=\"s-select__nativo\"\n      panelClass=\"s-select__painel\"\n      [id]=\"controlId()\"\n      [aria-label]=\"ariaLabel() ?? ''\"\n      [value]=\"value()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"isDisabled()\"\n      [required]=\"required()\"\n      [compareWith]=\"compareWith()\"\n      [aria-labelledby]=\"labelledBy() ?? ''\"\n      [attr.aria-describedby]=\"describedBy()\"\n      (selectionChange)=\"onSelectionChange($event)\"\n      (openedChange)=\"onOpenedChange($event)\"\n      (blur)=\"aoSairDoCampo()\"\n    >\n      @if (filterable()) {\n        <div class=\"s-painel__busca\">\n          <input\n            #busca\n            type=\"text\"\n            autocomplete=\"off\"\n            class=\"s-painel__busca-campo\"\n            role=\"combobox\"\n            aria-expanded=\"true\"\n            aria-autocomplete=\"list\"\n            [attr.aria-controls]=\"controlId() + '-panel'\"\n            [placeholder]=\"filterPlaceholder()\"\n            [attr.aria-label]=\"filterPlaceholder()\"\n            [sNativeValue]=\"termo()\"\n            (input)=\"onBusca($event)\"\n            (keydown)=\"onBuscaKeydown($event)\"\n          />\n        </div>\n      }\n\n      @if (semResultado()) {\n        <div class=\"s-painel__vazio\" role=\"status\">{{ noResultsText() }}</div>\n      }\n\n      @if (listaVazia()) {\n        <div class=\"s-painel__vazio\" role=\"status\">{{ emptyText() }}</div>\n        <!-- O `mat-select` nao abre sem nenhuma `mat-option`: sem esta sentinela,\n           oculta e desabilitada, a lista vazia nem chegava a mostrar o aviso. -->\n        <mat-option\n          class=\"s-painel__opcao--oculta\"\n          disabled\n          aria-hidden=\"true\"\n          [value]=\"sentinela\"\n        />\n      }\n\n      <!-- A opcao que nao bate com a busca some da vista, mas continua no\n         `mat-select`: e dela que ele tira o rotulo do gatilho, e removida o\n         campo fechado ficaria em branco. -->\n      @for (opcao of options(); track opcao.value) {\n        <mat-option\n          [value]=\"opcao.value\"\n          [disabled]=\"opcao.disabled ?? false\"\n          [class.s-painel__opcao--oculta]=\"!visiveis().has(opcao)\"\n        >\n          @if (opcaoTemplate(); as modelo) {\n            <ng-container\n              [ngTemplateOutlet]=\"modelo.template\"\n              [ngTemplateOutletContext]=\"{ $implicit: opcao, selected: selecionada(opcao) }\"\n            />\n          } @else {\n            {{ opcao.label }}\n          }\n        </mat-option>\n      }\n    </mat-select>\n\n    @if (mostraLimpar()) {\n      <s-icon-button\n        class=\"s-select__limpar\"\n        icon=\"close\"\n        label=\"Limpar sele\u00E7\u00E3o\"\n        size=\"sm\"\n        (click)=\"limpar($event)\"\n      />\n    }\n  </div>\n}\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%}.s-select__campo{--s-field-h: var(--field-h, 48px);box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;padding:0;position:relative;display:flex;align-items:center;gap:var(--space-8, 8px);cursor:pointer}.s-select__campo:hover:not([data-disabled=true]){border-color:var(--border);background:var(--card)}.s-select__campo:focus-within{border:2px solid var(--primary);background:var(--card)}.s-select__campo[data-invalid=true]{border-color:var(--destructive)}.s-select__campo[data-disabled=true]{opacity:.4;cursor:default}.s-select__nativo{display:flex;align-items:center;flex:1;min-width:0;height:var(--s-field-h, var(--field-h, 48px));font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);width:100%}:host ::ng-deep .s-select__nativo .mat-mdc-select-trigger{height:100%;padding:0 var(--field-px, 16px)}.s-select__readonly{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary)}:host ::ng-deep .s-select__campo[data-limpavel=true] .mat-mdc-select-arrow-wrapper{display:none}.s-select__limpar{position:absolute;top:50%;right:var(--space-8, 8px);transform:translateY(-50%)}:host ::ng-deep .s-select__campo[data-limpavel=true] .mat-mdc-select-trigger{padding-right:calc(var(--field-px, 16px) + var(--icon-sm, 20px) + var(--space-16, 16px) + var(--space-8, 8px))}:host ::ng-deep .mat-mdc-select-arrow{background-color:var(--text-secondary);width:var(--field-px, 20px);height:var(--icon-sm, 20px);-webkit-mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-344 240-584l56-56 184 184 184-184 56 56-240 240Z\"/></svg>');mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-344 240-584l56-56 184 184 184-184 56 56-240 240Z\"/></svg>');-webkit-mask-size:var(--icon-md, 24px);mask-size:var(--icon-md, 24px);-webkit-mask-position:center;mask-position:center}:host ::ng-deep .mat-mdc-select-arrow svg{display:none}:host ::ng-deep .mat-select-open .mat-mdc-select-arrow{transform:none;-webkit-mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-528 296-344l-56-56 240-240 240 240-56 56-184-184Z\"/></svg>');mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-528 296-344l-56-56 240-240 240 240-56 56-184-184Z\"/></svg>');-webkit-mask-size:var(--icon-md, 24px);mask-size:var(--icon-md, 24px);-webkit-mask-position:center;mask-position:center}:host ::ng-deep .mat-mdc-option .mdc-list-item__primary-text{font-family:var(--font-ui);font-size:var(--text-body, 14px)}\n"], dependencies: [{ kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i1$3.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: i1$3.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }, { kind: "directive", type: SNativeValueDirective, selector: "input[sNativeValue], textarea[sNativeValue]", inputs: ["sNativeValue"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-select', imports: [MatSelectModule, NgTemplateOutlet, SIconButtonComponent, SNativeValueDirective], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SSelectComponent),
                            multi: true,
                        },
                    ], host: {
                        class: 's-select',
                    }, template: "@if (readOnly()) {\n  <div class=\"s-select__readonly\" [attr.id]=\"controlId()\">{{ textoSelecionado() }}</div>\n} @else {\n  <div\n    class=\"s-select__campo\"\n    [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.data-disabled]=\"isDisabled() ? 'true' : null\"\n    [attr.data-limpavel]=\"mostraLimpar() ? 'true' : null\"\n  >\n    <mat-select\n      class=\"s-select__nativo\"\n      panelClass=\"s-select__painel\"\n      [id]=\"controlId()\"\n      [aria-label]=\"ariaLabel() ?? ''\"\n      [value]=\"value()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"isDisabled()\"\n      [required]=\"required()\"\n      [compareWith]=\"compareWith()\"\n      [aria-labelledby]=\"labelledBy() ?? ''\"\n      [attr.aria-describedby]=\"describedBy()\"\n      (selectionChange)=\"onSelectionChange($event)\"\n      (openedChange)=\"onOpenedChange($event)\"\n      (blur)=\"aoSairDoCampo()\"\n    >\n      @if (filterable()) {\n        <div class=\"s-painel__busca\">\n          <input\n            #busca\n            type=\"text\"\n            autocomplete=\"off\"\n            class=\"s-painel__busca-campo\"\n            role=\"combobox\"\n            aria-expanded=\"true\"\n            aria-autocomplete=\"list\"\n            [attr.aria-controls]=\"controlId() + '-panel'\"\n            [placeholder]=\"filterPlaceholder()\"\n            [attr.aria-label]=\"filterPlaceholder()\"\n            [sNativeValue]=\"termo()\"\n            (input)=\"onBusca($event)\"\n            (keydown)=\"onBuscaKeydown($event)\"\n          />\n        </div>\n      }\n\n      @if (semResultado()) {\n        <div class=\"s-painel__vazio\" role=\"status\">{{ noResultsText() }}</div>\n      }\n\n      @if (listaVazia()) {\n        <div class=\"s-painel__vazio\" role=\"status\">{{ emptyText() }}</div>\n        <!-- O `mat-select` nao abre sem nenhuma `mat-option`: sem esta sentinela,\n           oculta e desabilitada, a lista vazia nem chegava a mostrar o aviso. -->\n        <mat-option\n          class=\"s-painel__opcao--oculta\"\n          disabled\n          aria-hidden=\"true\"\n          [value]=\"sentinela\"\n        />\n      }\n\n      <!-- A opcao que nao bate com a busca some da vista, mas continua no\n         `mat-select`: e dela que ele tira o rotulo do gatilho, e removida o\n         campo fechado ficaria em branco. -->\n      @for (opcao of options(); track opcao.value) {\n        <mat-option\n          [value]=\"opcao.value\"\n          [disabled]=\"opcao.disabled ?? false\"\n          [class.s-painel__opcao--oculta]=\"!visiveis().has(opcao)\"\n        >\n          @if (opcaoTemplate(); as modelo) {\n            <ng-container\n              [ngTemplateOutlet]=\"modelo.template\"\n              [ngTemplateOutletContext]=\"{ $implicit: opcao, selected: selecionada(opcao) }\"\n            />\n          } @else {\n            {{ opcao.label }}\n          }\n        </mat-option>\n      }\n    </mat-select>\n\n    @if (mostraLimpar()) {\n      <s-icon-button\n        class=\"s-select__limpar\"\n        icon=\"close\"\n        label=\"Limpar sele\u00E7\u00E3o\"\n        size=\"sm\"\n        (click)=\"limpar($event)\"\n      />\n    }\n  </div>\n}\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%}.s-select__campo{--s-field-h: var(--field-h, 48px);box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;padding:0;position:relative;display:flex;align-items:center;gap:var(--space-8, 8px);cursor:pointer}.s-select__campo:hover:not([data-disabled=true]){border-color:var(--border);background:var(--card)}.s-select__campo:focus-within{border:2px solid var(--primary);background:var(--card)}.s-select__campo[data-invalid=true]{border-color:var(--destructive)}.s-select__campo[data-disabled=true]{opacity:.4;cursor:default}.s-select__nativo{display:flex;align-items:center;flex:1;min-width:0;height:var(--s-field-h, var(--field-h, 48px));font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);width:100%}:host ::ng-deep .s-select__nativo .mat-mdc-select-trigger{height:100%;padding:0 var(--field-px, 16px)}.s-select__readonly{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary)}:host ::ng-deep .s-select__campo[data-limpavel=true] .mat-mdc-select-arrow-wrapper{display:none}.s-select__limpar{position:absolute;top:50%;right:var(--space-8, 8px);transform:translateY(-50%)}:host ::ng-deep .s-select__campo[data-limpavel=true] .mat-mdc-select-trigger{padding-right:calc(var(--field-px, 16px) + var(--icon-sm, 20px) + var(--space-16, 16px) + var(--space-8, 8px))}:host ::ng-deep .mat-mdc-select-arrow{background-color:var(--text-secondary);width:var(--field-px, 20px);height:var(--icon-sm, 20px);-webkit-mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-344 240-584l56-56 184 184 184-184 56 56-240 240Z\"/></svg>');mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-344 240-584l56-56 184 184 184-184 56 56-240 240Z\"/></svg>');-webkit-mask-size:var(--icon-md, 24px);mask-size:var(--icon-md, 24px);-webkit-mask-position:center;mask-position:center}:host ::ng-deep .mat-mdc-select-arrow svg{display:none}:host ::ng-deep .mat-select-open .mat-mdc-select-arrow{transform:none;-webkit-mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-528 296-344l-56-56 240-240 240 240-56 56-184-184Z\"/></svg>');mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-528 296-344l-56-56 240-240 240 240-56 56-184-184Z\"/></svg>');-webkit-mask-size:var(--icon-md, 24px);mask-size:var(--icon-md, 24px);-webkit-mask-position:center;mask-position:center}:host ::ng-deep .mat-mdc-option .mdc-list-item__primary-text{font-family:var(--font-ui);font-size:var(--text-body, 14px)}\n"] }]
        }], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], compareWith: [{ type: i0.Input, args: [{ isSignal: true, alias: "compareWith", required: false }] }], clearable: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearable", required: false }] }], filterable: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterable", required: false }] }], filterPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterPlaceholder", required: false }] }], noResultsText: [{ type: i0.Input, args: [{ isSignal: true, alias: "noResultsText", required: false }] }], emptyText: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyText", required: false }] }], busca: [{ type: i0.ViewChild, args: ['busca', { isSignal: true }] }], seletor: [{ type: i0.ViewChild, args: [i0.forwardRef(() => MatSelect), { isSignal: true }] }], opcaoTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => SOptionTemplateDirective), { isSignal: true }] }] } });

/**
 * Fonte de dados do `<s-autocomplete>`.
 *
 * A biblioteca **nao faz HTTP**: nao importa `HttpClient`, nao conhece a URL
 * base da API, nao sabe o formato da resposta. Ela apenas descreve o pedido — a
 * aplicacao implementa esta classe e resolve como buscar.
 *
 * Foi o que permitiu trazer o atributo `url` do Professores sem trazer junto o
 * acoplamento: cada sistema (Professores, Gestor, Aluno) tem a sua camada de
 * API, e todos escrevem a mesma coisa no template.
 *
 * @example
 * ```ts
 * @Injectable({ providedIn: 'root' })
 * export class SiageAutocompleteSource extends SAutocompleteSource {
 *   private readonly api = inject(ApiService);
 *
 *   search({ url, term, params }: SAutocompleteQuery): Observable<SAutocompleteOption[]> {
 *     const busca = new URLSearchParams({ ...params, termo: term } as Record<string, string>);
 *     return this.api
 *       .get(`Autocomplete/${url}?${busca}`)
 *       .pipe(map((r) => r.body.data.map((i) => ({ label: i.descricao, value: i.id }))));
 *   }
 * }
 * ```
 */
class SAutocompleteSource {
}
/**
 * Registra a fonte de dados dos autocompletes da aplicacao.
 *
 * Necessario apenas quando alguma tela usa `<s-autocomplete url="...">`. Sem
 * `url`, o componente continua recebendo `options` da tela e nao consulta nada.
 *
 * ```ts
 * // app.config.ts
 * providers: [provideSiageAutocompleteSource(SiageAutocompleteSource)]
 * ```
 */
function provideSiageAutocompleteSource(source) {
    return makeEnvironmentProviders([{ provide: SAutocompleteSource, useExisting: source }]);
}

/**
 * Opcoes que chegam como objetos de dominio — `{ id, nome }` da API, um enum
 * `{ value, name }` — e entram inteiros no formulario.
 *
 * E o que `optionLabel` e `dataKey` fazem no `<s-autocomplete>` e no
 * `<s-multiselect>`: sem eles, a tela teria de converter cada lista para
 * `{ label, value }` e o formulario guardaria so o id.
 */
/** Rotulo de um objeto: a chave pedida, com os nomes usuais de reserva. */
function rotuloDoItem(item, chave) {
    if (item === null || item === undefined) {
        return '';
    }
    if (typeof item !== 'object') {
        return String(item);
    }
    const registro = item;
    return String(registro[chave] ?? registro['nome'] ?? registro['descricao'] ?? registro['name'] ?? '');
}
/**
 * Compara por uma chave (`id`), aceitando dos dois lados o objeto ou so a
 * chave: o formulario pode trazer `{ id: 3, nome }` ou `3`.
 */
function compararPorChave(chave) {
    const deCada = (valor) => valor !== null && typeof valor === 'object' ? valor[chave] : valor;
    return (a, b) => {
        if (a === b) {
            return true;
        }
        const ka = deCada(a);
        return ka !== null && ka !== undefined && ka === deCada(b);
    };
}
/** Com `optionLabel`, cada objeto vira uma opcao cujo valor e o proprio objeto. */
function normalizarOpcoes(lista, optionLabel) {
    if (!optionLabel) {
        return lista;
    }
    return lista.map((item) => ({
        label: rotuloDoItem(item, optionLabel),
        value: item,
        disabled: !!item?.disabled,
    }));
}

/** So as chaves preenchidas: a fonte que nao conhece as novas recebe o pedido de sempre. */
function extras$1(chaves) {
    return Object.fromEntries(Object.entries(chaves).filter(([, valor]) => valor));
}
/**
 * Escolha multipla em dominio fechado.
 *
 * Mesma anatomia do `<s-select>` - na verdade o mesmo `mat-select`, em modo
 * `multiple`, que ja desenha a caixa de selecao ao lado de cada opcao.
 *
 * **Nao esta no guia de design.** Entrou na biblioteca porque o Professores
 * usa selecao multipla em 14 lugares e o alternativo seria cada tela resolver
 * do seu jeito. Por isso segue a anatomia do campo a risca: quem olhar a tela
 * nao deve distinguir um `<s-select>` de um `<s-multiselect>` fechado.
 *
 * Ate `maxLabels` selecoes o gatilho lista os rotulos; acima disso passa a
 * mostrar a contagem, para o campo nao crescer nem truncar no meio de um nome.
 * No painel, rotulo longo quebra linha em vez de ser cortado.
 *
 * Em somente-leitura **todas** as selecoes aparecem, uma etiqueta por opcao,
 * quebrando linha: quem so le nao tem como abrir o painel para ver o resto.
 *
 * Opcoes com desenho proprio: `<ng-template sOption let-opcao>` dentro do
 * componente. Ver `SOptionTemplateDirective`.
 *
 * ## De onde vem a lista
 *
 * Como no multiselect do Professores e do Educacional, quem decide e o `url`:
 *
 * - **sem `url`**, a lista e `options`, e a busca (`filterable`) filtra por ela;
 * - **com `url`**, a busca aparece sempre, abrir o painel ja consulta e cada
 *   digitacao consulta de novo a `SAutocompleteSource` da aplicacao - a mesma
 *   fonte do `<s-autocomplete>`. A biblioteca nao faz HTTP.
 *
 * Com `url`, o que ja esta marcado continua marcado mesmo quando a busca atual
 * nao traz aquele item: ele sai da vista, nao do valor.
 */
class SMultiselectComponent extends SControlBase {
    /** Opcoes exibidas no painel. Com `url`, quem fornece a lista e a fonte. */
    options = input([], ...(ngDevMode ? [{ debugName: "options" }] : []));
    /**
     * Chave do rotulo quando `options` (ou a fonte) traz objetos de dominio.
     * Informada, cada **objeto inteiro** entra no array do formulario. Ver o
     * `<s-autocomplete>`.
     */
    optionLabel = input('', ...(ngDevMode ? [{ debugName: "optionLabel" }] : []));
    /** Chave que identifica o objeto (`id`). Vence `compareWith`. */
    dataKey = input('', ...(ngDevMode ? [{ debugName: "dataKey" }] : []));
    /** Nome do parametro do termo na busca por `url`. Vai para a fonte. */
    searchFor = input('', ...(ngDevMode ? [{ debugName: "searchFor" }] : []));
    /** Recurso onde `url` mora. Vai para a fonte. */
    controller = input('', ...(ngDevMode ? [{ debugName: "controller" }] : []));
    /**
     * Recurso a consultar, no lugar de `options`.
     *
     * Informado, o componente pede as opcoes a `SAutocompleteSource` que a
     * aplicacao registrou - ao abrir o painel e a cada digitacao na busca. Sem
     * `url`, a lista e `options` e a busca filtra localmente.
     */
    url = input('', ...(ngDevMode ? [{ debugName: "url" }] : []));
    /** Filtros adicionais enviados junto da busca. So tem efeito com `url`. */
    params = input({}, ...(ngDevMode ? [{ debugName: "params" }] : []));
    /** Caracteres minimos antes de consultar. `0` consulta ja ao abrir. So com `url`. */
    minLength = input(0, ...(ngDevMode ? [{ debugName: "minLength", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Espera entre a digitacao e a consulta, em ms. So tem efeito com `url`. */
    debounceTime = input(300, ...(ngDevMode ? [{ debugName: "debounceTime", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /**
     * Com `url`, consulta a fonte sem termo ao abrir o painel e filtra a lista no
     * navegador a cada digitacao. Para listas curtas — componentes, turmas —, em
     * que uma consulta por letra so custa viagens.
     */
    loadOnce = input(false, ...(ngDevMode ? [{ debugName: "loadOnce", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Texto exibido no painel enquanto a consulta por `url` corre. */
    loadingText = input('Carregando...', ...(ngDevMode ? [{ debugName: "loadingText" }] : []));
    /** Quantos rotulos cabem no gatilho antes de virar contagem. */
    maxLabels = input(2, ...(ngDevMode ? [{ debugName: "maxLabels", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Substantivo usado na contagem, no plural. */
    itemsLabel = input('selecionados', ...(ngDevMode ? [{ debugName: "itemsLabel" }] : []));
    /** Compara valor selecionado com o valor da opcao. Ver `<s-select>`. */
    compareWith = input((a, b) => a === b, ...(ngDevMode ? [{ debugName: "compareWith" }] : []));
    /**
     * Campo de busca no topo do painel. Ignora acento e caixa.
     *
     * Ligado por padrao, como no multiselect do PrimeNG; desligue com
     * `[filterable]="false"` numa lista curta, em que a busca so ocupa espaco.
     * Com busca ativa, a caixa de marcar todas vale so para as opcoes
     * encontradas - e o que permite "marcar todas as turmas do 9º ano". Com `url`
     * a busca aparece sempre: e ela que consulta a fonte.
     */
    filterable = input(true, ...(ngDevMode ? [{ debugName: "filterable", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Texto de exemplo do campo de busca. */
    filterPlaceholder = input('Buscar', ...(ngDevMode ? [{ debugName: "filterPlaceholder" }] : []));
    /** Texto exibido quando a busca nao acha nenhuma opcao. */
    noResultsText = input('Nenhum resultado encontrado', ...(ngDevMode ? [{ debugName: "noResultsText" }] : []));
    /** Texto exibido quando nao ha nenhuma opcao para listar. */
    emptyText = input('Nenhum resultado foi encontrado.', ...(ngDevMode ? [{ debugName: "emptyText" }] : []));
    /**
     * Caixa de "marcar todas" no topo do painel, ao lado da busca.
     *
     * Marca o que esta visivel; com tudo marcado, desmarca. Opcao desabilitada
     * nao muda de estado por ela: se veio marcada, continua.
     */
    selectAll = input(true, ...(ngDevMode ? [{ debugName: "selectAll", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Mostra o botao de limpar quando ha selecao, como no `<s-select>`.
     *
     * Desmarcar uma a uma, numa lista de vinte, e o que este botao poupa.
     * Desligue quando o campo e obrigatorio e o vazio nao e um estado valido.
     */
    clearable = input(true, ...(ngDevMode ? [{ debugName: "clearable", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Nome acessivel da caixa quando ela vai marcar todas. */
    selectAllLabel = input('Marcar todas', ...(ngDevMode ? [{ debugName: "selectAllLabel" }] : []));
    /** Nome acessivel da caixa quando ela vai desmarcar todas. */
    clearAllLabel = input('Desmarcar todas', ...(ngDevMode ? [{ debugName: "clearAllLabel" }] : []));
    campo = usarCampo('s-multiselect');
    fonte = inject(SAutocompleteSource, { optional: true });
    /** Opcoes que a fonte devolveu na ultima consulta. */
    buscadas = signal([], ...(ngDevMode ? [{ debugName: "buscadas" }] : []));
    buscando = signal(false, ...(ngDevMode ? [{ debugName: "buscando" }] : []));
    /**
     * Opcoes ja vistas que estao marcadas. Com `url`, e daqui que saem o rotulo e
     * a `mat-option` de um item marcado que a busca atual nao trouxe.
     */
    conhecidas = signal([], ...(ngDevMode ? [{ debugName: "conhecidas" }] : []));
    /** Valor da opcao sentinela: nunca e igual a nada que a aplicacao use. */
    sentinela = {};
    consultas = new Subject();
    /** `loadOnce`: a lista inteira, da primeira consulta. */
    carregadas = null;
    filtrarCarregadas(termo) {
        return (this.carregadas ?? []).filter((opcao) => contemTermo(opcao.label, termo));
    }
    aResolver = new Subject();
    busca = viewChild('busca', ...(ngDevMode ? [{ debugName: "busca" }] : []));
    seletor = viewChild(MatSelect, ...(ngDevMode ? [{ debugName: "seletor" }] : []));
    /** Desenho proprio da opcao, quando a aplicacao projeta um. */
    opcaoTemplate = contentChild(SOptionTemplateDirective, ...(ngDevMode ? [{ debugName: "opcaoTemplate" }] : []));
    controlId = this.campo.id;
    ariaLabel = this.campo.rotuloAvulso(this.label);
    describedBy = this.campo.describedBy;
    labelledBy = this.campo.rotuladoPor;
    required = this.campo.obrigatorio;
    isInvalid = computed(() => this.invalid() || this.campo.invalido(), ...(ngDevMode ? [{ debugName: "isInvalid" }] : []));
    /**
     * O `mat-select` escreve o proprio `aria-invalid` a partir do `errorState`,
     * que ele so recalcula quando tem um `NgControl` - aqui quem e controle de
     * formulario e este componente, entao ele ficava em `false` e vencia o
     * atributo da lib. O erro passa a ser entregue a ele.
     */
    sincronizaErro = effect(() => {
        const seletor = this.seletor();
        const invalido = this.isInvalid();
        if (seletor && seletor.errorState !== invalido) {
            seletor.errorState = invalido;
            seletor.stateChanges.next();
        }
    }, ...(ngDevMode ? [{ debugName: "sincronizaErro" }] : []));
    selecionados = computed(() => this.value() ?? [], ...(ngDevMode ? [{ debugName: "selecionados" }] : []));
    /** `options` no formato do painel. */
    opcoesBase = computed(() => normalizarOpcoes(this.options(), this.optionLabel()), ...(ngDevMode ? [{ debugName: "opcoesBase" }] : []));
    /** `dataKey` vence `compareWith`. */
    comparar = computed(() => {
        const chave = this.dataKey();
        return chave ? compararPorChave(chave) : this.compareWith();
    }, ...(ngDevMode ? [{ debugName: "comparar" }] : []));
    /** Com selecao, o "x" toma o lugar do chevron. */
    mostraLimpar = computed(() => this.clearable() && this.selecionados().length > 0 && !this.isDisabled(), ...(ngDevMode ? [{ debugName: "mostraLimpar" }] : []));
    termo = signal('', ...(ngDevMode ? [{ debugName: "termo" }] : []));
    comUrl = computed(() => !!this.url(), ...(ngDevMode ? [{ debugName: "comUrl" }] : []));
    mostraBusca = computed(() => this.filterable() || this.comUrl(), ...(ngDevMode ? [{ debugName: "mostraBusca" }] : []));
    /**
     * Tudo o que vira `mat-option`. Com `url`: o que a busca trouxe mais o que ja
     * esta marcado e ela nao trouxe - sem a opcao, o `mat-select` descartaria
     * esse valor no proximo clique.
     */
    opcoes = computed(() => {
        if (!this.comUrl()) {
            return this.opcoesBase();
        }
        const buscadas = this.buscadas();
        const comparar = this.comparar();
        const fora = this.conhecidas().filter((conhecida) => this.selecionada(conhecida) &&
            !buscadas.some((opcao) => comparar(opcao.value, conhecida.value)));
        return [...buscadas, ...fora];
    }, ...(ngDevMode ? [{ debugName: "opcoes" }] : []));
    visiveis = computed(() => {
        if (this.comUrl()) {
            return new Set(this.buscadas());
        }
        const termo = this.termo();
        return new Set(this.opcoesBase().filter((opcao) => contemTermo(opcao.label, termo)));
    }, ...(ngDevMode ? [{ debugName: "visiveis" }] : []));
    semResultado = computed(() => this.comUrl()
        ? !this.buscando() && this.visiveis().size === 0
        : this.opcoesBase().length > 0 && this.visiveis().size === 0, ...(ngDevMode ? [{ debugName: "semResultado" }] : []));
    listaVazia = computed(() => !this.comUrl() && this.opcoesBase().length === 0, ...(ngDevMode ? [{ debugName: "listaVazia" }] : []));
    /** Opcoes que as acoes em massa alcancam: visiveis e habilitadas. */
    alcancaveis = computed(() => this.opcoes().filter((opcao) => !opcao.disabled && this.visiveis().has(opcao)), ...(ngDevMode ? [{ debugName: "alcancaveis" }] : []));
    todasMarcadas = computed(() => {
        const alvo = this.alcancaveis();
        return alvo.length > 0 && alvo.every((opcao) => this.selecionada(opcao));
    }, ...(ngDevMode ? [{ debugName: "todasMarcadas" }] : []));
    nenhumaMarcada = computed(() => this.alcancaveis().every((opcao) => !this.selecionada(opcao)), ...(ngDevMode ? [{ debugName: "nenhumaMarcada" }] : []));
    temAlcancaveis = computed(() => this.alcancaveis().length > 0, ...(ngDevMode ? [{ debugName: "temAlcancaveis" }] : []));
    /** Estado da caixa do cabecalho: todas, nenhuma ou algumas das visiveis. */
    estadoTodas = computed(() => {
        if (this.todasMarcadas()) {
            return 'checked';
        }
        return this.nenhumaMarcada() ? 'unchecked' : 'indeterminate';
    }, ...(ngDevMode ? [{ debugName: "estadoTodas" }] : []));
    /** Rotulos das opcoes selecionadas, na ordem das opcoes. */
    rotulos = computed(() => this.opcoes()
        .filter((opcao) => this.selecionada(opcao))
        .map((opcao) => opcao.label), ...(ngDevMode ? [{ debugName: "rotulos" }] : []));
    constructor() {
        super();
        // Abrir consulta na hora; digitar espera o debounce. O `switchMap` descarta
        // a resposta de uma consulta que ja foi substituida por outra.
        this.consultas
            .pipe(debounce((consulta) => (consulta.imediata ? of(0) : timer(this.debounceTime()))), switchMap(({ termo }) => {
            const url = this.url();
            if (!url) {
                return EMPTY;
            }
            // Termo vazio (o painel abrindo) recarrega: os `params` podem ter mudado.
            if (this.loadOnce() && this.carregadas && termo) {
                return of(this.filtrarCarregadas(termo));
            }
            if (!this.loadOnce() && termo.length < this.minLength()) {
                this.buscadas.set([]);
                return EMPTY;
            }
            this.buscando.set(true);
            return this.exigirFonte()
                .search({
                url,
                term: this.loadOnce() ? '' : termo,
                params: this.params(),
                ...extras$1({
                    searchFor: this.searchFor(),
                    controller: this.controller(),
                    optionLabel: this.optionLabel(),
                }),
            })
                .pipe(
            // Uma busca que falha nao pode deixar o painel preso em "carregando".
            catchError(() => of([])), tap(() => this.buscando.set(false)), map((opcoes) => {
                if (!this.loadOnce()) {
                    return opcoes;
                }
                this.carregadas = opcoes;
                return this.filtrarCarregadas(termo);
            }), 
            // Ver `<s-autocomplete>`: cobre a consulta cancelada pelo `switchMap`.
            finalize(() => this.buscando.set(false)));
        }), takeUntilDestroyed())
            .subscribe((opcoes) => this.buscadas.set(opcoes));
        // Valor que chegou preenchido (tela de edicao): pede o rotulo de cada item
        // que ainda nao se conhece, se a fonte sabe resolver.
        this.aResolver
            .pipe(filter(() => !!this.url() && !!this.fonte?.resolve), mergeMap((valor) => this.fonte.resolve({
            url: this.url(),
            value: valor,
            params: this.params(),
            ...extras$1({ controller: this.controller(), optionLabel: this.optionLabel() }),
        }).pipe(catchError(() => of(null)))), takeUntilDestroyed())
            .subscribe((opcao) => {
            if (opcao) {
                this.lembrar([opcao]);
            }
        });
    }
    writeValue(valor) {
        super.writeValue(valor);
        if (!this.url()) {
            return;
        }
        const comparar = this.comparar();
        const vistas = [...this.conhecidas(), ...this.buscadas()];
        for (const item of valor ?? []) {
            if (vistas.some((opcao) => comparar(opcao.value, item))) {
                continue;
            }
            // Com `optionLabel`, o objeto que chegou ja diz o proprio rotulo.
            if (this.optionLabel() && item !== null && typeof item === 'object') {
                this.lembrar([{ label: rotuloDoItem(item, this.optionLabel()), value: item }]);
            }
            else {
                this.aResolver.next(item);
            }
        }
    }
    /** Texto do gatilho: os rotulos ate `maxLabels`, e a contagem acima disso. */
    resumo = computed(() => {
        const quantidade = this.selecionados().length;
        if (quantidade === 0) {
            return '';
        }
        return quantidade <= this.maxLabels()
            ? this.rotulos().join(', ')
            : `${quantidade} ${this.itemsLabel()}`;
    }, ...(ngDevMode ? [{ debugName: "resumo" }] : []));
    selecionada(opcao) {
        const comparar = this.comparar();
        return this.selecionados().some((valor) => comparar(opcao.value, valor));
    }
    onSelectionChange(event) {
        this.marcar(event.value ?? []);
    }
    marcarTodas() {
        const novos = this.alcancaveis()
            .filter((opcao) => !this.selecionada(opcao))
            .map((opcao) => opcao.value);
        this.marcar([...this.selecionados(), ...novos]);
    }
    /** Grava a selecao e guarda as opcoes marcadas, para o rotulo sobreviver a busca. */
    marcar(valores) {
        this.setValue(valores);
        if (this.comUrl()) {
            const comparar = this.comparar();
            this.lembrar(this.opcoes().filter((opcao) => valores.some((v) => comparar(opcao.value, v))));
        }
    }
    lembrar(novas) {
        const comparar = this.comparar();
        this.conhecidas.update((atuais) => [
            ...atuais,
            ...novas.filter((nova) => !atuais.some((opcao) => comparar(opcao.value, nova.value))),
        ]);
    }
    exigirFonte() {
        if (!this.fonte) {
            throw new Error('<s-multiselect url="..."> exige uma SAutocompleteSource. ' +
                'Registre provideSiageAutocompleteSource(...) no app.config.ts.');
        }
        return this.fonte;
    }
    alternarTodas() {
        if (this.todasMarcadas()) {
            this.desmarcarTodas();
        }
        else {
            this.marcarTodas();
        }
    }
    fechar() {
        this.seletor()?.close();
    }
    /** Esvazia a selecao inteira - inclusive o que a busca atual nao trouxe. */
    limpar(evento) {
        evento.stopPropagation();
        this.setValue([]);
        this.onTouched();
    }
    desmarcarTodas() {
        const comparar = this.comparar();
        const alvo = this.alcancaveis();
        this.setValue(this.selecionados().filter((valor) => !alvo.some((opcao) => comparar(opcao.value, valor))));
    }
    onOpenedChange(aberto) {
        if (aberto) {
            // `preventScroll`: a busca fica num cabecalho fixo, e focar sem isso faz o
            // navegador rolar a lista para "mostrar" o campo, escondendo a primeira opcao.
            queueMicrotask(() => this.busca()?.nativeElement.focus({ preventScroll: true }));
            this.consultas.next({ termo: this.termo(), imediata: true });
            return;
        }
        this.termo.set('');
        this.onTouched();
    }
    onBusca(evento) {
        const termo = evento.target.value;
        this.termo.set(termo);
        this.consultas.next({ termo, imediata: false });
    }
    /** Ver `<s-select>`: Tab pelo campo fechado tambem marca como tocado. */
    aoSairDoCampo() {
        if (!this.seletor()?.panelOpen) {
            this.onTouched();
        }
    }
    /** Texto fica na busca; setas e Enter navegam no painel. Ver `teclaNaBusca`. */
    onBuscaKeydown(evento) {
        teclaNaBusca(evento, this.seletor());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SMultiselectComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SMultiselectComponent, isStandalone: true, selector: "s-multiselect", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, optionLabel: { classPropertyName: "optionLabel", publicName: "optionLabel", isSignal: true, isRequired: false, transformFunction: null }, dataKey: { classPropertyName: "dataKey", publicName: "dataKey", isSignal: true, isRequired: false, transformFunction: null }, searchFor: { classPropertyName: "searchFor", publicName: "searchFor", isSignal: true, isRequired: false, transformFunction: null }, controller: { classPropertyName: "controller", publicName: "controller", isSignal: true, isRequired: false, transformFunction: null }, url: { classPropertyName: "url", publicName: "url", isSignal: true, isRequired: false, transformFunction: null }, params: { classPropertyName: "params", publicName: "params", isSignal: true, isRequired: false, transformFunction: null }, minLength: { classPropertyName: "minLength", publicName: "minLength", isSignal: true, isRequired: false, transformFunction: null }, debounceTime: { classPropertyName: "debounceTime", publicName: "debounceTime", isSignal: true, isRequired: false, transformFunction: null }, loadOnce: { classPropertyName: "loadOnce", publicName: "loadOnce", isSignal: true, isRequired: false, transformFunction: null }, loadingText: { classPropertyName: "loadingText", publicName: "loadingText", isSignal: true, isRequired: false, transformFunction: null }, maxLabels: { classPropertyName: "maxLabels", publicName: "maxLabels", isSignal: true, isRequired: false, transformFunction: null }, itemsLabel: { classPropertyName: "itemsLabel", publicName: "itemsLabel", isSignal: true, isRequired: false, transformFunction: null }, compareWith: { classPropertyName: "compareWith", publicName: "compareWith", isSignal: true, isRequired: false, transformFunction: null }, filterable: { classPropertyName: "filterable", publicName: "filterable", isSignal: true, isRequired: false, transformFunction: null }, filterPlaceholder: { classPropertyName: "filterPlaceholder", publicName: "filterPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, noResultsText: { classPropertyName: "noResultsText", publicName: "noResultsText", isSignal: true, isRequired: false, transformFunction: null }, emptyText: { classPropertyName: "emptyText", publicName: "emptyText", isSignal: true, isRequired: false, transformFunction: null }, selectAll: { classPropertyName: "selectAll", publicName: "selectAll", isSignal: true, isRequired: false, transformFunction: null }, clearable: { classPropertyName: "clearable", publicName: "clearable", isSignal: true, isRequired: false, transformFunction: null }, selectAllLabel: { classPropertyName: "selectAllLabel", publicName: "selectAllLabel", isSignal: true, isRequired: false, transformFunction: null }, clearAllLabel: { classPropertyName: "clearAllLabel", publicName: "clearAllLabel", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "s-multiselect" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SMultiselectComponent),
                multi: true,
            },
        ], queries: [{ propertyName: "opcaoTemplate", first: true, predicate: SOptionTemplateDirective, descendants: true, isSignal: true }], viewQueries: [{ propertyName: "busca", first: true, predicate: ["busca"], descendants: true, isSignal: true }, { propertyName: "seletor", first: true, predicate: MatSelect, descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "@if (readOnly()) {\n  <div class=\"s-multiselect__readonly\" [attr.id]=\"controlId()\">\n    @if (rotulos().length) {\n      <ul class=\"s-multiselect__etiquetas\">\n        @for (rotulo of rotulos(); track $index) {\n          <li class=\"s-multiselect__etiqueta\">{{ rotulo }}</li>\n        }\n      </ul>\n    }\n  </div>\n} @else {\n  <div\n    class=\"s-multiselect__campo\"\n    [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.data-disabled]=\"isDisabled() ? 'true' : null\"\n    [attr.data-limpavel]=\"mostraLimpar() ? 'true' : null\"\n  >\n    <mat-select\n      class=\"s-multiselect__nativo\"\n      panelClass=\"s-multiselect__painel\"\n      multiple\n      [id]=\"controlId()\"\n      [aria-label]=\"ariaLabel() ?? ''\"\n      [value]=\"selecionados()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"isDisabled()\"\n      [required]=\"required()\"\n      [compareWith]=\"comparar()\"\n      [aria-labelledby]=\"labelledBy() ?? ''\"\n      [attr.aria-describedby]=\"describedBy()\"\n      (selectionChange)=\"onSelectionChange($event)\"\n      (openedChange)=\"onOpenedChange($event)\"\n      (blur)=\"aoSairDoCampo()\"\n    >\n      <!-- Sem isto o Material lista todos os rotulos separados por virgula, e o\n         campo cresce ou trunca no meio de um nome. -->\n      <mat-select-trigger>{{ resumo() }}</mat-select-trigger>\n\n      <!-- Cabecalho numa linha so, fixo no topo do painel: marcar todas, busca e\n         fechar. Antes a busca era fixa e as acoes nao, e ao rolar uma passava\n         por baixo da outra. `mousedown.preventDefault` nos botoes mantem o foco\n         onde esta: sem isso o clique tira o foco do painel e o `mat-select`\n         fecha. -->\n      <div class=\"s-multiselect__cabecalho\">\n        @if (selectAll()) {\n          <button\n            type=\"button\"\n            role=\"checkbox\"\n            class=\"s-multiselect__todas\"\n            [attr.aria-checked]=\"estadoTodas() === 'indeterminate' ? 'mixed' : todasMarcadas()\"\n            [attr.aria-label]=\"todasMarcadas() ? clearAllLabel() : selectAllLabel()\"\n            [disabled]=\"!temAlcancaveis()\"\n            (mousedown)=\"$event.preventDefault()\"\n            (click)=\"alternarTodas()\"\n          >\n            <mat-pseudo-checkbox [state]=\"estadoTodas()\" [disabled]=\"!temAlcancaveis()\" />\n          </button>\n        }\n\n        @if (mostraBusca()) {\n          <div class=\"s-multiselect__busca\">\n            <input\n              #busca\n              type=\"text\"\n              autocomplete=\"off\"\n              class=\"s-painel__busca-campo s-multiselect__busca-campo\"\n              role=\"combobox\"\n              aria-expanded=\"true\"\n              aria-autocomplete=\"list\"\n              [attr.aria-controls]=\"controlId() + '-panel'\"\n              [placeholder]=\"filterPlaceholder()\"\n              [attr.aria-label]=\"filterPlaceholder()\"\n              [sNativeValue]=\"termo()\"\n              (input)=\"onBusca($event)\"\n              (keydown)=\"onBuscaKeydown($event)\"\n            />\n            <s-icon class=\"s-multiselect__lupa\" name=\"search\" size=\"sm\" variant=\"secondary\" />\n          </div>\n        } @else {\n          <span class=\"s-multiselect__espaco\"></span>\n        }\n\n        <s-icon-button\n          class=\"s-multiselect__fechar\"\n          icon=\"close\"\n          label=\"Fechar op\u00E7\u00F5es\"\n          size=\"sm\"\n          (mousedown)=\"$event.preventDefault()\"\n          (click)=\"fechar()\"\n        />\n      </div>\n\n      @if (buscando()) {\n        <div class=\"s-painel__vazio\" role=\"status\">{{ loadingText() }}</div>\n      }\n\n      @if (semResultado() && !buscando()) {\n        <div class=\"s-painel__vazio\" role=\"status\">{{ noResultsText() }}</div>\n      }\n\n      @if (listaVazia()) {\n        <div class=\"s-painel__vazio\" role=\"status\">{{ emptyText() }}</div>\n      }\n\n      @if (comUrl() || listaVazia()) {\n        <!-- O `mat-select` nao abre sem nenhuma `mat-option`: com `url` a lista\n           so chega depois que o painel abre, e sem `url` ela pode vir vazia.\n           Esta sentinela, oculta e desabilitada, e o que deixa abrir - para\n           disparar a primeira consulta ou mostrar o aviso de lista vazia. -->\n        <mat-option\n          class=\"s-painel__opcao--oculta\"\n          disabled\n          aria-hidden=\"true\"\n          [value]=\"sentinela\"\n        />\n      }\n\n      @for (opcao of opcoes(); track opcao.value) {\n        <mat-option\n          [value]=\"opcao.value\"\n          [disabled]=\"opcao.disabled ?? false\"\n          [class.s-painel__opcao--oculta]=\"!visiveis().has(opcao)\"\n        >\n          @if (opcaoTemplate(); as modelo) {\n            <ng-container\n              [ngTemplateOutlet]=\"modelo.template\"\n              [ngTemplateOutletContext]=\"{ $implicit: opcao, selected: selecionada(opcao) }\"\n            />\n          } @else {\n            {{ opcao.label }}\n          }\n        </mat-option>\n      }\n    </mat-select>\n\n    @if (mostraLimpar()) {\n      <s-icon-button\n        class=\"s-multiselect__limpar\"\n        icon=\"close\"\n        label=\"Limpar sele\u00E7\u00E3o\"\n        size=\"sm\"\n        (click)=\"limpar($event)\"\n      />\n    }\n  </div>\n}\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%}.s-multiselect__campo{--s-field-h: var(--field-h, 48px);box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;padding:0;position:relative;display:flex;align-items:center;gap:var(--space-8, 8px);cursor:pointer}.s-multiselect__campo:hover:not([data-disabled=true]){border-color:var(--border);background:var(--card)}.s-multiselect__campo:focus-within{border:2px solid var(--primary);background:var(--card)}.s-multiselect__campo[data-invalid=true]{border-color:var(--destructive)}.s-multiselect__campo[data-disabled=true]{opacity:.4;cursor:default}.s-multiselect__nativo{display:flex;align-items:center;flex:1;min-width:0;height:var(--s-field-h, var(--field-h, 48px));font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);width:100%}:host ::ng-deep .s-multiselect__nativo .mat-mdc-select-trigger{height:100%;padding:0 var(--field-px, 16px)}:host ::ng-deep .s-multiselect__nativo .mat-mdc-select-value-text{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.s-multiselect__readonly{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary);padding-block:var(--space-8, 8px)}.s-multiselect__etiquetas{display:flex;flex-wrap:wrap;gap:var(--space-8, 8px) var(--space-4, 4px);margin:0;padding:0;list-style:none}.s-multiselect__etiqueta{display:inline-flex;align-items:center;max-width:100%;min-height:var(--badge-h, 24px);padding:var(--space-4, 4px) var(--badge-px, 8px);border-radius:var(--radius-control, 8px);line-height:1.4;background:color-mix(in srgb,var(--primary) 18%,transparent);color:var(--text-primary);font-size:var(--text-label, 13px);overflow-wrap:anywhere}:host ::ng-deep .mat-mdc-select-arrow{background-color:var(--text-secondary);width:var(--field-px, 20px);height:var(--icon-sm, 20px);-webkit-mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-344 240-584l56-56 184 184 184-184 56 56-240 240Z\"/></svg>');mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-344 240-584l56-56 184 184 184-184 56 56-240 240Z\"/></svg>');-webkit-mask-size:var(--icon-md, 24px);mask-size:var(--icon-md, 24px);-webkit-mask-position:center;mask-position:center}:host ::ng-deep .mat-mdc-select-arrow svg{display:none}:host ::ng-deep .mat-select-open .mat-mdc-select-arrow{transform:none;-webkit-mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-528 296-344l-56-56 240-240 240 240-56 56-184-184Z\"/></svg>');mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-528 296-344l-56-56 240-240 240 240-56 56-184-184Z\"/></svg>');-webkit-mask-size:var(--icon-md, 24px);mask-size:var(--icon-md, 24px);-webkit-mask-position:center;mask-position:center}.s-multiselect__cabecalho{position:sticky;top:calc(var(--space-4, 4px) * -1);z-index:1;display:flex;align-items:center;gap:var(--space-8, 8px);padding:var(--space-8, 8px) var(--space-8, 8px) var(--space-8, 8px) var(--space-16, 16px);background:var(--card);border-bottom:1px solid var(--card-border)}.s-multiselect__todas{display:inline-flex;flex:0 0 auto;align-items:center;justify-content:center;padding:0;border:none;background:none;cursor:pointer}.s-multiselect__todas:disabled{cursor:default}.s-multiselect__todas:focus-visible{outline:2px solid var(--primary);outline-offset:2px;border-radius:var(--radius-control, 8px)}.s-multiselect__busca{position:relative;flex:1;min-width:0}.s-multiselect__busca-campo{padding-right:calc(var(--space-12, 12px) + var(--icon-sm, 20px) + var(--space-4, 4px))}.s-multiselect__busca-campo:focus{padding-right:calc(var(--space-12, 12px) + var(--icon-sm, 20px) + var(--space-4, 4px) - 1px)}.s-multiselect__lupa{position:absolute;top:50%;right:var(--space-12, 12px);transform:translateY(-50%);pointer-events:none}.s-multiselect__espaco{flex:1}.s-multiselect__fechar{flex:0 0 auto}:host ::ng-deep .mat-mdc-option .mdc-list-item__primary-text{font-family:var(--font-ui);font-size:var(--text-body, 14px)}:host ::ng-deep .s-multiselect__campo[data-limpavel=true] .mat-mdc-select-arrow-wrapper{display:none}.s-multiselect__limpar{position:absolute;top:50%;right:var(--space-8, 8px);transform:translateY(-50%)}:host ::ng-deep .s-multiselect__campo[data-limpavel=true] .mat-mdc-select-trigger{padding-right:calc(var(--field-px, 16px) + var(--icon-sm, 20px) + var(--space-16, 16px) + var(--space-8, 8px))}\n"], dependencies: [{ kind: "component", type: MatPseudoCheckbox, selector: "mat-pseudo-checkbox", inputs: ["state", "disabled", "appearance"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i1$3.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "directive", type: i1$3.MatSelectTrigger, selector: "mat-select-trigger" }, { kind: "component", type: i1$3.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }, { kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }, { kind: "directive", type: SNativeValueDirective, selector: "input[sNativeValue], textarea[sNativeValue]", inputs: ["sNativeValue"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SMultiselectComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-multiselect', imports: [
                        MatPseudoCheckbox,
                        MatSelectModule,
                        NgTemplateOutlet,
                        SIconButtonComponent,
                        SIconComponent,
                        SNativeValueDirective,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SMultiselectComponent),
                            multi: true,
                        },
                    ], host: {
                        class: 's-multiselect',
                    }, template: "@if (readOnly()) {\n  <div class=\"s-multiselect__readonly\" [attr.id]=\"controlId()\">\n    @if (rotulos().length) {\n      <ul class=\"s-multiselect__etiquetas\">\n        @for (rotulo of rotulos(); track $index) {\n          <li class=\"s-multiselect__etiqueta\">{{ rotulo }}</li>\n        }\n      </ul>\n    }\n  </div>\n} @else {\n  <div\n    class=\"s-multiselect__campo\"\n    [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.data-disabled]=\"isDisabled() ? 'true' : null\"\n    [attr.data-limpavel]=\"mostraLimpar() ? 'true' : null\"\n  >\n    <mat-select\n      class=\"s-multiselect__nativo\"\n      panelClass=\"s-multiselect__painel\"\n      multiple\n      [id]=\"controlId()\"\n      [aria-label]=\"ariaLabel() ?? ''\"\n      [value]=\"selecionados()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"isDisabled()\"\n      [required]=\"required()\"\n      [compareWith]=\"comparar()\"\n      [aria-labelledby]=\"labelledBy() ?? ''\"\n      [attr.aria-describedby]=\"describedBy()\"\n      (selectionChange)=\"onSelectionChange($event)\"\n      (openedChange)=\"onOpenedChange($event)\"\n      (blur)=\"aoSairDoCampo()\"\n    >\n      <!-- Sem isto o Material lista todos os rotulos separados por virgula, e o\n         campo cresce ou trunca no meio de um nome. -->\n      <mat-select-trigger>{{ resumo() }}</mat-select-trigger>\n\n      <!-- Cabecalho numa linha so, fixo no topo do painel: marcar todas, busca e\n         fechar. Antes a busca era fixa e as acoes nao, e ao rolar uma passava\n         por baixo da outra. `mousedown.preventDefault` nos botoes mantem o foco\n         onde esta: sem isso o clique tira o foco do painel e o `mat-select`\n         fecha. -->\n      <div class=\"s-multiselect__cabecalho\">\n        @if (selectAll()) {\n          <button\n            type=\"button\"\n            role=\"checkbox\"\n            class=\"s-multiselect__todas\"\n            [attr.aria-checked]=\"estadoTodas() === 'indeterminate' ? 'mixed' : todasMarcadas()\"\n            [attr.aria-label]=\"todasMarcadas() ? clearAllLabel() : selectAllLabel()\"\n            [disabled]=\"!temAlcancaveis()\"\n            (mousedown)=\"$event.preventDefault()\"\n            (click)=\"alternarTodas()\"\n          >\n            <mat-pseudo-checkbox [state]=\"estadoTodas()\" [disabled]=\"!temAlcancaveis()\" />\n          </button>\n        }\n\n        @if (mostraBusca()) {\n          <div class=\"s-multiselect__busca\">\n            <input\n              #busca\n              type=\"text\"\n              autocomplete=\"off\"\n              class=\"s-painel__busca-campo s-multiselect__busca-campo\"\n              role=\"combobox\"\n              aria-expanded=\"true\"\n              aria-autocomplete=\"list\"\n              [attr.aria-controls]=\"controlId() + '-panel'\"\n              [placeholder]=\"filterPlaceholder()\"\n              [attr.aria-label]=\"filterPlaceholder()\"\n              [sNativeValue]=\"termo()\"\n              (input)=\"onBusca($event)\"\n              (keydown)=\"onBuscaKeydown($event)\"\n            />\n            <s-icon class=\"s-multiselect__lupa\" name=\"search\" size=\"sm\" variant=\"secondary\" />\n          </div>\n        } @else {\n          <span class=\"s-multiselect__espaco\"></span>\n        }\n\n        <s-icon-button\n          class=\"s-multiselect__fechar\"\n          icon=\"close\"\n          label=\"Fechar op\u00E7\u00F5es\"\n          size=\"sm\"\n          (mousedown)=\"$event.preventDefault()\"\n          (click)=\"fechar()\"\n        />\n      </div>\n\n      @if (buscando()) {\n        <div class=\"s-painel__vazio\" role=\"status\">{{ loadingText() }}</div>\n      }\n\n      @if (semResultado() && !buscando()) {\n        <div class=\"s-painel__vazio\" role=\"status\">{{ noResultsText() }}</div>\n      }\n\n      @if (listaVazia()) {\n        <div class=\"s-painel__vazio\" role=\"status\">{{ emptyText() }}</div>\n      }\n\n      @if (comUrl() || listaVazia()) {\n        <!-- O `mat-select` nao abre sem nenhuma `mat-option`: com `url` a lista\n           so chega depois que o painel abre, e sem `url` ela pode vir vazia.\n           Esta sentinela, oculta e desabilitada, e o que deixa abrir - para\n           disparar a primeira consulta ou mostrar o aviso de lista vazia. -->\n        <mat-option\n          class=\"s-painel__opcao--oculta\"\n          disabled\n          aria-hidden=\"true\"\n          [value]=\"sentinela\"\n        />\n      }\n\n      @for (opcao of opcoes(); track opcao.value) {\n        <mat-option\n          [value]=\"opcao.value\"\n          [disabled]=\"opcao.disabled ?? false\"\n          [class.s-painel__opcao--oculta]=\"!visiveis().has(opcao)\"\n        >\n          @if (opcaoTemplate(); as modelo) {\n            <ng-container\n              [ngTemplateOutlet]=\"modelo.template\"\n              [ngTemplateOutletContext]=\"{ $implicit: opcao, selected: selecionada(opcao) }\"\n            />\n          } @else {\n            {{ opcao.label }}\n          }\n        </mat-option>\n      }\n    </mat-select>\n\n    @if (mostraLimpar()) {\n      <s-icon-button\n        class=\"s-multiselect__limpar\"\n        icon=\"close\"\n        label=\"Limpar sele\u00E7\u00E3o\"\n        size=\"sm\"\n        (click)=\"limpar($event)\"\n      />\n    }\n  </div>\n}\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%}.s-multiselect__campo{--s-field-h: var(--field-h, 48px);box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;padding:0;position:relative;display:flex;align-items:center;gap:var(--space-8, 8px);cursor:pointer}.s-multiselect__campo:hover:not([data-disabled=true]){border-color:var(--border);background:var(--card)}.s-multiselect__campo:focus-within{border:2px solid var(--primary);background:var(--card)}.s-multiselect__campo[data-invalid=true]{border-color:var(--destructive)}.s-multiselect__campo[data-disabled=true]{opacity:.4;cursor:default}.s-multiselect__nativo{display:flex;align-items:center;flex:1;min-width:0;height:var(--s-field-h, var(--field-h, 48px));font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);width:100%}:host ::ng-deep .s-multiselect__nativo .mat-mdc-select-trigger{height:100%;padding:0 var(--field-px, 16px)}:host ::ng-deep .s-multiselect__nativo .mat-mdc-select-value-text{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.s-multiselect__readonly{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary);padding-block:var(--space-8, 8px)}.s-multiselect__etiquetas{display:flex;flex-wrap:wrap;gap:var(--space-8, 8px) var(--space-4, 4px);margin:0;padding:0;list-style:none}.s-multiselect__etiqueta{display:inline-flex;align-items:center;max-width:100%;min-height:var(--badge-h, 24px);padding:var(--space-4, 4px) var(--badge-px, 8px);border-radius:var(--radius-control, 8px);line-height:1.4;background:color-mix(in srgb,var(--primary) 18%,transparent);color:var(--text-primary);font-size:var(--text-label, 13px);overflow-wrap:anywhere}:host ::ng-deep .mat-mdc-select-arrow{background-color:var(--text-secondary);width:var(--field-px, 20px);height:var(--icon-sm, 20px);-webkit-mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-344 240-584l56-56 184 184 184-184 56 56-240 240Z\"/></svg>');mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-344 240-584l56-56 184 184 184-184 56 56-240 240Z\"/></svg>');-webkit-mask-size:var(--icon-md, 24px);mask-size:var(--icon-md, 24px);-webkit-mask-position:center;mask-position:center}:host ::ng-deep .mat-mdc-select-arrow svg{display:none}:host ::ng-deep .mat-select-open .mat-mdc-select-arrow{transform:none;-webkit-mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-528 296-344l-56-56 240-240 240 240-56 56-184-184Z\"/></svg>');mask:url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24px\" viewBox=\"0 -960 960 960\" width=\"24px\" fill=\"%23e3e3e3\"><path d=\"M480-528 296-344l-56-56 240-240 240 240-56 56-184-184Z\"/></svg>');-webkit-mask-size:var(--icon-md, 24px);mask-size:var(--icon-md, 24px);-webkit-mask-position:center;mask-position:center}.s-multiselect__cabecalho{position:sticky;top:calc(var(--space-4, 4px) * -1);z-index:1;display:flex;align-items:center;gap:var(--space-8, 8px);padding:var(--space-8, 8px) var(--space-8, 8px) var(--space-8, 8px) var(--space-16, 16px);background:var(--card);border-bottom:1px solid var(--card-border)}.s-multiselect__todas{display:inline-flex;flex:0 0 auto;align-items:center;justify-content:center;padding:0;border:none;background:none;cursor:pointer}.s-multiselect__todas:disabled{cursor:default}.s-multiselect__todas:focus-visible{outline:2px solid var(--primary);outline-offset:2px;border-radius:var(--radius-control, 8px)}.s-multiselect__busca{position:relative;flex:1;min-width:0}.s-multiselect__busca-campo{padding-right:calc(var(--space-12, 12px) + var(--icon-sm, 20px) + var(--space-4, 4px))}.s-multiselect__busca-campo:focus{padding-right:calc(var(--space-12, 12px) + var(--icon-sm, 20px) + var(--space-4, 4px) - 1px)}.s-multiselect__lupa{position:absolute;top:50%;right:var(--space-12, 12px);transform:translateY(-50%);pointer-events:none}.s-multiselect__espaco{flex:1}.s-multiselect__fechar{flex:0 0 auto}:host ::ng-deep .mat-mdc-option .mdc-list-item__primary-text{font-family:var(--font-ui);font-size:var(--text-body, 14px)}:host ::ng-deep .s-multiselect__campo[data-limpavel=true] .mat-mdc-select-arrow-wrapper{display:none}.s-multiselect__limpar{position:absolute;top:50%;right:var(--space-8, 8px);transform:translateY(-50%)}:host ::ng-deep .s-multiselect__campo[data-limpavel=true] .mat-mdc-select-trigger{padding-right:calc(var(--field-px, 16px) + var(--icon-sm, 20px) + var(--space-16, 16px) + var(--space-8, 8px))}\n"] }]
        }], ctorParameters: () => [], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], optionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionLabel", required: false }] }], dataKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataKey", required: false }] }], searchFor: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchFor", required: false }] }], controller: [{ type: i0.Input, args: [{ isSignal: true, alias: "controller", required: false }] }], url: [{ type: i0.Input, args: [{ isSignal: true, alias: "url", required: false }] }], params: [{ type: i0.Input, args: [{ isSignal: true, alias: "params", required: false }] }], minLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "minLength", required: false }] }], debounceTime: [{ type: i0.Input, args: [{ isSignal: true, alias: "debounceTime", required: false }] }], loadOnce: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadOnce", required: false }] }], loadingText: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingText", required: false }] }], maxLabels: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxLabels", required: false }] }], itemsLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemsLabel", required: false }] }], compareWith: [{ type: i0.Input, args: [{ isSignal: true, alias: "compareWith", required: false }] }], filterable: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterable", required: false }] }], filterPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterPlaceholder", required: false }] }], noResultsText: [{ type: i0.Input, args: [{ isSignal: true, alias: "noResultsText", required: false }] }], emptyText: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyText", required: false }] }], selectAll: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectAll", required: false }] }], clearable: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearable", required: false }] }], selectAllLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectAllLabel", required: false }] }], clearAllLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearAllLabel", required: false }] }], busca: [{ type: i0.ViewChild, args: ['busca', { isSignal: true }] }], seletor: [{ type: i0.ViewChild, args: [i0.forwardRef(() => MatSelect), { isSignal: true }] }], opcaoTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => SOptionTemplateDirective), { isSignal: true }] }] } });

/**
 * Caixa de selecao da biblioteca `@siage/siage-ui`.
 *
 * Caixa de 20px com rotulo a direita, dentro de formularios **que sao salvos**.
 * Para alternancia com efeito imediato o componente e o `<s-switch>`.
 *
 * Nao envolve o `mat-checkbox`: o do Material desenha a propria caixa com
 * medidas e area de ripple fixas, e o guia especifica caixa de 20px com check
 * de 16px, sem ripple. Reproduzir isso por cima do Material daria mais CSS do
 * que o controle inteiro.
 *
 * O rotulo faz parte da area de clique — por isso o componente inteiro e um
 * `<label>`, e nao um `<div>` com um rotulo ao lado.
 */
class SCheckboxComponent extends SControlBase {
    /**
     * Estado visual indeterminado (traco, nao check).
     *
     * O valor do model continua sendo `boolean` — `indeterminate` e apenas uma
     * dica visual, nao um terceiro valor possivel. Util para checkbox de
     * cabecalho que representa uma selecao parcial.
     */
    indeterminate = input(false, ...(ngDevMode ? [{ debugName: "indeterminate", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Tres estados pelo clique: desmarcado -> marcado -> indeterminado ->
     * desmarcado. O valor do formulario vira `false`, `true` ou `null` — o
     * indeterminado aqui e um valor de verdade, para filtro do tipo "sim / nao /
     * tanto faz", e nao so a dica visual de `indeterminate`.
     *
     * `null` aparece como indeterminado: um `FormControl` sem valor inicial comeca
     * assim. Para comecar desmarcado, inicie o controle com `false`.
     */
    triState = input(false, ...(ngDevMode ? [{ debugName: "triState", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Nome para o leitor de tela quando nao ha `label` visivel, como na caixa de
     * selecao de uma linha de tabela. Vai no `<input>`, que e o que o leitor de
     * tela anuncia: um `aria-label` no host `<s-checkbox>` nao chega ate ele.
     * Com `label`, o rotulo visivel nomeia e este fica de fora.
     */
    ariaLabel = input('', ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
    nativoRef = viewChild('nativo', ...(ngDevMode ? [{ debugName: "nativoRef" }] : []));
    // Dentro de um <s-field>, o id, o erro e a obrigatoriedade vem dele, como nos
    // demais controles; fora, o controle se vira sozinho.
    campo = usarCampo('s-checkbox');
    controlId = this.campo.id;
    describedBy = this.campo.describedBy;
    required = this.campo.obrigatorio;
    isInvalid = computed(() => this.invalid() || this.campo.invalido(), ...(ngDevMode ? [{ debugName: "isInvalid" }] : []));
    marcado = computed(() => this.value() === true, ...(ngDevMode ? [{ debugName: "marcado" }] : []));
    /** Traco no lugar do check: pedido pela tela, ou o `null` do `triState`. */
    misto = computed(() => this.indeterminate() || (this.triState() && this.value() === null), ...(ngDevMode ? [{ debugName: "misto" }] : []));
    constructor() {
        super();
        // Sincroniza a propriedade DOM `indeterminate` com o signal — o Angular nao
        // expoe esse estado por binding de atributo.
        effect(() => {
            const valor = this.misto();
            const el = this.nativoRef()?.nativeElement;
            if (el) {
                el.indeterminate = valor;
            }
        });
    }
    onToggle(event) {
        const el = event.target;
        if (this.triState()) {
            // O navegador so alterna entre marcado e desmarcado; o terceiro estado e
            // daqui. O DOM e acertado na mao porque, de `null` para `false`, o
            // `[checked]` nao muda e o binding nao desfaria o check do navegador.
            const atual = this.value();
            const proximo = atual === false ? true : atual === true ? null : false;
            this.setValue(proximo);
            el.checked = proximo === true;
            el.indeterminate = proximo === null || this.indeterminate();
            return;
        }
        this.setValue(el.checked);
        // O clique zera `indeterminate` no DOM, mas o input continua como estava -
        // e o efeito acima nao roda de novo, porque o signal nao mudou. Sem isto o
        // traco seguia desenhado enquanto o leitor de tela ja nao ouvia "misto".
        // Quem decide o estado e quem passa o input (o cabecalho da tabela o
        // recalcula a partir da selecao).
        el.indeterminate = this.indeterminate();
    }
    onBlur() {
        this.onTouched();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SCheckboxComponent, isStandalone: true, selector: "s-checkbox", inputs: { indeterminate: { classPropertyName: "indeterminate", publicName: "indeterminate", isSignal: true, isRequired: false, transformFunction: null }, triState: { classPropertyName: "triState", publicName: "triState", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "s-checkbox" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SCheckboxComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "nativoRef", first: true, predicate: ["nativo"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "<label class=\"s-checkbox__area\" [attr.for]=\"controlId()\">\n  <!-- O <input> nativo continua no DOM, invisivel: e ele que carrega o foco, o\n       teclado e o estado para o leitor de tela. A caixa desenhada e decorativa. -->\n  <input\n    #nativo\n    class=\"s-checkbox__nativo\"\n    type=\"checkbox\"\n    [id]=\"controlId()\"\n    [checked]=\"marcado()\"\n    [disabled]=\"isDisabled()\"\n    [attr.aria-label]=\"label() ? null : ariaLabel() || null\"\n    [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy()\"\n    [attr.aria-required]=\"required() ? 'true' : null\"\n    [attr.aria-readonly]=\"readOnly() ? 'true' : null\"\n    (click)=\"barrarSeSomenteLeitura($event)\"\n    (change)=\"onToggle($event)\"\n    (blur)=\"onBlur()\"\n  />\n\n  <span\n    class=\"s-checkbox__caixa\"\n    [class.s-checkbox__caixa--invalid]=\"isInvalid()\"\n    [class.s-checkbox__caixa--indeterminada]=\"misto()\"\n    aria-hidden=\"true\"\n  >\n    @if (marcado() && !misto()) {\n      <s-icon name=\"check\" size=\"xs\" />\n    } @else if (misto()) {\n      <s-icon name=\"remove\" size=\"xs\" />\n    }\n  </span>\n\n  @if (label()) {\n    <span class=\"s-checkbox__rotulo\">{{ label() }}</span>\n  }\n</label>\n", styles: [":host{display:inline-flex}.s-checkbox__area{display:inline-flex;align-items:center;gap:var(--space-8, 8px);min-height:24px;cursor:pointer}.s-checkbox__nativo{position:absolute;width:1px;height:1px;opacity:0;margin:0}.s-checkbox__caixa{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;flex:0 0 20px;width:20px;height:20px;border-radius:4px;border:1px solid var(--border);background:var(--card);color:var(--on-filled);transition:background-color .15s ease,border-color .15s ease}.s-checkbox__rotulo{font-size:var(--text-body, 14px);color:var(--text-primary)}.s-checkbox__nativo:checked+.s-checkbox__caixa,.s-checkbox__caixa--indeterminada{border-color:var(--primary);background:var(--primary)}.s-checkbox__nativo:focus-visible+.s-checkbox__caixa{outline:none;box-shadow:0 0 0 2px var(--card),0 0 0 5px var(--focus-ring)}.s-checkbox__nativo:disabled+.s-checkbox__caixa{opacity:.4}.s-checkbox__nativo:disabled~.s-checkbox__rotulo{opacity:.4}.s-checkbox__area:has(.s-checkbox__nativo:disabled){cursor:default}.s-checkbox__caixa--invalid{border-color:var(--destructive)}.s-checkbox__area:has([aria-readonly=true]){cursor:default}\n"], dependencies: [{ kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SCheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-checkbox', imports: [SIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SCheckboxComponent),
                            multi: true,
                        },
                    ], host: {
                        class: 's-checkbox',
                    }, template: "<label class=\"s-checkbox__area\" [attr.for]=\"controlId()\">\n  <!-- O <input> nativo continua no DOM, invisivel: e ele que carrega o foco, o\n       teclado e o estado para o leitor de tela. A caixa desenhada e decorativa. -->\n  <input\n    #nativo\n    class=\"s-checkbox__nativo\"\n    type=\"checkbox\"\n    [id]=\"controlId()\"\n    [checked]=\"marcado()\"\n    [disabled]=\"isDisabled()\"\n    [attr.aria-label]=\"label() ? null : ariaLabel() || null\"\n    [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy()\"\n    [attr.aria-required]=\"required() ? 'true' : null\"\n    [attr.aria-readonly]=\"readOnly() ? 'true' : null\"\n    (click)=\"barrarSeSomenteLeitura($event)\"\n    (change)=\"onToggle($event)\"\n    (blur)=\"onBlur()\"\n  />\n\n  <span\n    class=\"s-checkbox__caixa\"\n    [class.s-checkbox__caixa--invalid]=\"isInvalid()\"\n    [class.s-checkbox__caixa--indeterminada]=\"misto()\"\n    aria-hidden=\"true\"\n  >\n    @if (marcado() && !misto()) {\n      <s-icon name=\"check\" size=\"xs\" />\n    } @else if (misto()) {\n      <s-icon name=\"remove\" size=\"xs\" />\n    }\n  </span>\n\n  @if (label()) {\n    <span class=\"s-checkbox__rotulo\">{{ label() }}</span>\n  }\n</label>\n", styles: [":host{display:inline-flex}.s-checkbox__area{display:inline-flex;align-items:center;gap:var(--space-8, 8px);min-height:24px;cursor:pointer}.s-checkbox__nativo{position:absolute;width:1px;height:1px;opacity:0;margin:0}.s-checkbox__caixa{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;flex:0 0 20px;width:20px;height:20px;border-radius:4px;border:1px solid var(--border);background:var(--card);color:var(--on-filled);transition:background-color .15s ease,border-color .15s ease}.s-checkbox__rotulo{font-size:var(--text-body, 14px);color:var(--text-primary)}.s-checkbox__nativo:checked+.s-checkbox__caixa,.s-checkbox__caixa--indeterminada{border-color:var(--primary);background:var(--primary)}.s-checkbox__nativo:focus-visible+.s-checkbox__caixa{outline:none;box-shadow:0 0 0 2px var(--card),0 0 0 5px var(--focus-ring)}.s-checkbox__nativo:disabled+.s-checkbox__caixa{opacity:.4}.s-checkbox__nativo:disabled~.s-checkbox__rotulo{opacity:.4}.s-checkbox__area:has(.s-checkbox__nativo:disabled){cursor:default}.s-checkbox__caixa--invalid{border-color:var(--destructive)}.s-checkbox__area:has([aria-readonly=true]){cursor:default}\n"] }]
        }], ctorParameters: () => [], propDecorators: { indeterminate: [{ type: i0.Input, args: [{ isSignal: true, alias: "indeterminate", required: false }] }], triState: [{ type: i0.Input, args: [{ isSignal: true, alias: "triState", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], nativoRef: [{ type: i0.ViewChild, args: ['nativo', { isSignal: true }] }] } });

/**
 * Alternancia booleana da biblioteca `@siage/siage-ui`.
 *
 * Use `<s-switch>` para estado que **aplica na hora**, sem botao de salvar; e
 * `<s-checkbox>` dentro de formulario que e salvo. A escolha entre os dois nao
 * e estetica: ela informa ao usuario se a mudanca ja valeu.
 *
 * Nao envolve o `mat-slide-toggle`, pelo mesmo motivo do checkbox: a trilha do
 * guia tem 44x24 com polegar de 20px, e o do Material vem com outra proporcao e
 * uma area de ripple que o design system nao usa.
 */
class SSwitchComponent extends SControlBase {
    /** Descricao para leitor de tela quando nao ha rotulo visivel. */
    ariaLabel = input('', ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
    /**
     * Emitido quando o usuario liga ou desliga, com o novo estado. E o gancho do
     * efeito imediato — salvar a preferencia, ativar o registro — sem
     * precisar de formulario. Nao dispara quando o valor muda pelo formulario
     * (`setValue`, `reset`, `patchValue`).
     *
     * Recebe sempre `boolean`: o `change` nativo do checkbox interno nao sobe ate
     * o `<s-switch>`, senao `(change)` na tela rodaria duas vezes, uma delas com
     * o `Event`.
     */
    change = output();
    // Dentro de um <s-field>, o id, o erro e a obrigatoriedade vem dele, como nos
    // demais controles; fora, o controle se vira sozinho.
    campo = usarCampo('s-switch');
    controlId = this.campo.id;
    describedBy = this.campo.describedBy;
    required = this.campo.obrigatorio;
    isInvalid = computed(() => this.invalid() || this.campo.invalido(), ...(ngDevMode ? [{ debugName: "isInvalid" }] : []));
    ligado = computed(() => this.value() === true, ...(ngDevMode ? [{ debugName: "ligado" }] : []));
    onToggle(event) {
        event.stopPropagation();
        const ligado = event.target.checked;
        this.setValue(ligado);
        this.change.emit(ligado);
    }
    onBlur() {
        this.onTouched();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SSwitchComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SSwitchComponent, isStandalone: true, selector: "s-switch", inputs: { ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { change: "change" }, host: { classAttribute: "s-switch" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SSwitchComponent),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: "<label class=\"s-switch__area\" [attr.for]=\"controlId()\">\n  <!-- `role=\"switch\"` e o que diferencia isto de um checkbox para o leitor de\n       tela: ele anuncia ligado/desligado, e nao marcado/desmarcado. -->\n  <input\n    class=\"s-switch__nativo\"\n    type=\"checkbox\"\n    role=\"switch\"\n    [id]=\"controlId()\"\n    [checked]=\"ligado()\"\n    [disabled]=\"isDisabled()\"\n    [attr.aria-label]=\"label() ? null : ariaLabel() || null\"\n    [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy()\"\n    [attr.aria-required]=\"required() ? 'true' : null\"\n    [attr.aria-readonly]=\"readOnly() ? 'true' : null\"\n    (click)=\"barrarSeSomenteLeitura($event)\"\n    (change)=\"onToggle($event)\"\n    (blur)=\"onBlur()\"\n  />\n\n  <span class=\"s-switch__trilha\" [class.s-switch__trilha--invalid]=\"isInvalid()\" aria-hidden=\"true\">\n    <span class=\"s-switch__polegar\"></span>\n  </span>\n\n  @if (label()) {\n    <span class=\"s-switch__rotulo\">{{ label() }}</span>\n  }\n</label>\n", styles: [":host{display:inline-flex}.s-switch__area{display:inline-flex;align-items:center;gap:var(--space-8, 8px);min-height:24px;cursor:pointer}.s-switch__nativo{position:absolute;width:1px;height:1px;opacity:0;margin:0}.s-switch__trilha{box-sizing:border-box;position:relative;flex:0 0 44px;width:44px;height:24px;border-radius:var(--radius-full, 9999px);background:color-mix(in srgb,var(--border) 60%,transparent);transition:background-color .15s ease}.s-switch__polegar{box-sizing:border-box;position:absolute;top:2px;left:2px;width:20px;height:20px;border-radius:var(--radius-full, 9999px);background:#fff;box-shadow:0 1px 2px #0003;transition:left .15s ease}.s-switch__rotulo{font-size:var(--text-body, 14px);color:var(--text-primary)}.s-switch__nativo:checked+.s-switch__trilha{background:var(--primary)}.s-switch__nativo:checked+.s-switch__trilha .s-switch__polegar{left:22px}.s-switch__nativo:focus-visible+.s-switch__trilha{outline:none;box-shadow:0 0 0 2px var(--card),0 0 0 5px var(--focus-ring)}.s-switch__nativo:disabled+.s-switch__trilha,.s-switch__nativo:disabled~.s-switch__rotulo{opacity:.4}.s-switch__area:has(.s-switch__nativo:disabled){cursor:default}.s-switch__trilha--invalid{border:1px solid var(--destructive)}@media(prefers-reduced-motion:reduce){.s-switch__polegar,.s-switch__trilha{transition:none}}.s-switch__area:has([aria-readonly=true]){cursor:default}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SSwitchComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-switch', changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SSwitchComponent),
                            multi: true,
                        },
                    ], host: {
                        class: 's-switch',
                    }, template: "<label class=\"s-switch__area\" [attr.for]=\"controlId()\">\n  <!-- `role=\"switch\"` e o que diferencia isto de um checkbox para o leitor de\n       tela: ele anuncia ligado/desligado, e nao marcado/desmarcado. -->\n  <input\n    class=\"s-switch__nativo\"\n    type=\"checkbox\"\n    role=\"switch\"\n    [id]=\"controlId()\"\n    [checked]=\"ligado()\"\n    [disabled]=\"isDisabled()\"\n    [attr.aria-label]=\"label() ? null : ariaLabel() || null\"\n    [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy()\"\n    [attr.aria-required]=\"required() ? 'true' : null\"\n    [attr.aria-readonly]=\"readOnly() ? 'true' : null\"\n    (click)=\"barrarSeSomenteLeitura($event)\"\n    (change)=\"onToggle($event)\"\n    (blur)=\"onBlur()\"\n  />\n\n  <span class=\"s-switch__trilha\" [class.s-switch__trilha--invalid]=\"isInvalid()\" aria-hidden=\"true\">\n    <span class=\"s-switch__polegar\"></span>\n  </span>\n\n  @if (label()) {\n    <span class=\"s-switch__rotulo\">{{ label() }}</span>\n  }\n</label>\n", styles: [":host{display:inline-flex}.s-switch__area{display:inline-flex;align-items:center;gap:var(--space-8, 8px);min-height:24px;cursor:pointer}.s-switch__nativo{position:absolute;width:1px;height:1px;opacity:0;margin:0}.s-switch__trilha{box-sizing:border-box;position:relative;flex:0 0 44px;width:44px;height:24px;border-radius:var(--radius-full, 9999px);background:color-mix(in srgb,var(--border) 60%,transparent);transition:background-color .15s ease}.s-switch__polegar{box-sizing:border-box;position:absolute;top:2px;left:2px;width:20px;height:20px;border-radius:var(--radius-full, 9999px);background:#fff;box-shadow:0 1px 2px #0003;transition:left .15s ease}.s-switch__rotulo{font-size:var(--text-body, 14px);color:var(--text-primary)}.s-switch__nativo:checked+.s-switch__trilha{background:var(--primary)}.s-switch__nativo:checked+.s-switch__trilha .s-switch__polegar{left:22px}.s-switch__nativo:focus-visible+.s-switch__trilha{outline:none;box-shadow:0 0 0 2px var(--card),0 0 0 5px var(--focus-ring)}.s-switch__nativo:disabled+.s-switch__trilha,.s-switch__nativo:disabled~.s-switch__rotulo{opacity:.4}.s-switch__area:has(.s-switch__nativo:disabled){cursor:default}.s-switch__trilha--invalid{border:1px solid var(--destructive)}@media(prefers-reduced-motion:reduce){.s-switch__polegar,.s-switch__trilha{transition:none}}.s-switch__area:has([aria-readonly=true]){cursor:default}\n"] }]
        }], propDecorators: { ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], change: [{ type: i0.Output, args: ["change"] }] } });

const LOCALE_PADRAO = 'pt-BR';
/** Quantos digitos cada parte aceita. */
const S_DATE_PART_LENGTH = { day: 2, month: 2, year: 4 };
/**
 * Monta a configuracao de data de um idioma, perguntando ao `Intl` em que ordem
 * e com que separador ele escreve uma data numerica.
 */
function criarConfigData(options = {}) {
    const locale = options.locale ?? LOCALE_PADRAO;
    const partes = new Intl.DateTimeFormat(locale, {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
    }).formatToParts(new Date(2026, 10, 22));
    const lidas = partes
        .map((parte) => parte.type)
        .filter((tipo) => tipo === 'day' || tipo === 'month' || tipo === 'year');
    const order = lidas.length === 3 ? lidas : ['day', 'month', 'year'];
    const separator = partes.find((parte) => parte.type === 'literal')?.value.trim() || '/';
    // O marcador do ano acompanha o idioma: "aaaa" para quem fala portugues.
    const ano = locale.toLowerCase().startsWith('pt') ? 'aaaa' : 'yyyy';
    const marcador = { day: 'dd', month: 'mm', year: ano };
    return {
        locale,
        order,
        separator,
        placeholder: options.placeholder ?? order.map((parte) => marcador[parte]).join(separator),
    };
}
/** Configuracao em uso. Sem `provideSiageDateAdapter()`, vale `pt-BR`. */
const S_DATE_CONFIG = new InjectionToken('S_DATE_CONFIG', {
    providedIn: 'root',
    factory: () => criarConfigData(),
});
/**
 * Aplica a mascara da data ao que foi digitado.
 *
 * So digitos passam; o separador entra sozinho entre as partes, e so quando ha
 * digito depois dele - assim o backspace nunca esbarra num separador que volta.
 */
function mascararData(texto, config) {
    let digitos = texto.replace(/\D/g, '');
    const grupos = [];
    for (const parte of config.order) {
        if (!digitos) {
            break;
        }
        grupos.push(digitos.slice(0, S_DATE_PART_LENGTH[parte]));
        digitos = digitos.slice(S_DATE_PART_LENGTH[parte]);
    }
    return grupos.join(config.separator);
}
/**
 * Chave do formato do campo. O nome e historico - o texto de fato segue a ordem
 * e o separador de `S_DATE_CONFIG`.
 */
const FORMATO_CAMPO = 'dd/MM/yyyy';
/**
 * Formatos de data do SIAGE.
 *
 * A entrada e a exibicao do campo seguem `S_DATE_CONFIG`; os rotulos
 * acessiveis do calendario ficam por extenso, que e o que o leitor de tela
 * anuncia.
 */
const S_DATE_FORMATS = {
    parse: {
        dateInput: FORMATO_CAMPO,
    },
    display: {
        dateInput: FORMATO_CAMPO,
        // Mes por extenso no cabecalho: "junho de 2043", e nao "jun. de 2043".
        monthYearLabel: { year: 'numeric', month: 'long' },
        dateA11yLabel: { year: 'numeric', month: 'long', day: 'numeric' },
        monthYearA11yLabel: { year: 'numeric', month: 'long' },
    },
};
/**
 * Adaptador de data que respeita a ordem do idioma.
 *
 * O `NativeDateAdapter` do Material delega a leitura de texto ao
 * `Date.parse` do navegador, que interpreta `03/04/2026` como 4 de marco -
 * ordem americana. Numa folha de ponto isso e um erro silencioso e caro, entao
 * `parse` e `format` seguem `S_DATE_CONFIG`.
 *
 * A extensao por heranca aqui e o ponto de extensao documentado do Material
 * para adaptadores; a regra de encapsular por composicao vale para componentes.
 */
class SDateAdapter extends NativeDateAdapter {
    config = inject(S_DATE_CONFIG);
    parse(value) {
        if (typeof value === 'string') {
            const texto = value.trim();
            if (!texto) {
                return null;
            }
            const partes = texto.split(this.config.separator);
            // Texto digitado que nao tem as tres partes numericas e data invalida - e
            // nao um convite para o `Date.parse` adivinhar.
            if (partes.length !== 3 || partes.some((parte) => !/^\d+$/.test(parte))) {
                return null;
            }
            const lido = { day: 0, month: 0, year: 0 };
            this.config.order.forEach((parte, indice) => (lido[parte] = Number(partes[indice])));
            if (partes[this.config.order.indexOf('year')].length !== 4) {
                return null;
            }
            if (lido.month < 1 || lido.month > 12) {
                return null;
            }
            const primeiro = this.createDate(lido.year, lido.month - 1, 1);
            // Recusa 31/02 em vez de deixar o Date rolar para 3 de marco.
            return lido.day >= 1 && lido.day <= this.getNumDaysInMonth(primeiro)
                ? this.createDate(lido.year, lido.month - 1, lido.day)
                : null;
        }
        return super.parse(value, null);
    }
    format(date, displayFormat) {
        if (displayFormat === FORMATO_CAMPO) {
            const valores = {
                day: `${this.getDate(date)}`.padStart(2, '0'),
                month: `${this.getMonth(date) + 1}`.padStart(2, '0'),
                year: `${this.getYear(date)}`,
            };
            return this.config.order.map((parte) => valores[parte]).join(this.config.separator);
        }
        return super.format(date, displayFormat);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SDateAdapter, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SDateAdapter });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SDateAdapter, decorators: [{
            type: Injectable
        }] });
/** Rotulos do calendario em portugues - os do Material vem em ingles. */
class SDatepickerIntl extends MatDatepickerIntl {
    calendarLabel = 'Calendário';
    openCalendarLabel = 'Abrir calendário';
    closeCalendarLabel = 'Fechar calendário';
    prevMonthLabel = 'Mês anterior';
    nextMonthLabel = 'Próximo mês';
    prevYearLabel = 'Ano anterior';
    nextYearLabel = 'Próximo ano';
    prevMultiYearLabel = '24 anos anteriores';
    nextMultiYearLabel = 'Próximos 24 anos';
    switchToMonthViewLabel = 'Escolher data';
    switchToMultiYearViewLabel = 'Escolher mês e ano';
    startDateLabel = 'Data inicial';
    endDateLabel = 'Data final';
    comparisonDateLabel = 'Período de comparação';
    formatYearRangeLabel(start, end) {
        return `${start} a ${end}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SDatepickerIntl, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SDatepickerIntl });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SDatepickerIntl, decorators: [{
            type: Injectable
        }] });
/**
 * Registra o adaptador de data da biblioteca na aplicacao.
 *
 * Necessario quando a aplicacao usa `<s-datepicker>`. Sem
 * ele o Material lanca erro em tempo de execucao pedindo um `DateAdapter`.
 *
 * O padrao e `pt-BR`. Para outro idioma, informe o codigo - a ordem das partes,
 * o separador e o texto de exemplo acompanham. Os rotulos do calendario so sao
 * traduzidos para portugues; em outro idioma ficam os do Material.
 *
 * ```ts
 * // app.config.ts
 * providers: [provideSiageDateAdapter()]            // pt-BR
 * providers: [provideSiageDateAdapter('en-US')]     // mm/dd/yyyy
 * providers: [provideSiageDateAdapter({ locale: 'pt-BR', placeholder: 'Ex.: 03/04/2026' })]
 * ```
 */
function provideSiageDateAdapter(options = LOCALE_PADRAO) {
    const config = criarConfigData(typeof options === 'string' ? { locale: options } : options);
    const portugues = config.locale.toLowerCase().startsWith('pt');
    return makeEnvironmentProviders([
        { provide: S_DATE_CONFIG, useValue: config },
        { provide: MAT_DATE_LOCALE, useValue: config.locale },
        // Sem `deps`: o `NativeDateAdapter` le o locale por `inject()`, entao ele
        // precisa ser construido dentro de um contexto de injecao.
        { provide: DateAdapter, useClass: SDateAdapter },
        { provide: MAT_DATE_FORMATS, useValue: S_DATE_FORMATS },
        ...(portugues ? [{ provide: MatDatepickerIntl, useClass: SDatepickerIntl }] : []),
    ]);
}

/**
 * Comportamento de digitacao comum as duas formas do `<s-datepicker>`: data e
 * periodo.
 *
 * Fica fora do template porque os tres campos nativos (data, inicio e fim)
 * precisam recusar letra e mascarar do mesmo jeito - divergir aqui e ter um
 * campo de data que aceita "abc" e outro que nao.
 */
/** Caracteres que o campo aceita: digito e o separador do idioma. */
function textoPermitido(texto, config) {
    return [...texto].every((caractere) => /\d/.test(caractere) || caractere === config.separator);
}
/**
 * Recusa letra antes que ela chegue ao campo.
 *
 * `beforeinput` pega digitacao, colagem e arrastar-e-soltar num lugar so -
 * `keydown` perderia a colagem pelo menu de contexto.
 */
function recusarLetras(evento, config) {
    const texto = evento.data ?? evento.dataTransfer?.getData('text') ?? '';
    if (texto && !textoPermitido(texto, config)) {
        evento.preventDefault();
    }
}
/**
 * Reescreve o valor do campo com a mascara.
 *
 * Quando o texto muda, o evento `input` e redisparado para o `matDatepicker`
 * reler o valor ja mascarado - a ordem entre o nosso ouvinte e o dele nao e
 * garantida. Na segunda passada o texto ja esta mascarado e nada se repete.
 */
function aplicarMascara(campo, config) {
    const mascarado = mascararData(campo.value, config);
    if (mascarado === campo.value) {
        return;
    }
    // Trocar o `value` por codigo manda o cursor para o fim: apagar um digito do
    // mes jogaria a pessoa para o ano. O cursor volta para depois do mesmo numero
    // de digitos que havia antes dele — os separadores mudam de lugar, os digitos
    // nao.
    const cursor = campo.selectionStart ?? campo.value.length;
    const digitosAntes = campo.value.slice(0, cursor).replace(/\D/g, '').length;
    campo.value = mascarado;
    if (campo.ownerDocument.activeElement === campo) {
        const posicao = posicaoAposDigitos(mascarado, digitosAntes);
        campo.setSelectionRange(posicao, posicao);
    }
    campo.dispatchEvent(new Event('input', { bubbles: true }));
}
/** Indice logo depois do `n`-esimo digito do texto (0 para nenhum). */
function posicaoAposDigitos(texto, n) {
    if (n === 0) {
        return 0;
    }
    let vistos = 0;
    for (let i = 0; i < texto.length; i++) {
        if (/\d/.test(texto[i]) && ++vistos === n) {
            return i + 1;
        }
    }
    return texto.length;
}
/** Tamanho maximo do texto: oito digitos e dois separadores. */
const S_DATE_MAX_LENGTH = 10;
/** `true` quando a data esta fora da faixa informada. */
function foraDaFaixa(data, min, max) {
    const dia = new Date(data.getFullYear(), data.getMonth(), data.getDate()).getTime();
    const inicio = min ? new Date(min.getFullYear(), min.getMonth(), min.getDate()).getTime() : null;
    const fim = max ? new Date(max.getFullYear(), max.getMonth(), max.getDate()).getTime() : null;
    return (inicio !== null && dia < inicio) || (fim !== null && dia > fim);
}

/**
 * Cabecalho proprio para o calendario: navegacao, atalhos, titulo do periodo.
 *
 * Substitui o cabecalho inteiro do Material - setas e botao de periodo
 * incluidos. O contexto traz o texto do periodo e as acoes de navegacao, que
 * respeitam `min` e `max`. Use botoes de verdade (`<s-icon-button>`), com os
 * rotulos de `previousLabel`/`nextLabel`: o calendario em overlay prende o foco,
 * e e pelo Tab que o teclado chega neles.
 *
 * @example
 * ```html
 * <s-datepicker formControlName="data">
 *   <ng-template sDatepickerHeader let-cal>
 *     <s-icon-button icon="chevron_left" [label]="cal.previousLabel"
 *       [disabled]="cal.previousDisabled" (click)="cal.previous()" />
 *     <strong>{{ cal.label }}</strong>
 *     <s-icon-button icon="chevron_right" [label]="cal.nextLabel"
 *       [disabled]="cal.nextDisabled" (click)="cal.next()" />
 *   </ng-template>
 * </s-datepicker>
 * ```
 */
class SDatepickerHeaderDirective {
    template = inject(TemplateRef);
    static ngTemplateContextGuard(_diretiva, contexto) {
        return true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SDatepickerHeaderDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.34", type: SDatepickerHeaderDirective, isStandalone: true, selector: "ng-template[sDatepickerHeader]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SDatepickerHeaderDirective, decorators: [{
            type: Directive,
            args: [{ selector: 'ng-template[sDatepickerHeader]' }]
        }] });
/**
 * Conteudo abaixo dos dias: legenda das marcas de `dateClass`, atalhos como
 * "Hoje" e "Limpar", um aviso sobre o prazo.
 *
 * Aparece no calendario de data e no de periodo. Para uma legenda com as
 * mesmas cores dos dias marcados, use as classes `s-datepicker-legend`,
 * `s-datepicker-legend__item` e `s-datepicker-mark s-datepicker-mark--<marca>`.
 *
 * @example
 * ```html
 * <s-datepicker formControlName="data" [dateClass]="marcar">
 *   <ng-template sDatepickerFooter let-cal>
 *     <s-button variant="ghost" (click)="cal.select(hoje)">Hoje</s-button>
 *     <s-button variant="ghost" [disabled]="!cal.value" (click)="cal.select(null)">Limpar</s-button>
 *   </ng-template>
 * </s-datepicker>
 * ```
 */
class SDatepickerFooterDirective {
    template = inject(TemplateRef);
    static ngTemplateContextGuard(_diretiva, contexto) {
        return true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SDatepickerFooterDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.34", type: SDatepickerFooterDirective, isStandalone: true, selector: "ng-template[sDatepickerFooter]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SDatepickerFooterDirective, decorators: [{
            type: Directive,
            args: [{ selector: 'ng-template[sDatepickerFooter]' }]
        }] });
/**
 * Liga o calendario ao `<s-datepicker>`. O overlay e criado no injetor do
 * elemento, entao o token chega la sem import circular entre os dois arquivos.
 */
const S_DATEPICKER_SLOTS = new InjectionToken('S_DATEPICKER_SLOTS');
/**
 * Cabecalho que o `<s-datepicker>` entrega ao `mat-calendar` quando ha
 * template. Herda a navegacao do `MatCalendarHeader` - rotulos, limites,
 * paginas de anos - e so troca o desenho.
 *
 * O rodape mora aqui tambem porque o Material so tem dois encaixes no
 * calendario: o cabecalho e as `mat-datepicker-actions`. As actions seguram a
 * selecao ate um "Aplicar" - clicar no dia deixaria de gravar. Com o host em
 * `display: contents` e o `mat-calendar` em coluna, o rodape desce para baixo
 * dos dias pelo `order`.
 *
 * @internal
 */
class SDatepickerCalendarHeaderComponent extends MatCalendarHeader {
    slots = inject(S_DATEPICKER_SLOTS);
    /**
     * Objeto unico com getters: o `ngTemplateOutlet` reaproveita a view, e cada
     * deteccao (o `MatCalendarHeader` marca a cada mudanca do calendario) le os
     * valores atuais.
     */
    contexto = this.criarContexto();
    criarContexto() {
        // eslint-disable-next-line @typescript-eslint/no-this-alias
        const cabecalho = this;
        const calendario = this.calendar;
        const contexto = {
            get $implicit() {
                return contexto;
            },
            get label() {
                return cabecalho.periodButtonText;
            },
            get view() {
                return calendario.currentView;
            },
            get activeDate() {
                return calendario.activeDate;
            },
            get previousDisabled() {
                return !cabecalho.previousEnabled();
            },
            get nextDisabled() {
                return !cabecalho.nextEnabled();
            },
            get previousLabel() {
                return cabecalho.prevButtonLabel;
            },
            get nextLabel() {
                return cabecalho.nextButtonLabel;
            },
            previous: () => this.previousClicked(),
            next: () => this.nextClicked(),
            toggleView: () => this.currentPeriodClicked(),
            setView: (view) => (calendario.currentView = view),
            goTo: (date) => (calendario.activeDate = date),
        };
        return contexto;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SDatepickerCalendarHeaderComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SDatepickerCalendarHeaderComponent, isStandalone: true, selector: "s-datepicker-calendar-header", host: { classAttribute: "s-datepicker-calendar" }, usesInheritance: true, ngImport: i0, template: `
    <div class="s-datepicker-calendar__header">
      @if (slots.headerTemplate(); as cabecalho) {
        <ng-container [ngTemplateOutlet]="cabecalho" [ngTemplateOutletContext]="contexto" />
      } @else {
        <mat-calendar-header />
      }
    </div>

    @if (slots.footerTemplate(); as rodape) {
      <div class="s-datepicker-calendar__footer">
        <ng-container [ngTemplateOutlet]="rodape" [ngTemplateOutletContext]="slots.footerContext" />
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: MatCalendarHeader, selector: "mat-calendar-header", exportAs: ["matCalendarHeader"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SDatepickerCalendarHeaderComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 's-datepicker-calendar-header',
                    imports: [NgTemplateOutlet, MatCalendarHeader],
                    template: `
    <div class="s-datepicker-calendar__header">
      @if (slots.headerTemplate(); as cabecalho) {
        <ng-container [ngTemplateOutlet]="cabecalho" [ngTemplateOutletContext]="contexto" />
      } @else {
        <mat-calendar-header />
      }
    </div>

    @if (slots.footerTemplate(); as rodape) {
      <div class="s-datepicker-calendar__footer">
        <ng-container [ngTemplateOutlet]="rodape" [ngTemplateOutletContext]="slots.footerContext" />
      </div>
    }
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: { class: 's-datepicker-calendar' },
                }]
        }] });

/**
 * Rotulos do calendario no idioma do campo.
 *
 * O `MatDatepickerModule` registra o proprio `MatDatepickerIntl` (em ingles) no
 * injetor do componente standalone que o importa — e esse vence o que a
 * aplicacao registrou. Declarado aqui, no elemento, chega ao calendario do
 * overlay antes dele.
 */
function rotulosDoCalendario() {
    const config = inject(S_DATE_CONFIG);
    return config.locale.toLowerCase().startsWith('pt')
        ? new SDatepickerIntl()
        : new MatDatepickerIntl();
}
function comoPeriodo(valor) {
    if (valor instanceof Date) {
        return { start: valor, end: null };
    }
    return { start: valor?.start ?? null, end: valor?.end ?? null };
}
function comoData(valor) {
    return valor instanceof Date ? valor : (valor?.start ?? null);
}
/**
 * Campo de data da biblioteca `@siage/siage-ui` — uma data ou um periodo.
 *
 * Encapsula (por composicao) o `matDatepicker` - **sem** `mat-form-field`, como
 * o `<s-select>`. A superficie e a mesma dos demais campos; o que vem do
 * Material e o calendario em overlay, a navegacao por teclado e a leitura de
 * datas.
 *
 * Clicar no campo abre o calendario, e a digitacao continua disponivel: so
 * aceita digitos, com a mascara do idioma (`dd/mm/aaaa` em `pt-BR`). Data que
 * nao existe, incompleta ou fora de `min`/`max` e apagada ao sair do campo e o
 * formulario recebe `null` - manter a ultima data valida faria o usuario
 * acreditar que o que digitou foi aceito.
 *
 * ## Periodo
 *
 * Com `range`, o mesmo campo recebe **uma ou duas datas** e o valor vira um
 * `SDateRange` (`{ start, end }`). Um filtro "a partir de" e so o inicio; o
 * separador "a" so aparece quando ha fim para separar. Para exigir as duas
 * pontas, ligue `requireEnd`: o periodo sem fim fica invalido com o erro
 * `sDateRangeIncomplete`, que o `<s-field>` ja traduz.
 *
 * Cada ponta e validada sozinha: data invalida ou fora de `min`/`max` e apagada
 * sem levar a outra junto. Fim antes do inicio tambem e apagado - um periodo
 * invertido nao filtra nada e nao avisa ninguem. Sem nenhuma das duas, o valor
 * e `null`, para `Validators.required` funcionar como num campo comum.
 *
 * **Nao esta no guia de design**, que nao define calendario. Segue a anatomia
 * do campo e o tamanho de icone de controle (20px).
 *
 * ## Templates
 *
 * O calendario aceita dois `ng-template` para desenho proprio, nos dois modos
 * (data e periodo):
 *
 * - `sDatepickerHeader` substitui o cabecalho (setas e periodo) e recebe a
 *   navegacao pronta, respeitando `min`/`max`;
 * - `sDatepickerFooter` entra abaixo dos dias - legenda, "Hoje", "Limpar" - e
 *   recebe o valor com `select()` e `close()`.
 *
 * Os dias continuam do Material, que nao aceita template de celula: para
 * pinta-los use `dateClass`.
 *
 * A aplicacao precisa registrar `provideSiageDateAdapter()` uma vez, no
 * `app.config.ts` - e o que ensina o Material a ler e escrever a data no idioma
 * escolhido (padrao `pt-BR`).
 *
 * @example
 * ```html
 * <s-field label="Data da aula" required>
 *   <s-datepicker formControlName="data" [max]="hoje" />
 * </s-field>
 *
 * <s-field label="Período">
 *   <s-datepicker formControlName="periodo" range />
 * </s-field>
 *
 * <s-datepicker formControlName="data">
 *   <ng-template sDatepickerFooter let-cal>
 *     <s-button variant="ghost" (click)="cal.select(hoje)">Hoje</s-button>
 *   </ng-template>
 * </s-datepicker>
 * ```
 */
class SDatepickerComponent extends SControlBase {
    /**
     * Transforma o campo em periodo: aceita uma ou duas datas e o valor passa a
     * ser `SDateRange`. O calendario marca o inicio e o fim de uma vez.
     */
    range = input(false, ...(ngDevMode ? [{ debugName: "range", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Com `range`, exige as duas datas. O periodo so com inicio fica invalido
     * (`sDateRangeIncomplete`) — sem isso, uma data so e um periodo valido.
     */
    requireEnd = input(false, ...(ngDevMode ? [{ debugName: "requireEnd", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Primeira data selecionavel. Data digitada antes dela e apagada. */
    min = input(null, ...(ngDevMode ? [{ debugName: "min" }] : []));
    /** Ultima data selecionavel. Data digitada depois dela e apagada. */
    max = input(null, ...(ngDevMode ? [{ debugName: "max" }] : []));
    /** Impede a digitacao, deixando apenas a escolha pelo calendario. */
    pickerOnly = input(false, ...(ngDevMode ? [{ debugName: "pickerOnly", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Abre o calendario ao clicar no campo.
     *
     * Desligue quando a tela e de lancamento em massa e o usuario digita as
     * datas: o calendario abrindo a cada clique atrapalha quem ja sabe o dia.
     */
    openOnClick = input(true, ...(ngDevMode ? [{ debugName: "openOnClick", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Com `range`: texto de exemplo da data inicial. Padrao: o formato do idioma. */
    startPlaceholder = input('', ...(ngDevMode ? [{ debugName: "startPlaceholder" }] : []));
    /** Com `range`: texto de exemplo da data final. Padrao: o formato do idioma. */
    endPlaceholder = input('', ...(ngDevMode ? [{ debugName: "endPlaceholder" }] : []));
    /** Com `range`: rotulo acessivel da data inicial. */
    startLabel = input('Data inicial', ...(ngDevMode ? [{ debugName: "startLabel" }] : []));
    /** Com `range`: rotulo acessivel da data final. */
    endLabel = input('Data final', ...(ngDevMode ? [{ debugName: "endLabel" }] : []));
    /**
     * Primeira tela aberta pelo calendario.
     *
     * Use `year` quando a escolha costuma ser mensal, e `multi-year` quando a
     * tela precisa navegar rapido entre anos. A selecao continua sendo diaria a
     * menos que `selectionMode` tambem seja ajustado.
     */
    startView = input('month', ...(ngDevMode ? [{ debugName: "startView" }] : []));
    /** Mes ou ano inicial do calendario quando o valor ainda esta vazio. */
    startAt = input(null, ...(ngDevMode ? [{ debugName: "startAt" }] : []));
    /**
     * Granularidade gravada no formulario.
     *
     * `month` grava o primeiro dia do mes escolhido; `year` grava 1º de janeiro.
     * Essa convencao entrega um `Date` simples para relatorios mensais/anuais sem
     * inventar outro tipo de valor. Em `range`, a granularidade permanece diaria.
     */
    selectionMode = input('date', ...(ngDevMode ? [{ debugName: "selectionMode" }] : []));
    /**
     * Marca dias com semantica do design system, e nao com classes da aplicacao.
     *
     * O calendario do Material vive em overlay; CSS da tela consumidora nao
     * atravessa esse encapsulamento de forma confiavel. Por isso a API recebe
     * `success`, `warning`, `destructive`, `info` ou `muted`, e a biblioteca
     * mapeia para tokens. A marca visual nao basta para acessibilidade: explique o
     * significado numa legenda no `<ng-template sDatepickerFooter>` e, quando a
     * regra exigir detalhe por dia, no texto/fluxo da propria tela.
     */
    dateClass = input(null, ...(ngDevMode ? [{ debugName: "dateClass" }] : []));
    cabecalhoDiretiva = contentChild(SDatepickerHeaderDirective, ...(ngDevMode ? [{ debugName: "cabecalhoDiretiva" }] : []));
    rodapeDiretiva = contentChild(SDatepickerFooterDirective, ...(ngDevMode ? [{ debugName: "rodapeDiretiva" }] : []));
    calendarioPopup = viewChild('calendario', ...(ngDevMode ? [{ debugName: "calendarioPopup" }] : []));
    periodoPopup = viewChild('periodo', ...(ngDevMode ? [{ debugName: "periodoPopup" }] : []));
    /** @internal Lido pelo cabecalho do calendario, que vive no overlay. */
    headerTemplate = computed(() => this.cabecalhoDiretiva()?.template, ...(ngDevMode ? [{ debugName: "headerTemplate" }] : []));
    /** @internal Lido pelo cabecalho do calendario, que vive no overlay. */
    footerTemplate = computed(() => this.rodapeDiretiva()?.template ?? (this.showClear() ? this.rodapeLimpar() : undefined), ...(ngDevMode ? [{ debugName: "footerTemplate" }] : []));
    /** O rodape de `showClear`, quando a tela nao projeta um. */
    rodapeLimpar = viewChild('limpar', ...(ngDevMode ? [{ debugName: "rodapeLimpar" }] : []));
    /** Botao "Limpar" no rodape do calendario. Um rodape proprio (`sDatepickerFooter`) vence. */
    showClear = input(false, ...(ngDevMode ? [{ debugName: "showClear", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Periodo como `[inicio, fim]` no formulario, no lugar de `{ start, end }` —
     * o formato que as telas vindas do PrimeNG ja usam. Datas em texto (ISO, da
     * API) tambem sao aceitas na entrada.
     */
    rangeAsArray = input(false, ...(ngDevMode ? [{ debugName: "rangeAsArray", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Data escolhida (no periodo, a ultima marcada). */
    dateSelect = output();
    /** O valor foi apagado. */
    cleared = output();
    /** @internal Objeto unico com getter: o template le sempre o valor atual. */
    footerContext = this.criarContextoRodape();
    /**
     * Sem template, o `mat-calendar` fica com o cabecalho do Material e a altura
     * fixa do overlay. O input do Material nao aceita vazio na tipagem, embora
     * trate `undefined` como "use o padrao".
     */
    cabecalho = computed(() => (this.headerTemplate() || this.footerTemplate()
        ? SDatepickerCalendarHeaderComponent
        : undefined), ...(ngDevMode ? [{ debugName: "cabecalho" }] : []));
    campo = usarCampo('s-datepicker');
    config = inject(S_DATE_CONFIG);
    maxLength = S_DATE_MAX_LENGTH;
    controlId = this.campo.id;
    ariaLabel = this.campo.rotuloAvulso(this.label);
    describedBy = this.campo.describedBy;
    required = this.campo.obrigatorio;
    isInvalid = computed(() => this.invalid() || this.campo.invalido() || (this.tocado() && this.periodoIncompleto()), ...(ngDevMode ? [{ debugName: "isInvalid" }] : []));
    textoExemplo = computed(() => this.placeholder() || this.config.placeholder, ...(ngDevMode ? [{ debugName: "textoExemplo" }] : []));
    data = computed(() => comoData(this.value()), ...(ngDevMode ? [{ debugName: "data" }] : []));
    inicio = computed(() => comoPeriodo(this.value()).start, ...(ngDevMode ? [{ debugName: "inicio" }] : []));
    fim = computed(() => comoPeriodo(this.value()).end, ...(ngDevMode ? [{ debugName: "fim" }] : []));
    calendarDateClass = computed(() => {
        const classify = this.dateClass();
        return (date) => {
            const marks = normalizeMarks(classify?.(date));
            return marks.map((mark) => `s-datepicker-day--${mark}`);
        };
    }, ...(ngDevMode ? [{ debugName: "calendarDateClass" }] : []));
    /** O fim esta sendo digitado: o separador aparece mesmo sem fim ainda. */
    editandoFim = signal(false, ...(ngDevMode ? [{ debugName: "editandoFim" }] : []));
    /**
     * Saiu do campo ou fechou o calendario. O periodo incompleto so pinta a borda
     * depois disso — enquanto escolhe o inicio, o fim ainda vai chegar.
     */
    tocado = signal(false, ...(ngDevMode ? [{ debugName: "tocado" }] : []));
    /**
     * Com `requireEnd`, o periodo so com inicio e invalido tambem fora de um
     * formulario: o validador so roda com `FormControl`, a borda nao depende dele.
     */
    periodoIncompleto = computed(() => this.range() && this.requireEnd() && !!this.inicio() && !this.fim(), ...(ngDevMode ? [{ debugName: "periodoIncompleto" }] : []));
    /** Inicio e fim no mesmo dia: um periodo de um dia so, escrito uma vez. */
    mesmoDia = computed(() => {
        const inicio = this.inicio();
        const fim = this.fim();
        return !!inicio && !!fim && inicio.toDateString() === fim.toDateString();
    }, ...(ngDevMode ? [{ debugName: "mesmoDia" }] : []));
    /** "a" so entre duas datas diferentes — sozinho ou repetido, so o inicio aparece. */
    /**
     * Com `range` e `placeholder`, o periodo vazio mostra um texto so ("Selecione a
     * Data"), sem o formato da data final nem o separador. Escolhido o inicio, o
     * campo volta a mostrar as duas pontas.
     */
    textoUnico = computed(() => !!this.placeholder() && !this.inicio() && !this.fim() && !this.editandoFim(), ...(ngDevMode ? [{ debugName: "textoUnico" }] : []));
    placeholderInicio = computed(() => this.startPlaceholder() || (this.textoUnico() ? this.placeholder() : this.config.placeholder), ...(ngDevMode ? [{ debugName: "placeholderInicio" }] : []));
    placeholderFim = computed(() => this.endPlaceholder() || (this.textoUnico() ? '' : this.config.placeholder), ...(ngDevMode ? [{ debugName: "placeholderFim" }] : []));
    semSeparador = computed(() => !!this.inicio() && (!this.fim() || this.mesmoDia()) && !this.editandoFim(), ...(ngDevMode ? [{ debugName: "semSeparador" }] : []));
    /** Texto da data ou do periodo no modo somente-leitura. */
    textoLeitura = computed(() => {
        const formatar = (data) => data ? data.toLocaleDateString(this.config.locale) : '';
        if (!this.range()) {
            return formatar(this.data());
        }
        const inicio = formatar(this.inicio());
        const fim = formatar(this.fim());
        if (inicio && fim) {
            return this.mesmoDia() ? inicio : `${inicio} a ${fim}`;
        }
        return inicio || (fim ? `até ${fim}` : '');
    }, ...(ngDevMode ? [{ debugName: "textoLeitura" }] : []));
    aoMudarValidacao = () => { };
    constructor() {
        super();
        // Ligar `requireEnd` ou `range` muda o que e valido sem o valor mudar.
        effect(() => {
            this.range();
            this.requireEnd();
            this.aoMudarValidacao();
        });
    }
    validate(controle) {
        if (!this.range() || !this.requireEnd()) {
            return null;
        }
        const { start, end } = comoPeriodo(this.doFormulario(controle.value));
        return start && !end ? { sDateRangeIncomplete: true } : null;
    }
    writeValue(valor) {
        super.writeValue(this.doFormulario(valor));
    }
    /** Grava, avisa o formulario no formato dele e emite `dateSelect`/`cleared`. */
    setValue(valor) {
        this.value.set(valor);
        this.onChange(this.paraFormulario(valor));
        if (!valor) {
            this.cleared.emit();
            return;
        }
        const data = valor instanceof Date ? valor : (valor.end ?? valor.start);
        if (data) {
            this.dateSelect.emit(data);
        }
    }
    /** O valor do formulario no formato do componente: texto vira data, `[a, b]` vira periodo. */
    doFormulario(valor) {
        const data = (v) => {
            if (v === null || v === undefined || v === '') {
                return null;
            }
            const d = v instanceof Date ? v : new Date(v);
            return isNaN(d.getTime()) ? null : d;
        };
        if (!this.range()) {
            return data(Array.isArray(valor) ? valor[0] : valor);
        }
        if (Array.isArray(valor)) {
            const start = data(valor[0]);
            const end = data(valor[1]);
            return start || end ? { start, end } : null;
        }
        if (valor && typeof valor === 'object' && !(valor instanceof Date)) {
            const { start, end } = valor;
            return data(start) || data(end) ? { start: data(start), end: data(end) } : null;
        }
        const unica = data(valor);
        return unica ? { start: unica, end: null } : null;
    }
    paraFormulario(valor) {
        if (!valor || !this.range() || !this.rangeAsArray()) {
            return valor;
        }
        const { start, end } = valor instanceof Date ? { start: valor, end: null } : valor;
        return [start, end ?? null];
    }
    registerOnValidatorChange(fn) {
        this.aoMudarValidacao = fn;
    }
    onBeforeInput(evento) {
        recusarLetras(evento, this.config);
    }
    onInput(evento) {
        aplicarMascara(evento.target, this.config);
    }
    abrirPeloClique(calendario) {
        if (this.openOnClick()) {
            calendario.open();
        }
    }
    onDateChange(event) {
        this.setValue(this.validar(event));
    }
    onMonthSelected(date, calendar) {
        if (this.isDisabled() || this.range() || this.selectionMode() !== 'month') {
            return;
        }
        this.setValue(this.normalizeMonth(date));
        calendar.close();
        this.onTouched();
    }
    onYearSelected(date, calendar) {
        if (this.isDisabled() || this.range() || this.selectionMode() !== 'year') {
            return;
        }
        this.setValue(this.normalizeYear(date));
        calendar.close();
        this.onTouched();
    }
    onStartChange(event) {
        const inicio = this.validar(event);
        const fim = this.fim();
        // O inicio andou para depois do fim: o fim deixa de fazer sentido.
        this.gravarPeriodo(inicio, inicio && fim && fim < inicio ? null : fim);
    }
    onEndChange(event) {
        const inicio = this.inicio();
        let fim = this.validar(event);
        if (fim && inicio && fim < inicio) {
            event.target.value = null;
            fim = null;
        }
        this.gravarPeriodo(inicio, fim);
    }
    onBlur() {
        this.tocado.set(true);
        this.onTouched();
    }
    onEndBlur() {
        this.editandoFim.set(false);
        this.onBlur();
    }
    /** Fechar o calendario so com o inicio escolhido tambem e sair do campo. */
    onPeriodoFechado() {
        this.onBlur();
    }
    criarContextoRodape() {
        // eslint-disable-next-line @typescript-eslint/no-this-alias
        const campo = this;
        const contexto = {
            get $implicit() {
                return contexto;
            },
            get value() {
                return campo.value();
            },
            select: (valor) => this.selecionar(valor),
            close: () => this.fecharCalendario(),
        };
        return contexto;
    }
    /** `select()` do rodape: grava no formato do modo, dentro de `min`/`max`, e fecha. */
    selecionar(valor) {
        if (this.isDisabled() || this.readOnly()) {
            return;
        }
        const dentro = (data) => data && !foraDaFaixa(data, this.min(), this.max()) ? data : null;
        if (this.range()) {
            const inicio = dentro(comoPeriodo(valor).start);
            const fim = dentro(comoPeriodo(valor).end);
            this.gravarPeriodo(inicio, inicio && fim && fim < inicio ? null : fim);
        }
        else {
            this.setValue(dentro(comoData(valor)));
        }
        this.onBlur();
        this.fecharCalendario();
    }
    fecharCalendario() {
        this.calendarioPopup()?.close();
        this.periodoPopup()?.close();
    }
    /** Sem nenhuma ponta o periodo e `null`, e o `required` do formulario enxerga. */
    gravarPeriodo(start, end) {
        this.setValue(start || end ? { start, end } : null);
    }
    /** Devolve a data, ou apaga o texto e devolve `null` quando ela nao vale. */
    validar(event) {
        const valor = event.value ?? null;
        // O `[min]`/`[max]` do Material so restringe o calendario - nao ha
        // `NgControl` no `<input>` interno (quem recebe o `formControlName` e o
        // componente), entao o validador que o Material registraria nunca roda.
        if (!valor || foraDaFaixa(valor, this.min(), this.max())) {
            event.target.value = null;
            return null;
        }
        return valor;
    }
    /**
     * Mes e ano valem quando algum dia deles cabe na faixa: o Material deixa
     * escolher o mes do `min`, e o dia 1 dele pode cair antes do limite.
     */
    normalizeMonth(date) {
        const value = new Date(date.getFullYear(), date.getMonth(), 1);
        const ultimoDia = new Date(date.getFullYear(), date.getMonth() + 1, 0);
        return this.periodoForaDaFaixa(value, ultimoDia) ? null : value;
    }
    normalizeYear(date) {
        const value = new Date(date.getFullYear(), 0, 1);
        const ultimoDia = new Date(date.getFullYear(), 11, 31);
        return this.periodoForaDaFaixa(value, ultimoDia) ? null : value;
    }
    periodoForaDaFaixa(inicio, fim) {
        return foraDaFaixa(fim, this.min(), null) || foraDaFaixa(inicio, null, this.max());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SDatepickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SDatepickerComponent, isStandalone: true, selector: "s-datepicker", inputs: { range: { classPropertyName: "range", publicName: "range", isSignal: true, isRequired: false, transformFunction: null }, requireEnd: { classPropertyName: "requireEnd", publicName: "requireEnd", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, pickerOnly: { classPropertyName: "pickerOnly", publicName: "pickerOnly", isSignal: true, isRequired: false, transformFunction: null }, openOnClick: { classPropertyName: "openOnClick", publicName: "openOnClick", isSignal: true, isRequired: false, transformFunction: null }, startPlaceholder: { classPropertyName: "startPlaceholder", publicName: "startPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, endPlaceholder: { classPropertyName: "endPlaceholder", publicName: "endPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, startLabel: { classPropertyName: "startLabel", publicName: "startLabel", isSignal: true, isRequired: false, transformFunction: null }, endLabel: { classPropertyName: "endLabel", publicName: "endLabel", isSignal: true, isRequired: false, transformFunction: null }, startView: { classPropertyName: "startView", publicName: "startView", isSignal: true, isRequired: false, transformFunction: null }, startAt: { classPropertyName: "startAt", publicName: "startAt", isSignal: true, isRequired: false, transformFunction: null }, selectionMode: { classPropertyName: "selectionMode", publicName: "selectionMode", isSignal: true, isRequired: false, transformFunction: null }, dateClass: { classPropertyName: "dateClass", publicName: "dateClass", isSignal: true, isRequired: false, transformFunction: null }, showClear: { classPropertyName: "showClear", publicName: "showClear", isSignal: true, isRequired: false, transformFunction: null }, rangeAsArray: { classPropertyName: "rangeAsArray", publicName: "rangeAsArray", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { dateSelect: "dateSelect", cleared: "cleared" }, host: { classAttribute: "s-datepicker" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SDatepickerComponent),
                multi: true,
            },
            {
                provide: NG_VALIDATORS,
                useExisting: forwardRef(() => SDatepickerComponent),
                multi: true,
            },
            { provide: MatDatepickerIntl, useFactory: rotulosDoCalendario },
            { provide: S_DATEPICKER_SLOTS, useExisting: forwardRef(() => SDatepickerComponent) },
        ], queries: [{ propertyName: "cabecalhoDiretiva", first: true, predicate: SDatepickerHeaderDirective, descendants: true, isSignal: true }, { propertyName: "rodapeDiretiva", first: true, predicate: SDatepickerFooterDirective, descendants: true, isSignal: true }], viewQueries: [{ propertyName: "calendarioPopup", first: true, predicate: ["calendario"], descendants: true, isSignal: true }, { propertyName: "periodoPopup", first: true, predicate: ["periodo"], descendants: true, isSignal: true }, { propertyName: "rodapeLimpar", first: true, predicate: ["limpar"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "<!-- O rodape de `showClear`. -->\n<ng-template #limpar let-cal>\n  <s-button variant=\"ghost\" [disabled]=\"!cal.value\" (click)=\"cal.select(null)\">Limpar</s-button>\n</ng-template>\n\n@if (readOnly()) {\n  <div class=\"s-datepicker__readonly\" [attr.id]=\"controlId()\">{{ textoLeitura() }}</div>\n} @else {\n  <div\n    class=\"s-datepicker__campo\"\n    [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.data-disabled]=\"isDisabled() ? 'true' : null\"\n  >\n    @if (range()) {\n      <mat-date-range-input\n        class=\"s-datepicker__intervalo\"\n        separator=\"a\"\n        [class.s-datepicker__intervalo--sem-fim]=\"semSeparador() || textoUnico()\"\n        [class.s-datepicker__intervalo--texto-unico]=\"textoUnico()\"\n        [class.s-datepicker__intervalo--mesmo-dia]=\"mesmoDia() && !editandoFim()\"\n        [rangePicker]=\"periodo\"\n        [min]=\"min()\"\n        [max]=\"max()\"\n        [disabled]=\"isDisabled()\"\n        [required]=\"required()\"\n        (click)=\"abrirPeloClique(periodo)\"\n      >\n        <input\n          matStartDate\n          class=\"s-datepicker__nativo\"\n          inputmode=\"numeric\"\n          autocomplete=\"off\"\n          [id]=\"controlId()\"\n          [value]=\"inicio()\"\n          [placeholder]=\"placeholderInicio()\"\n          [attr.maxlength]=\"maxLength\"\n          [readonly]=\"pickerOnly()\"\n          [attr.aria-label]=\"startLabel()\"\n          [attr.aria-required]=\"required() ? 'true' : null\"\n          [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n          [attr.aria-describedby]=\"describedBy()\"\n          (beforeinput)=\"onBeforeInput($event)\"\n          (input)=\"onInput($event)\"\n          (dateChange)=\"onStartChange($event)\"\n          (blur)=\"onBlur()\"\n        />\n        <input\n          matEndDate\n          class=\"s-datepicker__nativo\"\n          inputmode=\"numeric\"\n          autocomplete=\"off\"\n          [value]=\"fim()\"\n          [placeholder]=\"placeholderFim()\"\n          [attr.maxlength]=\"maxLength\"\n          [readonly]=\"pickerOnly()\"\n          [attr.aria-label]=\"endLabel()\"\n          [attr.aria-required]=\"required() ? 'true' : null\"\n          [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n          [attr.aria-describedby]=\"describedBy()\"\n          (beforeinput)=\"onBeforeInput($event)\"\n          (input)=\"onInput($event)\"\n          (dateChange)=\"onEndChange($event)\"\n          (focus)=\"editandoFim.set(true)\"\n          (blur)=\"onEndBlur()\"\n        />\n      </mat-date-range-input>\n\n      <s-icon-button\n        class=\"s-datepicker__gatilho\"\n        icon=\"date_range\"\n        label=\"Abrir calend\u00E1rio\"\n        size=\"sm\"\n        [disabled]=\"isDisabled()\"\n        (click)=\"periodo.open()\"\n      />\n\n      <mat-date-range-picker\n        #periodo\n        [startAt]=\"startAt() || inicio()\"\n        [startView]=\"startView()\"\n        [dateClass]=\"calendarDateClass()\"\n        [calendarHeaderComponent]=\"cabecalho()\"\n        (closed)=\"onPeriodoFechado()\"\n      />\n    } @else {\n      <input\n        class=\"s-datepicker__nativo\"\n        inputmode=\"numeric\"\n        autocomplete=\"off\"\n        [id]=\"controlId()\"\n        [attr.aria-label]=\"ariaLabel()\"\n        [matDatepicker]=\"calendario\"\n        [value]=\"data()\"\n        [min]=\"min()\"\n        [max]=\"max()\"\n        [placeholder]=\"textoExemplo()\"\n        [attr.maxlength]=\"maxLength\"\n        [disabled]=\"isDisabled()\"\n        [readonly]=\"pickerOnly()\"\n        [attr.aria-required]=\"required() ? 'true' : null\"\n        [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n        [attr.aria-describedby]=\"describedBy()\"\n        (beforeinput)=\"onBeforeInput($event)\"\n        (input)=\"onInput($event)\"\n        (dateChange)=\"onDateChange($event)\"\n        (click)=\"abrirPeloClique(calendario)\"\n        (blur)=\"onBlur()\"\n      />\n\n      <!-- O gatilho proprio do Material (`mat-datepicker-toggle`) traz um SVG de\n         calendario com medida propria. Aqui o botao e o do design system, com o\n         glifo de 20px do tamanho de controle. -->\n      <s-icon-button\n        class=\"s-datepicker__gatilho\"\n        icon=\"calendar_today\"\n        label=\"Abrir calend\u00E1rio\"\n        size=\"sm\"\n        [disabled]=\"isDisabled()\"\n        (click)=\"calendario.open()\"\n      />\n\n      <mat-datepicker\n        #calendario\n        [startAt]=\"startAt() || data()\"\n        [startView]=\"startView()\"\n        [dateClass]=\"calendarDateClass()\"\n        [calendarHeaderComponent]=\"cabecalho()\"\n        (monthSelected)=\"onMonthSelected($event, calendario)\"\n        (yearSelected)=\"onYearSelected($event, calendario)\"\n      />\n    }\n  </div>\n}\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%;--s-field-h: var(--field-h, 48px)}.s-datepicker__campo{box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;display:flex;align-items:center;gap:var(--space-8, 8px)}.s-datepicker__campo:hover:not([data-disabled=true]){border-color:var(--border);background:var(--card)}.s-datepicker__campo:focus-within{border:2px solid var(--primary);background:var(--card);padding:0 15px}.s-datepicker__campo[data-invalid=true]{border-color:var(--destructive)}.s-datepicker__campo[data-disabled=true]{opacity:.4}.s-datepicker__nativo{flex:1;min-width:0;height:var(--s-field-h, var(--field-h, 48px));padding:0;border:none;background:transparent;font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary)}.s-datepicker__nativo::placeholder{color:var(--text-secondary)}.s-datepicker__nativo:focus{outline:none}.s-datepicker__nativo:disabled{opacity:1;cursor:default}.s-datepicker__gatilho{flex:0 0 auto;margin-right:calc(var(--space-8, 8px) * -1);width:var(--icon-md, 24px)}.s-datepicker__readonly{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary)}.mat-calendar:has(>.s-datepicker-calendar){display:flex;flex-direction:column}.s-datepicker-calendar{display:contents}.s-datepicker-calendar__header:has(>:not(mat-calendar-header)){display:flex;align-items:center;gap:var(--space-8);padding:var(--space-8) var(--space-8) 0;font-family:var(--font-ui);color:var(--text-primary)}.s-datepicker-calendar__footer{order:1;display:flex;flex-wrap:wrap;align-items:center;gap:var(--space-8);padding:var(--space-8) var(--space-16) var(--space-16);border-top:1px solid var(--border);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary)}.s-datepicker-legend{display:flex;flex-wrap:wrap;gap:var(--space-8);font-size:var(--text-caption);color:var(--text-secondary)}.s-datepicker-legend__item{display:inline-flex;align-items:center;gap:var(--space-4)}.s-datepicker-mark{display:inline-block;flex:0 0 auto;width:var(--icon-xs);height:var(--icon-xs);border:1px solid currentColor;border-radius:var(--radius-full);background:var(--text-secondary)}.s-datepicker__intervalo{flex:1;min-width:0;align-self:stretch;font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary)}.s-datepicker__intervalo>.mat-date-range-input-container{flex:1;min-width:0}.s-datepicker__intervalo .s-datepicker__nativo{height:auto}.s-datepicker__intervalo .mat-date-range-input-separator{margin:0 2px}.s-datepicker__campo .s-datepicker__intervalo{display:flex;align-items:center}.s-datepicker__intervalo--sem-fim .mat-date-range-input-separator{visibility:hidden}.s-datepicker__intervalo--texto-unico .mat-date-range-input-wrapper:not(.mat-date-range-input-end-wrapper){flex:1 1 auto;max-width:100%}.s-datepicker__intervalo--texto-unico .mat-date-range-input-separator{display:none}.s-datepicker__intervalo--texto-unico .mat-date-range-input-wrapper.mat-date-range-input-end-wrapper{flex:0 0 0;min-width:0;overflow:hidden}.s-datepicker__intervalo--mesmo-dia .mat-end-date{color:transparent}.s-datepicker-day--success .mat-calendar-body-cell-content,.s-datepicker-mark--success{background:color-mix(in srgb,var(--success) calc(var(--tint-container) * 100%),transparent);color:var(--success-on-surface)}.s-datepicker-day--warning .mat-calendar-body-cell-content,.s-datepicker-mark--warning{background:color-mix(in srgb,var(--warning) calc(var(--tint-container) * 100%),transparent);color:var(--warning-on-surface)}.s-datepicker-day--destructive .mat-calendar-body-cell-content,.s-datepicker-mark--destructive{background:color-mix(in srgb,var(--destructive) calc(var(--tint-container) * 100%),transparent);color:var(--destructive-on-surface)}.s-datepicker-day--info .mat-calendar-body-cell-content,.s-datepicker-mark--info{background:color-mix(in srgb,var(--info) calc(var(--tint-container) * 100%),transparent);color:var(--info-on-surface)}.s-datepicker-day--muted .mat-calendar-body-cell-content,.s-datepicker-mark--muted{background:var(--secondary);color:var(--text-secondary)}.s-datepicker-day--success .mat-calendar-body-cell-content,.s-datepicker-day--warning .mat-calendar-body-cell-content,.s-datepicker-day--destructive .mat-calendar-body-cell-content,.s-datepicker-day--info .mat-calendar-body-cell-content,.s-datepicker-day--muted .mat-calendar-body-cell-content{border:1px solid currentColor;font-weight:var(--weight-medium)}\n"], dependencies: [{ kind: "ngmodule", type: MatDatepickerModule }, { kind: "component", type: i1$4.MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }, { kind: "directive", type: i1$4.MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "component", type: i1$4.MatDateRangeInput, selector: "mat-date-range-input", inputs: ["rangePicker", "required", "dateFilter", "min", "max", "disabled", "separator", "comparisonStart", "comparisonEnd"], exportAs: ["matDateRangeInput"] }, { kind: "directive", type: i1$4.MatStartDate, selector: "input[matStartDate]", outputs: ["dateChange", "dateInput"] }, { kind: "directive", type: i1$4.MatEndDate, selector: "input[matEndDate]", outputs: ["dateChange", "dateInput"] }, { kind: "component", type: i1$4.MatDateRangePicker, selector: "mat-date-range-picker", exportAs: ["matDateRangePicker"] }, { kind: "component", type: SButtonComponent, selector: "s-button", inputs: ["variant", "outlined", "fullWidth", "pressed", "buttonRole", "checked", "focusIndex", "loading", "loadingText", "disabled", "icon", "iconRight", "type", "label"] }, { kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SDatepickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-datepicker', imports: [MatDatepickerModule, SButtonComponent, SIconButtonComponent], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SDatepickerComponent),
                            multi: true,
                        },
                        {
                            provide: NG_VALIDATORS,
                            useExisting: forwardRef(() => SDatepickerComponent),
                            multi: true,
                        },
                        { provide: MatDatepickerIntl, useFactory: rotulosDoCalendario },
                        { provide: S_DATEPICKER_SLOTS, useExisting: forwardRef(() => SDatepickerComponent) },
                    ], host: {
                        class: 's-datepicker',
                    }, template: "<!-- O rodape de `showClear`. -->\n<ng-template #limpar let-cal>\n  <s-button variant=\"ghost\" [disabled]=\"!cal.value\" (click)=\"cal.select(null)\">Limpar</s-button>\n</ng-template>\n\n@if (readOnly()) {\n  <div class=\"s-datepicker__readonly\" [attr.id]=\"controlId()\">{{ textoLeitura() }}</div>\n} @else {\n  <div\n    class=\"s-datepicker__campo\"\n    [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.data-disabled]=\"isDisabled() ? 'true' : null\"\n  >\n    @if (range()) {\n      <mat-date-range-input\n        class=\"s-datepicker__intervalo\"\n        separator=\"a\"\n        [class.s-datepicker__intervalo--sem-fim]=\"semSeparador() || textoUnico()\"\n        [class.s-datepicker__intervalo--texto-unico]=\"textoUnico()\"\n        [class.s-datepicker__intervalo--mesmo-dia]=\"mesmoDia() && !editandoFim()\"\n        [rangePicker]=\"periodo\"\n        [min]=\"min()\"\n        [max]=\"max()\"\n        [disabled]=\"isDisabled()\"\n        [required]=\"required()\"\n        (click)=\"abrirPeloClique(periodo)\"\n      >\n        <input\n          matStartDate\n          class=\"s-datepicker__nativo\"\n          inputmode=\"numeric\"\n          autocomplete=\"off\"\n          [id]=\"controlId()\"\n          [value]=\"inicio()\"\n          [placeholder]=\"placeholderInicio()\"\n          [attr.maxlength]=\"maxLength\"\n          [readonly]=\"pickerOnly()\"\n          [attr.aria-label]=\"startLabel()\"\n          [attr.aria-required]=\"required() ? 'true' : null\"\n          [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n          [attr.aria-describedby]=\"describedBy()\"\n          (beforeinput)=\"onBeforeInput($event)\"\n          (input)=\"onInput($event)\"\n          (dateChange)=\"onStartChange($event)\"\n          (blur)=\"onBlur()\"\n        />\n        <input\n          matEndDate\n          class=\"s-datepicker__nativo\"\n          inputmode=\"numeric\"\n          autocomplete=\"off\"\n          [value]=\"fim()\"\n          [placeholder]=\"placeholderFim()\"\n          [attr.maxlength]=\"maxLength\"\n          [readonly]=\"pickerOnly()\"\n          [attr.aria-label]=\"endLabel()\"\n          [attr.aria-required]=\"required() ? 'true' : null\"\n          [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n          [attr.aria-describedby]=\"describedBy()\"\n          (beforeinput)=\"onBeforeInput($event)\"\n          (input)=\"onInput($event)\"\n          (dateChange)=\"onEndChange($event)\"\n          (focus)=\"editandoFim.set(true)\"\n          (blur)=\"onEndBlur()\"\n        />\n      </mat-date-range-input>\n\n      <s-icon-button\n        class=\"s-datepicker__gatilho\"\n        icon=\"date_range\"\n        label=\"Abrir calend\u00E1rio\"\n        size=\"sm\"\n        [disabled]=\"isDisabled()\"\n        (click)=\"periodo.open()\"\n      />\n\n      <mat-date-range-picker\n        #periodo\n        [startAt]=\"startAt() || inicio()\"\n        [startView]=\"startView()\"\n        [dateClass]=\"calendarDateClass()\"\n        [calendarHeaderComponent]=\"cabecalho()\"\n        (closed)=\"onPeriodoFechado()\"\n      />\n    } @else {\n      <input\n        class=\"s-datepicker__nativo\"\n        inputmode=\"numeric\"\n        autocomplete=\"off\"\n        [id]=\"controlId()\"\n        [attr.aria-label]=\"ariaLabel()\"\n        [matDatepicker]=\"calendario\"\n        [value]=\"data()\"\n        [min]=\"min()\"\n        [max]=\"max()\"\n        [placeholder]=\"textoExemplo()\"\n        [attr.maxlength]=\"maxLength\"\n        [disabled]=\"isDisabled()\"\n        [readonly]=\"pickerOnly()\"\n        [attr.aria-required]=\"required() ? 'true' : null\"\n        [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n        [attr.aria-describedby]=\"describedBy()\"\n        (beforeinput)=\"onBeforeInput($event)\"\n        (input)=\"onInput($event)\"\n        (dateChange)=\"onDateChange($event)\"\n        (click)=\"abrirPeloClique(calendario)\"\n        (blur)=\"onBlur()\"\n      />\n\n      <!-- O gatilho proprio do Material (`mat-datepicker-toggle`) traz um SVG de\n         calendario com medida propria. Aqui o botao e o do design system, com o\n         glifo de 20px do tamanho de controle. -->\n      <s-icon-button\n        class=\"s-datepicker__gatilho\"\n        icon=\"calendar_today\"\n        label=\"Abrir calend\u00E1rio\"\n        size=\"sm\"\n        [disabled]=\"isDisabled()\"\n        (click)=\"calendario.open()\"\n      />\n\n      <mat-datepicker\n        #calendario\n        [startAt]=\"startAt() || data()\"\n        [startView]=\"startView()\"\n        [dateClass]=\"calendarDateClass()\"\n        [calendarHeaderComponent]=\"cabecalho()\"\n        (monthSelected)=\"onMonthSelected($event, calendario)\"\n        (yearSelected)=\"onYearSelected($event, calendario)\"\n      />\n    }\n  </div>\n}\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%;--s-field-h: var(--field-h, 48px)}.s-datepicker__campo{box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;display:flex;align-items:center;gap:var(--space-8, 8px)}.s-datepicker__campo:hover:not([data-disabled=true]){border-color:var(--border);background:var(--card)}.s-datepicker__campo:focus-within{border:2px solid var(--primary);background:var(--card);padding:0 15px}.s-datepicker__campo[data-invalid=true]{border-color:var(--destructive)}.s-datepicker__campo[data-disabled=true]{opacity:.4}.s-datepicker__nativo{flex:1;min-width:0;height:var(--s-field-h, var(--field-h, 48px));padding:0;border:none;background:transparent;font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary)}.s-datepicker__nativo::placeholder{color:var(--text-secondary)}.s-datepicker__nativo:focus{outline:none}.s-datepicker__nativo:disabled{opacity:1;cursor:default}.s-datepicker__gatilho{flex:0 0 auto;margin-right:calc(var(--space-8, 8px) * -1);width:var(--icon-md, 24px)}.s-datepicker__readonly{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary)}.mat-calendar:has(>.s-datepicker-calendar){display:flex;flex-direction:column}.s-datepicker-calendar{display:contents}.s-datepicker-calendar__header:has(>:not(mat-calendar-header)){display:flex;align-items:center;gap:var(--space-8);padding:var(--space-8) var(--space-8) 0;font-family:var(--font-ui);color:var(--text-primary)}.s-datepicker-calendar__footer{order:1;display:flex;flex-wrap:wrap;align-items:center;gap:var(--space-8);padding:var(--space-8) var(--space-16) var(--space-16);border-top:1px solid var(--border);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary)}.s-datepicker-legend{display:flex;flex-wrap:wrap;gap:var(--space-8);font-size:var(--text-caption);color:var(--text-secondary)}.s-datepicker-legend__item{display:inline-flex;align-items:center;gap:var(--space-4)}.s-datepicker-mark{display:inline-block;flex:0 0 auto;width:var(--icon-xs);height:var(--icon-xs);border:1px solid currentColor;border-radius:var(--radius-full);background:var(--text-secondary)}.s-datepicker__intervalo{flex:1;min-width:0;align-self:stretch;font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary)}.s-datepicker__intervalo>.mat-date-range-input-container{flex:1;min-width:0}.s-datepicker__intervalo .s-datepicker__nativo{height:auto}.s-datepicker__intervalo .mat-date-range-input-separator{margin:0 2px}.s-datepicker__campo .s-datepicker__intervalo{display:flex;align-items:center}.s-datepicker__intervalo--sem-fim .mat-date-range-input-separator{visibility:hidden}.s-datepicker__intervalo--texto-unico .mat-date-range-input-wrapper:not(.mat-date-range-input-end-wrapper){flex:1 1 auto;max-width:100%}.s-datepicker__intervalo--texto-unico .mat-date-range-input-separator{display:none}.s-datepicker__intervalo--texto-unico .mat-date-range-input-wrapper.mat-date-range-input-end-wrapper{flex:0 0 0;min-width:0;overflow:hidden}.s-datepicker__intervalo--mesmo-dia .mat-end-date{color:transparent}.s-datepicker-day--success .mat-calendar-body-cell-content,.s-datepicker-mark--success{background:color-mix(in srgb,var(--success) calc(var(--tint-container) * 100%),transparent);color:var(--success-on-surface)}.s-datepicker-day--warning .mat-calendar-body-cell-content,.s-datepicker-mark--warning{background:color-mix(in srgb,var(--warning) calc(var(--tint-container) * 100%),transparent);color:var(--warning-on-surface)}.s-datepicker-day--destructive .mat-calendar-body-cell-content,.s-datepicker-mark--destructive{background:color-mix(in srgb,var(--destructive) calc(var(--tint-container) * 100%),transparent);color:var(--destructive-on-surface)}.s-datepicker-day--info .mat-calendar-body-cell-content,.s-datepicker-mark--info{background:color-mix(in srgb,var(--info) calc(var(--tint-container) * 100%),transparent);color:var(--info-on-surface)}.s-datepicker-day--muted .mat-calendar-body-cell-content,.s-datepicker-mark--muted{background:var(--secondary);color:var(--text-secondary)}.s-datepicker-day--success .mat-calendar-body-cell-content,.s-datepicker-day--warning .mat-calendar-body-cell-content,.s-datepicker-day--destructive .mat-calendar-body-cell-content,.s-datepicker-day--info .mat-calendar-body-cell-content,.s-datepicker-day--muted .mat-calendar-body-cell-content{border:1px solid currentColor;font-weight:var(--weight-medium)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { range: [{ type: i0.Input, args: [{ isSignal: true, alias: "range", required: false }] }], requireEnd: [{ type: i0.Input, args: [{ isSignal: true, alias: "requireEnd", required: false }] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], pickerOnly: [{ type: i0.Input, args: [{ isSignal: true, alias: "pickerOnly", required: false }] }], openOnClick: [{ type: i0.Input, args: [{ isSignal: true, alias: "openOnClick", required: false }] }], startPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "startPlaceholder", required: false }] }], endPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "endPlaceholder", required: false }] }], startLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "startLabel", required: false }] }], endLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "endLabel", required: false }] }], startView: [{ type: i0.Input, args: [{ isSignal: true, alias: "startView", required: false }] }], startAt: [{ type: i0.Input, args: [{ isSignal: true, alias: "startAt", required: false }] }], selectionMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectionMode", required: false }] }], dateClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "dateClass", required: false }] }], cabecalhoDiretiva: [{ type: i0.ContentChild, args: [i0.forwardRef(() => SDatepickerHeaderDirective), { isSignal: true }] }], rodapeDiretiva: [{ type: i0.ContentChild, args: [i0.forwardRef(() => SDatepickerFooterDirective), { isSignal: true }] }], calendarioPopup: [{ type: i0.ViewChild, args: ['calendario', { isSignal: true }] }], periodoPopup: [{ type: i0.ViewChild, args: ['periodo', { isSignal: true }] }], rodapeLimpar: [{ type: i0.ViewChild, args: ['limpar', { isSignal: true }] }], showClear: [{ type: i0.Input, args: [{ isSignal: true, alias: "showClear", required: false }] }], rangeAsArray: [{ type: i0.Input, args: [{ isSignal: true, alias: "rangeAsArray", required: false }] }], dateSelect: [{ type: i0.Output, args: ["dateSelect"] }], cleared: [{ type: i0.Output, args: ["cleared"] }] } });
function normalizeMarks(result) {
    if (!result) {
        return [];
    }
    return typeof result === 'string' ? [result] : result;
}

/**
 * Rodape do painel do `<s-autocomplete>`, abaixo das opcoes — para o que
 * completa a escolha sem sair do campo, como cadastrar um item que a busca
 * nao achou.
 *
 * Fica fixo no fim do painel enquanto as opcoes rolam. O clique e a digitacao
 * dentro dele nao fecham o painel nem escolhem uma opcao.
 *
 * Os controles do rodape **nao se ligam ao `<s-field>` em volta** do
 * autocomplete: sem isto, um `<s-input>` ali dentro herdaria o id, o rotulo e o
 * erro do campo. Nomeie-os pelo proprio `label`, que vira `aria-label`.
 *
 * Quando o template vem de outra tela e so e repassado (`ngTemplateOutlet`),
 * marque tambem o template de origem com `sAutocompleteFooter`: e la que o
 * conteudo procura o campo.
 *
 * @example
 * ```html
 * <s-autocomplete formControlName="recurso" url="recursos-educacionais">
 *   <ng-template sAutocompleteFooter>
 *     <s-input label="Novo recurso" placeholder="Digite o novo recurso" [(ngModel)]="novo" />
 *     <s-button icon="add" (click)="adicionar()">Adicionar</s-button>
 *   </ng-template>
 * </s-autocomplete>
 * ```
 */
class SAutocompleteFooterDirective {
    template = inject(TemplateRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAutocompleteFooterDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.34", type: SAutocompleteFooterDirective, isStandalone: true, selector: "ng-template[sAutocompleteFooter]", providers: [{ provide: SFieldContext, useValue: null }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAutocompleteFooterDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ng-template[sAutocompleteFooter]',
                    providers: [{ provide: SFieldContext, useValue: null }],
                }]
        }] });

/** So as chaves preenchidas: a fonte que nao conhece as novas recebe o pedido de sempre. */
function extras(chaves) {
    return Object.fromEntries(Object.entries(chaves).filter(([, valor]) => valor));
}
/**
 * Autocomplete da biblioteca `@siage/siage-ui`.
 *
 * Encapsula (por composição) `mat-autocomplete` e `mat-option`, sobre a mesma
 * superfície dos demais campos — **sem** `mat-form-field`, que traria o rótulo
 * flutuante dentro da moldura em vez do rótulo acima que o guia define.
 *
 * Como `<s-input>` e `<s-select>`, ele espera viver dentro de um `<s-field>`,
 * que fornece rótulo, obrigatoriedade e faixa de erro, e amarra `for`,
 * `aria-required`, `aria-invalid` e `aria-describedby`.
 *
 * A busca é responsabilidade da aplicação: o componente apenas emite `search`
 * com o texto digitado e renderiza o que receber em `options`.
 */
class SAutocompleteComponent extends SControlBase {
    /**
     * Opções exibidas no painel.
     *
     * Sem `url`, o próprio componente filtra a lista pelo texto digitado,
     * ignorando acento e caixa. Com `url`, quem filtra é a fonte de dados — como
     * no autocomplete do Professores e do Educacional, o `url` é o que decide.
     */
    options = input([], ...(ngDevMode ? [{ debugName: "options" }] : []));
    /**
     * Chave do rotulo quando `options` (ou a fonte) traz objetos de dominio —
     * `{ id, nome }` da API. Informada, o **objeto inteiro** e o valor do
     * formulario, como no `optionLabel` sem `optionValue` do PrimeNG; o campo ja
     * preenchido mostra o rotulo do proprio objeto, sem consulta.
     */
    optionLabel = input('', ...(ngDevMode ? [{ debugName: "optionLabel" }] : []));
    /**
     * Chave que identifica o objeto (`id`), para reconhecer o valor do
     * formulario entre as opcoes mesmo vindo de outra resposta da API. Vence
     * `compareWith`.
     */
    dataKey = input('', ...(ngDevMode ? [{ debugName: "dataKey" }] : []));
    /** Nome do parametro do termo na busca por `url` (`nome`, `descricao`). Vai para a fonte. */
    searchFor = input('', ...(ngDevMode ? [{ debugName: "searchFor" }] : []));
    /** Recurso onde `url` mora (`Autocomplete`, por padrao, na fonte do Professores). */
    controller = input('', ...(ngDevMode ? [{ debugName: "controller" }] : []));
    /**
     * Com `url`, abre ja listando ao focar o campo — sem esperar `minLength`
     * letras. Para listas curtas, em que o painel funciona como um select.
     */
    searchOnFocus = input(false, ...(ngDevMode ? [{ debugName: "searchOnFocus", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Texto digitado sem escolher uma opcao e descartado ao sair do campo. Sem
     * isto, o campo mostra um texto que nao esta no formulario.
     */
    forceSelection = input(false, ...(ngDevMode ? [{ debugName: "forceSelection", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Recurso a consultar a cada digitação, no lugar de `options`.
     *
     * Quando informado, o componente delega a busca à `SAutocompleteSource` que a
     * aplicação registrou — ele **não** faz HTTP. Sem `url`, nada muda: a tela
     * continua ouvindo `search` e alimentando `options`.
     */
    url = input('', ...(ngDevMode ? [{ debugName: "url" }] : []));
    /** Filtros adicionais enviados junto da busca. Só tem efeito com `url`. */
    params = input({}, ...(ngDevMode ? [{ debugName: "params" }] : []));
    /** Caracteres mínimos antes de consultar. Só tem efeito com `url`. */
    minLength = input(1, ...(ngDevMode ? [{ debugName: "minLength", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /**
     * Compara o valor escolhido com o valor de cada opção, como no `<s-select>`.
     *
     * O padrão é igualdade estrita, que basta para id e texto. Informe uma
     * função quando o valor for um objeto vindo de duas respostas diferentes da
     * API — sem isso, a tela de edição não reconhece o valor que veio preenchido.
     */
    compareWith = input((a, b) => a === b, ...(ngDevMode ? [{ debugName: "compareWith" }] : []));
    /** Espera entre a digitação e a consulta, em ms. Só tem efeito com `url`. */
    debounceTime = input(300, ...(ngDevMode ? [{ debugName: "debounceTime", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Marca o campo como obrigatório.
     *
     * Dentro de um `<s-field required>` a obrigatoriedade já vem do campo; este
     * input existe para o uso avulso.
     */
    required = input(false, ...(ngDevMode ? [{ debugName: "required", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Exibe indicador de carregamento no campo e no painel. */
    loading = input(false, ...(ngDevMode ? [{ debugName: "loading", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Texto exibido quando não há opções e não está carregando. */
    noResultsText = input('Nenhum resultado encontrado', ...(ngDevMode ? [{ debugName: "noResultsText" }] : []));
    /** Texto exibido quando não há nenhuma opção para listar. */
    emptyText = input('Nenhum resultado foi encontrado.', ...(ngDevMode ? [{ debugName: "emptyText" }] : []));
    /** Texto exibido no painel enquanto `loading` é `true`. */
    loadingText = input('Carregando...', ...(ngDevMode ? [{ debugName: "loadingText" }] : []));
    /** Emitido quando uma opção é selecionada, ou `null` quando a seleção é desfeita. */
    selectionChange = output();
    /** Emitido a cada alteração do texto digitado pelo usuário.
     *  Respeita o mesmo `debounceTime` de 300ms.
     */
    search = output();
    /** Controle interno do input. Nunca é exposto para a aplicação consumidora. */
    searchControl = new FormControl('');
    /** `true` quando existe um valor selecionado (habilita o botão de limpar). */
    hasValue = computed(() => this.value() !== null, ...(ngDevMode ? [{ debugName: "hasValue" }] : []));
    source = inject(SAutocompleteSource, { optional: true });
    fetched = signal([], ...(ngDevMode ? [{ debugName: "fetched" }] : []));
    fetching = signal(false, ...(ngDevMode ? [{ debugName: "fetching" }] : []));
    /** As opções que o painel realmente lista: as buscadas com `url`, ou as da tela. */
    /** `options` no formato do painel. */
    opcoesBase = computed(() => normalizarOpcoes(this.options(), this.optionLabel()), ...(ngDevMode ? [{ debugName: "opcoesBase" }] : []));
    /** `dataKey` vence `compareWith`. */
    comparar = computed(() => {
        const chave = this.dataKey();
        return chave ? compararPorChave(chave) : this.compareWith();
    }, ...(ngDevMode ? [{ debugName: "comparar" }] : []));
    visibleOptions = computed(() => {
        if (this.url()) {
            return this.fetched();
        }
        const termo = this.termo();
        return this.opcoesBase().filter((opcao) => contemTermo(opcao.label, termo));
    }, ...(ngDevMode ? [{ debugName: "visibleOptions" }] : []));
    /** Texto digitado, para o filtro local. Zera ao selecionar. */
    termo = signal('', ...(ngDevMode ? [{ debugName: "termo" }] : []));
    /** Desenho próprio da opção, quando a aplicação projeta um. */
    opcaoTemplate = contentChild(SOptionTemplateDirective, ...(ngDevMode ? [{ debugName: "opcaoTemplate" }] : []));
    /** Rodape do painel, abaixo das opcoes. Ver `SAutocompleteFooterDirective`. */
    rodape = contentChild(SAutocompleteFooterDirective, ...(ngDevMode ? [{ debugName: "rodape" }] : []));
    /** Carregando por `loading` da tela ou por uma consulta em andamento. */
    isLoading = computed(() => this.loading() || this.fetching(), ...(ngDevMode ? [{ debugName: "isLoading" }] : []));
    /** `true` quando não há opções para exibir e não está carregando. */
    isEmpty = computed(() => !this.isLoading() && this.visibleOptions().length === 0, ...(ngDevMode ? [{ debugName: "isEmpty" }] : []));
    /** Lista local vazia: nao e a busca que nao achou, e que nao ha o que listar. */
    listaVazia = computed(() => !this.url() && this.opcoesBase().length === 0, ...(ngDevMode ? [{ debugName: "listaVazia" }] : []));
    /** Texto exibido no modo somente-leitura: o rotulo da opcao selecionada. */
    textoSomenteLeitura = computed(() => {
        // Os signals primeiro: `searchControl.value` nao e signal, e um retorno
        // antes deles deixava o computed sem dependencia, preso no primeiro texto.
        const val = this.value();
        if (val === null || val === undefined) {
            return '';
        }
        const match = this.visibleOptions().find((o) => this.comparar()(o.value, val));
        if (match) {
            return match.label;
        }
        // Opcao escolhida numa busca que ja saiu da lista.
        const current = this.searchControl.value;
        return current !== null && typeof current !== 'string' && this.comparar()(current.value, val)
            ? current.label
            : '';
    }, ...(ngDevMode ? [{ debugName: "textoSomenteLeitura" }] : []));
    campo = usarCampo('s-autocomplete');
    /** Valores que chegaram do formulário e ainda não têm rótulo conhecido. */
    aResolver = new Subject();
    buscaAoFocar = new Subject();
    controlId = this.campo.id;
    describedBy = this.campo.describedBy;
    /** Obrigatório pelo input próprio ou pelo `<s-field>` que envolve o controle. */
    isRequired = computed(() => this.required() || this.campo.obrigatorio(), ...(ngDevMode ? [{ debugName: "isRequired" }] : []));
    /** Inválido pelo input próprio ou pelo `<s-field>` que envolve o controle. */
    isInvalid = computed(() => this.invalid() || this.campo.invalido(), ...(ngDevMode ? [{ debugName: "isInvalid" }] : []));
    /** O rótulo interno só existe fora de um `<s-field>`. Ver o input `label`. */
    rotuloProprio = computed(() => !this.campo.campo && this.label().length > 0, ...(ngDevMode ? [{ debugName: "rotuloProprio" }] : []));
    /** Painel aberto: a seta aponta para cima e passa a fechar. */
    painelAberto = signal(false, ...(ngDevMode ? [{ debugName: "painelAberto" }] : []));
    gatilho = viewChild(MatAutocompleteTrigger, ...(ngDevMode ? [{ debugName: "gatilho" }] : []));
    constructor() {
        super();
        this.searchControl.valueChanges.pipe(takeUntilDestroyed()).subscribe((next) => {
            // Só é texto quando o usuário está digitando; a seleção grava um objeto.
            if (typeof next !== 'string') {
                this.termo.set('');
                return;
            }
            this.termo.set(next);
            // Digitar depois de selecionar invalida a seleção anterior.
            if (this.value() !== null) {
                this.emitirSelecao(null, null);
            }
        });
        // O output `search` respeita o mesmo `debounceTime` da consulta por `url`:
        // quem alimenta `options` por conta própria não deveria receber um evento
        // por tecla enquanto quem usa `url` recebe um a cada 300ms.
        this.searchControl.valueChanges
            .pipe(filter((valor) => typeof valor === 'string'), debounce(() => timer(this.debounceTime())), takeUntilDestroyed())
            .subscribe((texto) => this.search.emit(texto));
        // Mantém o texto do input sincronizado quando as opções chegam depois do
        // valor (cenário comum: `patchValue` antes da resposta da API).
        effect(() => {
            const options = this.visibleOptions();
            const value = this.value();
            if (value === null) {
                return;
            }
            const current = this.searchControl.value;
            if (current !== null &&
                typeof current !== 'string' &&
                this.comparar()(current.value, value)) {
                return;
            }
            const match = options.find((option) => this.comparar()(option.value, value));
            if (match) {
                this.searchControl.setValue(match, { emitEvent: false });
                // Com `optionLabel`, o formulario guarda o objeto: um valor que chegou
                // so como chave (`'A1'`) e trocado pelo objeto da opcao.
                if (this.optionLabel() && typeof value !== 'object' && match.value !== value) {
                    untracked(() => this.setValue(match.value));
                }
            }
        });
        // Consulta a fonte de dados quando a tela informa `url`. Sem `url` o fluxo
        // nem chega a ser assinado — quem busca continua sendo a aplicacao.
        merge(this.searchControl.valueChanges.pipe(filter((valor) => typeof valor === 'string'), debounce(() => timer(this.debounceTime())), map((termo) => ({ termo, imediata: false }))), this.buscaAoFocar.pipe(map((termo) => ({ termo, imediata: true }))))
            .pipe(switchMap(({ termo, imediata }) => {
            const url = this.url();
            if (!url) {
                return EMPTY;
            }
            if (!imediata && termo.length < this.minLength()) {
                this.fetched.set([]);
                return EMPTY;
            }
            if (!this.source) {
                throw new Error('<s-autocomplete url="..."> exige uma SAutocompleteSource. ' +
                    'Registre provideSiageAutocompleteSource(...) no app.config.ts.');
            }
            this.fetching.set(true);
            return this.source.search(this.pedido(url, termo)).pipe(
            // Uma busca que falha nao pode deixar o campo preso em "carregando".
            catchError(() => of([])), tap(() => this.fetching.set(false)), 
            // Nem cancelada: apagar o termo abaixo de `minLength` com a consulta
            // em voo troca a consulta por `EMPTY`, e o `tap` acima nunca roda.
            finalize(() => this.fetching.set(false)));
        }), takeUntilDestroyed())
            .subscribe((opcoes) => this.fetched.set(opcoes));
        // Pede à fonte o rótulo de um valor que chegou preenchido. Sem isto, uma
        // tela de edição mostra o campo em branco até alguém digitar.
        this.aResolver
            .pipe(switchMap((valor) => {
            const url = this.url();
            if (!url || !this.source?.resolve) {
                return EMPTY;
            }
            return this.source
                .resolve({
                url,
                value: valor,
                params: this.params(),
                ...extras({ controller: this.controller(), optionLabel: this.optionLabel() }),
            })
                .pipe(catchError(() => of(null)));
        }), filter((opcao) => opcao !== null), takeUntilDestroyed())
            .subscribe((opcao) => {
            const resolvida = opcao;
            // Entra em `fetched` para o efeito de sincronia achar o rótulo, como
            // aconteceria se a opção tivesse vindo de uma busca.
            this.fetched.update((atuais) => atuais.some((item) => this.comparar()(item.value, resolvida.value))
                ? atuais
                : [resolvida, ...atuais]);
        });
        // Espelha o estado desabilitado no controle interno.
        effect(() => {
            if (this.isDisabled()) {
                this.searchControl.disable({ emitEvent: false });
            }
            else {
                this.searchControl.enable({ emitEvent: false });
            }
        });
    }
    /** Exibe o `label` da opção no input (usado pelo `displayWith` do Material). */
    displayFn = (option) => {
        if (option === null || typeof option === 'string') {
            return option ?? '';
        }
        return option.label;
    };
    onOptionSelected(event) {
        const option = event.option.value;
        this.emitirSelecao(option.value, option);
    }
    onBlur() {
        this.onTouched();
        // Com o painel aberto, quem decide e o fechamento: o clique numa opcao
        // chega depois do blur.
        if (!this.gatilho()?.panelOpen) {
            this.descartarTextoSolto();
        }
    }
    onFocus() {
        if (this.searchOnFocus() && this.url() && !this.isLoading() && !this.fetched().length) {
            const atual = this.searchControl.value;
            this.buscaAoFocar.next(typeof atual === 'string' ? atual : '');
        }
    }
    /** `forceSelection`: o texto que nao virou escolha sai do campo. */
    descartarTextoSolto() {
        const atual = this.searchControl.value;
        if (this.forceSelection() && this.value() === null && typeof atual === 'string' && atual) {
            this.searchControl.setValue('', { emitEvent: false });
            this.termo.set('');
        }
    }
    /** O pedido a fonte, so com as chaves que a tela informou. */
    pedido(url, termo) {
        return {
            url,
            term: termo,
            params: this.params(),
            ...extras({
                searchFor: this.searchFor(),
                controller: this.controller(),
                optionLabel: this.optionLabel(),
            }),
        };
    }
    ehSelecionada(opcao) {
        const valor = this.value();
        return valor !== null && valor !== undefined && this.comparar()(opcao.value, valor);
    }
    clear(event) {
        event.stopPropagation();
        this.searchControl.setValue('', { emitEvent: false });
        this.termo.set('');
        if (this.value() !== null) {
            this.emitirSelecao(null, null);
        }
        this.search.emit('');
    }
    /**
     * Grava o valor via base, avisa o formulario e emite `selectionChange`.
     *
     * Diferente do `setValue` da base (que apenas grava e notifica o form), este
     * metodo tambem dispara o output de selecao — logica propria do autocomplete.
     */
    emitirSelecao(value, option) {
        this.setValue(value);
        this.selectionChange.emit(option);
    }
    // ---------------------------------------------------------------------------
    // Sobrescritas de SControlBase<T>
    // ---------------------------------------------------------------------------
    writeValue(value) {
        super.writeValue(value);
        const match = value === null || value === undefined
            ? undefined
            : this.visibleOptions().find((option) => this.comparar()(option.value, value));
        this.searchControl.setValue(match ?? '', { emitEvent: false });
        if (value === null || value === undefined || match) {
            return;
        }
        // Com `optionLabel`, o objeto que chegou ja diz o proprio rotulo.
        if (this.optionLabel() && typeof value === 'object') {
            const propria = { label: rotuloDoItem(value, this.optionLabel()), value };
            this.fetched.update((atuais) => [propria, ...atuais]);
            this.searchControl.setValue(propria, { emitEvent: false });
            return;
        }
        // Valor sem rótulo conhecido: pede à fonte, se a aplicação implementou.
        this.aResolver.next(value);
    }
    onOpened() {
        this.painelAberto.set(true);
    }
    onClosed() {
        this.painelAberto.set(false);
        this.descartarTextoSolto();
    }
    /**
     * A seta abre e fecha o painel, como o chevron do `<s-select>`. O foco vai
     * para o input, que e onde a digitacao e o teclado do painel acontecem.
     */
    alternarPainel(campo) {
        const gatilho = this.gatilho();
        if (!gatilho || this.isDisabled()) {
            return;
        }
        if (gatilho.panelOpen) {
            gatilho.closePanel();
            return;
        }
        campo.focus();
        gatilho.openPanel();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAutocompleteComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SAutocompleteComponent, isStandalone: true, selector: "s-autocomplete", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, optionLabel: { classPropertyName: "optionLabel", publicName: "optionLabel", isSignal: true, isRequired: false, transformFunction: null }, dataKey: { classPropertyName: "dataKey", publicName: "dataKey", isSignal: true, isRequired: false, transformFunction: null }, searchFor: { classPropertyName: "searchFor", publicName: "searchFor", isSignal: true, isRequired: false, transformFunction: null }, controller: { classPropertyName: "controller", publicName: "controller", isSignal: true, isRequired: false, transformFunction: null }, searchOnFocus: { classPropertyName: "searchOnFocus", publicName: "searchOnFocus", isSignal: true, isRequired: false, transformFunction: null }, forceSelection: { classPropertyName: "forceSelection", publicName: "forceSelection", isSignal: true, isRequired: false, transformFunction: null }, url: { classPropertyName: "url", publicName: "url", isSignal: true, isRequired: false, transformFunction: null }, params: { classPropertyName: "params", publicName: "params", isSignal: true, isRequired: false, transformFunction: null }, minLength: { classPropertyName: "minLength", publicName: "minLength", isSignal: true, isRequired: false, transformFunction: null }, compareWith: { classPropertyName: "compareWith", publicName: "compareWith", isSignal: true, isRequired: false, transformFunction: null }, debounceTime: { classPropertyName: "debounceTime", publicName: "debounceTime", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, noResultsText: { classPropertyName: "noResultsText", publicName: "noResultsText", isSignal: true, isRequired: false, transformFunction: null }, emptyText: { classPropertyName: "emptyText", publicName: "emptyText", isSignal: true, isRequired: false, transformFunction: null }, loadingText: { classPropertyName: "loadingText", publicName: "loadingText", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectionChange: "selectionChange", search: "search" }, host: { classAttribute: "s-autocomplete" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SAutocompleteComponent),
                multi: true,
            },
        ], queries: [{ propertyName: "opcaoTemplate", first: true, predicate: SOptionTemplateDirective, descendants: true, isSignal: true }, { propertyName: "rodape", first: true, predicate: SAutocompleteFooterDirective, descendants: true, isSignal: true }], viewQueries: [{ propertyName: "gatilho", first: true, predicate: MatAutocompleteTrigger, descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "@if (readOnly()) {\n  <div class=\"s-autocomplete__readonly\" [attr.id]=\"controlId()\">{{ textoSomenteLeitura() }}</div>\n} @else {\n  @if (rotuloProprio()) {\n    <!-- Rotulo de compatibilidade: so aparece fora de um <s-field>, para nao\n       duplicar o rotulo que o campo ja desenha. Ver o input `label`. -->\n    <label class=\"s-autocomplete__label\" [attr.for]=\"controlId()\">\n      {{ label() }}\n      @if (isRequired()) {\n        <span class=\"s-autocomplete__required\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n\n  <div\n    class=\"s-autocomplete__campo\"\n    matAutocompleteOrigin\n    #origem=\"matAutocompleteOrigin\"\n    [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.data-disabled]=\"isDisabled() ? 'true' : null\"\n  >\n    <input\n      #nativo\n      class=\"s-autocomplete__nativo\"\n      type=\"text\"\n      autocomplete=\"off\"\n      [id]=\"controlId()\"\n      [formControl]=\"searchControl\"\n      [matAutocomplete]=\"auto\"\n      [matAutocompleteConnectedTo]=\"origem\"\n      [placeholder]=\"placeholder()\"\n      [attr.aria-required]=\"isRequired() ? 'true' : null\"\n      [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      [attr.aria-busy]=\"isLoading() ? 'true' : null\"\n      (blur)=\"onBlur()\"\n      (focus)=\"onFocus()\"\n    />\n\n    <!-- Um lugar so para o indicador e a seta, com a mesma medida: trocar um\n       pelo outro nao mexe no texto nem desalinha o fim do campo. -->\n    <span class=\"s-autocomplete__fim\">\n      @if (isLoading()) {\n        <mat-spinner class=\"s-autocomplete__spinner\" diameter=\"20\" aria-hidden=\"true\" />\n      } @else {\n        <!-- Fora da ordem de tabulacao: pelo teclado, a seta para baixo no\n           proprio input ja abre o painel. O mousedown nao tira o foco do input,\n           senao o painel fecharia no mesmo clique que o abre. -->\n        <button\n          type=\"button\"\n          class=\"s-autocomplete__seta\"\n          tabindex=\"-1\"\n          [attr.aria-label]=\"painelAberto() ? 'Fechar op\u00E7\u00F5es' : 'Abrir op\u00E7\u00F5es'\"\n          [disabled]=\"isDisabled()\"\n          (mousedown)=\"$event.preventDefault()\"\n          (click)=\"alternarPainel(nativo)\"\n        >\n          <s-icon\n            [name]=\"painelAberto() ? 'keyboard_arrow_up' : 'keyboard_arrow_down'\"\n            variant=\"secondary\"\n            size=\"md\"\n          />\n        </button>\n      }\n    </span>\n\n    <mat-autocomplete\n      #auto\n      class=\"s-autocomplete__painel\"\n      [displayWith]=\"displayFn\"\n      (optionSelected)=\"onOptionSelected($event)\"\n      (opened)=\"onOpened()\"\n      (closed)=\"onClosed()\"\n    >\n      @if (isLoading()) {\n        <mat-option class=\"s-autocomplete__message\" disabled>{{ loadingText() }}</mat-option>\n      } @else if (isEmpty()) {\n        <mat-option class=\"s-autocomplete__message\" disabled>\n          {{ listaVazia() ? emptyText() : noResultsText() }}\n        </mat-option>\n      } @else {\n        @for (option of visibleOptions(); track option.value) {\n          <mat-option [value]=\"option\" [disabled]=\"option.disabled ?? false\">\n            @if (opcaoTemplate(); as modelo) {\n              <ng-container\n                [ngTemplateOutlet]=\"modelo.template\"\n                [ngTemplateOutletContext]=\"{\n                  $implicit: option,\n                  selected: ehSelecionada(option),\n                }\"\n              />\n            } @else {\n              {{ option.label }}\n            }\n          </mat-option>\n        }\n      }\n\n      @if (rodape(); as rodapeProprio) {\n        <!-- Fora das opcoes: o clique aqui nao escolhe nada nem fecha o painel. -->\n        <div class=\"s-autocomplete__rodape\" (mousedown)=\"$event.stopPropagation()\">\n          <ng-container [ngTemplateOutlet]=\"rodapeProprio.template\" />\n        </div>\n      }\n    </mat-autocomplete>\n  </div>\n}\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%}.s-autocomplete__label{min-height:20px;display:flex;align-items:center;gap:var(--space-4, 4px);margin-bottom:var(--space-4, 4px);font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);color:var(--text-primary)}.s-autocomplete__required{color:var(--destructive-on-surface)}.s-autocomplete__campo{--s-field-h: var(--field-h, 48px);box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;padding:0;position:relative;cursor:pointer;display:flex;align-items:center;gap:var(--space-8, 8px)}.s-autocomplete__campo:hover:not([data-disabled=true]){border-color:var(--border);background:var(--card)}.s-autocomplete__campo:focus-within{border:2px solid var(--primary);background:var(--card)}.s-autocomplete__campo[data-invalid=true]{border-color:var(--destructive)}.s-autocomplete__campo[data-disabled=true]{opacity:.4}.s-autocomplete__nativo{flex:1;min-width:0;height:var(--s-field-h, var(--field-h, 48px));padding:0;border:none;background:transparent;font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);width:100%;padding:0 0 0 var(--field-px, 16px)}.s-autocomplete__nativo::placeholder{color:var(--text-secondary)}.s-autocomplete__nativo:focus{outline:none}.s-autocomplete__nativo:disabled{opacity:1;cursor:default}.s-autocomplete__fim{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;width:var(--icon-md, 24px);height:var(--icon-md, 24px);margin-right:var(--field-px, 16px)}.s-autocomplete__seta{display:inline-flex;align-items:center;justify-content:center;width:100%;height:100%;padding:0;border:none;background:none;color:inherit;cursor:pointer}.s-autocomplete__seta:disabled{cursor:default}.s-autocomplete__clear{flex:0 0 auto;margin-right:calc(var(--space-8, 8px) * -1);width:var(--icon-md, 24px)}.s-autocomplete__readonly{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary)}:host ::ng-deep .mat-mdc-option .mdc-list-item__primary-text{font-family:var(--font-ui);font-size:var(--text-body, 14px)}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$5.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$5.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$5.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatAutocompleteModule }, { kind: "component", type: i2.MatAutocomplete, selector: "mat-autocomplete", inputs: ["aria-label", "aria-labelledby", "displayWith", "autoActiveFirstOption", "autoSelectActiveOption", "requireSelection", "panelWidth", "disableRipple", "class", "hideSingleSelectionIndicator"], outputs: ["optionSelected", "opened", "closed", "optionActivated"], exportAs: ["matAutocomplete"] }, { kind: "component", type: i1$3.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i2.MatAutocompleteTrigger, selector: "input[matAutocomplete], textarea[matAutocomplete]", inputs: ["matAutocomplete", "matAutocompletePosition", "matAutocompleteConnectedTo", "autocomplete", "matAutocompleteDisabled"], exportAs: ["matAutocompleteTrigger"] }, { kind: "directive", type: i2.MatAutocompleteOrigin, selector: "[matAutocompleteOrigin]", exportAs: ["matAutocompleteOrigin"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i4.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAutocompleteComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-autocomplete', imports: [
                        NgTemplateOutlet,
                        ReactiveFormsModule,
                        MatAutocompleteModule,
                        MatProgressSpinnerModule,
                        SIconComponent,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SAutocompleteComponent),
                            multi: true,
                        },
                    ], host: {
                        class: 's-autocomplete',
                    }, template: "@if (readOnly()) {\n  <div class=\"s-autocomplete__readonly\" [attr.id]=\"controlId()\">{{ textoSomenteLeitura() }}</div>\n} @else {\n  @if (rotuloProprio()) {\n    <!-- Rotulo de compatibilidade: so aparece fora de um <s-field>, para nao\n       duplicar o rotulo que o campo ja desenha. Ver o input `label`. -->\n    <label class=\"s-autocomplete__label\" [attr.for]=\"controlId()\">\n      {{ label() }}\n      @if (isRequired()) {\n        <span class=\"s-autocomplete__required\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n\n  <div\n    class=\"s-autocomplete__campo\"\n    matAutocompleteOrigin\n    #origem=\"matAutocompleteOrigin\"\n    [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n    [attr.data-disabled]=\"isDisabled() ? 'true' : null\"\n  >\n    <input\n      #nativo\n      class=\"s-autocomplete__nativo\"\n      type=\"text\"\n      autocomplete=\"off\"\n      [id]=\"controlId()\"\n      [formControl]=\"searchControl\"\n      [matAutocomplete]=\"auto\"\n      [matAutocompleteConnectedTo]=\"origem\"\n      [placeholder]=\"placeholder()\"\n      [attr.aria-required]=\"isRequired() ? 'true' : null\"\n      [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      [attr.aria-busy]=\"isLoading() ? 'true' : null\"\n      (blur)=\"onBlur()\"\n      (focus)=\"onFocus()\"\n    />\n\n    <!-- Um lugar so para o indicador e a seta, com a mesma medida: trocar um\n       pelo outro nao mexe no texto nem desalinha o fim do campo. -->\n    <span class=\"s-autocomplete__fim\">\n      @if (isLoading()) {\n        <mat-spinner class=\"s-autocomplete__spinner\" diameter=\"20\" aria-hidden=\"true\" />\n      } @else {\n        <!-- Fora da ordem de tabulacao: pelo teclado, a seta para baixo no\n           proprio input ja abre o painel. O mousedown nao tira o foco do input,\n           senao o painel fecharia no mesmo clique que o abre. -->\n        <button\n          type=\"button\"\n          class=\"s-autocomplete__seta\"\n          tabindex=\"-1\"\n          [attr.aria-label]=\"painelAberto() ? 'Fechar op\u00E7\u00F5es' : 'Abrir op\u00E7\u00F5es'\"\n          [disabled]=\"isDisabled()\"\n          (mousedown)=\"$event.preventDefault()\"\n          (click)=\"alternarPainel(nativo)\"\n        >\n          <s-icon\n            [name]=\"painelAberto() ? 'keyboard_arrow_up' : 'keyboard_arrow_down'\"\n            variant=\"secondary\"\n            size=\"md\"\n          />\n        </button>\n      }\n    </span>\n\n    <mat-autocomplete\n      #auto\n      class=\"s-autocomplete__painel\"\n      [displayWith]=\"displayFn\"\n      (optionSelected)=\"onOptionSelected($event)\"\n      (opened)=\"onOpened()\"\n      (closed)=\"onClosed()\"\n    >\n      @if (isLoading()) {\n        <mat-option class=\"s-autocomplete__message\" disabled>{{ loadingText() }}</mat-option>\n      } @else if (isEmpty()) {\n        <mat-option class=\"s-autocomplete__message\" disabled>\n          {{ listaVazia() ? emptyText() : noResultsText() }}\n        </mat-option>\n      } @else {\n        @for (option of visibleOptions(); track option.value) {\n          <mat-option [value]=\"option\" [disabled]=\"option.disabled ?? false\">\n            @if (opcaoTemplate(); as modelo) {\n              <ng-container\n                [ngTemplateOutlet]=\"modelo.template\"\n                [ngTemplateOutletContext]=\"{\n                  $implicit: option,\n                  selected: ehSelecionada(option),\n                }\"\n              />\n            } @else {\n              {{ option.label }}\n            }\n          </mat-option>\n        }\n      }\n\n      @if (rodape(); as rodapeProprio) {\n        <!-- Fora das opcoes: o clique aqui nao escolhe nada nem fecha o painel. -->\n        <div class=\"s-autocomplete__rodape\" (mousedown)=\"$event.stopPropagation()\">\n          <ng-container [ngTemplateOutlet]=\"rodapeProprio.template\" />\n        </div>\n      }\n    </mat-autocomplete>\n  </div>\n}\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%}.s-autocomplete__label{min-height:20px;display:flex;align-items:center;gap:var(--space-4, 4px);margin-bottom:var(--space-4, 4px);font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);color:var(--text-primary)}.s-autocomplete__required{color:var(--destructive-on-surface)}.s-autocomplete__campo{--s-field-h: var(--field-h, 48px);box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;padding:0;position:relative;cursor:pointer;display:flex;align-items:center;gap:var(--space-8, 8px)}.s-autocomplete__campo:hover:not([data-disabled=true]){border-color:var(--border);background:var(--card)}.s-autocomplete__campo:focus-within{border:2px solid var(--primary);background:var(--card)}.s-autocomplete__campo[data-invalid=true]{border-color:var(--destructive)}.s-autocomplete__campo[data-disabled=true]{opacity:.4}.s-autocomplete__nativo{flex:1;min-width:0;height:var(--s-field-h, var(--field-h, 48px));padding:0;border:none;background:transparent;font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);width:100%;padding:0 0 0 var(--field-px, 16px)}.s-autocomplete__nativo::placeholder{color:var(--text-secondary)}.s-autocomplete__nativo:focus{outline:none}.s-autocomplete__nativo:disabled{opacity:1;cursor:default}.s-autocomplete__fim{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;width:var(--icon-md, 24px);height:var(--icon-md, 24px);margin-right:var(--field-px, 16px)}.s-autocomplete__seta{display:inline-flex;align-items:center;justify-content:center;width:100%;height:100%;padding:0;border:none;background:none;color:inherit;cursor:pointer}.s-autocomplete__seta:disabled{cursor:default}.s-autocomplete__clear{flex:0 0 auto;margin-right:calc(var(--space-8, 8px) * -1);width:var(--icon-md, 24px)}.s-autocomplete__readonly{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary)}:host ::ng-deep .mat-mdc-option .mdc-list-item__primary-text{font-family:var(--font-ui);font-size:var(--text-body, 14px)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], optionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionLabel", required: false }] }], dataKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataKey", required: false }] }], searchFor: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchFor", required: false }] }], controller: [{ type: i0.Input, args: [{ isSignal: true, alias: "controller", required: false }] }], searchOnFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchOnFocus", required: false }] }], forceSelection: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceSelection", required: false }] }], url: [{ type: i0.Input, args: [{ isSignal: true, alias: "url", required: false }] }], params: [{ type: i0.Input, args: [{ isSignal: true, alias: "params", required: false }] }], minLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "minLength", required: false }] }], compareWith: [{ type: i0.Input, args: [{ isSignal: true, alias: "compareWith", required: false }] }], debounceTime: [{ type: i0.Input, args: [{ isSignal: true, alias: "debounceTime", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], noResultsText: [{ type: i0.Input, args: [{ isSignal: true, alias: "noResultsText", required: false }] }], emptyText: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyText", required: false }] }], loadingText: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingText", required: false }] }], selectionChange: [{ type: i0.Output, args: ["selectionChange"] }], search: [{ type: i0.Output, args: ["search"] }], opcaoTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => SOptionTemplateDirective), { isSignal: true }] }], rodape: [{ type: i0.ContentChild, args: [i0.forwardRef(() => SAutocompleteFooterDirective), { isSignal: true }] }], gatilho: [{ type: i0.ViewChild, args: [i0.forwardRef(() => MatAutocompleteTrigger), { isSignal: true }] }] } });

/**
 * Conversao entre os dois vocabularios de paginacao que o SIAGE usa.
 *
 * O `<s-pagination>` e o `<s-table>` falam `page` (1-based) e `pageSize`,
 * porque e o que aparece na tela: "página 2 de 5". Paginadores baseados em
 * `p-table` (PrimeNG) — o que a listagem antiga usava — falam `first`, o
 * indice 0-based do primeiro registro da pagina, e `rows`.
 *
 * Quem migra uma tela do PrimeNG para o `<s-table>` traduz o evento de
 * paginacao com estas duas funcoes, em vez de reescrever a conta em cada tela.
 */
/** `first`/`rows` do PrimeNG -> `page` (1-based) do `<s-table>`. */
function pageFromFirst(first, rows) {
    return rows > 0 ? Math.floor(first / rows) + 1 : 1;
}
/** `page` (1-based) do `<s-table>` -> `first` (0-based) do PrimeNG. */
function firstFromPage(page, pageSize) {
    return Math.max(0, page - 1) * pageSize;
}

/**
 * Confere se o usuario tem uma permissao.
 *
 * A biblioteca **nao conhece** o sistema de permissoes de cada aplicacao — o
 * Educacional usa `ngx-permissions`, outro sistema pode ler do token. Ela so
 * pergunta; a aplicacao implementa e responde. E o que o `<s-table>` usa para
 * esconder acoes quando `options.permissionConfig.enabled` esta ligado.
 *
 * Regras como "administrador pode tudo" sao da implementacao, nao daqui.
 *
 * **Esconder acao nao e controle de acesso.** O botao some da tela, mas a
 * rota e o endpoint continuam la: o backend precisa autorizar cada operacao,
 * e as rotas de edicao precisam de guard proprio.
 *
 * @example
 * ```ts
 * @Injectable({ providedIn: 'root' })
 * export class NgxPermissionChecker extends SPermissionChecker {
 *   private readonly permissoes = inject(NgxPermissionsService);
 *
 *   has(permission: string): boolean {
 *     const atuais = this.permissoes.getPermissions();
 *     return permission in atuais || PERFIL.ADMIN in atuais;
 *   }
 * }
 * ```
 */
class SPermissionChecker {
}
/**
 * Registra o verificador de permissoes da aplicacao.
 *
 * Sem ele, a tabela mostra todas as acoes configuradas mesmo com
 * `permissionConfig.enabled` — esconder tudo por falta de configuracao
 * pareceria defeito na tela, nao falta de permissao. Em desenvolvimento, o
 * `<s-table>` e o `<s-crud-form>` avisam no console quando isso acontece.
 *
 * ```ts
 * // app.config.ts
 * providers: [provideSiagePermissionChecker(NgxPermissionChecker)]
 * ```
 */
function provideSiagePermissionChecker(checker) {
    return makeEnvironmentProviders([{ provide: SPermissionChecker, useExisting: checker }]);
}

const PADROES = {
    'no-data': {
        icon: 'inbox',
        title: 'Nenhum registro cadastrado ainda',
        description: 'Cadastre o primeiro registro para começar.',
        actionLabel: 'Cadastrar registro',
    },
    'no-results': {
        icon: 'search_off',
        title: 'Nenhum resultado encontrado',
        description: 'Nenhum registro corresponde aos filtros aplicados.',
        actionLabel: 'Limpar filtros',
    },
    error: {
        icon: 'cloud_off',
        title: 'Não foi possível carregar os dados',
        description: 'Verifique sua conexão e tente novamente.',
        actionLabel: 'Tentar novamente',
    },
    forbidden: {
        icon: 'lock',
        title: 'Acesso restrito',
        description: 'Solicite acesso ao gestor da sua unidade escolar.',
        actionLabel: '',
    },
};
/**
 * Tres dos quatro estados obrigatorios do guia: vazio, erro de carregamento e
 * sem permissao. O quarto, carregando, e o `<s-skeleton>`.
 *
 * Cada variante ja vem com glifo, titulo, descricao e rotulo de acao coerentes
 * — o minimo para nao aparecer uma tela branca. Sobrescreva o que a tela souber
 * dizer melhor: "Nenhuma jornada encontrada" ensina mais que "Nenhum resultado".
 */
class SEmptyStateComponent {
    /** Por que a area esta sem conteudo. Ver `SEmptyStateVariant`. */
    variant = input('no-data', ...(ngDevMode ? [{ debugName: "variant" }] : []));
    /** Glifo de 48px. Por padrao, o da variante. */
    icon = input('', ...(ngDevMode ? [{ debugName: "icon" }] : []));
    /** Titulo curto. Por padrao, o da variante. */
    title = input('', ...(ngDevMode ? [{ debugName: "title" }] : []));
    /** Uma linha explicando o que aconteceu. Por padrao, a da variante. */
    description = input('', ...(ngDevMode ? [{ debugName: "description" }] : []));
    /**
     * Rotulo da acao unica. Por padrao, o da variante.
     *
     * String vazia esconde o botao — e o caso de `forbidden`, em que nao ha nada
     * que o usuario possa fazer na propria tela.
     */
    actionLabel = input(null, ...(ngDevMode ? [{ debugName: "actionLabel" }] : []));
    /**
     * Nivel do titulo. O padrao, 3, serve ao estado vazio dentro de um card ou
     * secao que ja tem o seu `h2`. Numa tela que so tem o `h1` (uma listagem
     * direto abaixo do cabecalho), use 2: pular nivel desorienta quem navega pelos
     * titulos com leitor de tela. O tamanho nao muda com o nivel.
     */
    headingLevel = input(3, ...(ngDevMode ? [{ debugName: "headingLevel" }] : []));
    /** Disparado pelo botao da acao. */
    action = output();
    padrao = computed(() => PADROES[this.variant()], ...(ngDevMode ? [{ debugName: "padrao" }] : []));
    glifo = computed(() => this.icon() || this.padrao().icon, ...(ngDevMode ? [{ debugName: "glifo" }] : []));
    titulo = computed(() => this.title() || this.padrao().title, ...(ngDevMode ? [{ debugName: "titulo" }] : []));
    descricao = computed(() => this.description() || this.padrao().description, ...(ngDevMode ? [{ debugName: "descricao" }] : []));
    rotuloAcao = computed(() => {
        const informado = this.actionLabel();
        return informado === null ? this.padrao().actionLabel : informado;
    }, ...(ngDevMode ? [{ debugName: "rotuloAcao" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SEmptyStateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SEmptyStateComponent, isStandalone: true, selector: "s-empty-state", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, actionLabel: { classPropertyName: "actionLabel", publicName: "actionLabel", isSignal: true, isRequired: false, transformFunction: null }, headingLevel: { classPropertyName: "headingLevel", publicName: "headingLevel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { action: "action" }, host: { properties: { "attr.role": "variant() === \"error\" ? \"alert\" : \"status\"" }, classAttribute: "s-empty-state" }, ngImport: i0, template: "<s-icon class=\"s-empty-state__icone\" [name]=\"glifo()\" size=\"lg\" />\n\n@switch (headingLevel()) {\n  @case (2) {\n    <h2 class=\"s-empty-state__titulo\">{{ titulo() }}</h2>\n  }\n  @case (4) {\n    <h4 class=\"s-empty-state__titulo\">{{ titulo() }}</h4>\n  }\n  @default {\n    <h3 class=\"s-empty-state__titulo\">{{ titulo() }}</h3>\n  }\n}\n\n<p class=\"s-empty-state__descricao\">{{ descricao() }}</p>\n\n@if (rotuloAcao()) {\n  <!-- Acao unica: duas opcoes num estado vazio deixam de orientar e passam a\n       exigir uma decisao de quem ja nao encontrou o que procurava. Nunca\n       preenchido: o estado vazio nao e a rota principal da tela, e o guia\n       proibe dois `primary` disputando a mesma decisao \u2014 o botao que ja\n       existe no cabecalho (ex.: \"+ Nova jornada\") continua sendo o unico\n       preenchido. -->\n  <s-button variant=\"secondary\" outlined (click)=\"action.emit()\">{{ rotuloAcao() }}</s-button>\n}\n", styles: [":host{display:flex;flex-direction:column;align-items:center;gap:var(--space-12, 12px);padding:var(--space-48, 48px) var(--space-24, 24px);text-align:center}.s-empty-state__icone{color:var(--text-secondary)}.s-empty-state__titulo{margin:0;font-family:var(--font-display);font-size:var(--text-h4, 20px);font-weight:var(--weight-semibold, 600);color:var(--text-primary)}.s-empty-state__descricao{max-width:440px;margin:0;font-size:var(--text-body, 14px);line-height:var(--leading-relaxed, 1.6);color:var(--text-secondary)}\n"], dependencies: [{ kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }, { kind: "component", type: SButtonComponent, selector: "s-button", inputs: ["variant", "outlined", "fullWidth", "pressed", "buttonRole", "checked", "focusIndex", "loading", "loadingText", "disabled", "icon", "iconRight", "type", "label"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SEmptyStateComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-empty-state', imports: [SIconComponent, SButtonComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-empty-state',
                        // Erro interrompe a leitura; os demais esperam a vez.
                        '[attr.role]': 'variant() === "error" ? "alert" : "status"',
                    }, template: "<s-icon class=\"s-empty-state__icone\" [name]=\"glifo()\" size=\"lg\" />\n\n@switch (headingLevel()) {\n  @case (2) {\n    <h2 class=\"s-empty-state__titulo\">{{ titulo() }}</h2>\n  }\n  @case (4) {\n    <h4 class=\"s-empty-state__titulo\">{{ titulo() }}</h4>\n  }\n  @default {\n    <h3 class=\"s-empty-state__titulo\">{{ titulo() }}</h3>\n  }\n}\n\n<p class=\"s-empty-state__descricao\">{{ descricao() }}</p>\n\n@if (rotuloAcao()) {\n  <!-- Acao unica: duas opcoes num estado vazio deixam de orientar e passam a\n       exigir uma decisao de quem ja nao encontrou o que procurava. Nunca\n       preenchido: o estado vazio nao e a rota principal da tela, e o guia\n       proibe dois `primary` disputando a mesma decisao \u2014 o botao que ja\n       existe no cabecalho (ex.: \"+ Nova jornada\") continua sendo o unico\n       preenchido. -->\n  <s-button variant=\"secondary\" outlined (click)=\"action.emit()\">{{ rotuloAcao() }}</s-button>\n}\n", styles: [":host{display:flex;flex-direction:column;align-items:center;gap:var(--space-12, 12px);padding:var(--space-48, 48px) var(--space-24, 24px);text-align:center}.s-empty-state__icone{color:var(--text-secondary)}.s-empty-state__titulo{margin:0;font-family:var(--font-display);font-size:var(--text-h4, 20px);font-weight:var(--weight-semibold, 600);color:var(--text-primary)}.s-empty-state__descricao{max-width:440px;margin:0;font-size:var(--text-body, 14px);line-height:var(--leading-relaxed, 1.6);color:var(--text-secondary)}\n"] }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], actionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "actionLabel", required: false }] }], headingLevel: [{ type: i0.Input, args: [{ isSignal: true, alias: "headingLevel", required: false }] }], action: [{ type: i0.Output, args: ["action"] }] } });

/**
 * Faixa de contagem do resultado atual.
 *
 * O formato e fixo pelo guia, e vale a pena ler devagar porque as tres regras
 * costumam ser quebradas por engano:
 *
 * 1. **`1–10 de 47`**, com meia-risca e **sem espacos** em volta dela. Nao e
 *    hifen, nao e "1 - 10".
 * 2. Sem paginacao, some a faixa e fica so **`12 registros`**.
 * 3. Com zero resultados **nao renderiza nada** — quem comunica ausencia e o
 *    `<s-empty-state>`, que explica o motivo e oferece a acao certa.
 *
 * `total` e sempre o total do **resultado atual**, ja filtrado — nunca o total
 * da base. Mostrar 4.812 quando o filtro devolveu 3 desorienta.
 */
class SRecordCountComponent {
    /** Pagina atual, comecando em 1. */
    page = input(1, ...(ngDevMode ? [{ debugName: "page", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Registros por pagina. `0` significa sem paginacao. */
    pageSize = input(10, ...(ngDevMode ? [{ debugName: "pageSize", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Total do resultado atual, ja filtrado. */
    total = input(0, ...(ngDevMode ? [{ debugName: "total", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Substantivo da contagem sem paginacao: `12 registros`, `12 turmas`. */
    itemsLabel = input('registros', ...(ngDevMode ? [{ debugName: "itemsLabel" }] : []));
    texto = computed(() => {
        const total = this.total();
        if (total <= 0) {
            return '';
        }
        const tamanho = this.pageSize();
        if (tamanho <= 0) {
            return `${total} ${this.itemsLabel()}`;
        }
        // Pagina alem do total (o total encolheu e a tela ainda nao voltou) conta
        // como a ultima: "51–47 de 47" nao e uma faixa.
        const ultimaPagina = Math.ceil(total / tamanho);
        const pagina = Math.min(Math.max(this.page(), 1), ultimaPagina);
        const primeiro = (pagina - 1) * tamanho + 1;
        const ultimo = Math.min(pagina * tamanho, total);
        // Meia-risca (–), nao hifen, e sem espacos: e o formato do guia.
        return `${primeiro}–${ultimo} de ${total}`;
    }, ...(ngDevMode ? [{ debugName: "texto" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SRecordCountComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.34", type: SRecordCountComponent, isStandalone: true, selector: "s-record-count", inputs: { page: { classPropertyName: "page", publicName: "page", isSignal: true, isRequired: false, transformFunction: null }, pageSize: { classPropertyName: "pageSize", publicName: "pageSize", isSignal: true, isRequired: false, transformFunction: null }, total: { classPropertyName: "total", publicName: "total", isSignal: true, isRequired: false, transformFunction: null }, itemsLabel: { classPropertyName: "itemsLabel", publicName: "itemsLabel", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.aria-live": "'polite'" }, classAttribute: "s-record-count" }, ngImport: i0, template: '{{ texto() }}', isInline: true, styles: [":host{font-size:var(--text-caption, 12px);color:var(--text-secondary);font-variant-numeric:tabular-nums;white-space:nowrap}:host:empty{display:none}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SRecordCountComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-record-count', template: '{{ texto() }}', changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-record-count',
                        '[attr.aria-live]': "'polite'",
                    }, styles: [":host{font-size:var(--text-caption, 12px);color:var(--text-secondary);font-variant-numeric:tabular-nums;white-space:nowrap}:host:empty{display:none}\n"] }]
        }], propDecorators: { page: [{ type: i0.Input, args: [{ isSignal: true, alias: "page", required: false }] }], pageSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSize", required: false }] }], total: [{ type: i0.Input, args: [{ isSignal: true, alias: "total", required: false }] }], itemsLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemsLabel", required: false }] }] } });

/**
 * Rodape da tabela: registros por pagina, contagem e navegacao.
 *
 * Encapsula o `<s-record-count>` e o seletor de tamanho, para que a tela nao
 * precise montar os tres a mao. Fica **sempre no rodape da tabela**, nunca
 * flutuante.
 *
 * Nao envolve o `mat-paginator`: ele traz o proprio texto ("1 – 10 of 47"), a
 * propria ordem de controles e um `MatPaginatorIntl` global para traduzir. Como
 * o formato da contagem e fixo pelo guia e o seletor usa o `<s-select>` do
 * design system, sobrava pouco do Material para aproveitar.
 */
class SPaginationComponent {
    /** Pagina atual, comecando em 1. */
    page = input(1, ...(ngDevMode ? [{ debugName: "page", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Registros por pagina. */
    pageSize = input(10, ...(ngDevMode ? [{ debugName: "pageSize", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /**
     * Nome acessivel da navegacao entre paginas.
     *
     * Vira `aria-label` no `<nav>`. So precisa mudar quando a tela tem mais de uma
     * listagem paginada — dai "Paginação" sozinho deixa de distinguir qual.
     */
    label = input('Paginação', ...(ngDevMode ? [{ debugName: "label" }] : []));
    /** Total do resultado atual, ja filtrado. */
    total = input(0, ...(ngDevMode ? [{ debugName: "total", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Opcoes do seletor de tamanho. O guia fixa 10, 25 e 50. */
    pageSizeOptions = input([10, 25, 50], ...(ngDevMode ? [{ debugName: "pageSizeOptions" }] : []));
    /** Substantivo usado na contagem sem paginacao. */
    itemsLabel = input('registros', ...(ngDevMode ? [{ debugName: "itemsLabel" }] : []));
    /** Esconde o seletor de tamanho, quando a tela nao permite trocar. */
    hidePageSize = input(false, ...(ngDevMode ? [{ debugName: "hidePageSize", transform: (v) => v === '' || !!v }] : [{ transform: (v) => v === '' || !!v }]));
    /** Nova pagina escolhida. */
    pageChange = output();
    /** Novo tamanho de pagina. Quem escuta deve voltar para a pagina 1. */
    pageSizeChange = output();
    totalPaginas = computed(() => {
        const tamanho = this.pageSize();
        return tamanho > 0 ? Math.max(1, Math.ceil(this.total() / tamanho)) : 1;
    }, ...(ngDevMode ? [{ debugName: "totalPaginas" }] : []));
    naPrimeira = computed(() => this.page() <= 1, ...(ngDevMode ? [{ debugName: "naPrimeira" }] : []));
    naUltima = computed(() => this.page() >= this.totalPaginas(), ...(ngDevMode ? [{ debugName: "naUltima" }] : []));
    opcoesDeTamanho = computed(() => this.pageSizeOptions().map((tamanho) => ({ label: `${tamanho}`, value: tamanho })), ...(ngDevMode ? [{ debugName: "opcoesDeTamanho" }] : []));
    irPara(pagina) {
        const destino = Math.min(Math.max(pagina, 1), this.totalPaginas());
        if (destino !== this.page()) {
            this.pageChange.emit(destino);
        }
    }
    trocarTamanho(tamanho) {
        if (tamanho !== null && tamanho !== this.pageSize()) {
            this.pageSizeChange.emit(tamanho);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SPaginationComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SPaginationComponent, isStandalone: true, selector: "s-pagination", inputs: { page: { classPropertyName: "page", publicName: "page", isSignal: true, isRequired: false, transformFunction: null }, pageSize: { classPropertyName: "pageSize", publicName: "pageSize", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, total: { classPropertyName: "total", publicName: "total", isSignal: true, isRequired: false, transformFunction: null }, pageSizeOptions: { classPropertyName: "pageSizeOptions", publicName: "pageSizeOptions", isSignal: true, isRequired: false, transformFunction: null }, itemsLabel: { classPropertyName: "itemsLabel", publicName: "itemsLabel", isSignal: true, isRequired: false, transformFunction: null }, hidePageSize: { classPropertyName: "hidePageSize", publicName: "hidePageSize", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { pageChange: "pageChange", pageSizeChange: "pageSizeChange" }, host: { classAttribute: "s-pagination" }, ngImport: i0, template: "@if (!hidePageSize()) {\n  <label class=\"s-pagination__tamanho\">\n    Registros por p\u00E1gina\n    <s-select\n      class=\"s-pagination__select\"\n      [options]=\"opcoesDeTamanho()\"\n      [clearable]=\"false\"\n      label=\"Registros por p\u00E1gina\"\n      [ngModel]=\"pageSize()\"\n      (ngModelChange)=\"trocarTamanho($event)\"\n    />\n  </label>\n}\n\n<s-record-count\n  [page]=\"page()\"\n  [pageSize]=\"pageSize()\"\n  [total]=\"total()\"\n  [itemsLabel]=\"itemsLabel()\"\n/>\n\n<nav class=\"s-pagination__navegacao\" [attr.aria-label]=\"label()\">\n  <s-icon-button\n    icon=\"first_page\"\n    label=\"Primeira p\u00E1gina\"\n    size=\"sm\"\n    [disabled]=\"naPrimeira()\"\n    (click)=\"irPara(1)\"\n  />\n  <s-icon-button\n    icon=\"chevron_left\"\n    label=\"P\u00E1gina anterior\"\n    size=\"sm\"\n    [disabled]=\"naPrimeira()\"\n    (click)=\"irPara(page() - 1)\"\n  />\n\n  <span class=\"s-pagination__posicao\">{{ page() }} de {{ totalPaginas() }}</span>\n\n  <s-icon-button\n    icon=\"chevron_right\"\n    label=\"Pr\u00F3xima p\u00E1gina\"\n    size=\"sm\"\n    [disabled]=\"naUltima()\"\n    (click)=\"irPara(page() + 1)\"\n  />\n  <s-icon-button\n    icon=\"last_page\"\n    label=\"\u00DAltima p\u00E1gina\"\n    size=\"sm\"\n    [disabled]=\"naUltima()\"\n    (click)=\"irPara(totalPaginas())\"\n  />\n</nav>\n", styles: [":host{display:flex;align-items:center;gap:var(--space-16, 16px);flex-wrap:wrap;padding:var(--space-12, 12px) var(--space-16, 16px);border-top:1px solid var(--card-border)}.s-pagination__tamanho{display:inline-flex;align-items:center;gap:var(--space-8, 8px);font-size:var(--text-caption, 12px);color:var(--text-secondary);white-space:nowrap}.s-pagination__select{width:88px}.s-pagination__navegacao{display:flex;align-items:center;gap:var(--space-4, 4px);margin-left:auto}.s-pagination__posicao{padding:0 var(--space-8, 8px);font-size:var(--text-caption, 12px);color:var(--text-secondary);font-variant-numeric:tabular-nums;white-space:nowrap}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$5.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$5.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }, { kind: "component", type: SSelectComponent, selector: "s-select", inputs: ["options", "compareWith", "clearable", "filterable", "filterPlaceholder", "noResultsText", "emptyText"] }, { kind: "component", type: SRecordCountComponent, selector: "s-record-count", inputs: ["page", "pageSize", "total", "itemsLabel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SPaginationComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-pagination', imports: [FormsModule, SIconButtonComponent, SSelectComponent, SRecordCountComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-pagination',
                    }, template: "@if (!hidePageSize()) {\n  <label class=\"s-pagination__tamanho\">\n    Registros por p\u00E1gina\n    <s-select\n      class=\"s-pagination__select\"\n      [options]=\"opcoesDeTamanho()\"\n      [clearable]=\"false\"\n      label=\"Registros por p\u00E1gina\"\n      [ngModel]=\"pageSize()\"\n      (ngModelChange)=\"trocarTamanho($event)\"\n    />\n  </label>\n}\n\n<s-record-count\n  [page]=\"page()\"\n  [pageSize]=\"pageSize()\"\n  [total]=\"total()\"\n  [itemsLabel]=\"itemsLabel()\"\n/>\n\n<nav class=\"s-pagination__navegacao\" [attr.aria-label]=\"label()\">\n  <s-icon-button\n    icon=\"first_page\"\n    label=\"Primeira p\u00E1gina\"\n    size=\"sm\"\n    [disabled]=\"naPrimeira()\"\n    (click)=\"irPara(1)\"\n  />\n  <s-icon-button\n    icon=\"chevron_left\"\n    label=\"P\u00E1gina anterior\"\n    size=\"sm\"\n    [disabled]=\"naPrimeira()\"\n    (click)=\"irPara(page() - 1)\"\n  />\n\n  <span class=\"s-pagination__posicao\">{{ page() }} de {{ totalPaginas() }}</span>\n\n  <s-icon-button\n    icon=\"chevron_right\"\n    label=\"Pr\u00F3xima p\u00E1gina\"\n    size=\"sm\"\n    [disabled]=\"naUltima()\"\n    (click)=\"irPara(page() + 1)\"\n  />\n  <s-icon-button\n    icon=\"last_page\"\n    label=\"\u00DAltima p\u00E1gina\"\n    size=\"sm\"\n    [disabled]=\"naUltima()\"\n    (click)=\"irPara(totalPaginas())\"\n  />\n</nav>\n", styles: [":host{display:flex;align-items:center;gap:var(--space-16, 16px);flex-wrap:wrap;padding:var(--space-12, 12px) var(--space-16, 16px);border-top:1px solid var(--card-border)}.s-pagination__tamanho{display:inline-flex;align-items:center;gap:var(--space-8, 8px);font-size:var(--text-caption, 12px);color:var(--text-secondary);white-space:nowrap}.s-pagination__select{width:88px}.s-pagination__navegacao{display:flex;align-items:center;gap:var(--space-4, 4px);margin-left:auto}.s-pagination__posicao{padding:0 var(--space-8, 8px);font-size:var(--text-caption, 12px);color:var(--text-secondary);font-variant-numeric:tabular-nums;white-space:nowrap}\n"] }]
        }], propDecorators: { page: [{ type: i0.Input, args: [{ isSignal: true, alias: "page", required: false }] }], pageSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSize", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], total: [{ type: i0.Input, args: [{ isSignal: true, alias: "total", required: false }] }], pageSizeOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSizeOptions", required: false }] }], itemsLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemsLabel", required: false }] }], hidePageSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "hidePageSize", required: false }] }], pageChange: [{ type: i0.Output, args: ["pageChange"] }], pageSizeChange: [{ type: i0.Output, args: ["pageSizeChange"] }] } });

/** Aceita `180` e `'60%'` — px quando e numero. */
function medida(valor, padrao) {
    if (valor === undefined || valor === null || valor === '') {
        return padrao;
    }
    return typeof valor === 'number' ? `${valor}px` : valor;
}
/**
 * Placeholder no formato do conteudo final.
 *
 * O quarto dos estados obrigatorios do guia. A regra e curta e vale sempre:
 * **nunca spinner central** em tabela ou card — spinner so dentro de botao em
 * carregamento. O esqueleto ocupa o mesmo espaco que o dado vai ocupar, entao a
 * tela nao salta quando a resposta chega.
 *
 * Quando mostrar e decisao da aplicacao. Para uma tabela, o `<s-table>` ja
 * cuida disso com o limiar de `S_LOADING_DELAY`.
 */
class SSkeletonComponent {
    /** Largura. Numero vira px; string passa direto (`'60%'`). */
    width = input('100%', ...(ngDevMode ? [{ debugName: "width" }] : []));
    /** Altura. Numero vira px; string passa direto. */
    height = input(16, ...(ngDevMode ? [{ debugName: "height" }] : []));
    /** Deixa o bloco redondo — para o lugar de um avatar. */
    circle = input(false, ...(ngDevMode ? [{ debugName: "circle", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    larguraCss = computed(() => medida(this.width(), '100%'), ...(ngDevMode ? [{ debugName: "larguraCss" }] : []));
    alturaCss = computed(() => medida(this.height(), '16px'), ...(ngDevMode ? [{ debugName: "alturaCss" }] : []));
    raioCss = computed(() => this.circle() ? 'var(--radius-full, 9999px)' : 'var(--radius-control, 8px)', ...(ngDevMode ? [{ debugName: "raioCss" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SSkeletonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.34", type: SSkeletonComponent, isStandalone: true, selector: "s-skeleton", inputs: { width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null }, circle: { classPropertyName: "circle", publicName: "circle", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "aria-hidden": "true" }, properties: { "style.width": "larguraCss()", "style.height": "alturaCss()", "style.border-radius": "raioCss()" }, classAttribute: "s-skeleton" }, ngImport: i0, template: '', isInline: true, styles: [":host{display:block;background:color-mix(in srgb,var(--text-primary) 10%,transparent);animation:s-skeleton-brilho 1.4s ease-in-out infinite}@keyframes s-skeleton-brilho{0%,to{opacity:1}50%{opacity:.45}}@media(prefers-reduced-motion:reduce){:host{animation:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SSkeletonComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-skeleton', template: '', changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-skeleton',
                        'aria-hidden': 'true',
                        '[style.width]': 'larguraCss()',
                        '[style.height]': 'alturaCss()',
                        '[style.border-radius]': 'raioCss()',
                    }, styles: [":host{display:block;background:color-mix(in srgb,var(--text-primary) 10%,transparent);animation:s-skeleton-brilho 1.4s ease-in-out infinite}@keyframes s-skeleton-brilho{0%,to{opacity:1}50%{opacity:.45}}@media(prefers-reduced-motion:reduce){:host{animation:none}}\n"] }]
        }], propDecorators: { width: [{ type: i0.Input, args: [{ isSignal: true, alias: "width", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }], circle: [{ type: i0.Input, args: [{ isSignal: true, alias: "circle", required: false }] }] } });
/**
 * Esqueleto no formato de uma tabela.
 *
 * Desenha `rows` x `columns` blocos com a mesma altura de linha do
 * `<s-table>`, para que a troca do esqueleto pelos dados nao mova nada.
 *
 * `hasSelection` e `hasActions` desenham as colunas nao configuraveis do
 * `<s-table>` (caixa de selecao e acoes) com a mesma largura de conteudo
 * (`width:1%`) que elas tem na tabela real — sem isso, a grade uniforme
 * alargava a coluna de acoes e o esqueleto "pulava" na troca pelos dados.
 */
class STableSkeletonComponent {
    /** Linhas desenhadas. */
    rows = input(5, ...(ngDevMode ? [{ debugName: "rows", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Colunas de dados desenhadas — sem contar selecao e acoes. */
    columns = input(5, ...(ngDevMode ? [{ debugName: "columns", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Desenha a coluna de caixas de selecao, estreita como na tabela real. */
    hasSelection = input(false, ...(ngDevMode ? [{ debugName: "hasSelection", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Desenha a coluna de acoes, estreita como na tabela real. */
    hasActions = input(false, ...(ngDevMode ? [{ debugName: "hasActions", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    linhas = computed(() => Array.from({ length: this.rows() }, (_, i) => i), ...(ngDevMode ? [{ debugName: "linhas" }] : []));
    colunasDeDados = computed(() => Array.from({ length: this.columns() }, (_, i) => i), ...(ngDevMode ? [{ debugName: "colunasDeDados" }] : []));
    colunasCss = computed(() => {
        const partes = [];
        if (this.hasSelection()) {
            partes.push('40px');
        }
        partes.push(`repeat(${this.columns()}, 1fr)`);
        if (this.hasActions()) {
            partes.push('96px');
        }
        return partes.join(' ');
    }, ...(ngDevMode ? [{ debugName: "colunasCss" }] : []));
    larguraDaCelula(coluna) {
        // A primeira coluna costuma ser o nome, a mais longa; as demais alternam
        // para o bloco nao virar um retangulo chapado.
        if (coluna === 0) {
            return '80%';
        }
        return coluna % 2 === 0 ? '55%' : '70%';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: STableSkeletonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: STableSkeletonComponent, isStandalone: true, selector: "s-table-skeleton", inputs: { rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: false, transformFunction: null }, hasSelection: { classPropertyName: "hasSelection", publicName: "hasSelection", isSignal: true, isRequired: false, transformFunction: null }, hasActions: { classPropertyName: "hasActions", publicName: "hasActions", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "status", "aria-label": "Carregando" }, classAttribute: "s-table-skeleton" }, ngImport: i0, template: `
    <div class="s-table-skeleton__grade" [style.grid-template-columns]="colunasCss()">
      @for (linha of linhas(); track linha) {
        @if (hasSelection()) {
          <div class="s-table-skeleton__celula s-table-skeleton__celula--estreita">
            <s-skeleton [width]="20" [height]="20" />
          </div>
        }

        @for (coluna of colunasDeDados(); track coluna) {
          <div class="s-table-skeleton__celula">
            <!-- Larguras diferentes por coluna: um bloco uniforme parece uma
                 barra de progresso, nao uma tabela. -->
            <s-skeleton [width]="larguraDaCelula(coluna)" [height]="16" />
          </div>
        }

        @if (hasActions()) {
          <div class="s-table-skeleton__celula s-table-skeleton__celula--estreita">
            <s-skeleton [width]="64" [height]="16" />
          </div>
        }
      }
    </div>
  `, isInline: true, styles: [":host{display:block;width:100%}.s-table-skeleton__grade{display:grid}.s-table-skeleton__celula{display:flex;align-items:center;height:52px;padding:0 var(--space-16, 16px);border-top:1px solid var(--card-border)}.s-table-skeleton__celula--estreita{justify-content:center}\n"], dependencies: [{ kind: "component", type: SSkeletonComponent, selector: "s-skeleton", inputs: ["width", "height", "circle"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: STableSkeletonComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-table-skeleton', imports: [SSkeletonComponent], template: `
    <div class="s-table-skeleton__grade" [style.grid-template-columns]="colunasCss()">
      @for (linha of linhas(); track linha) {
        @if (hasSelection()) {
          <div class="s-table-skeleton__celula s-table-skeleton__celula--estreita">
            <s-skeleton [width]="20" [height]="20" />
          </div>
        }

        @for (coluna of colunasDeDados(); track coluna) {
          <div class="s-table-skeleton__celula">
            <!-- Larguras diferentes por coluna: um bloco uniforme parece uma
                 barra de progresso, nao uma tabela. -->
            <s-skeleton [width]="larguraDaCelula(coluna)" [height]="16" />
          </div>
        }

        @if (hasActions()) {
          <div class="s-table-skeleton__celula s-table-skeleton__celula--estreita">
            <s-skeleton [width]="64" [height]="16" />
          </div>
        }
      }
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-table-skeleton',
                        role: 'status',
                        'aria-label': 'Carregando',
                    }, styles: [":host{display:block;width:100%}.s-table-skeleton__grade{display:grid}.s-table-skeleton__celula{display:flex;align-items:center;height:52px;padding:0 var(--space-16, 16px);border-top:1px solid var(--card-border)}.s-table-skeleton__celula--estreita{justify-content:center}\n"] }]
        }], propDecorators: { rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: false }] }], columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: false }] }], hasSelection: [{ type: i0.Input, args: [{ isSignal: true, alias: "hasSelection", required: false }] }], hasActions: [{ type: i0.Input, args: [{ isSignal: true, alias: "hasActions", required: false }] }] } });

/**
 * Filtro da marcacao que o `formatter` do generic-list devolve.
 *
 * O `formatter` mistura marcacao fixa da tela com dado de quem cadastrou —
 * nome de arquivo enviado, nome de turma. O sanitizador do Angular ja tira
 * script e handler de evento, mas deixa passar `<img src>` e `<a href>`
 * externos: um anexo chamado `<img src="https://fora/pixel">` carregaria a
 * imagem de fora, e um `<a>` poria um link falso na tela de outra pessoa.
 *
 * Aqui so fica a marcacao de layout que as telas usam (blocos, enfase, lista)
 * com `class`, `title` e `aria-*`. Elemento fora da lista sai, mas o texto
 * dele fica — um `<a>` vira so o rotulo; script, estilo e afins saem inteiros.
 * O resultado ainda passa pelo sanitizador do Angular no `[innerHTML]`.
 *
 * Nao e exportado em `public-api.ts`: e detalhe do `<s-table>`.
 */
const TAGS_PERMITIDAS = new Set([
    'div',
    'span',
    'p',
    'br',
    'strong',
    'b',
    'em',
    'i',
    'small',
    'ul',
    'ol',
    'li',
]);
/** Fora da lista e sem texto util: sai com o conteudo. */
const TAGS_DESCARTADAS = new Set([
    'script',
    'style',
    'template',
    'iframe',
    'object',
    'embed',
    'noscript',
    'svg',
    'math',
    'textarea',
    'select',
    'option',
]);
const ATRIBUTO_PERMITIDO = /^(class|title|aria-[a-z-]+)$/;
function filtrarHtmlDaCelula(html, documento) {
    // `<template>` analisa sem executar nem carregar nada: imagem nao e buscada.
    const modelo = documento.createElement('template');
    modelo.innerHTML = html;
    const saida = documento.createElement('div');
    copiar(modelo.content, saida, documento);
    return saida.innerHTML;
}
function copiar(origem, destino, documento) {
    for (const no of Array.from(origem.childNodes)) {
        if (no.nodeType === Node.TEXT_NODE) {
            destino.appendChild(documento.createTextNode(no.textContent ?? ''));
            continue;
        }
        if (no.nodeType !== Node.ELEMENT_NODE) {
            continue;
        }
        const elemento = no;
        const tag = elemento.localName;
        if (TAGS_PERMITIDAS.has(tag)) {
            const copia = documento.createElement(tag);
            for (const atributo of Array.from(elemento.attributes)) {
                if (ATRIBUTO_PERMITIDO.test(atributo.name)) {
                    copia.setAttribute(atributo.name, atributo.value);
                }
            }
            destino.appendChild(copia);
            copiar(elemento, copia, documento);
        }
        else if (!TAGS_DESCARTADAS.has(tag)) {
            copiar(elemento, destino, documento);
        }
    }
}

/**
 * Template proprio para uma coluna, quando o texto nao da conta.
 *
 * A coluna comum e declarada em `STableColumn` — rotulo, alinhamento, badge,
 * valor formatado. Isso cobre a maioria das celulas, e por isso continua sendo
 * o caminho padrao. O que nao cabe ali e a celula que **age**: um botao que
 * abre o detalhe de "em uso", um link para outra tela, um progresso.
 *
 * Escrever a excecao como template mantem a configuracao declarativa para o
 * resto da tabela, sem obrigar a biblioteca a prever cada caso — que e como
 * uma coluna nova terminava virando um `if` a mais dentro do componente.
 *
 * @example
 * ```html
 * <s-table [columns]="colunas" [rows]="linhas()">
 *   <ng-template sTableCell="emUso" let-linha>
 *     @if (linha.emUso) {
 *       <s-button variant="ghost" icon="link" (click)="verUsos(linha)">Ver usos</s-button>
 *     } @else {
 *       <span aria-hidden="true">—</span>
 *     }
 *   </ng-template>
 * </s-table>
 * ```
 */
class STableCellDirective {
    /** `key` da coluna que este template desenha. */
    column = input.required(...(ngDevMode ? [{ debugName: "column", alias: 'sTableCell' }] : [{ alias: 'sTableCell' }]));
    /** @internal — lido pela tabela, nao pela aplicacao. */
    template = inject(TemplateRef);
    /**
     * Tipa `let-linha` no template, em vez de entregar `any`.
     *
     * Sem isto o `strictTemplates` trata o contexto como implicito e qualquer
     * erro de nome so aparece em execucao.
     */
    static ngTemplateContextGuard(_diretiva, _contexto) {
        return true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: STableCellDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "20.3.34", type: STableCellDirective, isStandalone: true, selector: "ng-template[sTableCell]", inputs: { column: { classPropertyName: "column", publicName: "sTableCell", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: STableCellDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ng-template[sTableCell]',
                }]
        }], propDecorators: { column: [{ type: i0.Input, args: [{ isSignal: true, alias: "sTableCell", required: true }] }] } });
/** @internal — usado pela tabela e pelo `<s-crud-list>`. */
function mapCellTemplates(diretivas) {
    const mapa = {};
    for (const diretiva of diretivas) {
        mapa[diretiva.column()] = diretiva.template;
    }
    return mapa;
}

/** @internal — traduz a severidade do PrimeNG para o tom do `<s-badge>`. */
function severityTone(severidade) {
    switch (severidade) {
        case 'success':
        case 'secondary':
        case 'info':
            return severidade;
        case 'warn':
            return 'warning';
        case 'danger':
            return 'destructive';
        case 'primary':
            return 'info';
        default:
            return 'default';
    }
}

/** Acoes padrao da configuracao por `options`, na ordem em que aparecem. */
const LIST_ACTIONS = [
    { id: 'view', icon: 'search', label: 'Visualizar' },
    { id: 'edit', icon: 'edit', label: 'Editar' },
    { id: 'remove', icon: 'delete', label: 'Remover', variant: 'destructive', text: true },
];
function pageRows(page) {
    const open = page;
    return open.items ?? open.data ?? [];
}
function pageTotal(page) {
    const open = page;
    return open.totalCount ?? open.total ?? 0;
}
/** Alinhamento pelas classes de texto do PrimeFlex que as telas ja usam no `styleClass`. */
function alignFromClass(styleClass) {
    const classes = styleClass?.split(/\s+/) ?? [];
    if (classes.includes('text-center')) {
        return 'center';
    }
    return classes.includes('text-right') || classes.includes('text-end') ? 'end' : undefined;
}
/** Formatacao padrao da celula no generic-list: booleano vira Sim/Nao, vazio vira "-". */
function defaultText(value) {
    if (typeof value === 'boolean') {
        return value ? 'Sim' : 'Não';
    }
    return value === null || value === undefined ? '-' : String(value);
}
function compareValues(a, b) {
    if (a === b) {
        return 0;
    }
    if (a === null || a === undefined) {
        return -1;
    }
    if (b === null || b === undefined) {
        return 1;
    }
    if (typeof a === 'number' && typeof b === 'number') {
        return a - b;
    }
    return String(a).localeCompare(String(b), 'pt-BR', { numeric: true });
}
/**
 * So nomes do Material Symbols (`check`, `add_circle`). Classe do PrimeIcons
 * (`pi pi-check`) viraria texto solto dentro do icone, entao e descartada.
 */
function materialGlyph(name) {
    return name && /^[a-z0-9_]+$/.test(name) ? name : '';
}
/**
 * Tabela de listagem, dentro de card, com os quatro estados obrigatorios.
 *
 * ## Por que existe uma so
 *
 * O Professores tinha duas: `app-table-custom` (a tabela) e `app-generic-list`
 * (titulo, botao de criar e a tabela dentro). A segunda nao acrescentava
 * comportamento de tabela — acrescentava **moldura de tela**.
 *
 * Aqui isso vira composicao, e cada peca tem um dono claro:
 *
 * ```html
 * <s-page-header title="Jornadas" [action]="..." />   <!-- titulo e criar -->
 * <s-filter-card (search)="buscar()" (clear)="limpar()">…</s-filter-card>
 * <s-table [columns]="colunas" [rows]="linhas()" />   <!-- so a tabela -->
 * ```
 *
 * Quem so precisa de tabela usa uma linha; quem precisa da tela inteira usa
 * tres, sem ter que escolher entre dois componentes concorrentes.
 *
 * ## Os quatro estados
 *
 * A tabela resolve os quatro sozinha, e e por isso que a tela nao precisa de
 * `@if` nenhum em volta dela:
 *
 * | Situacao | O que aparece |
 * | --- | --- |
 * | `loading` | linhas de esqueleto nas colunas, depois do limiar de `S_LOADING_DELAY` |
 * | sem linhas | `<s-empty-state>` com a variante de `empty` |
 * | com linhas | as linhas |
 * | erro / sem permissao | `<s-empty-state>`, informando `empty.variant` |
 *
 * O esqueleto **so aparece depois de 800ms** (ajustavel em `S_LOADING_DELAY`).
 * Uma resposta rapida que pisca o esqueleto por 80ms incomoda mais que a
 * espera. Ate la, sem linhas antigas para manter, o corpo fica em branco na
 * altura do esqueleto - nunca com o estado vazio, que afirmaria "nenhum
 * registro" antes de a consulta responder.
 *
 * ## Ordenacao
 *
 * E controlada: a tabela emite `sortChange` e espera receber `sort` de volta.
 * O ciclo do guia e `asc → desc → ordem original`, e quem reordena os dados e a
 * aplicacao — que muitas vezes vai delegar ao backend.
 *
 * ## Migrando do `app-generic-list`
 *
 * A tabela aceita os mesmos inputs, outputs e templates do generic-list do
 * Professores e do Educacional. A troca e so de tag e de nome de tipo:
 *
 * ```html
 * <s-table
 *   [options]="genericListOptions"
 *   [itensPaginated]="paginatedResource.value()"
 *   (filter)="onLazyLoad($event)"
 *   (create)="novo()" (view)="ver($event)" (edit)="editar($event)"
 *   (remove)="onDelete($event)" (inactivate)="onInactive($event)"
 * >
 *   <ng-template #customActions let-item>…</ng-template>
 * </s-table>
 * ```
 *
 * Com `options` informado, a tabela passa a controlar pagina, tamanho e
 * ordenacao por conta propria e avisa por `(filter)`, com `first`/`rows` como
 * o `p-table` fazia — o `onLazyLoad` da tela continua como esta. Os tipos
 * equivalentes estao em `SListOptions`.
 */
class STableComponent {
    /** Colunas exibidas, na ordem. */
    columns = input([], ...(ngDevMode ? [{ debugName: "columns" }] : []));
    /**
     * Nome acessivel da tabela, anunciado pelo leitor de tela.
     *
     * Vira `aria-label` no `<table>`. Use quando o titulo da secao ja diz o que a
     * tabela contem e nao ha motivo para repetir no HTML visivel. Numa tela com
     * mais de uma listagem, e o que distingue uma da outra para quem navega por
     * leitor de tela — que anuncia "tabela" e nada mais quando o nome falta.
     *
     * Quando ambos estiverem preenchidos, `caption` vence: o `<caption>` e visivel
     * **e** acessivel, e a presenca de `aria-label` junto de `<caption>` cria
     * anuncio duplicado. Prefira um ou outro; se informar os dois, `label` sera
     * ignorado e o template usa so `<caption>`.
     */
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
    /** Linhas da pagina atual. */
    rows = input([], ...(ngDevMode ? [{ debugName: "rows" }] : []));
    /** Acoes da ultima coluna. Vazio esconde a coluna. */
    actions = input([], ...(ngDevMode ? [{ debugName: "actions" }] : []));
    /**
     * Templates de celula por `key` de coluna, quando quem monta a tabela nao e
     * quem escreve o template.
     *
     * Usar `<ng-template sTableCell="...">` dentro da propria `<s-table>` e o
     * caminho normal, e continua sendo o recomendado. Este input existe para o
     * componente intermediario — o `<s-crud-list>` e casos parecidos — que
     * recebe os templates da tela e precisa repassa-los para a tabela que ele
     * possui por dentro.
     */
    cellTemplates = input({}, ...(ngDevMode ? [{ debugName: "cellTemplates" }] : []));
    /** Ordenacao atual. `null` e a ordem em que os dados chegaram. */
    sort = input(null, ...(ngDevMode ? [{ debugName: "sort" }] : []));
    /** Consulta em andamento. O esqueleto so aparece apos `S_LOADING_DELAY`. */
    loading = input(false, ...(ngDevMode ? [{ debugName: "loading", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** O que mostrar quando nao ha linhas. Ver `STableEmpty`. */
    empty = input({}, ...(ngDevMode ? [{ debugName: "empty" }] : []));
    /** Rotulo acessivel da tabela, visivel e anunciado por leitores de tela.
     *
     * Renderiza um `<caption>` dentro do `<table>`. Prefira quando o nome da
     * tabela deve aparecer na interface; quando basta o anuncio invisivel, use
     * `label` (que vira `aria-label`). Evite informar os dois: `caption` tem
     * prioridade, e `label` sera ignorado para nao duplicar o anuncio.
     */
    caption = input('', ...(ngDevMode ? [{ debugName: "caption" }] : []));
    /**
     * Acrescenta a coluna de selecao, antes de todas as outras.
     *
     * Use quando a tela tem acoes em lote — inativar varias jornadas, exportar
     * um recorte. Sem uma acao em lote, a coluna so ocupa espaco e sugere algo
     * que nao acontece.
     */
    selectable = input(false, ...(ngDevMode ? [{ debugName: "selectable", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Linhas marcadas. A selecao e controlada, como a ordenacao. */
    selection = input([], ...(ngDevMode ? [{ debugName: "selection" }] : []));
    /**
     * Compara linha com linha ao conferir a selecao.
     *
     * O padrao e identidade, que basta quando as linhas da tela sao as mesmas
     * instancias. Informe uma funcao quando os dados forem recriados a cada
     * resposta — comparar por id resolve.
     */
    compareWith = input((a, b) => a === b, ...(ngDevMode ? [{ debugName: "compareWith" }] : []));
    // --- rodape -------------------------------------------------------------
    /** Pagina atual. O rodape so aparece quando `total` e maior que zero. */
    page = input(1, ...(ngDevMode ? [{ debugName: "page", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Registros por pagina. */
    pageSize = input(10, ...(ngDevMode ? [{ debugName: "pageSize", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Total do resultado atual, ja filtrado. `0` esconde o rodape. */
    total = input(0, ...(ngDevMode ? [{ debugName: "total", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Opcoes do seletor de tamanho. */
    pageSizeOptions = input([10, 25, 50], ...(ngDevMode ? [{ debugName: "pageSizeOptions" }] : []));
    /** Substantivo usado na contagem. */
    itemsLabel = input('registros', ...(ngDevMode ? [{ debugName: "itemsLabel" }] : []));
    // --- configuracao do generic-list ---------------------------------------
    /**
     * Configuracao completa no formato do `GenericListOptions`: colunas, acoes
     * padrao, titulo, botao de cadastrar, permissoes e paginacao.
     *
     * Informada, substitui `columns`, `page`, `pageSize`, `sort` e
     * `pageSizeOptions`: a tabela guarda o estado de pagina e ordenacao e avisa
     * por `(filter)`. E o caminho para migrar tela que usava `app-generic-list`
     * sem reescrever o objeto de configuracao. Tela nova pode usar os inputs
     * soltos.
     */
    options = input(null, ...(ngDevMode ? [{ debugName: "options" }] : []));
    /**
     * Pagina vinda do servidor, como `PaginacaoDto` (`data`/`total`) ou
     * `PagedResult` (`items`/`totalCount`). Tem prioridade sobre `itens`.
     */
    itensPaginated = input(undefined, ...(ngDevMode ? [{ debugName: "itensPaginated" }] : []));
    /**
     * Lista completa, sem paginacao no servidor. Com `tableConfig.lazy: false`,
     * a tabela pagina e ordena em memoria; sem isso, exibe a lista como veio.
     */
    itens = input(undefined, ...(ngDevMode ? [{ debugName: "itens" }] : []));
    /**
     * Lista vazia, no modo `options`: com texto, ele aparece sozinho, numa
     * linha, como aviso da propria tela ("Nenhuma certidão adicionada."). Sem
     * texto, vale o estado vazio de "nenhum resultado". O template
     * `#emptyMessage` e `empty` tem prioridade.
     */
    emptyMessage = input('', ...(ngDevMode ? [{ debugName: "emptyMessage" }] : []));
    /**
     * Sem a moldura de card (fundo, borda, sombra). Para a tabela que ja mora
     * dentro de um card da tela — duas molduras uma dentro da outra pesam.
     */
    frameless = input(false, ...(ngDevMode ? [{ debugName: "frameless", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    // --- saidas -------------------------------------------------------------
    /** Botao de cadastrar do cabecalho (`options.addButton`). */
    create = output();
    /** Acao "Visualizar". Nao emite quando `options.routeBase` navega. */
    view = output();
    /** Acao "Editar". Nao emite quando `options.routeBase` navega. */
    edit = output();
    /** Acao "Remover". A confirmacao e da tela. */
    remove = output();
    /**
     * Chave de ativo/inativo. Emite a linha como estava antes do clique; quem
     * confirma e persiste e a tela.
     */
    inactivate = output();
    /**
     * Pagina, tamanho ou ordenacao mudaram — e uma vez na criacao, como o
     * `onLazyLoad` do `p-table`, a menos que `tableConfig.lazy` seja `false`.
     * So emite com `options`.
     */
    filter = output();
    /** Nova ordenacao pedida. Ciclo: asc, desc, original. */
    sortChange = output();
    /** Nova selecao. Quem escuta deve devolver em `selection`. */
    selectionChange = output();
    /** Acao acionada numa linha. */
    actionClick = output();
    /** Nova pagina. */
    pageChange = output();
    /** Novo tamanho de pagina. Quem escuta deve voltar para a pagina 1. */
    pageSizeChange = output();
    /** Botao do estado vazio. */
    emptyAction = output();
    /** Carregando ha tempo suficiente para valer a pena mostrar. */
    showSkeleton = adiarCarregamento(this.loading);
    /**
     * Linhas de esqueleto no corpo: depois do limiar, ou antes dele quando nao ha
     * linhas antigas para manter na tela.
     *
     * No segundo caso elas entram invisiveis (ver `skeletonHidden`), so para
     * reservar a altura. O que nao pode aparecer ali e o estado vazio: "nenhum
     * registro cadastrado" com o botao de cadastrar, durante uma consulta que
     * ainda nao respondeu, e uma afirmacao falsa.
     */
    skeletonVisible = computed(() => this.showSkeleton() || (this.loading() && this.isEmpty()), ...(ngDevMode ? [{ debugName: "skeletonVisible" }] : []));
    skeletonHidden = computed(() => !this.showSkeleton(), ...(ngDevMode ? [{ debugName: "skeletonHidden" }] : []));
    /** Cinco linhas: o bastante para ler como tabela sem empurrar o rodape. */
    skeletonRows = [0, 1, 2, 3, 4];
    router = inject(Router, { optional: true });
    permissionChecker = inject(SPermissionChecker, { optional: true });
    documento = inject(DOCUMENT);
    // O template pede a celula a cada verificacao; o filtro analisa HTML. A mesma
    // string devolve o mesmo resultado, entao fica guardada — com teto, para uma
    // listagem longa nao acumular memoria.
    htmlFiltrado = new Map();
    // Estado de paginacao e ordenacao do modo `options`. A `tableConfig` e um
    // objeto que a tela muta (`tableConfig.first = 0`), sem trocar a referencia;
    // por isso a sincronizacao e feita em `ngDoCheck`, como o `p-table` fazia ao
    // reler o binding a cada verificacao.
    listFirst = signal(0, ...(ngDevMode ? [{ debugName: "listFirst" }] : []));
    listRows = signal(10, ...(ngDevMode ? [{ debugName: "listRows" }] : []));
    listSort = signal(null, ...(ngDevMode ? [{ debugName: "listSort" }] : []));
    seenConfig = null;
    /** Acoes extras da linha: a projetada vence a da configuracao. */
    projectedActionsTemplate = contentChild('customActions', ...(ngDevMode ? [{ debugName: "projectedActionsTemplate" }] : []));
    addButtonTemplate = contentChild('addButton', ...(ngDevMode ? [{ debugName: "addButtonTemplate" }] : []));
    emptyMessageTemplate = contentChild('emptyMessage', ...(ngDevMode ? [{ debugName: "emptyMessageTemplate" }] : []));
    listMode = computed(() => this.options() !== null, ...(ngDevMode ? [{ debugName: "listMode" }] : []));
    customActionsTemplate = computed(() => this.projectedActionsTemplate() ?? this.options()?.customActionsTemplate ?? null, ...(ngDevMode ? [{ debugName: "customActionsTemplate" }] : []));
    resolvedColumns = computed(() => {
        const opts = this.options();
        return opts ? opts.tableConfig.columns.map((c) => this.toTableColumn(c)) : this.columns();
    }, ...(ngDevMode ? [{ debugName: "resolvedColumns" }] : []));
    resolvedRows = computed(() => {
        const opts = this.options();
        if (!opts) {
            return this.rows();
        }
        const page = this.itensPaginated();
        if (page) {
            return pageRows(page);
        }
        const items = this.itens() ?? [];
        return opts.tableConfig.lazy === false ? this.paginateInMemory(items, opts) : items;
    }, ...(ngDevMode ? [{ debugName: "resolvedRows" }] : []));
    resolvedTotal = computed(() => {
        if (!this.listMode()) {
            return this.total();
        }
        const page = this.itensPaginated();
        return page ? pageTotal(page) : (this.itens()?.length ?? 0);
    }, ...(ngDevMode ? [{ debugName: "resolvedTotal" }] : []));
    resolvedPageSize = computed(() => this.listMode() ? this.listRows() : this.pageSize(), ...(ngDevMode ? [{ debugName: "resolvedPageSize" }] : []));
    resolvedPage = computed(() => this.listMode() ? pageFromFirst(this.listFirst(), this.listRows()) : this.page(), ...(ngDevMode ? [{ debugName: "resolvedPage" }] : []));
    resolvedPageSizeOptions = computed(() => this.options()?.tableConfig.rowsPerPageOptions ?? this.pageSizeOptions(), ...(ngDevMode ? [{ debugName: "resolvedPageSizeOptions" }] : []));
    resolvedSort = computed(() => {
        if (!this.listMode()) {
            return this.sort();
        }
        const order = this.listSort();
        const column = order && this.resolvedColumns().find((c) => c.source?.sort === order.field);
        return column ? { key: column.key, direction: order.order === -1 ? 'desc' : 'asc' } : null;
    }, ...(ngDevMode ? [{ debugName: "resolvedSort" }] : []));
    /** Acoes padrao do generic-list, ja filtradas pela configuracao e permissao. */
    listActions = computed(() => {
        const opts = this.options();
        if (!opts) {
            return [];
        }
        return LIST_ACTIONS.filter((action) => opts.actions?.[action.id] && this.isAllowed(action.id)).map((action) => ({
            id: action.id,
            icon: action.icon,
            label: opts.actionsTooltips?.[action.id] ?? action.label,
            variant: action.variant,
            text: action.text,
        }));
    }, ...(ngDevMode ? [{ debugName: "listActions" }] : []));
    resolvedActions = computed(() => [...this.listActions(), ...this.actions()], ...(ngDevMode ? [{ debugName: "resolvedActions" }] : []));
    /** A chave de ativo/inativo; na linha, so aparece se ela tiver `ativo`. */
    hasInactivate = computed(() => !!this.options()?.actions?.inactivate && this.isAllowed('inactivate'), ...(ngDevMode ? [{ debugName: "hasInactivate" }] : []));
    inactivateLabel = computed(() => this.options()?.actionsTooltips?.inactivate ?? 'Ativar/Inativar', ...(ngDevMode ? [{ debugName: "inactivateLabel" }] : []));
    addButton = computed(() => {
        const button = this.options()?.addButton;
        if (!button?.show || !this.isAllowed('create')) {
            return null;
        }
        return { label: button.label ?? 'Adicionar', icon: materialGlyph(button.icon) || 'add' };
    }, ...(ngDevMode ? [{ debugName: "addButton" }] : []));
    titleIcon = computed(() => materialGlyph(this.options()?.iconTitle), ...(ngDevMode ? [{ debugName: "titleIcon" }] : []));
    hasHeader = computed(() => this.listMode() &&
        !!(this.options()?.title || this.titleIcon() || this.addButton() || this.addButtonTemplate()), ...(ngDevMode ? [{ debugName: "hasHeader" }] : []));
    isEmpty = computed(() => this.resolvedRows().length === 0, ...(ngDevMode ? [{ debugName: "isEmpty" }] : []));
    hasFooter = computed(() => 
    // Sem exigir linhas na pagina: com `total > 0` ha para onde ir, e o
    // paginador e a saida de uma pagina que ficou vazia.
    this.options()?.tableConfig.paginator !== false && this.resolvedTotal() > 0, ...(ngDevMode ? [{ debugName: "hasFooter" }] : []));
    hasActions = computed(() => this.resolvedActions().length > 0 || this.hasInactivate() || !!this.customActionsTemplate(), ...(ngDevMode ? [{ debugName: "hasActions" }] : []));
    /** Colunas mais as duas que nao sao configuraveis: selecao e acoes. */
    columnCount = computed(() => this.resolvedColumns().length + (this.hasActions() ? 1 : 0) + (this.selectable() ? 1 : 0), ...(ngDevMode ? [{ debugName: "columnCount" }] : []));
    /**
     * Quantas linhas **desta pagina** estao marcadas. A caixa do cabecalho fala
     * da pagina; contar a selecao inteira dava "15 de 10 linhas selecionadas"
     * quando havia marcadas em outras paginas.
     */
    marcadasNaPagina = computed(() => this.resolvedRows().filter((row) => this.isSelected(row)).length, ...(ngDevMode ? [{ debugName: "marcadasNaPagina" }] : []));
    allSelected = computed(() => {
        const total = this.resolvedRows().length;
        return total > 0 && this.marcadasNaPagina() === total;
    }, ...(ngDevMode ? [{ debugName: "allSelected" }] : []));
    /** Algumas, mas nao todas — o estado que a caixa do cabecalho representa. */
    someSelected = computed(() => this.marcadasNaPagina() > 0 && !this.allSelected(), ...(ngDevMode ? [{ debugName: "someSelected" }] : []));
    emptyVariant = computed(() => this.empty().variant ?? (this.listMode() ? 'no-results' : 'no-data'), ...(ngDevMode ? [{ debugName: "emptyVariant" }] : []));
    emptyTitle = computed(() => this.empty().title ?? '', ...(ngDevMode ? [{ debugName: "emptyTitle" }] : []));
    /** O aviso em texto simples de `emptyMessage` (ver o input). */
    emptyText = computed(() => this.listMode() && !this.empty().title ? this.emptyMessage() : '', ...(ngDevMode ? [{ debugName: "emptyText" }] : []));
    /**
     * Aria-label dinamico do checkbox do cabecalho, refletindo a quantidade
     * selecionada para quem navega por leitor de tela.
     */
    headerCheckboxLabel = computed(() => {
        const total = this.resolvedRows().length;
        const selectedCount = this.marcadasNaPagina();
        if (selectedCount === 0) {
            return 'Selecionar todas as linhas desta página';
        }
        if (selectedCount === total) {
            return `Desmarcar todas as ${total} linhas desta página`;
        }
        return `${selectedCount} de ${total} linhas selecionadas. Clique para selecionar todas`;
    }, ...(ngDevMode ? [{ debugName: "headerCheckboxLabel" }] : []));
    /**
     * Referencia ao `<s-checkbox>` do cabecalho, para setar `indeterminate` no
     * `<input>` nativo que ele encapsula. O Angular nao expoe esse estado por
     * binding (`[indeterminate]` nao e um atributo HTML refletido em booleano),
     * entao e preciso acesso direto ao DOM.
     */
    headerCheckboxRef = viewChild('headerCheckbox', ...(ngDevMode ? [{ debugName: "headerCheckboxRef", read: ElementRef }] : [{
            read: ElementRef,
        }]));
    constructor() {
        // Sem verificador registrado, a conferencia ligada mostra todas as acoes
        // (ver `provideSiagePermissionChecker`). Em producao isso e silencioso; em
        // desenvolvimento avisa, para o esquecimento aparecer antes do deploy.
        effect(() => {
            if (typeof ngDevMode !== 'undefined' &&
                ngDevMode &&
                this.options()?.permissionConfig?.enabled &&
                !this.permissionChecker) {
                console.warn('[STableComponent] permissionConfig.enabled está ligado, mas a aplicação não registrou ' +
                    'provideSiagePermissionChecker: todas as ações aparecem. Esconder ação não é controle ' +
                    'de acesso — o backend precisa autorizar cada operação.');
            }
        });
        effect(() => {
            const indeterminate = this.someSelected();
            const el = this.headerCheckboxRef()?.nativeElement;
            const nativeInput = el?.querySelector('input[type="checkbox"]');
            if (nativeInput) {
                nativeInput.indeterminate = indeterminate;
            }
        });
        // Pagina que ficou vazia - a ultima linha dela foi excluida, ou o total
        // encolheu - volta para a ultima pagina que existe. Sem isto o usuario fica
        // diante de "nenhum registro" sem paginador para sair dali.
        effect(() => {
            if (this.loading() || !this.isEmpty()) {
                return;
            }
            const total = this.resolvedTotal();
            const tamanho = this.resolvedPageSize();
            const pagina = this.resolvedPage();
            if (total <= 0 || tamanho <= 0 || pagina <= 1) {
                return;
            }
            const ultima = Math.ceil(total / tamanho);
            if (pagina > ultima) {
                untracked(() => this.goToPage(ultima));
            }
        });
    }
    ngOnInit() {
        this.syncWithConfig();
        if (this.options() && this.options()?.tableConfig.lazy !== false) {
            this.emitFilter();
        }
    }
    ngDoCheck() {
        this.syncWithConfig();
    }
    /** Aplica o que mudou na `tableConfig` desde a ultima verificacao. */
    syncWithConfig() {
        const config = this.options()?.tableConfig;
        if (!config) {
            this.seenConfig = null;
            return;
        }
        const current = {
            first: config.first,
            rows: config.defaultRows,
            sortField: config.sortField,
            sortOrder: config.sortOrder,
        };
        const seen = this.seenConfig;
        if (!seen || seen.first !== current.first) {
            this.listFirst.set(current.first ?? 0);
        }
        if (!seen || seen.rows !== current.rows) {
            this.listRows.set(current.rows ?? 10);
        }
        if (!seen || seen.sortField !== current.sortField || seen.sortOrder !== current.sortOrder) {
            this.listSort.set(current.sortField
                ? { field: current.sortField, order: current.sortOrder === -1 ? -1 : 1 }
                : null);
        }
        this.seenConfig = current;
    }
    emitFilter() {
        const order = this.listSort();
        this.filter.emit({
            first: this.listFirst(),
            rows: this.listRows(),
            sortField: order?.field ?? null,
            sortOrder: order?.order ?? 1,
        });
    }
    isAllowed(action) {
        const config = this.options()?.permissionConfig;
        const required = config?.enabled ? config.permissions?.[action] : undefined;
        return !required || !this.permissionChecker || this.permissionChecker.has(required);
    }
    toTableColumn(column) {
        const value = (row) => column.formatter ? column.formatter(row) : defaultText(row[column.field]);
        const severity = column.pTag;
        return {
            key: String(column.field),
            label: column.header,
            align: column.align ?? alignFromClass(column.styleClass),
            sortable: !!column.sort,
            truncate: column.truncate,
            value,
            badge: severity
                ? (row) => ({
                    label: value(row),
                    tone: severityTone(severity(row)),
                    icon: materialGlyph(column.pTagIcon),
                })
                : undefined,
            source: column,
        };
    }
    /** `itens` com `lazy: false`: ordena e recorta a pagina aqui mesmo. */
    paginateInMemory(items, opts) {
        const order = this.listSort();
        const column = order && opts.tableConfig.columns.find((c) => c.sort === order.field);
        const sorted = column
            ? [...items].sort((a, b) => compareValues(a[column.field], b[column.field]) * order.order)
            : items;
        if (opts.tableConfig.paginator === false) {
            return sorted;
        }
        const start = this.listFirst();
        return sorted.slice(start, start + this.listRows());
    }
    /** Templates declarados dentro da propria tag. */
    projectedCellTemplates = contentChildren((STableCellDirective), ...(ngDevMode ? [{ debugName: "projectedCellTemplates" }] : []));
    /**
     * Os dois caminhos somados: o que veio projetado vence o que veio por input,
     * porque quem escreveu o template ali na tela e quem esta mais perto do caso.
     */
    cellTemplateMap = computed(() => ({
        ...this.cellTemplates(),
        ...mapCellTemplates(this.projectedCellTemplates()),
    }), ...(ngDevMode ? [{ debugName: "cellTemplateMap" }] : []));
    cellTemplate(column) {
        return this.cellTemplateMap()[column.key] ?? null;
    }
    cellContext(column, row, index) {
        return { $implicit: row, row, column, index };
    }
    /**
     * Tooltip da celula: o que a coluna definir; na falta dele, o texto inteiro,
     * mas so quando a coluna trunca — repetir em tooltip o que ja esta legivel na
     * tela e ruido.
     */
    cellTooltip(column, row) {
        const custom = column.tooltip?.(row);
        if (custom) {
            return custom;
        }
        return column.truncate ? this.cellText(column, row) : '';
    }
    cellText(column, row) {
        if (column.value) {
            return column.value(row);
        }
        const raw = row[column.key];
        return raw === null || raw === undefined ? '' : String(raw);
    }
    /** Celula do `formatter`: so a marcacao de layout passa (ver `celula-html.ts`). */
    cellHtml(column, row) {
        const bruto = this.cellText(column, row);
        let filtrado = this.htmlFiltrado.get(bruto);
        if (filtrado === undefined) {
            filtrado = filtrarHtmlDaCelula(bruto, this.documento);
            if (this.htmlFiltrado.size >= 500) {
                this.htmlFiltrado.clear();
            }
            this.htmlFiltrado.set(bruto, filtrado);
        }
        return filtrado;
    }
    /**
     * A primeira coluna costuma ser o nome, a mais longa; as demais alternam
     * para o esqueleto nao virar uma barra de progresso.
     */
    skeletonWidth(index) {
        if (index === 0) {
            return '80%';
        }
        return index % 2 === 0 ? '55%' : '70%';
    }
    actionLabel(action, row) {
        return typeof action.label === 'function' ? action.label(row) : action.label;
    }
    isSelected(row) {
        const compare = this.compareWith();
        return this.selection().some((selected) => compare(selected, row));
    }
    toggleRow(row) {
        const compare = this.compareWith();
        this.selectionChange.emit(this.isSelected(row)
            ? this.selection().filter((selected) => !compare(selected, row))
            : [...this.selection(), row]);
    }
    /**
     * A caixa do cabecalho vale para a **pagina atual**, nao para o resultado
     * inteiro: marcar 10 linhas e desmarcar 4.812 sem aviso seria uma surpresa
     * cara. Selecionar tudo alem da pagina, se a tela precisar, e acao dela.
     *
     * Pelo mesmo motivo, o que foi marcado em outras paginas fica como esta: a
     * caixa so marca e desmarca as linhas que a pessoa esta vendo.
     */
    toggleAll() {
        const compare = this.compareWith();
        const pagina = this.resolvedRows();
        const deOutrasPaginas = this.selection().filter((selected) => !pagina.some((row) => compare(selected, row)));
        this.selectionChange.emit(this.allSelected() ? deOutrasPaginas : [...deOutrasPaginas, ...pagina]);
    }
    /** Como a linha e chamada para o leitor de tela: o texto da primeira coluna. */
    rowLabel(row) {
        const primeira = this.resolvedColumns()[0];
        return primeira ? this.cellText(primeira, row) : '';
    }
    /**
     * A chave de ativo/inativo so avisa a tela; quem muda `row.ativo` e ela,
     * depois de confirmar e persistir. Ate la a chave volta para o valor da
     * linha - se a tela cancelar, o `[ngModel]` nao mudaria e a chave ficaria
     * invertida, mostrando um estado que nao e o do registro.
     */
    alternarAtivo(row, chave) {
        this.inactivate.emit(row);
        // O `viewModel` tambem volta: sem isso, quando a tela confirmar e trocar
        // `row.ativo`, o `NgModel` acharia que a chave ja mostra o valor novo e nao
        // a atualizaria.
        const atual = !!row.ativo;
        chave.viewModel = atual;
        chave.control.setValue(atual, { emitViewToModelChange: false });
    }
    visibleActions(row) {
        return this.resolvedActions().filter((action) => !action.hidden?.(row));
    }
    /**
     * Toda acao sai por `actionClick`; as padrao do generic-list tambem pelo
     * output com o nome dela, que e o que a tela migrada escuta.
     */
    runAction(action, row) {
        this.actionClick.emit({ action: action.id, row });
        if (!this.listActions().includes(action)) {
            return;
        }
        if (action.id === 'remove') {
            this.remove.emit(row);
        }
        else if (action.id === 'view' || action.id === 'edit') {
            this.navigateOrEmit(action.id, row);
        }
    }
    /** Com `routeBase` e `id`, navega como o Educacional; sem, emite. */
    navigateOrEmit(action, row) {
        const base = this.options()?.routeBase;
        const id = row.id;
        if (base && this.router && id !== null && id !== undefined) {
            void this.router.navigate([base, action === 'edit' ? 'editar' : 'visualizar', id]);
            return;
        }
        (action === 'edit' ? this.edit : this.view).emit(row);
    }
    hasActiveFlag(row) {
        return 'ativo' in row;
    }
    goToPage(page) {
        if (this.listMode()) {
            this.listFirst.set(firstFromPage(page, this.listRows()));
            this.emitFilter();
        }
        this.pageChange.emit(page);
    }
    changePageSize(size) {
        if (this.listMode()) {
            this.listRows.set(size);
            this.listFirst.set(0);
            this.emitFilter();
        }
        this.pageSizeChange.emit(size);
    }
    /** `aria-sort` da coluna, para o leitor de tela anunciar a ordenacao. */
    ariaSort(column) {
        if (!column.sortable) {
            return null;
        }
        const current = this.resolvedSort();
        if (current?.key !== column.key) {
            return 'none';
        }
        return current.direction === 'asc' ? 'ascending' : 'descending';
    }
    sortIcon(column) {
        const current = this.resolvedSort();
        if (current?.key !== column.key) {
            return 'unfold_more';
        }
        return current.direction === 'asc' ? 'arrow_upward' : 'arrow_downward';
    }
    /**
     * Ciclo do guia: ascendente, descendente, ordem original. Com `options`, a
     * tabela guarda a ordenacao, volta para a primeira pagina (como o `p-table`)
     * e avisa por `(filter)`; a ordem original sai como `sortField: null`.
     */
    toggleSort(column) {
        if (!column.sortable) {
            return;
        }
        const current = this.resolvedSort();
        let next;
        if (current?.key !== column.key) {
            next = { key: column.key, direction: 'asc' };
        }
        else {
            next = current.direction === 'asc' ? { key: column.key, direction: 'desc' } : null;
        }
        const field = column.source?.sort;
        if (this.listMode() && field) {
            this.listSort.set(next ? { field, order: next.direction === 'desc' ? -1 : 1 } : null);
            this.listFirst.set(0);
            this.emitFilter();
        }
        this.sortChange.emit(next);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: STableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: STableComponent, isStandalone: true, selector: "s-table", inputs: { columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, actions: { classPropertyName: "actions", publicName: "actions", isSignal: true, isRequired: false, transformFunction: null }, cellTemplates: { classPropertyName: "cellTemplates", publicName: "cellTemplates", isSignal: true, isRequired: false, transformFunction: null }, sort: { classPropertyName: "sort", publicName: "sort", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, empty: { classPropertyName: "empty", publicName: "empty", isSignal: true, isRequired: false, transformFunction: null }, caption: { classPropertyName: "caption", publicName: "caption", isSignal: true, isRequired: false, transformFunction: null }, selectable: { classPropertyName: "selectable", publicName: "selectable", isSignal: true, isRequired: false, transformFunction: null }, selection: { classPropertyName: "selection", publicName: "selection", isSignal: true, isRequired: false, transformFunction: null }, compareWith: { classPropertyName: "compareWith", publicName: "compareWith", isSignal: true, isRequired: false, transformFunction: null }, page: { classPropertyName: "page", publicName: "page", isSignal: true, isRequired: false, transformFunction: null }, pageSize: { classPropertyName: "pageSize", publicName: "pageSize", isSignal: true, isRequired: false, transformFunction: null }, total: { classPropertyName: "total", publicName: "total", isSignal: true, isRequired: false, transformFunction: null }, pageSizeOptions: { classPropertyName: "pageSizeOptions", publicName: "pageSizeOptions", isSignal: true, isRequired: false, transformFunction: null }, itemsLabel: { classPropertyName: "itemsLabel", publicName: "itemsLabel", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, itensPaginated: { classPropertyName: "itensPaginated", publicName: "itensPaginated", isSignal: true, isRequired: false, transformFunction: null }, itens: { classPropertyName: "itens", publicName: "itens", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null }, frameless: { classPropertyName: "frameless", publicName: "frameless", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { create: "create", view: "view", edit: "edit", remove: "remove", inactivate: "inactivate", filter: "filter", sortChange: "sortChange", selectionChange: "selectionChange", actionClick: "actionClick", pageChange: "pageChange", pageSizeChange: "pageSizeChange", emptyAction: "emptyAction" }, host: { properties: { "class.s-table--sem-moldura": "frameless()" }, classAttribute: "s-table" }, queries: [{ propertyName: "projectedActionsTemplate", first: true, predicate: ["customActions"], descendants: true, isSignal: true }, { propertyName: "addButtonTemplate", first: true, predicate: ["addButton"], descendants: true, isSignal: true }, { propertyName: "emptyMessageTemplate", first: true, predicate: ["emptyMessage"], descendants: true, isSignal: true }, { propertyName: "projectedCellTemplates", predicate: (STableCellDirective), isSignal: true }], viewQueries: [{ propertyName: "headerCheckboxRef", first: true, predicate: ["headerCheckbox"], descendants: true, read: ElementRef, isSignal: true }], ngImport: i0, template: "@if (hasHeader()) {\n  <!-- Moldura do generic-list: titulo e botao de cadastrar no topo do card. -->\n  <div class=\"s-table__topo\">\n    <h2 class=\"s-table__titulo\">\n      @if (titleIcon()) {\n        <s-icon [name]=\"titleIcon()\" size=\"sm\" />\n      }\n      {{ options()?.title }}\n    </h2>\n\n    @if (addButtonTemplate(); as customButton) {\n      <ng-container *ngTemplateOutlet=\"customButton\" />\n    } @else if (addButton(); as button) {\n      <s-button [icon]=\"button.icon\" (click)=\"create.emit()\">{{ button.label }}</s-button>\n    }\n  </div>\n}\n\n<div class=\"s-table__rolagem\">\n  <table\n    class=\"s-table__tabela\"\n    [attr.aria-label]=\"caption() ? null : label() || null\"\n    [attr.aria-busy]=\"loading() || null\"\n  >\n    @if (caption()) {\n      <caption class=\"s-table__legenda\">\n        {{\n          caption()\n        }}\n      </caption>\n    }\n\n    <thead class=\"s-table__cabecalho\">\n      <tr>\n        @if (selectable()) {\n          <th scope=\"col\" class=\"s-table__coluna-selecao\">\n            <s-checkbox\n              #headerCheckbox\n              [ngModel]=\"allSelected()\"\n              [ngModelOptions]=\"{ standalone: true }\"\n              [attr.aria-label]=\"headerCheckboxLabel()\"\n              [ariaLabel]=\"headerCheckboxLabel()\"\n              (ngModelChange)=\"toggleAll()\"\n            />\n          </th>\n        }\n\n        @for (column of resolvedColumns(); track $index) {\n          <th\n            scope=\"col\"\n            [style.width]=\"column.width\"\n            [attr.data-align]=\"column.align ?? 'start'\"\n            [attr.aria-sort]=\"ariaSort(column)\"\n          >\n            @if (column.sortable) {\n              <!-- Um <button> de verdade: ordenar precisa funcionar com Enter e\n                   espaco, e um <th> com (click) n\u00E3o funciona pelo teclado. -->\n              <button type=\"button\" class=\"s-table__ordenar\" (click)=\"toggleSort(column)\">\n                <span>{{ column.label }}</span>\n                <s-icon [name]=\"sortIcon(column)\" size=\"xs\" />\n              </button>\n            } @else {\n              <span>{{ column.label }}</span>\n            }\n\n            @if (column.help) {\n              <s-icon\n                class=\"s-table__ajuda\"\n                name=\"info\"\n                size=\"xs\"\n                [label]=\"'Ajuda sobre ' + column.label\"\n                [sTooltip]=\"column.help\"\n              />\n            }\n          </th>\n        }\n\n        @if (hasActions()) {\n          <!-- A coluna de acoes vai sempre no fim, centralizada e sem ordenacao. -->\n          <th scope=\"col\" data-align=\"center\" class=\"s-table__coluna-acoes\">A\u00E7\u00F5es</th>\n        }\n      </tr>\n    </thead>\n\n    <tbody>\n      @if (skeletonVisible()) {\n        <!-- Linhas da propria tabela, e nao uma grade a parte: cada bloco fica\n             na coluna do cabecalho, com a mesma largura e alinhamento. -->\n        @for (row of skeletonRows; track row) {\n          <tr\n            class=\"s-table__linha-esqueleto\"\n            [class.s-table__linha-esqueleto--reserva]=\"skeletonHidden()\"\n            aria-hidden=\"true\"\n          >\n            @if (selectable()) {\n              <td class=\"s-table__coluna-selecao\">\n                <s-skeleton [width]=\"20\" [height]=\"20\" />\n              </td>\n            }\n\n            @for (column of resolvedColumns(); track $index; let columnIndex = $index) {\n              <td [attr.data-align]=\"column.align ?? 'start'\">\n                <s-skeleton [width]=\"skeletonWidth(columnIndex)\" [height]=\"16\" />\n              </td>\n            }\n\n            @if (hasActions()) {\n              <td data-align=\"center\">\n                <s-skeleton [width]=\"64\" [height]=\"16\" />\n              </td>\n            }\n          </tr>\n        }\n      } @else if (isEmpty()) {\n        <tr>\n          <td [attr.colspan]=\"columnCount()\" class=\"s-table__vao\">\n            @if (listMode() && emptyMessageTemplate(); as emptyTemplate) {\n              <ng-container *ngTemplateOutlet=\"emptyTemplate\" />\n            } @else if (emptyText()) {\n              <p class=\"s-table__mensagem\">{{ emptyText() }}</p>\n            } @else {\n              <s-empty-state\n                [variant]=\"emptyVariant()\"\n                [title]=\"emptyTitle()\"\n                [description]=\"empty().description ?? ''\"\n                [actionLabel]=\"empty().actionLabel ?? null\"\n                [headingLevel]=\"empty().headingLevel ?? 3\"\n                (action)=\"emptyAction.emit()\"\n              />\n            }\n          </td>\n        </tr>\n      } @else {\n        @for (row of resolvedRows(); track $index; let rowIndex = $index) {\n          <tr class=\"s-table__linha\" [class.s-table__linha--marcada]=\"isSelected(row)\">\n            @if (selectable()) {\n              <td class=\"s-table__coluna-selecao\">\n                <s-checkbox\n                  [ngModel]=\"isSelected(row)\"\n                  [ngModelOptions]=\"{ standalone: true }\"\n                  [attr.aria-label]=\"\n                    rowLabel(row) ? 'Selecionar ' + rowLabel(row) : 'Selecionar linha'\n                  \"\n                  [ariaLabel]=\"rowLabel(row) ? 'Selecionar ' + rowLabel(row) : 'Selecionar linha'\"\n                  (ngModelChange)=\"toggleRow(row)\"\n                />\n              </td>\n            }\n\n            @for (column of resolvedColumns(); track $index) {\n              @let tooltip = cellTooltip(column, row);\n              @let template = cellTemplate(column);\n\n              <td\n                [attr.data-align]=\"column.align ?? 'start'\"\n                [class]=\"column.source?.styleClass ?? ''\"\n                [style]=\"column.source?.style ?? null\"\n                [sTooltip]=\"tooltip\"\n                [sTooltipDisabled]=\"!tooltip\"\n              >\n                @if (template) {\n                  <!-- Celula que age (um botao, um link) e responsabilidade da\n                       tela: a tabela so entrega a linha ao template dela. -->\n                  <ng-container\n                    *ngTemplateOutlet=\"template; context: cellContext(column, row, rowIndex)\"\n                  />\n                } @else if (column.source?.bodyTemplate; as body) {\n                  <ng-container\n                    *ngTemplateOutlet=\"body; context: { $implicit: row, index: rowIndex }\"\n                  />\n                } @else if (column.badge && column.badge(row); as badge) {\n                  <s-badge [tone]=\"badge.tone ?? 'default'\" [icon]=\"badge.icon ?? ''\">{{\n                    badge.label\n                  }}</s-badge>\n                } @else if (column.source?.formatter && !column.truncate) {\n                  <!-- O formatter do generic-list pode trazer marcacao de layout\n                       (<div class>, <strong>). cellHtml tira imagem, link e o\n                       resto; o sanitizador do Angular confere de novo. -->\n                  <span class=\"s-table__valor\" [innerHTML]=\"cellHtml(column, row)\"></span>\n                } @else {\n                  <span\n                    class=\"s-table__valor\"\n                    [class.s-table__valor--truncado]=\"column.truncate\"\n                    [style.--s-table-trunc]=\"column.width\"\n                    >{{ cellText(column, row) }}</span\n                  >\n\n                  @if (column.secondary) {\n                    <!-- Dado que anda junto do principal \u2014 matricula, codigo\n                         INEP \u2014 sem gastar uma coluna a mais. -->\n                    <span class=\"s-table__secundario\">{{ column.secondary(row) }}</span>\n                  }\n                }\n              </td>\n            }\n\n            @if (hasActions()) {\n              <td data-align=\"center\">\n                <div class=\"s-table__acoes\">\n                  @for (action of visibleActions(row); track action.id) {\n                    <s-icon-button\n                      [icon]=\"action.icon\"\n                      [label]=\"actionLabel(action, row)\"\n                      [variant]=\"action.variant ?? 'ghost'\"\n                      [text]=\"action.text ?? false\"\n                      size=\"sm\"\n                      [disabled]=\"action.disabled?.(row) ?? false\"\n                      (click)=\"runAction(action, row)\"\n                    />\n                  }\n\n                  @if (hasInactivate() && hasActiveFlag(row)) {\n                    <s-switch\n                      #chave=\"ngModel\"\n                      [ngModel]=\"!!row.ativo\"\n                      [ngModelOptions]=\"{ standalone: true }\"\n                      [ariaLabel]=\"inactivateLabel()\"\n                      [sTooltip]=\"inactivateLabel()\"\n                      (ngModelChange)=\"alternarAtivo(row, chave)\"\n                    />\n                  }\n\n                  @if (customActionsTemplate(); as extraActions) {\n                    <ng-container\n                      *ngTemplateOutlet=\"extraActions; context: { $implicit: row, index: rowIndex }\"\n                    />\n                  }\n                </div>\n              </td>\n            }\n          </tr>\n        }\n      }\n    </tbody>\n  </table>\n</div>\n\n@if (hasFooter()) {\n  <s-pagination\n    [page]=\"resolvedPage()\"\n    [pageSize]=\"resolvedPageSize()\"\n    [total]=\"resolvedTotal()\"\n    [pageSizeOptions]=\"resolvedPageSizeOptions()\"\n    [hidePageSize]=\"resolvedPageSizeOptions().length === 0\"\n    [itemsLabel]=\"itemsLabel()\"\n    (pageChange)=\"goToPage($event)\"\n    (pageSizeChange)=\"changePageSize($event)\"\n  />\n}\n", styles: [":host{display:block;background:var(--card);border:1px solid var(--card-border);border-radius:var(--radius-container, 12px);box-shadow:var(--elevation-1);overflow:hidden}.s-table__topo{display:flex;align-items:center;justify-content:space-between;gap:var(--space-16, 16px);padding:var(--space-16, 16px)}.s-table__titulo{display:inline-flex;align-items:center;gap:var(--space-8, 8px);margin:0;font-family:var(--font-ui);font-size:var(--text-h6, 16px);font-weight:var(--weight-semibold, 600);color:var(--text-primary)}.s-table__rolagem{width:100%;overflow-x:auto}.s-table__tabela{width:100%;border-collapse:collapse;font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary)}.s-table__legenda{padding:var(--space-16, 16px) var(--space-16, 16px) 0;text-align:left;font-size:var(--text-caption, 12px);color:var(--text-secondary)}.s-table__cabecalho th{position:sticky;top:0;z-index:1;background:var(--surface-table-head);padding:var(--space-12, 12px) var(--space-16, 16px);font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);color:var(--text-secondary);white-space:nowrap;border-bottom:1px solid var(--card-border)}[data-align=start]{text-align:left}[data-align=center]{text-align:center}[data-align=end]{text-align:right;font-variant-numeric:tabular-nums}.s-table__ordenar{display:inline-flex;align-items:center;gap:var(--space-4, 4px);padding:0;border:none;background:none;font:inherit;color:inherit;cursor:pointer;-webkit-user-select:none;user-select:none}.s-table__ordenar:hover{color:var(--text-primary)}.s-table__ordenar:focus-visible{outline:none;box-shadow:0 0 0 2px var(--surface-table-head),0 0 0 5px var(--focus-ring);border-radius:var(--radius-control, 8px)}[data-align=center] .s-table__ordenar{justify-content:center}[data-align=end] .s-table__ordenar{justify-content:flex-end}.s-table__ajuda{margin-left:var(--space-4, 4px);vertical-align:middle;color:var(--text-secondary);cursor:help}.s-table__tabela td{padding:var(--space-12, 12px) var(--space-16, 16px);border-top:1px solid var(--card-border);vertical-align:middle}.s-table__linha{transition:background-color .12s ease}.s-table__linha:hover{background:color-mix(in srgb,var(--text-primary) 3%,transparent)}.s-table__valor{display:block}.s-table__valor--truncado{max-width:var(--s-table-trunc, 28ch);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.s-table__secundario{display:block;margin-top:2px;font-size:var(--text-caption, 12px);color:var(--text-secondary)}.s-table__coluna-acoes,.s-table__coluna-selecao{width:1%;white-space:nowrap}.s-table__coluna-selecao{padding-right:0}.s-table__linha--marcada,.s-table__linha--marcada:hover{background:color-mix(in srgb,var(--primary) 8%,transparent)}.s-table__acoes{display:flex;align-items:center;justify-content:center;gap:var(--space-4, 4px)}.s-table__linha-esqueleto td{height:28px}.s-table__linha-esqueleto--reserva{visibility:hidden}.s-table__linha-esqueleto [data-align=center] s-skeleton{margin-inline:auto}.s-table__linha-esqueleto [data-align=end] s-skeleton{margin-left:auto}.s-table__vao{padding:0;border-top:1px solid var(--card-border)}.s-table__mensagem{margin:0;padding:var(--space-16, 16px);text-align:center;color:var(--text-secondary)}:host(.s-table--sem-moldura){background:transparent;border:0;border-radius:0;box-shadow:none}:host(.s-table--sem-moldura) .s-table__topo{padding-bottom:0}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$5.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$5.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: SBadgeComponent, selector: "s-badge", inputs: ["tone", "wrap", "icon"] }, { kind: "component", type: SButtonComponent, selector: "s-button", inputs: ["variant", "outlined", "fullWidth", "pressed", "buttonRole", "checked", "focusIndex", "loading", "loadingText", "disabled", "icon", "iconRight", "type", "label"] }, { kind: "component", type: SCheckboxComponent, selector: "s-checkbox", inputs: ["indeterminate", "triState", "ariaLabel"] }, { kind: "component", type: SEmptyStateComponent, selector: "s-empty-state", inputs: ["variant", "icon", "title", "description", "actionLabel", "headingLevel"], outputs: ["action"] }, { kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }, { kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }, { kind: "component", type: SPaginationComponent, selector: "s-pagination", inputs: ["page", "pageSize", "label", "total", "pageSizeOptions", "itemsLabel", "hidePageSize"], outputs: ["pageChange", "pageSizeChange"] }, { kind: "component", type: SSkeletonComponent, selector: "s-skeleton", inputs: ["width", "height", "circle"] }, { kind: "component", type: SSwitchComponent, selector: "s-switch", inputs: ["ariaLabel"], outputs: ["change"] }, { kind: "directive", type: STooltipDirective, selector: "[sTooltip]", inputs: ["sTooltip", "sTooltipPosition", "sTooltipDisabled", "sTooltipDelay"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: STableComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-table', imports: [
                        FormsModule,
                        NgTemplateOutlet,
                        SBadgeComponent,
                        SButtonComponent,
                        SCheckboxComponent,
                        SEmptyStateComponent,
                        SIconComponent,
                        SIconButtonComponent,
                        SPaginationComponent,
                        SSkeletonComponent,
                        SSwitchComponent,
                        STooltipDirective,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-table',
                        '[class.s-table--sem-moldura]': 'frameless()',
                    }, template: "@if (hasHeader()) {\n  <!-- Moldura do generic-list: titulo e botao de cadastrar no topo do card. -->\n  <div class=\"s-table__topo\">\n    <h2 class=\"s-table__titulo\">\n      @if (titleIcon()) {\n        <s-icon [name]=\"titleIcon()\" size=\"sm\" />\n      }\n      {{ options()?.title }}\n    </h2>\n\n    @if (addButtonTemplate(); as customButton) {\n      <ng-container *ngTemplateOutlet=\"customButton\" />\n    } @else if (addButton(); as button) {\n      <s-button [icon]=\"button.icon\" (click)=\"create.emit()\">{{ button.label }}</s-button>\n    }\n  </div>\n}\n\n<div class=\"s-table__rolagem\">\n  <table\n    class=\"s-table__tabela\"\n    [attr.aria-label]=\"caption() ? null : label() || null\"\n    [attr.aria-busy]=\"loading() || null\"\n  >\n    @if (caption()) {\n      <caption class=\"s-table__legenda\">\n        {{\n          caption()\n        }}\n      </caption>\n    }\n\n    <thead class=\"s-table__cabecalho\">\n      <tr>\n        @if (selectable()) {\n          <th scope=\"col\" class=\"s-table__coluna-selecao\">\n            <s-checkbox\n              #headerCheckbox\n              [ngModel]=\"allSelected()\"\n              [ngModelOptions]=\"{ standalone: true }\"\n              [attr.aria-label]=\"headerCheckboxLabel()\"\n              [ariaLabel]=\"headerCheckboxLabel()\"\n              (ngModelChange)=\"toggleAll()\"\n            />\n          </th>\n        }\n\n        @for (column of resolvedColumns(); track $index) {\n          <th\n            scope=\"col\"\n            [style.width]=\"column.width\"\n            [attr.data-align]=\"column.align ?? 'start'\"\n            [attr.aria-sort]=\"ariaSort(column)\"\n          >\n            @if (column.sortable) {\n              <!-- Um <button> de verdade: ordenar precisa funcionar com Enter e\n                   espaco, e um <th> com (click) n\u00E3o funciona pelo teclado. -->\n              <button type=\"button\" class=\"s-table__ordenar\" (click)=\"toggleSort(column)\">\n                <span>{{ column.label }}</span>\n                <s-icon [name]=\"sortIcon(column)\" size=\"xs\" />\n              </button>\n            } @else {\n              <span>{{ column.label }}</span>\n            }\n\n            @if (column.help) {\n              <s-icon\n                class=\"s-table__ajuda\"\n                name=\"info\"\n                size=\"xs\"\n                [label]=\"'Ajuda sobre ' + column.label\"\n                [sTooltip]=\"column.help\"\n              />\n            }\n          </th>\n        }\n\n        @if (hasActions()) {\n          <!-- A coluna de acoes vai sempre no fim, centralizada e sem ordenacao. -->\n          <th scope=\"col\" data-align=\"center\" class=\"s-table__coluna-acoes\">A\u00E7\u00F5es</th>\n        }\n      </tr>\n    </thead>\n\n    <tbody>\n      @if (skeletonVisible()) {\n        <!-- Linhas da propria tabela, e nao uma grade a parte: cada bloco fica\n             na coluna do cabecalho, com a mesma largura e alinhamento. -->\n        @for (row of skeletonRows; track row) {\n          <tr\n            class=\"s-table__linha-esqueleto\"\n            [class.s-table__linha-esqueleto--reserva]=\"skeletonHidden()\"\n            aria-hidden=\"true\"\n          >\n            @if (selectable()) {\n              <td class=\"s-table__coluna-selecao\">\n                <s-skeleton [width]=\"20\" [height]=\"20\" />\n              </td>\n            }\n\n            @for (column of resolvedColumns(); track $index; let columnIndex = $index) {\n              <td [attr.data-align]=\"column.align ?? 'start'\">\n                <s-skeleton [width]=\"skeletonWidth(columnIndex)\" [height]=\"16\" />\n              </td>\n            }\n\n            @if (hasActions()) {\n              <td data-align=\"center\">\n                <s-skeleton [width]=\"64\" [height]=\"16\" />\n              </td>\n            }\n          </tr>\n        }\n      } @else if (isEmpty()) {\n        <tr>\n          <td [attr.colspan]=\"columnCount()\" class=\"s-table__vao\">\n            @if (listMode() && emptyMessageTemplate(); as emptyTemplate) {\n              <ng-container *ngTemplateOutlet=\"emptyTemplate\" />\n            } @else if (emptyText()) {\n              <p class=\"s-table__mensagem\">{{ emptyText() }}</p>\n            } @else {\n              <s-empty-state\n                [variant]=\"emptyVariant()\"\n                [title]=\"emptyTitle()\"\n                [description]=\"empty().description ?? ''\"\n                [actionLabel]=\"empty().actionLabel ?? null\"\n                [headingLevel]=\"empty().headingLevel ?? 3\"\n                (action)=\"emptyAction.emit()\"\n              />\n            }\n          </td>\n        </tr>\n      } @else {\n        @for (row of resolvedRows(); track $index; let rowIndex = $index) {\n          <tr class=\"s-table__linha\" [class.s-table__linha--marcada]=\"isSelected(row)\">\n            @if (selectable()) {\n              <td class=\"s-table__coluna-selecao\">\n                <s-checkbox\n                  [ngModel]=\"isSelected(row)\"\n                  [ngModelOptions]=\"{ standalone: true }\"\n                  [attr.aria-label]=\"\n                    rowLabel(row) ? 'Selecionar ' + rowLabel(row) : 'Selecionar linha'\n                  \"\n                  [ariaLabel]=\"rowLabel(row) ? 'Selecionar ' + rowLabel(row) : 'Selecionar linha'\"\n                  (ngModelChange)=\"toggleRow(row)\"\n                />\n              </td>\n            }\n\n            @for (column of resolvedColumns(); track $index) {\n              @let tooltip = cellTooltip(column, row);\n              @let template = cellTemplate(column);\n\n              <td\n                [attr.data-align]=\"column.align ?? 'start'\"\n                [class]=\"column.source?.styleClass ?? ''\"\n                [style]=\"column.source?.style ?? null\"\n                [sTooltip]=\"tooltip\"\n                [sTooltipDisabled]=\"!tooltip\"\n              >\n                @if (template) {\n                  <!-- Celula que age (um botao, um link) e responsabilidade da\n                       tela: a tabela so entrega a linha ao template dela. -->\n                  <ng-container\n                    *ngTemplateOutlet=\"template; context: cellContext(column, row, rowIndex)\"\n                  />\n                } @else if (column.source?.bodyTemplate; as body) {\n                  <ng-container\n                    *ngTemplateOutlet=\"body; context: { $implicit: row, index: rowIndex }\"\n                  />\n                } @else if (column.badge && column.badge(row); as badge) {\n                  <s-badge [tone]=\"badge.tone ?? 'default'\" [icon]=\"badge.icon ?? ''\">{{\n                    badge.label\n                  }}</s-badge>\n                } @else if (column.source?.formatter && !column.truncate) {\n                  <!-- O formatter do generic-list pode trazer marcacao de layout\n                       (<div class>, <strong>). cellHtml tira imagem, link e o\n                       resto; o sanitizador do Angular confere de novo. -->\n                  <span class=\"s-table__valor\" [innerHTML]=\"cellHtml(column, row)\"></span>\n                } @else {\n                  <span\n                    class=\"s-table__valor\"\n                    [class.s-table__valor--truncado]=\"column.truncate\"\n                    [style.--s-table-trunc]=\"column.width\"\n                    >{{ cellText(column, row) }}</span\n                  >\n\n                  @if (column.secondary) {\n                    <!-- Dado que anda junto do principal \u2014 matricula, codigo\n                         INEP \u2014 sem gastar uma coluna a mais. -->\n                    <span class=\"s-table__secundario\">{{ column.secondary(row) }}</span>\n                  }\n                }\n              </td>\n            }\n\n            @if (hasActions()) {\n              <td data-align=\"center\">\n                <div class=\"s-table__acoes\">\n                  @for (action of visibleActions(row); track action.id) {\n                    <s-icon-button\n                      [icon]=\"action.icon\"\n                      [label]=\"actionLabel(action, row)\"\n                      [variant]=\"action.variant ?? 'ghost'\"\n                      [text]=\"action.text ?? false\"\n                      size=\"sm\"\n                      [disabled]=\"action.disabled?.(row) ?? false\"\n                      (click)=\"runAction(action, row)\"\n                    />\n                  }\n\n                  @if (hasInactivate() && hasActiveFlag(row)) {\n                    <s-switch\n                      #chave=\"ngModel\"\n                      [ngModel]=\"!!row.ativo\"\n                      [ngModelOptions]=\"{ standalone: true }\"\n                      [ariaLabel]=\"inactivateLabel()\"\n                      [sTooltip]=\"inactivateLabel()\"\n                      (ngModelChange)=\"alternarAtivo(row, chave)\"\n                    />\n                  }\n\n                  @if (customActionsTemplate(); as extraActions) {\n                    <ng-container\n                      *ngTemplateOutlet=\"extraActions; context: { $implicit: row, index: rowIndex }\"\n                    />\n                  }\n                </div>\n              </td>\n            }\n          </tr>\n        }\n      }\n    </tbody>\n  </table>\n</div>\n\n@if (hasFooter()) {\n  <s-pagination\n    [page]=\"resolvedPage()\"\n    [pageSize]=\"resolvedPageSize()\"\n    [total]=\"resolvedTotal()\"\n    [pageSizeOptions]=\"resolvedPageSizeOptions()\"\n    [hidePageSize]=\"resolvedPageSizeOptions().length === 0\"\n    [itemsLabel]=\"itemsLabel()\"\n    (pageChange)=\"goToPage($event)\"\n    (pageSizeChange)=\"changePageSize($event)\"\n  />\n}\n", styles: [":host{display:block;background:var(--card);border:1px solid var(--card-border);border-radius:var(--radius-container, 12px);box-shadow:var(--elevation-1);overflow:hidden}.s-table__topo{display:flex;align-items:center;justify-content:space-between;gap:var(--space-16, 16px);padding:var(--space-16, 16px)}.s-table__titulo{display:inline-flex;align-items:center;gap:var(--space-8, 8px);margin:0;font-family:var(--font-ui);font-size:var(--text-h6, 16px);font-weight:var(--weight-semibold, 600);color:var(--text-primary)}.s-table__rolagem{width:100%;overflow-x:auto}.s-table__tabela{width:100%;border-collapse:collapse;font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary)}.s-table__legenda{padding:var(--space-16, 16px) var(--space-16, 16px) 0;text-align:left;font-size:var(--text-caption, 12px);color:var(--text-secondary)}.s-table__cabecalho th{position:sticky;top:0;z-index:1;background:var(--surface-table-head);padding:var(--space-12, 12px) var(--space-16, 16px);font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);color:var(--text-secondary);white-space:nowrap;border-bottom:1px solid var(--card-border)}[data-align=start]{text-align:left}[data-align=center]{text-align:center}[data-align=end]{text-align:right;font-variant-numeric:tabular-nums}.s-table__ordenar{display:inline-flex;align-items:center;gap:var(--space-4, 4px);padding:0;border:none;background:none;font:inherit;color:inherit;cursor:pointer;-webkit-user-select:none;user-select:none}.s-table__ordenar:hover{color:var(--text-primary)}.s-table__ordenar:focus-visible{outline:none;box-shadow:0 0 0 2px var(--surface-table-head),0 0 0 5px var(--focus-ring);border-radius:var(--radius-control, 8px)}[data-align=center] .s-table__ordenar{justify-content:center}[data-align=end] .s-table__ordenar{justify-content:flex-end}.s-table__ajuda{margin-left:var(--space-4, 4px);vertical-align:middle;color:var(--text-secondary);cursor:help}.s-table__tabela td{padding:var(--space-12, 12px) var(--space-16, 16px);border-top:1px solid var(--card-border);vertical-align:middle}.s-table__linha{transition:background-color .12s ease}.s-table__linha:hover{background:color-mix(in srgb,var(--text-primary) 3%,transparent)}.s-table__valor{display:block}.s-table__valor--truncado{max-width:var(--s-table-trunc, 28ch);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.s-table__secundario{display:block;margin-top:2px;font-size:var(--text-caption, 12px);color:var(--text-secondary)}.s-table__coluna-acoes,.s-table__coluna-selecao{width:1%;white-space:nowrap}.s-table__coluna-selecao{padding-right:0}.s-table__linha--marcada,.s-table__linha--marcada:hover{background:color-mix(in srgb,var(--primary) 8%,transparent)}.s-table__acoes{display:flex;align-items:center;justify-content:center;gap:var(--space-4, 4px)}.s-table__linha-esqueleto td{height:28px}.s-table__linha-esqueleto--reserva{visibility:hidden}.s-table__linha-esqueleto [data-align=center] s-skeleton{margin-inline:auto}.s-table__linha-esqueleto [data-align=end] s-skeleton{margin-left:auto}.s-table__vao{padding:0;border-top:1px solid var(--card-border)}.s-table__mensagem{margin:0;padding:var(--space-16, 16px);text-align:center;color:var(--text-secondary)}:host(.s-table--sem-moldura){background:transparent;border:0;border-radius:0;box-shadow:none}:host(.s-table--sem-moldura) .s-table__topo{padding-bottom:0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: false }] }], actions: [{ type: i0.Input, args: [{ isSignal: true, alias: "actions", required: false }] }], cellTemplates: [{ type: i0.Input, args: [{ isSignal: true, alias: "cellTemplates", required: false }] }], sort: [{ type: i0.Input, args: [{ isSignal: true, alias: "sort", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], empty: [{ type: i0.Input, args: [{ isSignal: true, alias: "empty", required: false }] }], caption: [{ type: i0.Input, args: [{ isSignal: true, alias: "caption", required: false }] }], selectable: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectable", required: false }] }], selection: [{ type: i0.Input, args: [{ isSignal: true, alias: "selection", required: false }] }], compareWith: [{ type: i0.Input, args: [{ isSignal: true, alias: "compareWith", required: false }] }], page: [{ type: i0.Input, args: [{ isSignal: true, alias: "page", required: false }] }], pageSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSize", required: false }] }], total: [{ type: i0.Input, args: [{ isSignal: true, alias: "total", required: false }] }], pageSizeOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSizeOptions", required: false }] }], itemsLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemsLabel", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], itensPaginated: [{ type: i0.Input, args: [{ isSignal: true, alias: "itensPaginated", required: false }] }], itens: [{ type: i0.Input, args: [{ isSignal: true, alias: "itens", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }], frameless: [{ type: i0.Input, args: [{ isSignal: true, alias: "frameless", required: false }] }], create: [{ type: i0.Output, args: ["create"] }], view: [{ type: i0.Output, args: ["view"] }], edit: [{ type: i0.Output, args: ["edit"] }], remove: [{ type: i0.Output, args: ["remove"] }], inactivate: [{ type: i0.Output, args: ["inactivate"] }], filter: [{ type: i0.Output, args: ["filter"] }], sortChange: [{ type: i0.Output, args: ["sortChange"] }], selectionChange: [{ type: i0.Output, args: ["selectionChange"] }], actionClick: [{ type: i0.Output, args: ["actionClick"] }], pageChange: [{ type: i0.Output, args: ["pageChange"] }], pageSizeChange: [{ type: i0.Output, args: ["pageSizeChange"] }], emptyAction: [{ type: i0.Output, args: ["emptyAction"] }], projectedActionsTemplate: [{ type: i0.ContentChild, args: ['customActions', { isSignal: true }] }], addButtonTemplate: [{ type: i0.ContentChild, args: ['addButton', { isSignal: true }] }], emptyMessageTemplate: [{ type: i0.ContentChild, args: ['emptyMessage', { isSignal: true }] }], headerCheckboxRef: [{ type: i0.ViewChild, args: ['headerCheckbox', { ...{
                            read: ElementRef,
                        }, isSignal: true }] }], projectedCellTemplates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => STableCellDirective), { isSignal: true }] }] } });

const STORAGE_PREFIX = 'siage-ui:filter-card:';
/**
 * Contrato de persistencia dos filtros do card.
 *
 * A implementacao padrao usa `sessionStorage` porque filtro de listagem e
 * contexto de navegacao: voltar para a tela na mesma sessao deve manter a
 * consulta, mas abrir o sistema outro dia nao deve herdar uma busca antiga que
 * esconde registros sem o usuario perceber.
 */
class SFilterStorage {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SFilterStorage, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SFilterStorage, providedIn: 'root', useFactory: () => new SSessionFilterStorage() });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SFilterStorage, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => new SSessionFilterStorage(),
                }]
        }] });
/**
 * Troca o armazenamento de filtros sem colocar HTTP ou regra de app no card.
 *
 * A classe precisa de `@Injectable()` propria: sem ela, o Angular herda a
 * fabrica de `SFilterStorage` e entrega o `SSessionFilterStorage` padrao, sem
 * erro nenhum.
 */
function provideSiageFilterStorage(storage) {
    return { provide: SFilterStorage, useClass: storage };
}
class SSessionFilterStorage extends SFilterStorage {
    get(key) {
        const storage = getSessionStorage();
        const raw = storage?.getItem(persistedKey(key));
        if (!raw) {
            return null;
        }
        try {
            return reviveDates(JSON.parse(raw));
        }
        catch {
            storage?.removeItem(persistedKey(key));
            return null;
        }
    }
    set(key, value) {
        const storage = getSessionStorage();
        if (!storage) {
            return;
        }
        storage.setItem(persistedKey(key), JSON.stringify(serializeDates(value)));
    }
    remove(key) {
        getSessionStorage()?.removeItem(persistedKey(key));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SSessionFilterStorage, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SSessionFilterStorage });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SSessionFilterStorage, decorators: [{
            type: Injectable
        }] });
/** Valor que conta como filtro: nem vazio, nem lista vazia, nem intervalo sem datas. */
function hasValue(valor) {
    return !isEmpty(valor);
}
/**
 * Bloco de filtros em card proprio, acima de toda tabela de listagem.
 *
 * ## Vocabulario fixo
 *
 * Os dois botoes se chamam **Buscar** e **Limpar**. Nao "Aplicar", nao
 * "Filtrar", nao "Pesquisar". Sao os mesmos verbos em todos os sistemas da
 * rede, e trocar um deles numa tela quebra o reconhecimento em todas as
 * outras — por isso os rotulos nao sao configuraveis por engano: ha inputs,
 * mas com esses padroes.
 *
 * Eles formam um grupo unico ao pe, a direita, com **Limpar antes de Buscar**:
 * a acao de confirmar fica sempre na posicao mais a direita, como no modal.
 *
 * ## A grade se ajusta a largura
 *
 * Cabem tantas colunas quantas a largura permitir, cada uma com no minimo
 * 240px — o mesmo card serve a tela cheia, a janela dividida e o tablet, sem
 * um numero fixo de colunas que so vale para uma delas. Campo que pede mais
 * espaco leva `class="s-filter-card__largo"` (duas colunas) ou
 * `class="s-filter-card__inteiro"` (a linha inteira).
 *
 * ## Enter tambem busca
 *
 * O card escuta `Enter` em qualquer campo projetado e dispara `search`. Quem
 * preenche um filtro e tecla Enter espera que a consulta aconteca, e sem isto
 * cada tela teria que ligar isso a mao em cada campo.
 *
 * @example
 * ```html
 * <s-filter-card (search)="buscar()" (clear)="limpar()">
 *   <s-field label="Nome">
 *     <s-input icon="search" formControlName="nome" />
 *   </s-field>
 *   <s-field label="Status">
 *     <s-select [options]="status" placeholder="Todos" formControlName="status" />
 *   </s-field>
 * </s-filter-card>
 * ```
 */
class SFilterCardComponent {
    /** Titulo do bloco. */
    title = input('Filtros', ...(ngDevMode ? [{ debugName: "title" }] : []));
    /** Rotulo do botao de buscar. Trocar quebra o vocabulario do ecossistema. */
    searchLabel = input('Buscar', ...(ngDevMode ? [{ debugName: "searchLabel" }] : []));
    /** Rotulo do botao de limpar. */
    clearLabel = input('Limpar', ...(ngDevMode ? [{ debugName: "clearLabel" }] : []));
    /** Desabilita o botao de limpar — util quando nenhum filtro esta preenchido. */
    clearDisabled = input(false, ...(ngDevMode ? [{ debugName: "clearDisabled", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Buscar so age com algum filtro preenchido no `form`: sem nenhum, a
     * consulta seria a lista inteira, que a tela nao quer trazer por engano.
     */
    requireValue = input(false, ...(ngDevMode ? [{ debugName: "requireValue", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Desabilita o botao Buscar (e o Enter) enquanto nenhum campo do `form` tem
     * valor. Diferente de `requireValue`, que deixa o botao habilitado e so
     * ignora o clique, este avisa a pessoa de antemao que ainda nao ha o que
     * buscar. Precisa do `form` (projetado ou via input); sem ele nao desabilita.
     * Vazio e `null`, `undefined`, `''`, lista vazia e intervalo sem inicio e fim.
     */
    disableSearchWithoutValue = input(false, ...(ngDevMode ? [{ debugName: "disableSearchWithoutValue", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Com `requireValue` ou `disableSearchWithoutValue`, remover o ultimo chip ou
     * usar "Limpar todos" so atualiza os chips, sem emitir `search`: a consulta
     * sem filtro seria justamente a que a tela quer evitar. Ligue quando, nessa
     * tela, esvaziar os filtros significa voltar a lista completa. Sem as duas
     * travas, a busca sempre e emitida e este input nao tem efeito.
     */
    searchWhenEmptied = input(false, ...(ngDevMode ? [{ debugName: "searchWhenEmptied", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Limpar tambem esvazia o `form` (`reset()`), antes de emitir `clear`. */
    resetOnClear = input(false, ...(ngDevMode ? [{ debugName: "resetOnClear", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Os chips de filtro ativo depois da busca. Desligue quando a tela usa o
     * `form` so para `requireValue`/`resetOnClear`, sem os chips.
     */
    showActiveFilters = input(true, ...(ngDevMode ? [{ debugName: "showActiveFilters", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Consulta em andamento: o botao Buscar entra em carregamento. */
    loading = input(false, ...(ngDevMode ? [{ debugName: "loading", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Identificador estavel da listagem para restaurar filtros ao voltar a ela.
     *
     * Sem `filterId`, o card nao grava nada: filtros sem identidade nao devem
     * disputar a mesma chave no armazenamento da sessao.
     */
    filterId = input('', ...(ngDevMode ? [{ debugName: "filterId" }] : []));
    /**
     * Formulario de filtros quando a tela prefere passar explicitamente.
     *
     * Normalmente o card encontra o `[formGroup]` projetado sozinho; este input
     * existe para composicoes que encapsulam o form em outro componente.
     */
    form = input(null, ...(ngDevMode ? [{ debugName: "form" }] : []));
    /**
     * Rotulos humanos por chave do formulario.
     *
     * O nome tecnico do controle raramente e o texto que a pessoa viu no campo;
     * chips usam este mapa para repetir a linguagem da tela.
     */
    labelMap = input({}, ...(ngDevMode ? [{ debugName: "labelMap" }] : []));
    /**
     * Opcoes por chave para transformar ids de select/multiselect em rotulos.
     *
     * O formulario guarda o valor de dominio, mas o chip precisa mostrar o mesmo
     * texto escolhido na lista.
     */
    optionMap = input({}, ...(ngDevMode ? [{ debugName: "optionMap" }] : []));
    /**
     * Formata valores que nao cabem em `optionMap`.
     *
     * Use para regras de dominio; datas e arrays ja recebem formato legivel pelo
     * card para manter a paridade entre listagens.
     */
    valueFormatter = input(null, ...(ngDevMode ? [{ debugName: "valueFormatter" }] : []));
    /** Dispara a consulta. Tambem emitido no `Enter` de qualquer campo. */
    search = output();
    /** Redefine os campos. */
    clear = output();
    /**
     * Filtros restaurados de `filterId` ao abrir a tela.
     *
     * A restauracao so preenche o formulario; quem consulta precisa saber que ha
     * filtros valendo para buscar de novo, senao a tabela mostra o resultado sem
     * filtro debaixo de chips que dizem o contrario.
     */
    restored = output();
    storage = inject(SFilterStorage);
    projectedForm = contentChild(FormGroupDirective, ...(ngDevMode ? [{ debugName: "projectedForm", descendants: true }] : [{ descendants: true }]));
    currentForm = computed(() => this.form() ?? this.projectedForm()?.form ?? null, ...(ngDevMode ? [{ debugName: "currentForm" }] : []));
    restoredFilters = new Set();
    activeChips = signal([], ...(ngDevMode ? [{ debugName: "activeChips" }] : []));
    chips = computed(() => this.activeChips(), ...(ngDevMode ? [{ debugName: "chips" }] : []));
    formHasValue = signal(false, ...(ngDevMode ? [{ debugName: "formHasValue" }] : []));
    searchDisabled = computed(() => this.disableSearchWithoutValue() && this.currentForm() !== null && !this.formHasValue(), ...(ngDevMode ? [{ debugName: "searchDisabled" }] : []));
    constructor() {
        effect((onCleanup) => {
            const form = this.currentForm();
            if (!form) {
                this.formHasValue.set(false);
                return;
            }
            const sync = () => this.syncHasValue(form);
            sync();
            const subscription = form.valueChanges.subscribe(sync);
            onCleanup(() => subscription.unsubscribe());
        });
        effect(() => {
            const filterId = this.filterId();
            const form = this.currentForm();
            if (!filterId || !form || this.restoredFilters.has(filterId)) {
                return;
            }
            this.restoredFilters.add(filterId);
            const storedValue = this.storage.get(filterId);
            if (storedValue) {
                form.patchValue(storedValue, { emitEvent: false });
                // Sem evento, o `valueChanges` nao avisa: o Buscar ficaria desabilitado
                // debaixo de filtros restaurados.
                this.syncHasValue(form);
                this.updateChips(storedValue);
                this.restored.emit();
            }
        });
    }
    /**
     * Enter num campo de digitacao busca. So nele:
     * - num botao, Enter e o clique dele - em "Limpar", buscar seria o oposto
     *   do pedido;
     * - num `<textarea>`, quebra linha;
     * - no gatilho de um select, abre o painel;
     * - quando o proprio campo ja usou o Enter (o autocomplete escolhendo a
     *   opcao destacada, o chips criando uma etiqueta), o evento chega aqui com
     *   `defaultPrevented`, e a tecla ja teve dono.
     *
     * E nada acontece durante `loading`: o botao Buscar esta bloqueado, e o
     * teclado nao pode ser um atalho para disparar a mesma consulta de novo.
     */
    aoTeclarEnter(evento) {
        if (evento.defaultPrevented || !ehCampoDeTexto(evento.target)) {
            return;
        }
        evento.preventDefault();
        if (!this.loading() && !this.searchDisabled()) {
            this.searchFilters();
        }
    }
    /**
     * `refresh` e a remocao de chip (ou "Limpar todos"): os chips e o
     * armazenamento sempre acompanham o form. Se o form ficou vazio e a tela
     * exige valor (`requireValue`/`disableSearchWithoutValue`), nao emite
     * `search`, salvo com `searchWhenEmptied`.
     */
    searchFilters(refresh = false) {
        const value = this.formValue();
        const vazio = !Object.values(value).some(hasValue);
        const exigeValor = this.requireValue() || this.disableSearchWithoutValue();
        if (!refresh && this.requireValue() && vazio) {
            return;
        }
        if (refresh && vazio && exigeValor && !this.searchWhenEmptied()) {
            this.updateChips(value);
            this.persist(value);
            return;
        }
        this.updateChips(value);
        this.persist(value);
        this.search.emit();
    }
    removeFilter(chip) {
        const form = this.currentForm();
        if (!form) {
            return;
        }
        const control = form.get(chip.key);
        const currentValue = control?.value;
        if (Array.isArray(currentValue)) {
            control?.setValue(currentValue.filter((value) => !sameValue(value, chip.value)));
        }
        else {
            control?.setValue(null);
        }
        this.searchFilters(true);
    }
    clearActiveFilters() {
        const form = this.currentForm();
        if (!form) {
            return;
        }
        for (const chip of this.chips()) {
            const control = form.get(chip.key);
            control?.setValue(Array.isArray(control.value) ? [] : null);
        }
        this.searchFilters(true);
    }
    clearFilters() {
        this.activeChips.set([]);
        if (this.resetOnClear()) {
            this.currentForm()?.reset();
        }
        const filterId = this.filterId();
        if (filterId) {
            this.storage.remove(filterId);
        }
        this.clear.emit();
    }
    syncHasValue(form) {
        this.formHasValue.set(Object.values(form.getRawValue()).some(hasValue));
    }
    formValue() {
        return (this.currentForm()?.getRawValue() ?? {});
    }
    updateChips(value) {
        this.activeChips.set(this.createChips(value));
    }
    persist(value) {
        const filterId = this.filterId();
        if (!filterId) {
            return;
        }
        if (this.createChips(value).length === 0) {
            this.storage.remove(filterId);
            return;
        }
        this.storage.set(filterId, value);
    }
    createChips(value) {
        return Object.entries(value).flatMap(([key, raw]) => {
            const label = this.labelMap()[key] ?? key;
            if (Array.isArray(raw)) {
                return raw
                    .filter((item) => !isEmpty(item))
                    .map((item) => this.createChip(key, label, item));
            }
            if (isEmpty(raw)) {
                return [];
            }
            return [this.createChip(key, label, raw)];
        });
    }
    createChip(key, label, value) {
        const formattedValue = this.formatValue(key, value);
        const text = `${label}: ${formattedValue}`;
        return {
            key,
            label,
            value,
            text,
            removeLabel: `Remover filtro ${text}`,
        };
    }
    formatValue(key, value) {
        const formatted = this.valueFormatter()?.(key, value);
        if (formatted) {
            return formatted;
        }
        const option = this.optionMap()[key]?.find((item) => sameValue(item.value, value));
        if (option) {
            return option.label;
        }
        if (value instanceof Date) {
            return formatDate(value);
        }
        if (isDateRange(value)) {
            return formatDateRange(value);
        }
        return String(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SFilterCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SFilterCardComponent, isStandalone: true, selector: "s-filter-card", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, searchLabel: { classPropertyName: "searchLabel", publicName: "searchLabel", isSignal: true, isRequired: false, transformFunction: null }, clearLabel: { classPropertyName: "clearLabel", publicName: "clearLabel", isSignal: true, isRequired: false, transformFunction: null }, clearDisabled: { classPropertyName: "clearDisabled", publicName: "clearDisabled", isSignal: true, isRequired: false, transformFunction: null }, requireValue: { classPropertyName: "requireValue", publicName: "requireValue", isSignal: true, isRequired: false, transformFunction: null }, disableSearchWithoutValue: { classPropertyName: "disableSearchWithoutValue", publicName: "disableSearchWithoutValue", isSignal: true, isRequired: false, transformFunction: null }, searchWhenEmptied: { classPropertyName: "searchWhenEmptied", publicName: "searchWhenEmptied", isSignal: true, isRequired: false, transformFunction: null }, resetOnClear: { classPropertyName: "resetOnClear", publicName: "resetOnClear", isSignal: true, isRequired: false, transformFunction: null }, showActiveFilters: { classPropertyName: "showActiveFilters", publicName: "showActiveFilters", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, filterId: { classPropertyName: "filterId", publicName: "filterId", isSignal: true, isRequired: false, transformFunction: null }, form: { classPropertyName: "form", publicName: "form", isSignal: true, isRequired: false, transformFunction: null }, labelMap: { classPropertyName: "labelMap", publicName: "labelMap", isSignal: true, isRequired: false, transformFunction: null }, optionMap: { classPropertyName: "optionMap", publicName: "optionMap", isSignal: true, isRequired: false, transformFunction: null }, valueFormatter: { classPropertyName: "valueFormatter", publicName: "valueFormatter", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { search: "search", clear: "clear", restored: "restored" }, host: { attributes: { "role": "search" }, listeners: { "keydown.enter": "aoTeclarEnter($event)" }, properties: { "attr.aria-label": "title()" }, classAttribute: "s-filter-card" }, queries: [{ propertyName: "projectedForm", first: true, predicate: FormGroupDirective, descendants: true, isSignal: true }], ngImport: i0, template: "@if (title()) {\n  <h2 class=\"s-filter-card__titulo\">{{ title() }}</h2>\n}\n\n<div class=\"s-filter-card__grade\">\n  <ng-content />\n</div>\n\n@if (showActiveFilters() && chips().length) {\n  <div class=\"s-filter-card__chips\">\n    <ul class=\"s-filter-card__chips-list\" aria-label=\"Filtros ativos\">\n      @for (chip of chips(); track chip.key + chip.text) {\n        <li class=\"s-filter-card__chip\">\n          <span>{{ chip.text }}</span>\n          <s-icon-button\n            class=\"s-filter-card__chip-remove\"\n            icon=\"close\"\n            size=\"xs\"\n            [label]=\"chip.removeLabel\"\n            (click)=\"removeFilter(chip)\"\n          />\n        </li>\n      }\n    </ul>\n\n    @if (chips().length >= 2) {\n      <s-button variant=\"secondary\" outlined (click)=\"clearActiveFilters()\">\n        Limpar todos\n      </s-button>\n    }\n  </div>\n}\n\n<!-- Grupo unico ao pe, a direita, com Limpar antes de Buscar: confirmar fica\n     sempre na posicao mais a direita, como no modal. -->\n<div class=\"s-filter-card__acoes\">\n  <s-button variant=\"secondary\" outlined [disabled]=\"clearDisabled()\" (click)=\"clearFilters()\">\n    {{ clearLabel() }}\n  </s-button>\n  <s-button\n    variant=\"primary\"\n    [loading]=\"loading()\"\n    [disabled]=\"searchDisabled()\"\n    (click)=\"searchFilters()\"\n  >\n    {{ searchLabel() }}\n  </s-button>\n</div>\n", styles: [":host{display:block;padding:var(--space-16, 16px);background:var(--card);border:1px solid var(--card-border);border-radius:var(--radius-container, 12px);box-shadow:var(--elevation-1)}.s-filter-card__titulo{margin:0 0 var(--space-16, 16px);font-family:var(--font-display);font-size:var(--text-h6, 16px);font-weight:var(--weight-semibold, 600);color:var(--text-primary)}.s-filter-card__grade{--s-filtro-min: 240px;--s-filtro-gap: var(--field-gap, 16px);display:grid;container:s-filtros/inline-size;grid-template-columns:repeat(auto-fill,minmax(min(100%,var(--s-filtro-min)),1fr));align-items:start;gap:var(--s-filtro-gap)}.s-filter-card__grade>::ng-deep :is(form,[filters]){display:contents}.s-filter-card__grade>::ng-deep *,.s-filter-card__grade>::ng-deep :is(form,[filters])>*{min-width:0}.s-filter-card__grade ::ng-deep .s-filter-card__largo{grid-column:span 2}@container s-filtros (max-width: 496px){.s-filter-card__grade ::ng-deep .s-filter-card__largo{grid-column:1/-1}}.s-filter-card__grade ::ng-deep .s-filter-card__inteiro{grid-column:1/-1}.s-filter-card__chips{display:flex;flex-wrap:wrap;align-items:center;gap:var(--space-8, 8px);margin-top:var(--space-16, 16px)}.s-filter-card__chips-list{display:flex;flex:1;flex-wrap:wrap;gap:var(--space-8, 8px);min-width:0;margin:0;padding:0;list-style:none}.s-filter-card__chip{display:inline-flex;align-items:center;gap:var(--space-4, 4px);max-width:100%;min-height:var(--badge-h, 24px);padding:0 var(--space-4, 4px) 0 var(--badge-px, 8px);border-radius:var(--radius-control, 8px);background:color-mix(in srgb,var(--primary) calc(var(--tint-container, .12) * 100%),transparent);color:var(--primary-on-surface);font-size:var(--text-badge, 12px);font-weight:var(--weight-medium, 500);line-height:1}.s-filter-card__chip span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.s-filter-card__chip-remove{--s-icon-button-size: 20px;flex:0 0 auto}.s-filter-card__acoes{display:flex;justify-content:flex-end;gap:var(--space-8, 8px);margin-top:var(--space-16, 16px)}\n"], dependencies: [{ kind: "component", type: SButtonComponent, selector: "s-button", inputs: ["variant", "outlined", "fullWidth", "pressed", "buttonRole", "checked", "focusIndex", "loading", "loadingText", "disabled", "icon", "iconRight", "type", "label"] }, { kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SFilterCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-filter-card', imports: [SButtonComponent, SIconButtonComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-filter-card',
                        // Marco de busca: quem navega por regioes chega aos filtros num atalho.
                        role: 'search',
                        '[attr.aria-label]': 'title()',
                        '(keydown.enter)': 'aoTeclarEnter($event)',
                    }, template: "@if (title()) {\n  <h2 class=\"s-filter-card__titulo\">{{ title() }}</h2>\n}\n\n<div class=\"s-filter-card__grade\">\n  <ng-content />\n</div>\n\n@if (showActiveFilters() && chips().length) {\n  <div class=\"s-filter-card__chips\">\n    <ul class=\"s-filter-card__chips-list\" aria-label=\"Filtros ativos\">\n      @for (chip of chips(); track chip.key + chip.text) {\n        <li class=\"s-filter-card__chip\">\n          <span>{{ chip.text }}</span>\n          <s-icon-button\n            class=\"s-filter-card__chip-remove\"\n            icon=\"close\"\n            size=\"xs\"\n            [label]=\"chip.removeLabel\"\n            (click)=\"removeFilter(chip)\"\n          />\n        </li>\n      }\n    </ul>\n\n    @if (chips().length >= 2) {\n      <s-button variant=\"secondary\" outlined (click)=\"clearActiveFilters()\">\n        Limpar todos\n      </s-button>\n    }\n  </div>\n}\n\n<!-- Grupo unico ao pe, a direita, com Limpar antes de Buscar: confirmar fica\n     sempre na posicao mais a direita, como no modal. -->\n<div class=\"s-filter-card__acoes\">\n  <s-button variant=\"secondary\" outlined [disabled]=\"clearDisabled()\" (click)=\"clearFilters()\">\n    {{ clearLabel() }}\n  </s-button>\n  <s-button\n    variant=\"primary\"\n    [loading]=\"loading()\"\n    [disabled]=\"searchDisabled()\"\n    (click)=\"searchFilters()\"\n  >\n    {{ searchLabel() }}\n  </s-button>\n</div>\n", styles: [":host{display:block;padding:var(--space-16, 16px);background:var(--card);border:1px solid var(--card-border);border-radius:var(--radius-container, 12px);box-shadow:var(--elevation-1)}.s-filter-card__titulo{margin:0 0 var(--space-16, 16px);font-family:var(--font-display);font-size:var(--text-h6, 16px);font-weight:var(--weight-semibold, 600);color:var(--text-primary)}.s-filter-card__grade{--s-filtro-min: 240px;--s-filtro-gap: var(--field-gap, 16px);display:grid;container:s-filtros/inline-size;grid-template-columns:repeat(auto-fill,minmax(min(100%,var(--s-filtro-min)),1fr));align-items:start;gap:var(--s-filtro-gap)}.s-filter-card__grade>::ng-deep :is(form,[filters]){display:contents}.s-filter-card__grade>::ng-deep *,.s-filter-card__grade>::ng-deep :is(form,[filters])>*{min-width:0}.s-filter-card__grade ::ng-deep .s-filter-card__largo{grid-column:span 2}@container s-filtros (max-width: 496px){.s-filter-card__grade ::ng-deep .s-filter-card__largo{grid-column:1/-1}}.s-filter-card__grade ::ng-deep .s-filter-card__inteiro{grid-column:1/-1}.s-filter-card__chips{display:flex;flex-wrap:wrap;align-items:center;gap:var(--space-8, 8px);margin-top:var(--space-16, 16px)}.s-filter-card__chips-list{display:flex;flex:1;flex-wrap:wrap;gap:var(--space-8, 8px);min-width:0;margin:0;padding:0;list-style:none}.s-filter-card__chip{display:inline-flex;align-items:center;gap:var(--space-4, 4px);max-width:100%;min-height:var(--badge-h, 24px);padding:0 var(--space-4, 4px) 0 var(--badge-px, 8px);border-radius:var(--radius-control, 8px);background:color-mix(in srgb,var(--primary) calc(var(--tint-container, .12) * 100%),transparent);color:var(--primary-on-surface);font-size:var(--text-badge, 12px);font-weight:var(--weight-medium, 500);line-height:1}.s-filter-card__chip span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.s-filter-card__chip-remove{--s-icon-button-size: 20px;flex:0 0 auto}.s-filter-card__acoes{display:flex;justify-content:flex-end;gap:var(--space-8, 8px);margin-top:var(--space-16, 16px)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], searchLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchLabel", required: false }] }], clearLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearLabel", required: false }] }], clearDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearDisabled", required: false }] }], requireValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "requireValue", required: false }] }], disableSearchWithoutValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "disableSearchWithoutValue", required: false }] }], searchWhenEmptied: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchWhenEmptied", required: false }] }], resetOnClear: [{ type: i0.Input, args: [{ isSignal: true, alias: "resetOnClear", required: false }] }], showActiveFilters: [{ type: i0.Input, args: [{ isSignal: true, alias: "showActiveFilters", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], filterId: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterId", required: false }] }], form: [{ type: i0.Input, args: [{ isSignal: true, alias: "form", required: false }] }], labelMap: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelMap", required: false }] }], optionMap: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionMap", required: false }] }], valueFormatter: [{ type: i0.Input, args: [{ isSignal: true, alias: "valueFormatter", required: false }] }], search: [{ type: i0.Output, args: ["search"] }], clear: [{ type: i0.Output, args: ["clear"] }], restored: [{ type: i0.Output, args: ["restored"] }], projectedForm: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FormGroupDirective), { ...{ descendants: true }, isSignal: true }] }] } });
/** Tipos de `<input>` em que Enter nao tem outro significado. */
const TIPOS_SEM_ACAO_PROPRIA = new Set(['checkbox', 'radio', 'button', 'submit', 'reset', 'file']);
function ehCampoDeTexto(alvo) {
    return alvo instanceof HTMLInputElement && !TIPOS_SEM_ACAO_PROPRIA.has(alvo.type);
}
function persistedKey(key) {
    return `${STORAGE_PREFIX}${key}`;
}
function getSessionStorage() {
    return typeof sessionStorage === 'undefined' ? null : sessionStorage;
}
function isEmpty(value) {
    if (value === null || value === undefined || value === '') {
        return true;
    }
    if (Array.isArray(value)) {
        return value.length === 0;
    }
    if (isDateRange(value)) {
        return !value.start && !value.end;
    }
    return false;
}
function sameValue(a, b) {
    if (Object.is(a, b)) {
        return true;
    }
    if (a instanceof Date && b instanceof Date) {
        return a.getTime() === b.getTime();
    }
    return JSON.stringify(a) === JSON.stringify(b);
}
function formatDate(date) {
    return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()}`;
}
function isDateRange(value) {
    if (!value || typeof value !== 'object') {
        return false;
    }
    const range = value;
    return ((range.start === null || range.start instanceof Date) &&
        (range.end === null || range.end instanceof Date) &&
        ('start' in range || 'end' in range));
}
function formatDateRange(range) {
    if (range.start && range.end) {
        return `${formatDate(range.start)} a ${formatDate(range.end)}`;
    }
    if (range.start) {
        return `a partir de ${formatDate(range.start)}`;
    }
    return range.end ? `até ${formatDate(range.end)}` : '';
}
function serializeDates(value) {
    if (value instanceof Date) {
        return { __sFilterDate: value.toISOString() };
    }
    if (Array.isArray(value)) {
        return value.map(serializeDates);
    }
    if (value && typeof value === 'object') {
        return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, serializeDates(item)]));
    }
    return value;
}
function reviveDates(value) {
    if (Array.isArray(value)) {
        return value.map(reviveDates);
    }
    if (value && typeof value === 'object') {
        const map = value;
        if (typeof map['__sFilterDate'] === 'string') {
            return new Date(map['__sFilterDate']);
        }
        return Object.fromEntries(Object.entries(map).map(([key, item]) => [key, reviveDates(item)]));
    }
    return value;
}

const GLIFOS$1 = {
    info: 'info',
    success: 'check_circle',
    warning: 'warning',
    error: 'error',
};
/**
 * Banner inline: feedback contextual que **permanece na pagina** ate a condicao
 * ser resolvida.
 *
 * A diferenca para o toast e a persistencia, nao a aparencia. Toast confirma
 * algo que ja aconteceu e some; alerta descreve uma condicao que continua
 * valendo — "esta jornada tem alteracao aguardando aprovacao" segue verdade
 * depois de quatro segundos.
 *
 * Os dois compartilham a linguagem visual (fundo tintado, borda, icone
 * on-surface), mas o alerta usa a versao mais discreta: tint 12% e borda 24%,
 * contra 24% e cor cheia do toast. Ele fica na pagina; nao precisa competir.
 *
 * **A cor nunca vem sozinha.** Todo tipo traz um icone, porque cerca de 8% dos
 * homens nao distingue vermelho de verde.
 */
class SAlertComponent {
    /** Natureza da mensagem. Ver `SAlertType`. */
    type = input('info', ...(ngDevMode ? [{ debugName: "type" }] : []));
    /** Titulo curto. Sem ele, so o conteudo projetado aparece. */
    title = input('', ...(ngDevMode ? [{ debugName: "title" }] : []));
    /** Permite dispensar o aviso antes de resolver a condicao ou terminar o prazo. */
    dismissible = input(false, ...(ngDevMode ? [{ debugName: "dismissible", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Prazo em milissegundos para emitir `close`. Zero ou negativo mantem o aviso permanente.
     *
     * Use apenas em mensagens transitorias: condicoes que ainda exigem atencao
     * devem permanecer visiveis. Alterar o prazo reinicia a contagem.
     */
    duration = input(0, ...(ngDevMode ? [{ debugName: "duration", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /**
     * Disparado pelo botao de fechar ou ao terminar `duration`.
     *
     * O alerta **nao se esconde sozinho**: quem decide e a tela, que o tira com
     * um `@if` - e pode, por exemplo, lembrar que a pessoa ja dispensou o aviso.
     *
     * ```html
     * @if (mostrarAviso()) {
     *   <s-alert dismissible (close)="mostrarAviso.set(false)">...</s-alert>
     * }
     * ```
     */
    close = output();
    glifo = computed(() => GLIFOS$1[this.type()], ...(ngDevMode ? [{ debugName: "glifo" }] : []));
    relogio;
    constructor() {
        effect((onCleanup) => {
            const prazo = this.duration();
            if (!Number.isFinite(prazo) || prazo <= 0) {
                return;
            }
            this.relogio = setTimeout(() => this.fechar(), prazo);
            onCleanup(() => clearTimeout(this.relogio));
        });
    }
    fechar() {
        clearTimeout(this.relogio);
        this.close.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAlertComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SAlertComponent, isStandalone: true, selector: "s-alert", inputs: { type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, dismissible: { classPropertyName: "dismissible", publicName: "dismissible", isSignal: true, isRequired: false, transformFunction: null }, duration: { classPropertyName: "duration", publicName: "duration", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { close: "close" }, host: { properties: { "class": "\"s-alert s-alert--\" + type()", "attr.role": "type() === 'error' ? 'alert' : 'status'" } }, ngImport: i0, template: "<s-icon class=\"s-alert__icone\" [name]=\"glifo()\" size=\"sm\" />\n\n<div class=\"s-alert__corpo\">\n  @if (title()) {\n    <strong class=\"s-alert__titulo\">{{ title() }}</strong>\n  }\n  <div class=\"s-alert__texto\"><ng-content /></div>\n</div>\n\n@if (dismissible()) {\n  <s-icon-button\n    class=\"s-alert__fechar\"\n    icon=\"close\"\n    label=\"Fechar aviso\"\n    size=\"sm\"\n    (click)=\"fechar()\"\n  />\n}\n", styles: [":host{display:flex;align-items:flex-start;gap:var(--space-12, 12px);padding:var(--space-12, 12px) var(--space-16, 16px);border:1px solid transparent;border-radius:var(--radius-control, 8px);font-family:var(--font-ui);font-size:var(--text-body, 14px);line-height:var(--leading-normal, 1.45);color:var(--text-primary)}:host(.s-alert--info){background:color-mix(in srgb,var(--info) calc(var(--tint-container, .12) * 100%),transparent);border-color:color-mix(in srgb,var(--info) calc(var(--tint-strong, .24) * 100%),transparent)}:host(.s-alert--info) .s-alert__icone{color:var(--info-on-surface)}:host(.s-alert--success){background:color-mix(in srgb,var(--success) calc(var(--tint-container, .12) * 100%),transparent);border-color:color-mix(in srgb,var(--success) calc(var(--tint-strong, .24) * 100%),transparent)}:host(.s-alert--success) .s-alert__icone{color:var(--success-on-surface)}:host(.s-alert--warning){background:color-mix(in srgb,var(--warning) calc(var(--tint-container, .12) * 100%),transparent);border-color:color-mix(in srgb,var(--warning) calc(var(--tint-strong, .24) * 100%),transparent)}:host(.s-alert--warning) .s-alert__icone{color:var(--warning-on-surface)}:host(.s-alert--error){background:color-mix(in srgb,var(--destructive) calc(var(--tint-container, .12) * 100%),transparent);border-color:color-mix(in srgb,var(--destructive) calc(var(--tint-strong, .24) * 100%),transparent)}:host(.s-alert--error) .s-alert__icone{color:var(--destructive-on-surface)}.s-alert__icone{flex:0 0 auto;margin-top:1px}.s-alert__corpo{flex:1;min-width:0;display:flex;flex-direction:column;gap:var(--space-4, 4px)}.s-alert__titulo{font-weight:var(--weight-semibold, 600)}.s-alert__texto{color:var(--text-secondary)}.s-alert__fechar{flex:0 0 auto;margin:-4px -8px 0 0}\n"], dependencies: [{ kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }, { kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAlertComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-alert', imports: [SIconComponent, SIconButtonComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        '[class]': '"s-alert s-alert--" + type()',
                        '[attr.role]': "type() === 'error' ? 'alert' : 'status'",
                    }, template: "<s-icon class=\"s-alert__icone\" [name]=\"glifo()\" size=\"sm\" />\n\n<div class=\"s-alert__corpo\">\n  @if (title()) {\n    <strong class=\"s-alert__titulo\">{{ title() }}</strong>\n  }\n  <div class=\"s-alert__texto\"><ng-content /></div>\n</div>\n\n@if (dismissible()) {\n  <s-icon-button\n    class=\"s-alert__fechar\"\n    icon=\"close\"\n    label=\"Fechar aviso\"\n    size=\"sm\"\n    (click)=\"fechar()\"\n  />\n}\n", styles: [":host{display:flex;align-items:flex-start;gap:var(--space-12, 12px);padding:var(--space-12, 12px) var(--space-16, 16px);border:1px solid transparent;border-radius:var(--radius-control, 8px);font-family:var(--font-ui);font-size:var(--text-body, 14px);line-height:var(--leading-normal, 1.45);color:var(--text-primary)}:host(.s-alert--info){background:color-mix(in srgb,var(--info) calc(var(--tint-container, .12) * 100%),transparent);border-color:color-mix(in srgb,var(--info) calc(var(--tint-strong, .24) * 100%),transparent)}:host(.s-alert--info) .s-alert__icone{color:var(--info-on-surface)}:host(.s-alert--success){background:color-mix(in srgb,var(--success) calc(var(--tint-container, .12) * 100%),transparent);border-color:color-mix(in srgb,var(--success) calc(var(--tint-strong, .24) * 100%),transparent)}:host(.s-alert--success) .s-alert__icone{color:var(--success-on-surface)}:host(.s-alert--warning){background:color-mix(in srgb,var(--warning) calc(var(--tint-container, .12) * 100%),transparent);border-color:color-mix(in srgb,var(--warning) calc(var(--tint-strong, .24) * 100%),transparent)}:host(.s-alert--warning) .s-alert__icone{color:var(--warning-on-surface)}:host(.s-alert--error){background:color-mix(in srgb,var(--destructive) calc(var(--tint-container, .12) * 100%),transparent);border-color:color-mix(in srgb,var(--destructive) calc(var(--tint-strong, .24) * 100%),transparent)}:host(.s-alert--error) .s-alert__icone{color:var(--destructive-on-surface)}.s-alert__icone{flex:0 0 auto;margin-top:1px}.s-alert__corpo{flex:1;min-width:0;display:flex;flex-direction:column;gap:var(--space-4, 4px)}.s-alert__titulo{font-weight:var(--weight-semibold, 600)}.s-alert__texto{color:var(--text-secondary)}.s-alert__fechar{flex:0 0 auto;margin:-4px -8px 0 0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], dismissible: [{ type: i0.Input, args: [{ isSignal: true, alias: "dismissible", required: false }] }], duration: [{ type: i0.Input, args: [{ isSignal: true, alias: "duration", required: false }] }], close: [{ type: i0.Output, args: ["close"] }] } });

/** Quantos avisos ficam visiveis ao mesmo tempo. */
const S_TOAST_MAXIMO = 3;
/** Tempo padrao de permanencia, em ms. */
const S_TOAST_DURACAO = 4000;

/** Padroes em vigor. Sem `provideSiageToast`, os do guia. */
const S_TOAST_DEFAULTS = new InjectionToken('S_TOAST_DEFAULTS', {
    providedIn: 'root',
    factory: () => ({ duration: S_TOAST_DURACAO, errorDuration: 0 }),
});
/**
 * Troca o prazo padrao dos avisos da aplicacao inteira.
 *
 * Os 4s do guia servem a maioria das telas; uma aplicacao de uso em sala, com
 * o professor olhando para a turma e nao para a tela, pode querer mais.
 *
 * @example
 * ```ts
 * // app.config.ts
 * providers: [provideSiageToast({ duration: 6000 })]
 * ```
 */
function provideSiageToast(defaults) {
    return makeEnvironmentProviders([
        {
            provide: S_TOAST_DEFAULTS,
            useValue: { duration: S_TOAST_DURACAO, errorDuration: 0, ...defaults },
        },
    ]);
}

const GLIFOS = {
    success: 'check_circle',
    info: 'info',
    warning: 'warning',
    error: 'error',
};
// O botao de fechar usa a mesma variante semantica do aviso, com o modificador
// `text`: neutro ate o hover, cor do tipo so ali — igual a qualquer outra acao
// destrutiva/de tipo em coluna, sem inventar um estilo novo so para o toast.
const VARIANTES = {
    success: 'success',
    info: 'info',
    warning: 'warning',
    error: 'destructive',
};
/**
 * A pilha de avisos, renderizada dentro de um unico snackbar do Material.
 *
 * Nao e usada diretamente pela aplicacao: quem publica avisos e o
 * `SToastService`. Ela e exportada apenas porque o `MatSnackBar` precisa da
 * classe para instanciar.
 *
 * Os itens nao tem `role` de regiao viva: quem anuncia e o `SToastService`,
 * pelo `LiveAnnouncer`. Os dois juntos faziam o leitor de tela ler o aviso
 * duas vezes.
 */
class SToastStackComponent {
    servico = inject(SToastService);
    avisos = viewChildren('aviso', ...(ngDevMode ? [{ debugName: "avisos", read: (ElementRef) }] : [{ read: (ElementRef) }]));
    /** Avisos que ja entraram: so o que chegou agora anima. */
    animados = new Set();
    constructor() {
        // A entrada e pela Web Animations API, e nao por `@keyframes` no CSS. Logo
        // depois de abrir, o snackbar do Material move o conteudo para a regiao que
        // o leitor de tela anuncia; mover um elemento reinicia a animacao CSS dele,
        // e o primeiro aviso piscava — entrava, sumia e entrava de novo. Animacao
        // criada por `animate()` sobrevive a mudanca de lugar no DOM.
        afterRenderEffect(() => {
            const semMovimento = matchMedia('(prefers-reduced-motion: reduce)').matches;
            const presentes = new Set(this.avisos().map((ref) => ref.nativeElement.dataset['toastId']));
            // Esquece quem ja saiu, para o conjunto nao crescer a sessao inteira.
            for (const id of this.animados) {
                if (!presentes.has(id)) {
                    this.animados.delete(id);
                }
            }
            for (const { nativeElement: aviso } of this.avisos()) {
                const id = aviso.dataset['toastId'] ?? '';
                if (this.animados.has(id)) {
                    continue;
                }
                this.animados.add(id);
                if (!semMovimento) {
                    aviso.animate([
                        { opacity: 0, transform: 'translateX(12px)' },
                        { opacity: 1, transform: 'none' },
                    ], 
                    // `forwards`: o CSS deixa o aviso em opacidade 0; quem o mantem
                    // visivel depois da entrada e o ultimo quadro da animacao.
                    { duration: 180, easing: 'ease-out', fill: 'forwards' });
                }
            }
        });
    }
    glifo(tipo) {
        return GLIFOS[tipo];
    }
    variante(tipo) {
        return VARIANTES[tipo];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SToastStackComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SToastStackComponent, isStandalone: true, selector: "s-toast-stack", host: { classAttribute: "s-toast-stack" }, viewQueries: [{ propertyName: "avisos", predicate: ["aviso"], descendants: true, read: ElementRef, isSignal: true }], ngImport: i0, template: `
    @for (toast of servico.toasts(); track toast.id) {
      <div
        #aviso
        [class]="'s-toast s-toast--' + toast.type"
        [attr.data-toast-id]="toast.id"
        (mouseenter)="servico.pause(toast.id)"
        (mouseleave)="servico.resume(toast.id)"
        (focusin)="servico.pause(toast.id)"
        (focusout)="servico.resume(toast.id)"
      >
        <s-icon class="s-toast__icone" [name]="glifo(toast.type)" size="sm" />

        <div class="s-toast__corpo">
          <strong class="s-toast__titulo">{{ toast.title }}</strong>
          @if (toast.message) {
            <span class="s-toast__mensagem">{{ toast.message }}</span>
          }
        </div>

        <s-icon-button
          class="s-toast__fechar"
          icon="close"
          label="Fechar aviso"
          size="sm"
          [variant]="variante(toast.type)"
          text
          (click)="servico.dismiss(toast.id)"
        />
      </div>
    }
  `, isInline: true, styles: [":host{display:flex;flex-direction:column;gap:var(--space-8, 8px);width:380px;max-width:calc(100vw - var(--space-32, 32px))}.s-toast{display:flex;align-items:flex-start;gap:var(--space-12, 12px);padding:var(--space-12, 12px) var(--space-16, 16px);border:1px solid transparent;border-radius:var(--radius-container, 12px);box-shadow:var(--elevation-2);font-family:var(--font-ui);font-size:var(--text-body, 14px);line-height:var(--leading-normal, 1.45);color:var(--text-primary);opacity:0}@media(prefers-reduced-motion:reduce){.s-toast{opacity:1}}.s-toast--success{background:color-mix(in srgb,var(--success) calc(var(--tint-strong, .24) * 100%),var(--card));border-color:var(--success)}.s-toast--success .s-toast__icone{color:var(--success-on-surface)}.s-toast--info{background:color-mix(in srgb,var(--info) calc(var(--tint-strong, .24) * 100%),var(--card));border-color:var(--info)}.s-toast--info .s-toast__icone{color:var(--info-on-surface)}.s-toast--warning{background:color-mix(in srgb,var(--warning) calc(var(--tint-strong, .24) * 100%),var(--card));border-color:var(--warning)}.s-toast--warning .s-toast__icone{color:var(--warning-on-surface)}.s-toast--error{background:color-mix(in srgb,var(--destructive) calc(var(--tint-strong, .24) * 100%),var(--card));border-color:var(--destructive)}.s-toast--error .s-toast__icone{color:var(--destructive-on-surface)}.s-toast__icone{flex:0 0 auto;margin-top:1px}.s-toast__corpo{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}.s-toast__titulo{font-weight:var(--weight-semibold, 600)}.s-toast__mensagem{color:var(--text-secondary)}.s-toast__fechar{flex:0 0 auto;margin:-4px -8px 0 0}\n"], dependencies: [{ kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }, { kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SToastStackComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-toast-stack', imports: [SIconComponent, SIconButtonComponent], template: `
    @for (toast of servico.toasts(); track toast.id) {
      <div
        #aviso
        [class]="'s-toast s-toast--' + toast.type"
        [attr.data-toast-id]="toast.id"
        (mouseenter)="servico.pause(toast.id)"
        (mouseleave)="servico.resume(toast.id)"
        (focusin)="servico.pause(toast.id)"
        (focusout)="servico.resume(toast.id)"
      >
        <s-icon class="s-toast__icone" [name]="glifo(toast.type)" size="sm" />

        <div class="s-toast__corpo">
          <strong class="s-toast__titulo">{{ toast.title }}</strong>
          @if (toast.message) {
            <span class="s-toast__mensagem">{{ toast.message }}</span>
          }
        </div>

        <s-icon-button
          class="s-toast__fechar"
          icon="close"
          label="Fechar aviso"
          size="sm"
          [variant]="variante(toast.type)"
          text
          (click)="servico.dismiss(toast.id)"
        />
      </div>
    }
  `, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-toast-stack',
                    }, styles: [":host{display:flex;flex-direction:column;gap:var(--space-8, 8px);width:380px;max-width:calc(100vw - var(--space-32, 32px))}.s-toast{display:flex;align-items:flex-start;gap:var(--space-12, 12px);padding:var(--space-12, 12px) var(--space-16, 16px);border:1px solid transparent;border-radius:var(--radius-container, 12px);box-shadow:var(--elevation-2);font-family:var(--font-ui);font-size:var(--text-body, 14px);line-height:var(--leading-normal, 1.45);color:var(--text-primary);opacity:0}@media(prefers-reduced-motion:reduce){.s-toast{opacity:1}}.s-toast--success{background:color-mix(in srgb,var(--success) calc(var(--tint-strong, .24) * 100%),var(--card));border-color:var(--success)}.s-toast--success .s-toast__icone{color:var(--success-on-surface)}.s-toast--info{background:color-mix(in srgb,var(--info) calc(var(--tint-strong, .24) * 100%),var(--card));border-color:var(--info)}.s-toast--info .s-toast__icone{color:var(--info-on-surface)}.s-toast--warning{background:color-mix(in srgb,var(--warning) calc(var(--tint-strong, .24) * 100%),var(--card));border-color:var(--warning)}.s-toast--warning .s-toast__icone{color:var(--warning-on-surface)}.s-toast--error{background:color-mix(in srgb,var(--destructive) calc(var(--tint-strong, .24) * 100%),var(--card));border-color:var(--destructive)}.s-toast--error .s-toast__icone{color:var(--destructive-on-surface)}.s-toast__icone{flex:0 0 auto;margin-top:1px}.s-toast__corpo{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}.s-toast__titulo{font-weight:var(--weight-semibold, 600)}.s-toast__mensagem{color:var(--text-secondary)}.s-toast__fechar{flex:0 0 auto;margin:-4px -8px 0 0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { avisos: [{ type: i0.ViewChildren, args: ['aviso', { ...{ read: (ElementRef) }, isSignal: true }] }] } });

/**
 * Avisos que confirmam algo concluido, sem exigir atencao nem clique.
 *
 * ## Como a pilha funciona
 *
 * Ficam **tres visiveis**, o mais recente no topo. A partir do quarto, o
 * primeiro que foi acionado sai para dar lugar — o mais antigo ja teve tempo de
 * tela, e empilhar seis avisos vira uma parede que ninguem le.
 *
 * ## Por que um unico snackbar
 *
 * O `MatSnackBar` cobre posicao, animacao, overlay e tema, mas mostra **um por
 * vez**: `openFromComponent` fecha o anterior ao abrir o proximo. Entao o
 * servico abre *um* snackbar cujo conteudo e a pilha inteira, e empurra itens
 * nele. E por isso que o prazo de cada aviso vive aqui, e nao no `duration` do
 * Material — aquele encerraria o container inteiro, levando junto os outros
 * dois.
 *
 * Pelo mesmo motivo o anuncio para leitor de tela e feito item a item: com um
 * container de vida longa, so o primeiro seria anunciado.
 *
 * @example
 * ```ts
 * private readonly toast = inject(SToastService);
 *
 * salvar(): void {
 *   this.servico.salvar().subscribe({
 *     next: () => this.toast.success('Jornada salva', 'As alterações foram aplicadas.'),
 *     error: () => this.toast.error('Não foi possível salvar'),
 *   });
 * }
 *
 * // Prazo proprio, em ms, so para este aviso:
 * this.toast.info('Sincronizando', 'Pode levar alguns segundos.', { duration: 8000 });
 * ```
 */
class SToastService {
    snackBar = inject(MatSnackBar);
    announcer = inject(LiveAnnouncer);
    padroes = inject(S_TOAST_DEFAULTS);
    /** A pilha visivel, do mais recente para o mais antigo. */
    toasts = signal([], ...(ngDevMode ? [{ debugName: "toasts" }] : []));
    referencia;
    relogios = new Map();
    sequencia = 0;
    /** Confirma uma acao concluida. */
    success(title, message, options) {
        return this.show({ title, message, type: 'success', ...options });
    }
    /** Informa algo que o usuario nao pediu, mas precisa saber. */
    info(title, message, options) {
        return this.show({ title, message, type: 'info', ...options });
    }
    /** Chama atencao para algo que ainda vai dar problema. */
    warning(title, message, options) {
        return this.show({ title, message, type: 'warning', ...options });
    }
    /** Comunica uma falha. **Nao fecha sozinho.** */
    error(title, message, options) {
        return this.show({ title, message, type: 'error', ...options });
    }
    /** Publica um aviso e devolve o id, para poder fecha-lo antes da hora. */
    show(config) {
        this.sequencia += 1;
        const tipo = config.type ?? 'success';
        const toast = { ...config, id: this.sequencia, type: tipo };
        this.toasts.update((atuais) => {
            const proximos = [toast, ...atuais];
            // A partir do quarto, sai o primeiro que foi acionado: ele ja teve tempo
            // de tela, e uma parede de seis avisos nao e lida por ninguem.
            const excedentes = proximos.slice(S_TOAST_MAXIMO);
            excedentes.forEach((antigo) => this.pararRelogio(antigo.id));
            return proximos.slice(0, S_TOAST_MAXIMO);
        });
        this.abrirSePreciso();
        this.anunciar(toast);
        this.agendarFechamento(toast);
        return toast.id;
    }
    /** Fecha um aviso pelo id. */
    dismiss(id) {
        this.pararRelogio(id);
        this.toasts.update((atuais) => atuais.filter((toast) => toast.id !== id));
        if (this.toasts().length === 0) {
            this.referencia?.dismiss();
            this.referencia = undefined;
        }
    }
    /**
     * Segura o prazo de um aviso enquanto a pessoa esta nele - com o mouse em
     * cima ou o foco no botao de fechar. Sem isto, quem le devagar ou navega
     * pelo teclado ate o "fechar" via o aviso sumir no caminho (WCAG 2.2.1).
     *
     * Chamado pela pilha; a aplicacao nao precisa chamar.
     */
    pause(id) {
        const relogio = this.relogios.get(id);
        if (relogio?.timer !== undefined) {
            clearTimeout(relogio.timer);
            relogio.restante = Math.max(relogio.fimEm - Date.now(), 0);
            relogio.timer = undefined;
        }
    }
    /** Retoma o prazo de onde parou. Ver `pause`. */
    resume(id) {
        const relogio = this.relogios.get(id);
        if (relogio && relogio.timer === undefined) {
            this.iniciarRelogio(id, relogio.restante);
        }
    }
    /** Fecha todos. Util ao trocar de rota. */
    clear() {
        this.relogios.forEach((relogio) => clearTimeout(relogio.timer));
        this.relogios.clear();
        this.toasts.set([]);
        this.referencia?.dismiss();
        this.referencia = undefined;
    }
    abrirSePreciso() {
        if (this.referencia) {
            return;
        }
        this.referencia = this.snackBar.openFromComponent(SToastStackComponent, {
            horizontalPosition: 'end',
            verticalPosition: 'top',
            panelClass: 's-toast-stack__painel',
            // Sem anuncio do container: quem anuncia e cada item, em `anunciar`.
            politeness: 'off',
        });
        this.referencia.afterDismissed().subscribe(() => (this.referencia = undefined));
    }
    anunciar(toast) {
        const texto = toast.message ? `${toast.title}. ${toast.message}` : toast.title;
        // Erro interrompe a leitura em curso; o resto espera a vez.
        void this.announcer.announce(texto, toast.type === 'error' ? 'assertive' : 'polite');
    }
    agendarFechamento(toast) {
        const padrao = toast.type === 'error' ? this.padroes.errorDuration : this.padroes.duration;
        const prazo = toast.duration ?? padrao;
        if (prazo <= 0) {
            return;
        }
        this.iniciarRelogio(toast.id, prazo);
    }
    iniciarRelogio(id, prazo) {
        this.relogios.set(id, {
            timer: setTimeout(() => this.dismiss(id), prazo),
            fimEm: Date.now() + prazo,
            restante: prazo,
        });
    }
    pararRelogio(id) {
        const relogio = this.relogios.get(id);
        if (relogio !== undefined) {
            clearTimeout(relogio.timer);
            this.relogios.delete(id);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SToastService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SToastService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SToastService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * O conteudo que o `SModalService.confirm()` abre.
 *
 * Nao e usado diretamente pela aplicacao — existe porque o `MatDialog` precisa
 * de uma classe para instanciar. Quem escreve a tela chama `confirm()`.
 */
class SConfirmDialogComponent {
    dados = inject(MAT_DIALOG_DATA);
    referencia = inject(MatDialogRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SConfirmDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.34", type: SConfirmDialogComponent, isStandalone: true, selector: "s-confirm-dialog", ngImport: i0, template: `
    <s-modal
      [title]="dados.title"
      [description]="dados.description ?? ''"
      [variant]="dados.variant ?? 'default'"
      [icon]="dados.icon ?? ''"
      [iconVariant]="dados.iconVariant ?? null"
      [alertMessage]="dados.alertMessage ?? ''"
      [alertType]="dados.alertType ?? 'warning'"
      [confirmLabel]="dados.confirmLabel ?? 'Confirmar'"
      [cancelLabel]="dados.cancelLabel ?? 'Cancelar'"
      [size]="dados.size ?? 'md'"
      [width]="dados.width ?? null"
      [closable]="!dados.disableClose"
      (confirm)="referencia.close(true)"
      (cancel)="referencia.close(false)"
    />
  `, isInline: true, dependencies: [{ kind: "component", type: i0.forwardRef(() => SModalComponent), selector: "s-modal", inputs: ["title", "description", "variant", "icon", "iconVariant", "alertMessage", "alertType", "confirmLabel", "cancelLabel", "size", "width", "visible", "closable", "disableClose", "showActions", "centered"], outputs: ["visibleChange", "confirm", "cancel", "closed"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SConfirmDialogComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 's-confirm-dialog',
                    // `forwardRef`: o `<s-modal>` usa o servico, que abre este componente.
                    imports: [forwardRef(() => SModalComponent)],
                    template: `
    <s-modal
      [title]="dados.title"
      [description]="dados.description ?? ''"
      [variant]="dados.variant ?? 'default'"
      [icon]="dados.icon ?? ''"
      [iconVariant]="dados.iconVariant ?? null"
      [alertMessage]="dados.alertMessage ?? ''"
      [alertType]="dados.alertType ?? 'warning'"
      [confirmLabel]="dados.confirmLabel ?? 'Confirmar'"
      [cancelLabel]="dados.cancelLabel ?? 'Cancelar'"
      [size]="dados.size ?? 'md'"
      [width]="dados.width ?? null"
      [closable]="!dados.disableClose"
      (confirm)="referencia.close(true)"
      (cancel)="referencia.close(false)"
    />
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }] });

/**
 * Referencia ao dialogo aberto por `SModalService.open()`.
 *
 * Encapsula `MatDialogRef` sem expor o tipo do Material na API publica.
 * A aplicacao usa apenas `close()`, `afterClosed()` e `componentInstance`.
 */
class SModalRef {
    /** @internal — construido pelo `SModalService`, nao pela aplicacao. */
    #ref;
    /** @internal */
    constructor(ref) {
        this.#ref = ref;
    }
    /** Fecha o dialogo, opcionalmente com um resultado tipado. */
    close(result) {
        this.#ref.close(result);
    }
    /** Observable que emite o resultado quando o dialogo fecha. */
    afterClosed() {
        return this.#ref.afterClosed();
    }
    /** Instancia do componente aberto dentro do dialogo. */
    get componentInstance() {
        return this.#ref.componentInstance;
    }
}
/**
 * Os `data` passados a `SModalService.open()`, lidos de dentro do componente
 * aberto - sem a tela tocar no `MAT_DIALOG_DATA` do Material.
 *
 * Chame num campo de classe, como qualquer `inject()`.
 *
 * @example
 * ```ts
 * export class EditarJornadaComponent {
 *   protected readonly jornada = injectModalData<Jornada>();
 * }
 * ```
 */
function injectModalData() {
    return inject(MAT_DIALOG_DATA);
}
/**
 * A referencia do proprio dialogo, de dentro do componente aberto por
 * `SModalService.open()`: e por ela que ele se fecha e devolve o resultado.
 *
 * @example
 * ```ts
 * export class EditarJornadaComponent {
 *   private readonly modal = injectModalRef<Jornada>();
 *
 *   salvar(jornada: Jornada): void {
 *     this.modal.close(jornada);
 *   }
 * }
 * ```
 */
function injectModalRef() {
    return new SModalRef(inject(MatDialogRef));
}

/**
 * Abaixo desta largura o dialogo vira painel de rodape.
 *
 * E o mesmo corte de "telefone" do CDK (`Breakpoints.XSmall`), escrito aqui
 * para o servico nao depender do mapa inteiro.
 */
const TELA_PEQUENA = '(max-width: 599.98px)';
/** Classe do painel quando ele esta ancorado no rodape. */
const CLASSE_RODAPE = 's-modal__painel--rodape';
/**
 * O guia define o medio em 520px. Os vizinhos mantem a escala simples da
 * migracao do `showModal()` sem criar tokens que o guia ainda nao nomeou.
 */
const WIDTH_BY_SIZE$1 = {
    sm: 400,
    md: 520,
    lg: 720,
};
function confirmWidth(config) {
    return `${config.width ?? WIDTH_BY_SIZE$1[config.size ?? 'md']}px`;
}
function contentWidth(config) {
    return config.width ?? `${WIDTH_BY_SIZE$1[config.size ?? 'md']}px`;
}
/**
 * Abre dialogos sem a aplicacao tocar no `MatDialog`.
 *
 * `confirm()` cobre o caso mais comum — perguntar antes de uma acao — numa
 * linha. Para dialogos com conteudo proprio, `open()` recebe um componente.
 *
 * @example
 * ```ts
 * private readonly modal = inject(SModalService);
 *
 * async excluir(jornada: Jornada): Promise<void> {
 *   const confirmou = await this.modal.confirm({
 *     variant: 'destructive',
 *     title: 'Excluir Registro de Aula?',
 *     description: 'Esta ação não pode ser desfeita.',
 *     confirmLabel: 'Sim, excluir registro',
 *   });
 *
 *   if (confirmou) {
 *     this.servico.excluir(jornada.id).subscribe();
 *   }
 * }
 * ```
 */
class SModalService {
    dialog = inject(MatDialog);
    #telas = inject(BreakpointObserver);
    /**
     * Os dois niveis possiveis: o modal de conteudo (`open`) e, por cima dele,
     * uma confirmacao (`confirm`).
     *
     * E o unico empilhamento que existe, e existe por um caso so: o formulario
     * aberto em modal que pergunta "Descartar alteracoes?" antes de fechar. Sem
     * ele, a pergunta fechava o proprio formulario. Fora isso, abrir um segundo
     * modal do mesmo nivel substitui o primeiro.
     */
    #conteudo = null;
    #confirmacao = null;
    /**
     * Pergunta antes de agir.
     *
     * Resolve `true` quando o usuario confirma e `false` quando cancela — pelo
     * botao, pelo `x` ou pelo Esc. Clicar fora so cancela com
     * `closeOnBackdrop`.
     */
    async confirm(config) {
        // Uma confirmacao substitui outra, mas abre por cima de um modal de
        // conteudo - ver `#conteudo`.
        this.#fechar('confirmacao');
        const width = confirmWidth(config);
        const referencia = this.dialog.open(SConfirmDialogComponent, {
            data: config,
            panelClass: 's-modal__painel',
            backdropClass: 's-modal-backdrop',
            width,
            maxWidth: '92vw',
            // No `x` - o primeiro focavel -, o foco programatico pintava a camada
            // de estado do botao: abria com um quadrado cinza atras dele.
            autoFocus: config.autoFocus ?? 'dialog',
            restoreFocus: true,
            // O fechamento e decidido em `#controlarFechamento`.
            disableClose: true,
        });
        this.#registrarModal('confirmacao', referencia, config, { width });
        // Esc e clique fora devolvem `undefined`; para quem chamou, sao um "nao".
        return (await firstValueFrom(referencia.afterClosed())) ?? false;
    }
    /**
     * Abre um componente proprio (ou um template) como dialogo.
     *
     * Use quando o conteudo for um formulario ou uma tabela. Dentro dele, o
     * `<s-modal>` continua servindo de casca, com titulo e botoes.
     *
     * Retorna {@link SModalRef} — a referencia da propria lib, sem expor
     * `MatDialogRef` na API publica.
     *
     * @example
     * ```ts
     * const ref = this.modal.open(MeuFormularioComponent, {
     *   data: { id: 42 },
     *   width: '600px',
     * });
     *
     * ref.afterClosed().subscribe((resultado) => { ... });
     * ```
     */
    open(component, config = {}) {
        this.#fechar('confirmacao');
        this.#fechar('conteudo');
        const width = contentWidth(config);
        const matConfig = {
            panelClass: 's-modal__painel',
            backdropClass: 's-modal-backdrop',
            maxWidth: config.maxWidth ?? '92vw',
            autoFocus: config.autoFocus ?? 'dialog',
            restoreFocus: true,
            data: config.data,
            width,
            disableClose: true,
        };
        const ref = this.dialog.open(component, matConfig);
        this.#registrarModal('conteudo', ref, config, { width });
        return new SModalRef(ref);
    }
    /** Fecha o modal daquele nivel, se houver, e avisa em dev. */
    #fechar(nivel) {
        const atual = nivel === 'conteudo' ? this.#conteudo : this.#confirmacao;
        if (!atual) {
            return;
        }
        if (isDevMode()) {
            console.warn('[SModalService] Um modal já estava aberto e foi fechado para abrir este novo — ' +
                'só uma confirmação pode abrir por cima de outro modal.');
        }
        atual.close();
        this.#guardar(nivel, null);
    }
    #guardar(nivel, ref) {
        if (nivel === 'conteudo') {
            this.#conteudo = ref;
        }
        else {
            this.#confirmacao = ref;
        }
    }
    /** Registra a referencia, liga fechamento e tamanho, e limpa ao fechar. */
    #registrarModal(nivel, ref, fechamento, tamanho) {
        this.#guardar(nivel, ref);
        this.#controlarFechamento(ref, fechamento);
        this.#acompanharTela(ref, tamanho);
        ref.afterClosed().subscribe(() => {
            if ((nivel === 'conteudo' ? this.#conteudo : this.#confirmacao) === ref) {
                this.#guardar(nivel, null);
            }
        });
    }
    /**
     * Esc fecha; clique fora, so se pedido.
     *
     * O `disableClose` do Material e tudo ou nada — liga os dois ou desliga os
     * dois. Clicar fora por engano, no meio de um formulario, jogava fora o que
     * foi digitado; o Esc, por outro lado, e gesto deliberado. Por isso o dialogo
     * abre sempre com `disableClose` e os dois caminhos sao ligados aqui.
     */
    #controlarFechamento(ref, fechamento) {
        if (fechamento.disableClose) {
            return;
        }
        const fechou = ref.afterClosed();
        ref
            .keydownEvents()
            .pipe(filter$1((evento) => evento.key === 'Escape'), takeUntil(fechou))
            .subscribe((evento) => {
            evento.preventDefault();
            ref.close();
        });
        if (fechamento.closeOnBackdrop) {
            ref
                .backdropClick()
                .pipe(takeUntil(fechou))
                .subscribe(() => ref.close());
        }
    }
    /**
     * Em janela estreita, o dialogo vira painel de rodape: largura total, colado
     * na borda de baixo, em vez de uma caixa espremida no meio. Acompanha o
     * redimensionamento enquanto estiver aberto.
     */
    #acompanharTela(ref, tamanho) {
        this.#telas
            .observe(TELA_PEQUENA)
            .pipe(takeUntil(ref.afterClosed()))
            .subscribe(({ matches }) => {
            if (matches) {
                ref.addPanelClass(CLASSE_RODAPE);
                ref.updatePosition({ bottom: '0' });
                // O `maxWidth` fica com o CSS de `.s-modal__painel--rodape`: o Material
                // nao deixa troca-lo depois de aberto.
                ref.updateSize('100vw');
            }
            else {
                ref.removePanelClass(CLASSE_RODAPE);
                ref.updatePosition();
                ref.updateSize(tamanho.width);
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SModalService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SModalService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SModalService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const WIDTH_BY_SIZE = {
    sm: 400,
    md: 520,
    lg: 720,
};
const ICON_VARIANT_BY_MODAL_VARIANT = {
    default: 'primary',
    destructive: 'destructive',
    result: 'success',
};
/** Numero (ou texto so com digitos) e px; qualquer outro texto vai como CSS (`'40rem'`). */
function widthAttribute(value) {
    if (value === null || value === undefined || value === '') {
        return null;
    }
    if (typeof value === 'number') {
        return value;
    }
    const texto = String(value).trim();
    return /^\d+(\.\d+)?$/.test(texto) ? Number(texto) : texto;
}
/**
 * Marca o rodape proprio de um `<s-modal>`, no lugar dos botoes padrao.
 *
 * ```html
 * <s-modal [(visible)]="aberto" title="Adicionar comprovante">
 *   ...campos...
 *   <div sModalFooter>
 *     <s-button variant="secondary" outlined (click)="aberto.set(false)">Cancelar</s-button>
 *     <s-button (click)="salvar()">Salvar</s-button>
 *   </div>
 * </s-modal>
 * ```
 */
class SModalFooterDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SModalFooterDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.34", type: SModalFooterDirective, isStandalone: true, selector: "[sModalFooter]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SModalFooterDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[sModalFooter]' }]
        }] });
/**
 * Dialogo centralizado.
 *
 * Aplicado **com moderacao**: so quando a interacao exige atencao imediata ou e
 * preciso manter o contexto da tela atras. Confirmar um sucesso simples e
 * trabalho do `SToastService`; um modal para isso interrompe sem necessidade.
 *
 * ## A ordem dos botoes nao e estetica
 *
 * Cancelar fica **sempre a esquerda** e a acao nomeada **sempre a direita**.
 * Quem confirma dez vezes por dia decora a posicao, nao o texto — trocar a
 * ordem numa tela faz a pessoa clicar em excluir por reflexo motor.
 *
 * ## Esta e a casca
 *
 * Para a confirmacao comum, use `SModalService.confirm()`, que abre este
 * componente e devolve a resposta. Use a casca direto quando o dialogo tiver
 * conteudo proprio — um formulario, uma tabela — projetado no meio.
 *
 * O focus trap esta ativo tanto via servico quanto no uso direto em template:
 * a diretiva `cdkTrapFocus` no proprio componente garante que o foco nao
 * escape do dialogo enquanto ele estiver visivel.
 *
 * O `x` do cabecalho emite o mesmo `cancel` do botao "Cancelar" — e uma saida
 * a mais, nao uma terceira decisao.
 *
 * ## Aberto pelo proprio template: `[(visible)]`
 *
 * Com `visible` ligado, o `<s-modal>` deixa de ser desenhado onde esta e abre
 * no overlay pelo `SModalService`, com o mesmo painel, Esc e rodape de tela
 * pequena. O conteudo continua no template da tela, com os bindings dela — e
 * o caminho para formularios que antes moravam num `p-dialog`. Os botoes
 * padrao podem dar lugar a um rodape proprio (`sModalFooter`) ou sumir
 * (`showActions`).
 *
 * Empilhamento de modais esta fora do guia, com uma excecao: uma confirmacao
 * (`confirm()`) pode abrir por cima de um modal de conteudo (`open()`) - e o
 * "Descartar alteracoes?" de um formulario em modal. Ver `SModalService`.
 */
class SModalComponent {
    #elemento = inject(ElementRef);
    #modais = inject(SModalService);
    #aberto = null;
    #destruido = false;
    /** Fora do `MatDialog`: usado direto num template. */
    avulso = !inject(MatDialogRef, { optional: true });
    tituloId = proximoId('s-modal-titulo');
    descricaoId = proximoId('s-modal-descricao');
    painel = viewChild('painel', ...(ngDevMode ? [{ debugName: "painel" }] : []));
    caixa = viewChild('caixa', ...(ngDevMode ? [{ debugName: "caixa" }] : []));
    rodape = contentChild(SModalFooterDirective, ...(ngDevMode ? [{ debugName: "rodape" }] : []));
    constructor() {
        // O `MatDialog` ja prende o foco e o devolve ao fechar; um segundo trap
        // disputava o foco inicial com o `autoFocus` dele.
        const trap = inject(CdkTrapFocus);
        trap.enabled = this.avulso;
        trap.autoCapture = this.avulso;
        effect(() => (trap.enabled = this.emLinha()));
        effect(() => {
            const aberto = this.visible();
            const painel = this.painel();
            untracked(() => {
                if (aberto && painel) {
                    this.#abrir(painel);
                }
                else if (!aberto) {
                    this.#aberto?.close();
                }
            });
        });
        // A tela saiu com o dialogo aberto: fecha junto, sem avisar quem ja nao existe.
        inject(DestroyRef).onDestroy(() => {
            this.#destruido = true;
            this.#aberto?.close();
        });
        // A descricao chega ao container do `MatDialog` por aqui: o Material so
        // liga o titulo sozinho (`matDialogTitle`), nao a descricao.
        afterRenderEffect(() => {
            if (this.emLinha()) {
                return;
            }
            const alvo = this.declarativo() ? this.caixa()?.nativeElement : this.#elemento.nativeElement;
            const container = alvo?.closest('.mat-mdc-dialog-container');
            if (this.description()) {
                container?.setAttribute('aria-describedby', this.descricaoId);
            }
            else {
                container?.removeAttribute('aria-describedby');
            }
        });
    }
    /** Titulo em `--text-h3`. */
    title = input('', ...(ngDevMode ? [{ debugName: "title" }] : []));
    /** Consequencia da acao, em linguagem clara. */
    description = input('', ...(ngDevMode ? [{ debugName: "description" }] : []));
    /** Ver `SModalVariant`. */
    variant = input('default', ...(ngDevMode ? [{ debugName: "variant" }] : []));
    /**
     * Glifo Material Symbols no topo. Opcional: sem ele, o dialogo abre direto no
     * titulo, que e a estrutura minima do guia. A cor segue a variante.
     */
    icon = input('', ...(ngDevMode ? [{ debugName: "icon" }] : []));
    /** Cor do icone. Sem ela, segue a variante. */
    iconVariant = input(null, ...(ngDevMode ? [{ debugName: "iconVariant" }] : []));
    /**
     * Aviso embutido no corpo, perto da decisao.
     *
     * Use quando a consequencia precisa continuar visivel ate a pessoa escolher
     * um botao; para feedback passageiro, prefira `SToastService`.
     */
    alertMessage = input('', ...(ngDevMode ? [{ debugName: "alertMessage" }] : []));
    /** Tom do aviso embutido. */
    alertType = input('warning', ...(ngDevMode ? [{ debugName: "alertType" }] : []));
    /** Rotulo da acao. Nomeie o que vai acontecer — nunca "OK" num destrutivo. */
    confirmLabel = input('Confirmar', ...(ngDevMode ? [{ debugName: "confirmLabel" }] : []));
    /** Rotulo de cancelar. Fica sempre a esquerda. */
    cancelLabel = input('Cancelar', ...(ngDevMode ? [{ debugName: "cancelLabel" }] : []));
    /**
     * Largura semantica.
     *
     * O guia fixa o medio em 520px. `sm` e `lg` existem para cobrir migracoes do
     * `showModal()` antigo sem espalhar numeros nas telas. `width` vence.
     */
    size = input('md', ...(ngDevMode ? [{ debugName: "size" }] : []));
    /**
     * Largura maxima. Numero e px; texto vai como CSS (`'40rem'`). Vence `size`
     * por compatibilidade.
     */
    width = input(null, ...(ngDevMode ? [{ debugName: "width", transform: widthAttribute }] : [{ transform: widthAttribute }]));
    /**
     * Abre e fecha o dialogo no overlay, pelo proprio template. Sem ligar este
     * input, o `<s-modal>` e desenhado onde esta (ou dentro de `open()`).
     *
     * Volta a `false` quando o dialogo fecha por qualquer caminho: `x`,
     * Cancelar, Esc.
     */
    visible = model(undefined, ...(ngDevMode ? [{ debugName: "visible" }] : []));
    /**
     * Mostra o `x` do cabecalho. Desligado, o Esc tambem deixa de fechar o
     * dialogo aberto por `visible`: a saida passa a ser so pelos botoes da tela.
     */
    closable = input(true, ...(ngDevMode ? [{ debugName: "closable", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Impede o Esc de fechar o dialogo aberto por `visible`. */
    disableClose = input(false, ...(ngDevMode ? [{ debugName: "disableClose", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Botoes Cancelar e Confirmar. Ignorado quando ha rodape proprio (`sModalFooter`). */
    showActions = input(true, ...(ngDevMode ? [{ debugName: "showActions", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Titulo, conteudo e acoes centralizados — para avisos curtos. */
    centered = input(false, ...(ngDevMode ? [{ debugName: "centered", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Acao confirmada. */
    confirm = output();
    /** Dialogo cancelado, pelo botao ou pelo `x` (solto na pagina, tambem pelo Esc). */
    cancel = output();
    /** O dialogo aberto por `visible` fechou, por qualquer caminho. */
    closed = output();
    /** `visible` ligado: abre no overlay em vez de ser desenhado aqui. */
    declarativo = computed(() => this.visible() !== undefined, ...(ngDevMode ? [{ debugName: "declarativo" }] : []));
    /** Desenhado solto na pagina — e ele mesmo o dialogo. */
    emLinha = computed(() => this.avulso && !this.declarativo(), ...(ngDevMode ? [{ debugName: "emLinha" }] : []));
    classes = computed(() => `s-modal s-modal--${this.variant()} s-modal--${this.size()}` +
        (this.centered() ? ' s-modal--centro' : ''), ...(ngDevMode ? [{ debugName: "classes" }] : []));
    /** `result` nao oferece escolha: um botao unico, em largura total. */
    ehResultado = computed(() => this.variant() === 'result', ...(ngDevMode ? [{ debugName: "ehResultado" }] : []));
    varianteDaAcao = computed(() => this.variant() === 'destructive' ? 'destructive' : 'primary', ...(ngDevMode ? [{ debugName: "varianteDaAcao" }] : []));
    larguraCss = computed(() => {
        const largura = this.width() ?? WIDTH_BY_SIZE[this.size()];
        return typeof largura === 'number' ? `${largura}px` : largura;
    }, ...(ngDevMode ? [{ debugName: "larguraCss" }] : []));
    iconName = computed(() => this.icon(), ...(ngDevMode ? [{ debugName: "iconName" }] : []));
    corDoIcone = computed(() => this.iconVariant() ?? ICON_VARIANT_BY_MODAL_VARIANT[this.variant()], ...(ngDevMode ? [{ debugName: "corDoIcone" }] : []));
    /** `x` e Cancelar: avisa e, aberto por `visible`, fecha. */
    cancelar() {
        this.cancel.emit();
        if (this.declarativo()) {
            this.visible.set(false);
        }
    }
    /**
     * Esc cancela no uso direto em template. Aberto pelo servico (ou por
     * `visible`), quem trata o Esc e o `SModalService`, respeitando `disableClose`.
     */
    aoTeclarEsc(evento) {
        if (this.emLinha()) {
            evento.preventDefault();
            this.cancel.emit();
        }
    }
    #abrir(painel) {
        if (this.#aberto) {
            return;
        }
        const ref = this.#modais.open(painel, {
            width: this.larguraCss(),
            disableClose: this.disableClose() || !this.closable(),
        });
        this.#aberto = ref;
        ref.afterClosed().subscribe(() => {
            this.#aberto = null;
            if (this.#destruido) {
                return;
            }
            if (this.visible()) {
                this.visible.set(false);
            }
            this.closed.emit();
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SModalComponent, isStandalone: true, selector: "s-modal", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, iconVariant: { classPropertyName: "iconVariant", publicName: "iconVariant", isSignal: true, isRequired: false, transformFunction: null }, alertMessage: { classPropertyName: "alertMessage", publicName: "alertMessage", isSignal: true, isRequired: false, transformFunction: null }, alertType: { classPropertyName: "alertType", publicName: "alertType", isSignal: true, isRequired: false, transformFunction: null }, confirmLabel: { classPropertyName: "confirmLabel", publicName: "confirmLabel", isSignal: true, isRequired: false, transformFunction: null }, cancelLabel: { classPropertyName: "cancelLabel", publicName: "cancelLabel", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, visible: { classPropertyName: "visible", publicName: "visible", isSignal: true, isRequired: false, transformFunction: null }, closable: { classPropertyName: "closable", publicName: "closable", isSignal: true, isRequired: false, transformFunction: null }, disableClose: { classPropertyName: "disableClose", publicName: "disableClose", isSignal: true, isRequired: false, transformFunction: null }, showActions: { classPropertyName: "showActions", publicName: "showActions", isSignal: true, isRequired: false, transformFunction: null }, centered: { classPropertyName: "centered", publicName: "centered", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { visible: "visibleChange", confirm: "confirm", cancel: "cancel", closed: "closed" }, host: { listeners: { "keydown.escape": "aoTeclarEsc($event)" }, properties: { "class": "classes() + (declarativo() ? \" s-modal--declarativo\" : \"\")", "style.--s-modal-w": "larguraCss()", "attr.role": "emLinha() ? \"dialog\" : null", "attr.aria-modal": "emLinha() ? \"true\" : null", "attr.aria-labelledby": "emLinha() && title() ? tituloId : null", "attr.aria-describedby": "emLinha() && description() ? descricaoId : null" }, classAttribute: "s-modal" }, queries: [{ propertyName: "rodape", first: true, predicate: SModalFooterDirective, descendants: true, isSignal: true }], viewQueries: [{ propertyName: "painel", first: true, predicate: ["painel"], descendants: true, isSignal: true }, { propertyName: "caixa", first: true, predicate: ["caixa"], descendants: true, isSignal: true }], hostDirectives: [{ directive: i1$6.CdkTrapFocus }], ngImport: i0, template: "<!-- O miolo e o mesmo nos dois jeitos de usar: desenhado aqui ou, com\n     `visible`, dentro do overlay. -->\n<ng-template #miolo>\n  <div class=\"s-modal__cabecalho\">\n    @if (iconName()) {\n      <s-icon\n        class=\"s-modal__icon\"\n        [name]=\"iconName()\"\n        [variant]=\"corDoIcone()\"\n        filled\n        iconFilled\n        size=\"md\"\n      />\n    }\n    @if (title()) {\n      <!-- `matDialogTitle` entrega o id ao container do MatDialog, que passa a\n           ser anunciado com este titulo. Fora dele, nao faz nada. -->\n      <h2 class=\"s-modal__titulo\" matDialogTitle [id]=\"tituloId\">{{ title() }}</h2>\n    }\n    @if (closable()) {\n      <s-icon-button\n        class=\"s-modal__fechar\"\n        icon=\"close\"\n        label=\"Fechar\"\n        size=\"sm\"\n        (click)=\"cancelar()\"\n      />\n    }\n  </div>\n\n  @if (description()) {\n    <p class=\"s-modal__descricao\" [id]=\"descricaoId\">{{ description() }}</p>\n  }\n\n  @if (alertMessage()) {\n    <s-alert class=\"s-modal__alert\" [type]=\"alertType()\">{{ alertMessage() }}</s-alert>\n  }\n\n  <div class=\"s-modal__conteudo\"><ng-content /></div>\n\n  @if (rodape()) {\n    <div class=\"s-modal__acoes s-modal__rodape\"><ng-content select=\"[sModalFooter]\" /></div>\n  } @else if (showActions()) {\n    <div class=\"s-modal__acoes\">\n      @if (ehResultado()) {\n        <!-- So ciencia a dar, sem decisao a tomar. A partir de 768px o botao\n             tem o tamanho do proprio texto, alinhado a direita como os demais;\n             abaixo disso, ocupa a largura toda. -->\n        <s-button variant=\"primary\" (click)=\"confirm.emit()\">\n          {{ confirmLabel() }}\n        </s-button>\n      } @else {\n        <!-- Cancelar sempre a esquerda: quem confirma dez vezes por dia decora a\n             posicao, nao o texto. -->\n        <s-button data-s-modal-cancel variant=\"secondary\" outlined (click)=\"cancelar()\">{{\n          cancelLabel()\n        }}</s-button>\n        <s-button [variant]=\"varianteDaAcao()\" (click)=\"confirm.emit()\">\n          {{ confirmLabel() }}\n        </s-button>\n      }\n    </div>\n  }\n</ng-template>\n\n@if (declarativo()) {\n  <!-- Aberto pelo `SModalService`: a caixa faz no overlay o papel do host. -->\n  <ng-template #painel>\n    <div #caixa class=\"s-modal__caixa\" [class]=\"classes()\" [style.--s-modal-w]=\"larguraCss()\">\n      <ng-container [ngTemplateOutlet]=\"miolo\" />\n    </div>\n  </ng-template>\n} @else {\n  <ng-container [ngTemplateOutlet]=\"miolo\" />\n}\n", styles: [":host(.s-modal--declarativo){display:none}:host(:not(.s-modal--declarativo)),.s-modal__caixa{display:flex;flex-direction:column;max-height:90vh;box-sizing:border-box;width:min(var(--s-modal-w, 520px),100%);padding:var(--space-24, 24px);background:var(--card);border-radius:var(--radius-control, 8px);color:var(--text-primary);font-family:var(--font-ui)}.s-modal__icon{display:inline-flex;flex:0 0 auto;align-items:center;height:calc(var(--text-h4, 20px) * var(--leading-tight, 1.2));margin-right:calc(var(--space-4, 4px) * -1)}.s-modal__cabecalho{display:flex;align-items:center;gap:var(--space-16, 16px)}.s-modal__titulo{flex:1 1 auto;min-width:0;margin:0;font-family:var(--font-display);font-size:var(--text-h4, 20px);font-weight:var(--weight-semibold, 600);line-height:var(--leading-tight, 1.2)}.s-modal__titulo.mat-mdc-dialog-title{padding:0}.s-modal__titulo.mat-mdc-dialog-title:before{display:none}.s-modal__fechar{flex:0 0 auto;margin:calc(var(--space-8, 8px) * -1) calc(var(--space-8, 8px) * -1) calc(var(--space-8, 8px) * -1) auto}.s-modal__descricao{margin:var(--space-16, 16px) 0 0;font-size:var(--text-body, 14px);line-height:var(--leading-relaxed, 1.6);color:var(--text-secondary)}.s-modal__alert{display:block;margin-top:var(--space-16, 16px)}.s-modal__conteudo{min-height:0;overflow-y:auto;padding-inline:var(--space-8, 8px);margin-inline:calc(var(--space-8, 8px) * -1)}.s-modal__conteudo:not(:empty){margin-top:var(--space-16, 16px)}.s-modal__acoes{display:flex;flex:0 0 auto;flex-wrap:wrap;justify-content:flex-end;gap:var(--space-8, 8px);margin-top:var(--space-24, 24px)}:host(.s-modal--centro),.s-modal__caixa.s-modal--centro{text-align:center}:host(.s-modal--centro) .s-modal__cabecalho,.s-modal__caixa.s-modal--centro .s-modal__cabecalho{position:relative;justify-content:center}:host(.s-modal--centro) .s-modal__titulo,.s-modal__caixa.s-modal--centro .s-modal__titulo{flex:0 1 auto}:host(.s-modal--centro) .s-modal__fechar,.s-modal__caixa.s-modal--centro .s-modal__fechar{position:absolute;top:0;right:0;margin:calc(var(--space-8, 8px) * -1) calc(var(--space-8, 8px) * -1) 0 0}:host(.s-modal--centro) .s-modal__acoes,.s-modal__caixa.s-modal--centro .s-modal__acoes{justify-content:center}.s-modal__rodape ::ng-deep>*{display:flex;flex:1 1 auto;flex-wrap:wrap;justify-content:flex-end;gap:var(--space-8, 8px)}:host(.s-modal--centro) .s-modal__rodape ::ng-deep>*,.s-modal__caixa.s-modal--centro .s-modal__rodape ::ng-deep>*{justify-content:center}@media(max-width:767.98px){.s-modal__acoes:not(.s-modal__rodape),.s-modal__rodape ::ng-deep>*{flex-direction:column-reverse;flex-wrap:nowrap;align-items:stretch;justify-content:flex-start}.s-modal__acoes s-button,.s-modal__rodape ::ng-deep>*>*{display:flex;box-sizing:border-box;width:100%;min-height:var(--control-h-primary-full, 48px);--s-button-h: var(--control-h-primary-full, 48px)}.s-modal__acoes ::ng-deep .s-button__native,.s-modal__rodape ::ng-deep>*>button{width:100%;min-height:var(--control-h-primary-full, 48px)}}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "component", type: SButtonComponent, selector: "s-button", inputs: ["variant", "outlined", "fullWidth", "pressed", "buttonRole", "checked", "focusIndex", "loading", "loadingText", "disabled", "icon", "iconRight", "type", "label"] }, { kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }, { kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }, { kind: "component", type: SAlertComponent, selector: "s-alert", inputs: ["type", "title", "dismissible", "duration"], outputs: ["close"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-modal', imports: [
                        NgTemplateOutlet,
                        MatDialogTitle,
                        SButtonComponent,
                        SIconButtonComponent,
                        SIconComponent,
                        SAlertComponent,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-modal',
                        '[class]': 'classes() + (declarativo() ? " s-modal--declarativo" : "")',
                        '[style.--s-modal-w]': 'larguraCss()',
                        // Aberto pelo `SModalService`, quem e o dialogo e o container do
                        // `MatDialog` - ele ja tem `role="dialog"` e `aria-modal`, e recebe o
                        // titulo pelo `matDialogTitle`. Repetir os papeis aqui criava um dialogo
                        // dentro do outro, os dois sem nome. Solto num template, o dialogo e este.
                        // Com `visible`, abre pelo servico: de novo, o dialogo e o container.
                        '[attr.role]': 'emLinha() ? "dialog" : null',
                        '[attr.aria-modal]': 'emLinha() ? "true" : null',
                        '[attr.aria-labelledby]': 'emLinha() && title() ? tituloId : null',
                        '[attr.aria-describedby]': 'emLinha() && description() ? descricaoId : null',
                        '(keydown.escape)': 'aoTeclarEsc($event)',
                    }, hostDirectives: [CdkTrapFocus], template: "<!-- O miolo e o mesmo nos dois jeitos de usar: desenhado aqui ou, com\n     `visible`, dentro do overlay. -->\n<ng-template #miolo>\n  <div class=\"s-modal__cabecalho\">\n    @if (iconName()) {\n      <s-icon\n        class=\"s-modal__icon\"\n        [name]=\"iconName()\"\n        [variant]=\"corDoIcone()\"\n        filled\n        iconFilled\n        size=\"md\"\n      />\n    }\n    @if (title()) {\n      <!-- `matDialogTitle` entrega o id ao container do MatDialog, que passa a\n           ser anunciado com este titulo. Fora dele, nao faz nada. -->\n      <h2 class=\"s-modal__titulo\" matDialogTitle [id]=\"tituloId\">{{ title() }}</h2>\n    }\n    @if (closable()) {\n      <s-icon-button\n        class=\"s-modal__fechar\"\n        icon=\"close\"\n        label=\"Fechar\"\n        size=\"sm\"\n        (click)=\"cancelar()\"\n      />\n    }\n  </div>\n\n  @if (description()) {\n    <p class=\"s-modal__descricao\" [id]=\"descricaoId\">{{ description() }}</p>\n  }\n\n  @if (alertMessage()) {\n    <s-alert class=\"s-modal__alert\" [type]=\"alertType()\">{{ alertMessage() }}</s-alert>\n  }\n\n  <div class=\"s-modal__conteudo\"><ng-content /></div>\n\n  @if (rodape()) {\n    <div class=\"s-modal__acoes s-modal__rodape\"><ng-content select=\"[sModalFooter]\" /></div>\n  } @else if (showActions()) {\n    <div class=\"s-modal__acoes\">\n      @if (ehResultado()) {\n        <!-- So ciencia a dar, sem decisao a tomar. A partir de 768px o botao\n             tem o tamanho do proprio texto, alinhado a direita como os demais;\n             abaixo disso, ocupa a largura toda. -->\n        <s-button variant=\"primary\" (click)=\"confirm.emit()\">\n          {{ confirmLabel() }}\n        </s-button>\n      } @else {\n        <!-- Cancelar sempre a esquerda: quem confirma dez vezes por dia decora a\n             posicao, nao o texto. -->\n        <s-button data-s-modal-cancel variant=\"secondary\" outlined (click)=\"cancelar()\">{{\n          cancelLabel()\n        }}</s-button>\n        <s-button [variant]=\"varianteDaAcao()\" (click)=\"confirm.emit()\">\n          {{ confirmLabel() }}\n        </s-button>\n      }\n    </div>\n  }\n</ng-template>\n\n@if (declarativo()) {\n  <!-- Aberto pelo `SModalService`: a caixa faz no overlay o papel do host. -->\n  <ng-template #painel>\n    <div #caixa class=\"s-modal__caixa\" [class]=\"classes()\" [style.--s-modal-w]=\"larguraCss()\">\n      <ng-container [ngTemplateOutlet]=\"miolo\" />\n    </div>\n  </ng-template>\n} @else {\n  <ng-container [ngTemplateOutlet]=\"miolo\" />\n}\n", styles: [":host(.s-modal--declarativo){display:none}:host(:not(.s-modal--declarativo)),.s-modal__caixa{display:flex;flex-direction:column;max-height:90vh;box-sizing:border-box;width:min(var(--s-modal-w, 520px),100%);padding:var(--space-24, 24px);background:var(--card);border-radius:var(--radius-control, 8px);color:var(--text-primary);font-family:var(--font-ui)}.s-modal__icon{display:inline-flex;flex:0 0 auto;align-items:center;height:calc(var(--text-h4, 20px) * var(--leading-tight, 1.2));margin-right:calc(var(--space-4, 4px) * -1)}.s-modal__cabecalho{display:flex;align-items:center;gap:var(--space-16, 16px)}.s-modal__titulo{flex:1 1 auto;min-width:0;margin:0;font-family:var(--font-display);font-size:var(--text-h4, 20px);font-weight:var(--weight-semibold, 600);line-height:var(--leading-tight, 1.2)}.s-modal__titulo.mat-mdc-dialog-title{padding:0}.s-modal__titulo.mat-mdc-dialog-title:before{display:none}.s-modal__fechar{flex:0 0 auto;margin:calc(var(--space-8, 8px) * -1) calc(var(--space-8, 8px) * -1) calc(var(--space-8, 8px) * -1) auto}.s-modal__descricao{margin:var(--space-16, 16px) 0 0;font-size:var(--text-body, 14px);line-height:var(--leading-relaxed, 1.6);color:var(--text-secondary)}.s-modal__alert{display:block;margin-top:var(--space-16, 16px)}.s-modal__conteudo{min-height:0;overflow-y:auto;padding-inline:var(--space-8, 8px);margin-inline:calc(var(--space-8, 8px) * -1)}.s-modal__conteudo:not(:empty){margin-top:var(--space-16, 16px)}.s-modal__acoes{display:flex;flex:0 0 auto;flex-wrap:wrap;justify-content:flex-end;gap:var(--space-8, 8px);margin-top:var(--space-24, 24px)}:host(.s-modal--centro),.s-modal__caixa.s-modal--centro{text-align:center}:host(.s-modal--centro) .s-modal__cabecalho,.s-modal__caixa.s-modal--centro .s-modal__cabecalho{position:relative;justify-content:center}:host(.s-modal--centro) .s-modal__titulo,.s-modal__caixa.s-modal--centro .s-modal__titulo{flex:0 1 auto}:host(.s-modal--centro) .s-modal__fechar,.s-modal__caixa.s-modal--centro .s-modal__fechar{position:absolute;top:0;right:0;margin:calc(var(--space-8, 8px) * -1) calc(var(--space-8, 8px) * -1) 0 0}:host(.s-modal--centro) .s-modal__acoes,.s-modal__caixa.s-modal--centro .s-modal__acoes{justify-content:center}.s-modal__rodape ::ng-deep>*{display:flex;flex:1 1 auto;flex-wrap:wrap;justify-content:flex-end;gap:var(--space-8, 8px)}:host(.s-modal--centro) .s-modal__rodape ::ng-deep>*,.s-modal__caixa.s-modal--centro .s-modal__rodape ::ng-deep>*{justify-content:center}@media(max-width:767.98px){.s-modal__acoes:not(.s-modal__rodape),.s-modal__rodape ::ng-deep>*{flex-direction:column-reverse;flex-wrap:nowrap;align-items:stretch;justify-content:flex-start}.s-modal__acoes s-button,.s-modal__rodape ::ng-deep>*>*{display:flex;box-sizing:border-box;width:100%;min-height:var(--control-h-primary-full, 48px);--s-button-h: var(--control-h-primary-full, 48px)}.s-modal__acoes ::ng-deep .s-button__native,.s-modal__rodape ::ng-deep>*>button{width:100%;min-height:var(--control-h-primary-full, 48px)}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { painel: [{ type: i0.ViewChild, args: ['painel', { isSignal: true }] }], caixa: [{ type: i0.ViewChild, args: ['caixa', { isSignal: true }] }], rodape: [{ type: i0.ContentChild, args: [i0.forwardRef(() => SModalFooterDirective), { isSignal: true }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], iconVariant: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconVariant", required: false }] }], alertMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "alertMessage", required: false }] }], alertType: [{ type: i0.Input, args: [{ isSignal: true, alias: "alertType", required: false }] }], confirmLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "confirmLabel", required: false }] }], cancelLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "cancelLabel", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], width: [{ type: i0.Input, args: [{ isSignal: true, alias: "width", required: false }] }], visible: [{ type: i0.Input, args: [{ isSignal: true, alias: "visible", required: false }] }, { type: i0.Output, args: ["visibleChange"] }], closable: [{ type: i0.Input, args: [{ isSignal: true, alias: "closable", required: false }] }], disableClose: [{ type: i0.Input, args: [{ isSignal: true, alias: "disableClose", required: false }] }], showActions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showActions", required: false }] }], centered: [{ type: i0.Input, args: [{ isSignal: true, alias: "centered", required: false }] }], confirm: [{ type: i0.Output, args: ["confirm"] }], cancel: [{ type: i0.Output, args: ["cancel"] }], closed: [{ type: i0.Output, args: ["closed"] }] } });

/**
 * Indicador circular indeterminado.
 *
 * O guia proíbe spinner central para carregamento de tela inteira: nesse caso,
 * prefira skeleton ou `<s-loading-overlay>` quando a aplicação ainda estiver
 * presa ao padrão antigo. Este componente existe para os pontos em que o estado
 * é curto e inline — o mesmo papel do `progress_activity` usado pelos botões em
 * `loading`.
 *
 * A implementação é CSS + `<s-icon>`, e não `mat-progress-spinner`, para manter
 * a mesma linguagem visual do botão e evitar dois desenhos de progresso dentro
 * da biblioteca.
 */
class SSpinnerComponent {
    /**
     * Passo da escala de ícone.
     *
     * Spinner inline acompanha a mesma escala dos ícones porque ele substitui um
     * glifo de estado, não um bloco de conteúdo. Para carregamento estrutural,
     * use skeleton.
     */
    size = input('md', ...(ngDevMode ? [{ debugName: "size", transform: tamanhoDeIcone('md') }] : [{ transform: tamanhoDeIcone('md') }]));
    /** Nome anunciado por leitor de tela quando não há texto visível por perto. */
    label = input('Carregando', ...(ngDevMode ? [{ debugName: "label" }] : []));
    sizeCss = computed(() => `var(--icon-${this.size()})`, ...(ngDevMode ? [{ debugName: "sizeCss" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SSpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.34", type: SSpinnerComponent, isStandalone: true, selector: "s-spinner", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "progressbar" }, properties: { "attr.aria-label": "label()", "style.--s-spinner-size": "sizeCss()" }, classAttribute: "s-spinner" }, ngImport: i0, template: `<s-icon class="s-spinner__icon" name="progress_activity" [size]="size()" />`, isInline: true, styles: [":host{display:inline-flex;align-items:center;justify-content:center;width:var(--s-spinner-size);height:var(--s-spinner-size);color:var(--primary);vertical-align:middle}.s-spinner__icon{animation:s-spinner-spin .9s linear infinite}@keyframes s-spinner-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.s-spinner__icon{animation-duration:3s}}\n"], dependencies: [{ kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SSpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-spinner', imports: [SIconComponent], template: `<s-icon class="s-spinner__icon" name="progress_activity" [size]="size()" />`, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-spinner',
                        role: 'progressbar',
                        '[attr.aria-label]': 'label()',
                        '[style.--s-spinner-size]': 'sizeCss()',
                    }, styles: [":host{display:inline-flex;align-items:center;justify-content:center;width:var(--s-spinner-size);height:var(--s-spinner-size);color:var(--primary);vertical-align:middle}.s-spinner__icon{animation:s-spinner-spin .9s linear infinite}@keyframes s-spinner-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.s-spinner__icon{animation-duration:3s}}\n"] }]
        }], propDecorators: { size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

/**
 * Estado global de carregamento controlado pela aplicação.
 *
 * A biblioteca não faz HTTP dentro de componente. Este serviço só conta
 * operações que a aplicação informa: um `HttpInterceptorFn`, um resolver ou uma
 * ação manual chamam `begin()` e garantem `end()` no `finalize`.
 */
class SLoadingService {
    count = signal(0, ...(ngDevMode ? [{ debugName: "count" }] : []));
    /** `true` enquanto existir ao menos uma operação em aberto. */
    active = computed(() => this.count() > 0, ...(ngDevMode ? [{ debugName: "active" }] : []));
    /**
     * Marca o início de uma operação.
     *
     * Devolve uma função de finalização idempotente para o chamador não perder a
     * contagem em caminhos de erro, cancelamento ou `return` antecipado.
     */
    begin() {
        let ended = false;
        this.count.update((value) => value + 1);
        return () => {
            if (!ended) {
                ended = true;
                this.end();
            }
        };
    }
    /** Marca o fim de uma operação. Chamadas sobrando não deixam a contagem negativa. */
    end() {
        this.count.update((value) => Math.max(0, value - 1));
    }
    /** Envolve um Observable garantindo `end()` em sucesso, erro ou cancelamento. */
    track(source) {
        const finish = this.begin();
        return source.pipe(finalize$1(finish));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SLoadingService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SLoadingService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SLoadingService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/**
 * Interceptor opcional para ligar o overlay no HTTP da aplicação.
 *
 * Ele não viola a regra "nada de HTTP dentro de componente": fica fora dos
 * componentes, não conhece endpoint nenhum e só observa o ciclo da requisição.
 *
 * ```ts
 * provideHttpClient(withInterceptors([siageLoadingInterceptor]))
 * ```
 */
const siageLoadingInterceptor = (req, next) => {
    const loading = injectLoadingService();
    const finish = loading.begin();
    return next(req).pipe(finalize$1(finish));
};
function injectLoadingService() {
    return inject(SLoadingService);
}

/**
 * Bloqueio visual para carregamentos globais durante a migração.
 *
 * O guia prefere skeleton no formato do conteúdo. Este overlay existe para dar
 * paridade ao `app-loading` usado pelos sistemas enquanto cada tela migra para
 * estados mais específicos. O atraso de `S_LOADING_DELAY` evita o piscar de
 * requisições rápidas.
 */
class SLoadingOverlayComponent {
    /**
     * Estado controlado pela tela.
     *
     * Quando omitido, o componente usa `SLoadingService.active`, pensado para o
     * interceptor da aplicação.
     */
    active = input(null, ...(ngDevMode ? [{ debugName: "active" }] : []));
    /** Prende o overlay ao container posicionado pelo consumidor, em vez da viewport. */
    contained = input(false, ...(ngDevMode ? [{ debugName: "contained", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Texto anunciado quando o overlay finalmente aparece. */
    label = input('Carregando', ...(ngDevMode ? [{ debugName: "label" }] : []));
    loading = inject(SLoadingService);
    el = inject(ElementRef);
    rawActive = computed(() => this.active() ?? this.loading.active(), ...(ngDevMode ? [{ debugName: "rawActive" }] : []));
    visible = adiarCarregamento(this.rawActive);
    constructor() {
        // Depois do render: um `effect` rodaria antes de o `@if` desenhar o bloqueio.
        afterRenderEffect(() => {
            if (this.visible()) {
                this.el.nativeElement.querySelector('.s-loading-overlay__blocker')?.focus();
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SLoadingOverlayComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SLoadingOverlayComponent, isStandalone: true, selector: "s-loading-overlay", inputs: { active: { classPropertyName: "active", publicName: "active", isSignal: true, isRequired: false, transformFunction: null }, contained: { classPropertyName: "contained", publicName: "contained", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.s-loading-overlay--contained": "contained()", "class.s-loading-overlay--visible": "visible()", "attr.aria-busy": "rawActive() ? \"true\" : null", "attr.aria-hidden": "visible() ? null : \"true\"" }, classAttribute: "s-loading-overlay" }, ngImport: i0, template: "@if (visible()) {\n  <div class=\"s-loading-overlay__blocker\" tabindex=\"-1\" role=\"status\" aria-live=\"polite\">\n    <div class=\"s-loading-overlay__card\">\n      <s-spinner size=\"lg\" [label]=\"label()\" />\n      <span class=\"s-loading-overlay__text\">{{ label() }}</span>\n    </div>\n  </div>\n}\n", styles: [":host{display:contents}.s-loading-overlay__blocker{position:fixed;inset:0;z-index:var(--z-modal, 1000);display:grid;place-items:center;padding:var(--space-24, 24px);background:color-mix(in srgb,var(--background) 72%,transparent);-webkit-backdrop-filter:blur(2px);backdrop-filter:blur(2px);cursor:progress}:host(.s-loading-overlay--contained) .s-loading-overlay__blocker{position:absolute;border-radius:inherit}.s-loading-overlay__blocker:focus-visible{outline:none}.s-loading-overlay__card{display:inline-flex;align-items:center;gap:var(--space-12, 12px);padding:var(--space-16, 16px) var(--space-24, 24px);border:1px solid var(--card-border);border-radius:var(--radius-container, 12px);background:var(--card);color:var(--text-primary);box-shadow:var(--shadow-lg);font-family:var(--font-ui);font-size:var(--text-body, 14px)}\n"], dependencies: [{ kind: "component", type: SSpinnerComponent, selector: "s-spinner", inputs: ["size", "label"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SLoadingOverlayComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-loading-overlay', imports: [SSpinnerComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-loading-overlay',
                        '[class.s-loading-overlay--contained]': 'contained()',
                        '[class.s-loading-overlay--visible]': 'visible()',
                        '[attr.aria-busy]': 'rawActive() ? "true" : null',
                        '[attr.aria-hidden]': 'visible() ? null : "true"',
                    }, template: "@if (visible()) {\n  <div class=\"s-loading-overlay__blocker\" tabindex=\"-1\" role=\"status\" aria-live=\"polite\">\n    <div class=\"s-loading-overlay__card\">\n      <s-spinner size=\"lg\" [label]=\"label()\" />\n      <span class=\"s-loading-overlay__text\">{{ label() }}</span>\n    </div>\n  </div>\n}\n", styles: [":host{display:contents}.s-loading-overlay__blocker{position:fixed;inset:0;z-index:var(--z-modal, 1000);display:grid;place-items:center;padding:var(--space-24, 24px);background:color-mix(in srgb,var(--background) 72%,transparent);-webkit-backdrop-filter:blur(2px);backdrop-filter:blur(2px);cursor:progress}:host(.s-loading-overlay--contained) .s-loading-overlay__blocker{position:absolute;border-radius:inherit}.s-loading-overlay__blocker:focus-visible{outline:none}.s-loading-overlay__card{display:inline-flex;align-items:center;gap:var(--space-12, 12px);padding:var(--space-16, 16px) var(--space-24, 24px);border:1px solid var(--card-border);border-radius:var(--radius-container, 12px);background:var(--card);color:var(--text-primary);box-shadow:var(--shadow-lg);font-family:var(--font-ui);font-size:var(--text-body, 14px)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { active: [{ type: i0.Input, args: [{ isSignal: true, alias: "active", required: false }] }], contained: [{ type: i0.Input, args: [{ isSignal: true, alias: "contained", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

function clampPercent(value) {
    if (Number.isNaN(value)) {
        return 0;
    }
    return Math.min(100, Math.max(0, value));
}
/**
 * Barra de progresso linear.
 *
 * Use `determinate` quando a aplicação sabe o percentual real; use
 * `indeterminate` quando só sabe que há trabalho em andamento. A barra não faz
 * requisição nem assume etapas: ela só comunica o estado recebido pela tela.
 */
class SProgressBarComponent {
    /** Percentual real do processo. Só é anunciado em `determinate`. */
    value = input(0, ...(ngDevMode ? [{ debugName: "value", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** `indeterminate` remove `aria-valuenow` porque não há percentual confiável. */
    mode = input('determinate', ...(ngDevMode ? [{ debugName: "mode" }] : []));
    /** Tom visual. Ver `SProgressBarTone`. */
    tone = input('primary', ...(ngDevMode ? [{ debugName: "tone" }] : []));
    /** Exibe o percentual ao lado da barra quando ele ajuda a comparar avanço. */
    showValue = input(false, ...(ngDevMode ? [{ debugName: "showValue", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Nome acessível do progresso no contexto da tela. */
    label = input('Progresso', ...(ngDevMode ? [{ debugName: "label" }] : []));
    normalizedValue = computed(() => clampPercent(this.value()), ...(ngDevMode ? [{ debugName: "normalizedValue" }] : []));
    valueCss = computed(() => `${this.normalizedValue()}%`, ...(ngDevMode ? [{ debugName: "valueCss" }] : []));
    ariaValue = computed(() => this.mode() === 'determinate' ? String(this.normalizedValue()) : null, ...(ngDevMode ? [{ debugName: "ariaValue" }] : []));
    hostClasses = computed(() => ['s-progress-bar--' + this.tone(), 's-progress-bar--' + this.mode()].join(' '), ...(ngDevMode ? [{ debugName: "hostClasses" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SProgressBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SProgressBarComponent, isStandalone: true, selector: "s-progress-bar", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, showValue: { classPropertyName: "showValue", publicName: "showValue", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "progressbar", "aria-valuemin": "0", "aria-valuemax": "100" }, properties: { "class": "hostClasses()", "attr.aria-valuenow": "ariaValue()", "attr.aria-label": "label()", "style.--s-progress-value": "valueCss()" }, classAttribute: "s-progress-bar" }, ngImport: i0, template: "<div class=\"s-progress-bar__track\" aria-hidden=\"true\">\n  <div class=\"s-progress-bar__fill\"></div>\n</div>\n\n@if (showValue() && mode() === 'determinate') {\n  <span class=\"s-progress-bar__value\">{{ normalizedValue() }}%</span>\n}\n", styles: [":host{display:flex;align-items:center;gap:var(--space-8, 8px);width:100%;color:var(--text-secondary);font-family:var(--font-ui);font-size:var(--text-small, 12px)}.s-progress-bar__track{flex:1;min-width:0;height:var(--space-8, 8px);overflow:hidden;border-radius:var(--radius-full, 9999px);background:color-mix(in srgb,var(--text-primary) 10%,transparent)}.s-progress-bar__fill{width:var(--s-progress-value);height:100%;border-radius:inherit;background:var(--s-progress-color);transition:width .15s ease}.s-progress-bar__value{min-width:4ch;text-align:right;font-variant-numeric:tabular-nums}:host(.s-progress-bar--primary){--s-progress-color: var(--primary)}:host(.s-progress-bar--success){--s-progress-color: var(--success)}:host(.s-progress-bar--warning){--s-progress-color: var(--warning)}:host(.s-progress-bar--destructive){--s-progress-color: var(--destructive)}:host(.s-progress-bar--indeterminate) .s-progress-bar__fill{width:40%;animation:s-progress-indeterminate 1.4s ease-in-out infinite}@keyframes s-progress-indeterminate{0%{transform:translate(-100%)}to{transform:translate(250%)}}@media(prefers-reduced-motion:reduce){.s-progress-bar__fill{transition:none}:host(.s-progress-bar--indeterminate) .s-progress-bar__fill{animation:none;width:100%;opacity:.45}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SProgressBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-progress-bar', changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-progress-bar',
                        '[class]': 'hostClasses()',
                        role: 'progressbar',
                        'aria-valuemin': '0',
                        'aria-valuemax': '100',
                        '[attr.aria-valuenow]': 'ariaValue()',
                        '[attr.aria-label]': 'label()',
                        '[style.--s-progress-value]': 'valueCss()',
                    }, template: "<div class=\"s-progress-bar__track\" aria-hidden=\"true\">\n  <div class=\"s-progress-bar__fill\"></div>\n</div>\n\n@if (showValue() && mode() === 'determinate') {\n  <span class=\"s-progress-bar__value\">{{ normalizedValue() }}%</span>\n}\n", styles: [":host{display:flex;align-items:center;gap:var(--space-8, 8px);width:100%;color:var(--text-secondary);font-family:var(--font-ui);font-size:var(--text-small, 12px)}.s-progress-bar__track{flex:1;min-width:0;height:var(--space-8, 8px);overflow:hidden;border-radius:var(--radius-full, 9999px);background:color-mix(in srgb,var(--text-primary) 10%,transparent)}.s-progress-bar__fill{width:var(--s-progress-value);height:100%;border-radius:inherit;background:var(--s-progress-color);transition:width .15s ease}.s-progress-bar__value{min-width:4ch;text-align:right;font-variant-numeric:tabular-nums}:host(.s-progress-bar--primary){--s-progress-color: var(--primary)}:host(.s-progress-bar--success){--s-progress-color: var(--success)}:host(.s-progress-bar--warning){--s-progress-color: var(--warning)}:host(.s-progress-bar--destructive){--s-progress-color: var(--destructive)}:host(.s-progress-bar--indeterminate) .s-progress-bar__fill{width:40%;animation:s-progress-indeterminate 1.4s ease-in-out infinite}@keyframes s-progress-indeterminate{0%{transform:translate(-100%)}to{transform:translate(250%)}}@media(prefers-reduced-motion:reduce){.s-progress-bar__fill{transition:none}:host(.s-progress-bar--indeterminate) .s-progress-bar__fill{animation:none;width:100%;opacity:.45}}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], mode: [{ type: i0.Input, args: [{ isSignal: true, alias: "mode", required: false }] }], tone: [{ type: i0.Input, args: [{ isSignal: true, alias: "tone", required: false }] }], showValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "showValue", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

function isRouteBreadcrumbConfig(value) {
    return (typeof value === 'object' &&
        value !== null &&
        'label' in value &&
        typeof value.label === 'string');
}
function routeLinkFromSnapshots(snapshots) {
    const segments = snapshots.flatMap((snapshot) => snapshot.url.map((segment) => segment.path));
    return segments.length ? `/${segments.join('/')}` : '/';
}
/**
 * Monta a trilha a partir de `data.breadcrumb` no Router, sem obrigar quem
 * prefere informar os itens manualmente a registrar providers extras.
 *
 * Use quando a aplicacao ja tem a hierarquia nas rotas. `breadcrumb: null`
 * pula o nivel; string vira o rotulo; objeto permite sobrescrever `href` ou
 * `routerLink`. O ultimo item continua marcado como pagina atual pelo
 * componente, por isso o link dele nao fica clicavel.
 *
 * @example
 * ```ts
 * const routes: Routes = [
 *   { path: 'configuracoes', data: { breadcrumb: 'Configurações' } },
 * ];
 *
 * readonly breadcrumbs = breadcrumbFromRoute(inject(ActivatedRoute));
 * ```
 */
function breadcrumbFromRoute(route) {
    const snapshots = [];
    const breadcrumbs = [];
    for (const snapshot of route.snapshot.pathFromRoot) {
        snapshots.push(snapshot);
        const value = snapshot.data['breadcrumb'];
        if (value === undefined || value === null) {
            continue;
        }
        const routerLink = routeLinkFromSnapshots(snapshots);
        if (typeof value === 'string') {
            breadcrumbs.push({ label: value, routerLink });
            continue;
        }
        if (isRouteBreadcrumbConfig(value)) {
            breadcrumbs.push({
                label: value.label,
                href: value.href,
                routerLink: value.routerLink ?? routerLink,
            });
        }
    }
    return breadcrumbs;
}

/**
 * Marca o conteudo projetado como estado do registro ao lado do titulo.
 *
 * O PageHeader nao recria tons de status porque o guia ja tem o `s-badge` para
 * isso. A diretiva so reserva o lugar certo no cabecalho; a aplicacao escolhe
 * o componente visual que conhece o estado do seu dominio.
 *
 * @example
 * ```html
 * <s-page-header title="Publicação">
 *   <s-badge sPageHeaderStatus tone="success">Publicado</s-badge>
 * </s-page-header>
 * ```
 */
class SPageHeaderStatusDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SPageHeaderStatusDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.34", type: SPageHeaderStatusDirective, isStandalone: true, selector: "[sPageHeaderStatus]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SPageHeaderStatusDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[sPageHeaderStatus]',
                    standalone: true,
                }]
        }] });

const TONS = [
    'default',
    'success',
    'warning',
    'destructive',
    'info',
    'secondary',
    'outline',
];
/**
 * Bloco inicial de toda tela: breadcrumbs, titulo, descricao e a acao primaria.
 *
 * ## A ordem e obrigatoria
 *
 * Trilha, titulo, descricao. Nessa sequencia, sempre — em cadastro, listagem,
 * visualizacao e dashboard. E o que faz alguem reconhecer onde esta antes de
 * ler qualquer coisa.
 *
 * ## Por que existe um so
 *
 * O Professores tinha `app-header-page` (titulo, subtitulo, tag e voltar) e
 * `app-generic-page-structure` (titulo e subtitulo). O segundo era um
 * subconjunto do primeiro, entao nao havia o que escolher — havia o que
 * unificar. Este componente cobre os dois. A `tag` ficou como slot
 * `[sPageHeaderStatus]`: estado do registro pertence ao conteudo da tela, mas
 * algumas telas precisam posicionar esse estado ao lado do titulo. A aplicacao
 * projeta um `<s-badge>` real e o PageHeader nao duplica tons.
 *
 * ## A acao primaria e uma so
 *
 * O slot `[action]` recebe **a** acao da tela, no singular. Duas acoes
 * primarias competindo no topo e o mesmo que nenhuma; a segunda desce para
 * dentro do conteudo. Permissao tambem fica na aplicacao: use `@if` ao projetar
 * a acao. A biblioteca nao consulta `SPermissionChecker` aqui porque cada tela
 * decide se a falta de permissao esconde, desabilita ou desloca a acao.
 *
 * @example
 * ```html
 * <s-page-header
 *   [breadcrumbs]="[{ label: 'Configurações' }, { label: 'Jornadas' }]"
 *   title="Jornadas de Trabalho"
 *   description="Gerencie as jornadas que definem o horário padrão de trabalho."
 *   showBack
 *   (back)="voltar()"
 * >
 *   <s-badge sPageHeaderStatus tone="warning" icon="warning">Rascunho</s-badge>
 *   <s-button action variant="primary" icon="add">Nova Jornada</s-button>
 * </s-page-header>
 * ```
 */
class SPageHeaderComponent {
    #router = inject(Router, { optional: true });
    /** Trilha de navegacao. O ultimo item e a tela atual. */
    breadcrumbs = input([], ...(ngDevMode ? [{ debugName: "breadcrumbs" }] : []));
    /**
     * Monta a trilha sozinho, pelo `data.breadcrumb` das rotas ativas, e a
     * refaz a cada navegacao. Ver `breadcrumbFromRoute` para o formato. Vence
     * `breadcrumbs`.
     */
    breadcrumbsFromRoute = input(false, ...(ngDevMode ? [{ debugName: "breadcrumbsFromRoute", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Rota do inicio (`'/'`). Informada, a trilha abre com o icone de casa, que
     * leva para la — so quando ha trilha para mostrar.
     */
    homeLink = input(null, ...(ngDevMode ? [{ debugName: "homeLink" }] : []));
    /** Texto do status ao lado do titulo — para o caso comum, sem montar o badge. */
    status = input('', ...(ngDevMode ? [{ debugName: "status" }] : []));
    /** Tom do status. Aceita tambem as severidades antigas (`warn`, `danger`...). */
    statusTone = input('info', ...(ngDevMode ? [{ debugName: "statusTone" }] : []));
    /** Glifo do status. */
    statusIcon = input('', ...(ngDevMode ? [{ debugName: "statusIcon" }] : []));
    /** Titulo da tela, em `--text-h1`. */
    title = input('', ...(ngDevMode ? [{ debugName: "title" }] : []));
    /** Uma ou duas linhas dizendo para que serve a tela. */
    description = input('', ...(ngDevMode ? [{ debugName: "description" }] : []));
    /**
     * Icone opcional antes da descricao.
     *
     * O guia permite iconografia quando ela ajuda a reconhecer o contexto do
     * subtitulo; o texto continua sendo a fonte de significado, entao o icone e
     * decorativo e usa o tamanho de controle.
     */
    subtitleIcon = input('', ...(ngDevMode ? [{ debugName: "subtitleIcon" }] : []));
    /** Exibe a seta de voltar a esquerda do titulo. */
    showBack = input(false, ...(ngDevMode ? [{ debugName: "showBack", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Disparado pela seta de voltar. */
    back = output();
    statusProjetado = contentChild(SPageHeaderStatusDirective, ...(ngDevMode ? [{ debugName: "statusProjetado" }] : []));
    tomDoStatus = computed(() => {
        const tom = this.statusTone();
        return TONS.includes(tom)
            ? tom
            : severityTone(tom);
    }, ...(ngDevMode ? [{ debugName: "tomDoStatus" }] : []));
    /** Muda a cada navegacao concluida, para a trilha da rota se refazer. */
    #navegacao = toSignal(this.#router?.events?.pipe(filter$1((evento) => evento instanceof NavigationEnd)) ?? EMPTY);
    trilha = computed(() => {
        const itens = this.breadcrumbsFromRoute() ? this.#trilhaDaRota() : this.breadcrumbs();
        const inicio = this.homeLink();
        return inicio !== null && itens.length
            ? [{ label: 'Início', icon: 'home', routerLink: inicio }, ...itens]
            : itens;
    }, ...(ngDevMode ? [{ debugName: "trilha" }] : []));
    isCurrent(index) {
        return index === this.trilha().length - 1;
    }
    #trilhaDaRota() {
        this.#navegacao();
        if (!this.#router) {
            return [];
        }
        // A rota mais funda da navegacao principal: e dela que sai `pathFromRoot`.
        let rota = this.#router.routerState.root;
        while (rota.firstChild) {
            rota = rota.firstChild;
        }
        return breadcrumbFromRoute(rota);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SPageHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SPageHeaderComponent, isStandalone: true, selector: "s-page-header", inputs: { breadcrumbs: { classPropertyName: "breadcrumbs", publicName: "breadcrumbs", isSignal: true, isRequired: false, transformFunction: null }, breadcrumbsFromRoute: { classPropertyName: "breadcrumbsFromRoute", publicName: "breadcrumbsFromRoute", isSignal: true, isRequired: false, transformFunction: null }, homeLink: { classPropertyName: "homeLink", publicName: "homeLink", isSignal: true, isRequired: false, transformFunction: null }, status: { classPropertyName: "status", publicName: "status", isSignal: true, isRequired: false, transformFunction: null }, statusTone: { classPropertyName: "statusTone", publicName: "statusTone", isSignal: true, isRequired: false, transformFunction: null }, statusIcon: { classPropertyName: "statusIcon", publicName: "statusIcon", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, subtitleIcon: { classPropertyName: "subtitleIcon", publicName: "subtitleIcon", isSignal: true, isRequired: false, transformFunction: null }, showBack: { classPropertyName: "showBack", publicName: "showBack", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { back: "back" }, host: { classAttribute: "s-page-header" }, queries: [{ propertyName: "statusProjetado", first: true, predicate: SPageHeaderStatusDirective, descendants: true, isSignal: true }], ngImport: i0, template: "@if (trilha().length) {\n  <nav class=\"s-page-header__trilha\" aria-label=\"Trilha de navega\u00E7\u00E3o\">\n    @for (item of trilha(); track $index; let i = $index) {\n      @if (i > 0) {\n        <s-icon class=\"s-page-header__separador\" name=\"chevron_right\" size=\"xs\" />\n      }\n\n      @if (item.routerLink && !isCurrent(i)) {\n        <a\n          [routerLink]=\"item.routerLink\"\n          [attr.title]=\"item.label\"\n          [attr.aria-label]=\"item.icon ? item.label : null\"\n        >\n          @if (item.icon) {\n            <s-icon [name]=\"item.icon\" size=\"sm\" />\n          } @else {\n            {{ item.label }}\n          }\n        </a>\n      } @else if (item.href && !isCurrent(i)) {\n        <a [href]=\"item.href\">{{ item.label }}</a>\n      } @else {\n        <span\n          [class.s-page-header__atual]=\"isCurrent(i)\"\n          [attr.aria-current]=\"isCurrent(i) ? 'page' : null\"\n        >\n          {{ item.label }}\n        </span>\n      }\n    }\n  </nav>\n}\n\n<div class=\"s-page-header__linha\">\n  @if (showBack()) {\n    <s-icon-button\n      class=\"s-page-header__voltar\"\n      icon=\"arrow_back\"\n      label=\"Voltar\"\n      (click)=\"back.emit()\"\n    />\n  }\n\n  <div class=\"s-page-header__texto\">\n    @if (title()) {\n      <div class=\"s-page-header__title-row\">\n        <h1 class=\"s-page-header__titulo\">{{ title() }}</h1>\n\n        @if (status()) {\n          <span class=\"s-page-header__status\">\n            <s-badge [tone]=\"tomDoStatus()\" [icon]=\"statusIcon()\">{{ status() }}</s-badge>\n          </span>\n        } @else if (statusProjetado()) {\n          <span class=\"s-page-header__status\">\n            <ng-content select=\"[sPageHeaderStatus]\" />\n          </span>\n        }\n      </div>\n    }\n\n    @if (description()) {\n      <p class=\"s-page-header__descricao\">\n        @if (subtitleIcon()) {\n          <s-icon [name]=\"subtitleIcon()\" size=\"sm\" />\n        }\n        <span>{{ description() }}</span>\n      </p>\n    }\n  </div>\n\n  <!-- A acao primaria da tela, no singular. Duas competindo aqui equivalem a\n       nenhuma; a segunda desce para dentro do conteudo. -->\n  <div class=\"s-page-header__acao\"><ng-content select=\"[action]\" /></div>\n</div>\n", styles: [":host{display:flex;flex-direction:column;gap:var(--space-12, 12px);font-family:var(--font-ui);container:s-page-header/inline-size}@container s-page-header (max-width: 600px){.s-page-header__linha{flex-wrap:wrap}.s-page-header__acao{flex-basis:100%}.s-page-header__titulo{font-size:var(--text-h3, 24px)}}.s-page-header__trilha{display:flex;align-items:center;gap:var(--space-4, 4px);flex-wrap:wrap;font-size:var(--text-label, 14px);color:var(--text-secondary)}.s-page-header__trilha a{display:inline-flex;align-items:center;padding:var(--space-4, 4px) var(--space-8, 8px);border-radius:var(--radius-control, 8px);color:inherit;text-decoration:none;transition:background-color .2s,color .2s}.s-page-header__trilha a:hover{background-color:color-mix(in srgb,var(--text-primary) 6%,transparent);color:var(--primary)}.s-page-header__trilha a:focus-visible{outline:2px solid var(--primary);outline-offset:2px}.s-page-header__separador{display:inline-flex}.s-page-header__atual{padding:var(--space-4, 4px) var(--space-8, 8px);color:var(--text-primary);font-weight:var(--weight-medium, 500)}.s-page-header__linha{display:flex;align-items:flex-start;gap:var(--space-16, 16px)}.s-page-header__voltar{margin-top:-2px}.s-page-header__texto{flex:1;min-width:0;display:flex;flex-direction:column;gap:var(--space-8, 8px)}.s-page-header__title-row{display:flex;align-items:center;gap:var(--space-12, 12px);flex-wrap:wrap}.s-page-header__titulo{margin:0;font-family:var(--font-display);font-size:var(--text-h1, 36px);font-weight:var(--weight-semibold, 600);line-height:var(--leading-tight, 1.2);color:var(--text-primary)}.s-page-header__descricao{max-width:var(--page-header-description-max-width, 900px);margin:0;display:inline-flex;align-items:flex-start;gap:var(--space-8, 8px);font-size:var(--text-body, 14px);line-height:var(--leading-relaxed, 1.6);color:var(--text-secondary)}.s-page-header__acao{flex:0 0 auto}\n"], dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: SBadgeComponent, selector: "s-badge", inputs: ["tone", "wrap", "icon"] }, { kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }, { kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SPageHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-page-header', imports: [RouterLink, SBadgeComponent, SIconComponent, SIconButtonComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-page-header',
                    }, template: "@if (trilha().length) {\n  <nav class=\"s-page-header__trilha\" aria-label=\"Trilha de navega\u00E7\u00E3o\">\n    @for (item of trilha(); track $index; let i = $index) {\n      @if (i > 0) {\n        <s-icon class=\"s-page-header__separador\" name=\"chevron_right\" size=\"xs\" />\n      }\n\n      @if (item.routerLink && !isCurrent(i)) {\n        <a\n          [routerLink]=\"item.routerLink\"\n          [attr.title]=\"item.label\"\n          [attr.aria-label]=\"item.icon ? item.label : null\"\n        >\n          @if (item.icon) {\n            <s-icon [name]=\"item.icon\" size=\"sm\" />\n          } @else {\n            {{ item.label }}\n          }\n        </a>\n      } @else if (item.href && !isCurrent(i)) {\n        <a [href]=\"item.href\">{{ item.label }}</a>\n      } @else {\n        <span\n          [class.s-page-header__atual]=\"isCurrent(i)\"\n          [attr.aria-current]=\"isCurrent(i) ? 'page' : null\"\n        >\n          {{ item.label }}\n        </span>\n      }\n    }\n  </nav>\n}\n\n<div class=\"s-page-header__linha\">\n  @if (showBack()) {\n    <s-icon-button\n      class=\"s-page-header__voltar\"\n      icon=\"arrow_back\"\n      label=\"Voltar\"\n      (click)=\"back.emit()\"\n    />\n  }\n\n  <div class=\"s-page-header__texto\">\n    @if (title()) {\n      <div class=\"s-page-header__title-row\">\n        <h1 class=\"s-page-header__titulo\">{{ title() }}</h1>\n\n        @if (status()) {\n          <span class=\"s-page-header__status\">\n            <s-badge [tone]=\"tomDoStatus()\" [icon]=\"statusIcon()\">{{ status() }}</s-badge>\n          </span>\n        } @else if (statusProjetado()) {\n          <span class=\"s-page-header__status\">\n            <ng-content select=\"[sPageHeaderStatus]\" />\n          </span>\n        }\n      </div>\n    }\n\n    @if (description()) {\n      <p class=\"s-page-header__descricao\">\n        @if (subtitleIcon()) {\n          <s-icon [name]=\"subtitleIcon()\" size=\"sm\" />\n        }\n        <span>{{ description() }}</span>\n      </p>\n    }\n  </div>\n\n  <!-- A acao primaria da tela, no singular. Duas competindo aqui equivalem a\n       nenhuma; a segunda desce para dentro do conteudo. -->\n  <div class=\"s-page-header__acao\"><ng-content select=\"[action]\" /></div>\n</div>\n", styles: [":host{display:flex;flex-direction:column;gap:var(--space-12, 12px);font-family:var(--font-ui);container:s-page-header/inline-size}@container s-page-header (max-width: 600px){.s-page-header__linha{flex-wrap:wrap}.s-page-header__acao{flex-basis:100%}.s-page-header__titulo{font-size:var(--text-h3, 24px)}}.s-page-header__trilha{display:flex;align-items:center;gap:var(--space-4, 4px);flex-wrap:wrap;font-size:var(--text-label, 14px);color:var(--text-secondary)}.s-page-header__trilha a{display:inline-flex;align-items:center;padding:var(--space-4, 4px) var(--space-8, 8px);border-radius:var(--radius-control, 8px);color:inherit;text-decoration:none;transition:background-color .2s,color .2s}.s-page-header__trilha a:hover{background-color:color-mix(in srgb,var(--text-primary) 6%,transparent);color:var(--primary)}.s-page-header__trilha a:focus-visible{outline:2px solid var(--primary);outline-offset:2px}.s-page-header__separador{display:inline-flex}.s-page-header__atual{padding:var(--space-4, 4px) var(--space-8, 8px);color:var(--text-primary);font-weight:var(--weight-medium, 500)}.s-page-header__linha{display:flex;align-items:flex-start;gap:var(--space-16, 16px)}.s-page-header__voltar{margin-top:-2px}.s-page-header__texto{flex:1;min-width:0;display:flex;flex-direction:column;gap:var(--space-8, 8px)}.s-page-header__title-row{display:flex;align-items:center;gap:var(--space-12, 12px);flex-wrap:wrap}.s-page-header__titulo{margin:0;font-family:var(--font-display);font-size:var(--text-h1, 36px);font-weight:var(--weight-semibold, 600);line-height:var(--leading-tight, 1.2);color:var(--text-primary)}.s-page-header__descricao{max-width:var(--page-header-description-max-width, 900px);margin:0;display:inline-flex;align-items:flex-start;gap:var(--space-8, 8px);font-size:var(--text-body, 14px);line-height:var(--leading-relaxed, 1.6);color:var(--text-secondary)}.s-page-header__acao{flex:0 0 auto}\n"] }]
        }], propDecorators: { breadcrumbs: [{ type: i0.Input, args: [{ isSignal: true, alias: "breadcrumbs", required: false }] }], breadcrumbsFromRoute: [{ type: i0.Input, args: [{ isSignal: true, alias: "breadcrumbsFromRoute", required: false }] }], homeLink: [{ type: i0.Input, args: [{ isSignal: true, alias: "homeLink", required: false }] }], status: [{ type: i0.Input, args: [{ isSignal: true, alias: "status", required: false }] }], statusTone: [{ type: i0.Input, args: [{ isSignal: true, alias: "statusTone", required: false }] }], statusIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "statusIcon", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], subtitleIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "subtitleIcon", required: false }] }], showBack: [{ type: i0.Input, args: [{ isSignal: true, alias: "showBack", required: false }] }], back: [{ type: i0.Output, args: ["back"] }], statusProjetado: [{ type: i0.ContentChild, args: [i0.forwardRef(() => SPageHeaderStatusDirective), { isSignal: true }] }] } });

/**
 * Contexto de campo do seletor de ano letivo.
 *
 * Fora de um `<s-field>`, o `<s-select>` nao tem a quem apontar o
 * `aria-labelledby`. A barra faz o papel do campo para o seu proprio seletor,
 * e o texto "Ano letivo" vira o nome acessivel do combobox.
 */
class CampoAnoLetivo {
    id = proximoId('s-top-bar-ano');
    controlId = () => this.id;
    errorId = () => null;
    hasError = () => false;
    isRequired = () => false;
    labelId = () => `${this.id}-rotulo`;
}
/**
 * Barra superior de 64px: menu, marca, ano letivo, tema e perfil.
 *
 * ## Uma moldura, nao uma barra fechada
 *
 * O Professores e o Educacional tem barras parecidas, mas nao iguais: um tem
 * ano letivo, o outro busca global; nenhum tem notificacoes. Por isso cada
 * peca alem do menu, da marca, do tema e do perfil e opcional, e o espaco antes
 * do ano letivo recebe o que a aplicacao projetar — a lupa da busca global do
 * Educacional, por exemplo.
 *
 * ## Ela nao compete com o conteudo
 *
 * As acoes da direita sao **so-icone**, em 24px, cada uma com rotulo acessivel.
 * O seletor de ano letivo e o unico controle com texto, porque o ano vigente
 * muda o significado de tudo que a tela mostra.
 *
 * ## O que ela nao faz
 *
 * Menu de perfil e painel de notificacoes estao **fora de escopo no guia**. Os
 * botoes emitem o `MouseEvent` do clique, que e o que um menu em popup precisa
 * para se ancorar no botao (`menu.toggle(evento)` no PrimeNG).
 *
 * @example
 * ```html
 * <s-top-bar
 *   systemName="SIAGE"
 *   systemSubtitle="Professores"
 *   homeLink="/"
 *   [schoolYears]="anos()"
 *   [schoolYear]="ano()"
 *   [schoolYearLoading]="carregandoAnos()"
 *   (toggleMenu)="alternarMenu()"
 *   (schoolYearChange)="trocarAno($event)"
 *   (profileClick)="menuDoUsuario.toggle($event)"
 * >
 *   <img brand src="logo.png" alt="" />
 * </s-top-bar>
 * ```
 */
class STopBarComponent {
    /** Nome do sistema. String vazia esconde o texto — util quando o logotipo ja o traz. */
    systemName = input('SIAGE', ...(ngDevMode ? [{ debugName: "systemName" }] : []));
    /** Segunda linha da marca, menor: o modulo — "Professores", "Educacional". */
    systemSubtitle = input('', ...(ngDevMode ? [{ debugName: "systemSubtitle" }] : []));
    /**
     * Endereco do inicio. Informado, a marca vira link: com Router, navega sem
     * recarregar a pagina; sem ele, e um link comum.
     *
     * So caminho interno, comecando com `/` (nao `//`): o clique pode cair em
     * `location.assign`, que nao passa pelo sanitizador do Angular, entao um
     * `javascript:` ou endereco externo vindo de configuracao viraria execucao ou
     * redirecionamento. Fora disso a marca fica sem link.
     */
    homeLink = input('', ...(ngDevMode ? [{ debugName: "homeLink" }] : []));
    /** `homeLink` aceito: caminho interno, ou vazio. */
    inicio = computed(() => {
        const destino = this.homeLink();
        if (!destino || (destino.startsWith('/') && !/^\/[/\\]/.test(destino))) {
            return destino;
        }
        if (typeof ngDevMode !== 'undefined' && ngDevMode) {
            console.warn(`[STopBarComponent] homeLink "${destino}" ignorado: use um caminho interno que comece com "/".`);
        }
        return '';
    }, ...(ngDevMode ? [{ debugName: "inicio" }] : []));
    /** Exibe o botao que recolhe e expande o menu lateral. */
    showMenuButton = input(true, ...(ngDevMode ? [{ debugName: "showMenuButton", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Anos do seletor. Aceita texto (`'2026'`) ou `SOption` — o Professores usa
     * objetos `{ id, nome }`, que viram `{ label: nome, value: ... }`. Vazio
     * esconde o seletor.
     */
    schoolYears = input([], ...(ngDevMode ? [{ debugName: "schoolYears" }] : []));
    /** Ano letivo selecionado: o `value` da opcao, ou o texto. */
    schoolYear = input(null, ...(ngDevMode ? [{ debugName: "schoolYear" }] : []));
    /** Compara o ano selecionado com o de cada opcao. Ver `<s-select>`. */
    schoolYearCompareWith = input((a, b) => a === b, ...(ngDevMode ? [{ debugName: "schoolYearCompareWith" }] : []));
    /** Anos ainda chegando: o seletor fica desabilitado, com reticencias no lugar do ano. */
    schoolYearLoading = input(false, ...(ngDevMode ? [{ debugName: "schoolYearLoading", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Desabilita o seletor — em telas onde trocar o ano nao se aplica. */
    schoolYearDisabled = input(false, ...(ngDevMode ? [{ debugName: "schoolYearDisabled", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Exibe o sino. Nenhum dos sistemas atuais tem notificacoes, entao vem desligado. */
    showNotifications = input(false, ...(ngDevMode ? [{ debugName: "showNotifications", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Nao lidas no sino. `0` esconde o indicador. */
    notifications = input(0, ...(ngDevMode ? [{ debugName: "notifications", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /**
     * Tema que esta na tela, so para escolher o glifo do botao.
     *
     * A barra nao troca o tema sozinha: quem decide e a aplicacao, pelo
     * `toggleTheme` - ha sistemas com tema proprio, e a barra nao pode brigar com
     * ele. Com o tema da biblioteca, ligue os dois ao `SThemeService`, passando o
     * tema **resolvido** (com o sistema operacional ja considerado):
     *
     * ```html
     * <s-top-bar [theme]="tema.resolved()" (toggleTheme)="tema.toggle()" />
     * ```
     */
    theme = input('light', ...(ngDevMode ? [{ debugName: "theme" }] : []));
    /** Recolher ou expandir o menu lateral. */
    toggleMenu = output();
    /** Novo ano letivo: o `value` da opcao escolhida. */
    schoolYearChange = output();
    /** Alternar o tema. */
    toggleTheme = output();
    /** Sino de notificacoes, com o clique para ancorar o painel. */
    notificationsClick = output();
    /** Botao de perfil, com o clique para ancorar o menu do usuario. */
    profileClick = output();
    campoAno = inject(SFieldContext);
    // O Router e `providedIn: 'root'` e existe mesmo sem `provideRouter`; `ROUTES`
    // so existe quando a aplicacao configurou o roteamento.
    router = inject(ROUTES, { optional: true }) ? inject(Router) : null;
    /** Anos no formato de opcao do `<s-select>`. */
    opcoesAno = computed(() => this.schoolYears().map((ano) => typeof ano === 'string' ? { label: ano, value: ano } : ano), ...(ngDevMode ? [{ debugName: "opcoesAno" }] : []));
    /** Clique na marca: com rotas configuradas, navega dentro da aplicacao. */
    irParaInicio(evento) {
        // Ctrl/Cmd/clique do meio abrem em outra aba, como qualquer link.
        if (!this.router ||
            evento.ctrlKey ||
            evento.metaKey ||
            evento.shiftKey ||
            evento.button !== 0) {
            return;
        }
        evento.preventDefault();
        const destino = this.inicio();
        // Rota que nao existe na aplicacao: carrega a pagina, como o link faria.
        this.router.navigateByUrl(destino).catch(() => window.location.assign(destino));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: STopBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: STopBarComponent, isStandalone: true, selector: "s-top-bar", inputs: { systemName: { classPropertyName: "systemName", publicName: "systemName", isSignal: true, isRequired: false, transformFunction: null }, systemSubtitle: { classPropertyName: "systemSubtitle", publicName: "systemSubtitle", isSignal: true, isRequired: false, transformFunction: null }, homeLink: { classPropertyName: "homeLink", publicName: "homeLink", isSignal: true, isRequired: false, transformFunction: null }, showMenuButton: { classPropertyName: "showMenuButton", publicName: "showMenuButton", isSignal: true, isRequired: false, transformFunction: null }, schoolYears: { classPropertyName: "schoolYears", publicName: "schoolYears", isSignal: true, isRequired: false, transformFunction: null }, schoolYear: { classPropertyName: "schoolYear", publicName: "schoolYear", isSignal: true, isRequired: false, transformFunction: null }, schoolYearCompareWith: { classPropertyName: "schoolYearCompareWith", publicName: "schoolYearCompareWith", isSignal: true, isRequired: false, transformFunction: null }, schoolYearLoading: { classPropertyName: "schoolYearLoading", publicName: "schoolYearLoading", isSignal: true, isRequired: false, transformFunction: null }, schoolYearDisabled: { classPropertyName: "schoolYearDisabled", publicName: "schoolYearDisabled", isSignal: true, isRequired: false, transformFunction: null }, showNotifications: { classPropertyName: "showNotifications", publicName: "showNotifications", isSignal: true, isRequired: false, transformFunction: null }, notifications: { classPropertyName: "notifications", publicName: "notifications", isSignal: true, isRequired: false, transformFunction: null }, theme: { classPropertyName: "theme", publicName: "theme", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { toggleMenu: "toggleMenu", schoolYearChange: "schoolYearChange", toggleTheme: "toggleTheme", notificationsClick: "notificationsClick", profileClick: "profileClick" }, host: { attributes: { "role": "banner" }, classAttribute: "s-top-bar" }, ngImport: i0, template: "@if (showMenuButton()) {\n  <s-icon-button icon=\"menu\" label=\"Expandir ou recolher menu\" (click)=\"toggleMenu.emit()\" />\n}\n\n<ng-template #marca>\n  <ng-content select=\"[brand]\" />\n\n  @if (systemName() || systemSubtitle()) {\n    <span class=\"s-top-bar__nomes\">\n      @if (systemName()) {\n        <span class=\"s-top-bar__nome\">{{ systemName() }}</span>\n      }\n      @if (systemSubtitle()) {\n        <span class=\"s-top-bar__subtitulo\">{{ systemSubtitle() }}</span>\n      }\n    </span>\n  }\n</ng-template>\n\n@if (inicio()) {\n  <a\n    class=\"s-top-bar__marca s-top-bar__marca--link\"\n    [href]=\"inicio()\"\n    title=\"Ir para o in\u00EDcio\"\n    (click)=\"irParaInicio($event)\"\n  >\n    <ng-container [ngTemplateOutlet]=\"marca\" />\n  </a>\n} @else {\n  <div class=\"s-top-bar__marca\">\n    <ng-container [ngTemplateOutlet]=\"marca\" />\n  </div>\n}\n\n<!-- Espacador: empurra o grupo da direita, como no componente do guia. -->\n<div class=\"s-top-bar__espaco\"></div>\n\n<!-- Acoes proprias do sistema, antes do ano letivo: a busca global do\n     Educacional, por exemplo. -->\n<ng-content />\n\n@if (schoolYears().length || schoolYearLoading()) {\n  <div class=\"s-top-bar__ano\" [attr.aria-busy]=\"schoolYearLoading() || null\">\n    <span class=\"s-top-bar__ano-rotulo\" [id]=\"campoAno.labelId()\">Ano letivo</span>\n    <!-- Unico controle com texto na barra: o ano vigente muda o significado de\n         tudo que a tela mostra. E o mesmo <s-select> dos formularios, so mais\n         baixo; o rotulo se liga a ele pelo contexto de campo da barra. -->\n    <s-select\n      class=\"s-top-bar__select\"\n      [options]=\"opcoesAno()\"\n      [clearable]=\"false\"\n      [compareWith]=\"schoolYearCompareWith()\"\n      [disabled]=\"schoolYearLoading() || schoolYearDisabled()\"\n      [placeholder]=\"schoolYearLoading() ? '\u2026' : ''\"\n      [ngModel]=\"schoolYearLoading() ? null : schoolYear()\"\n      (ngModelChange)=\"schoolYearChange.emit($event)\"\n    />\n  </div>\n}\n\n<s-icon-button\n  [icon]=\"theme() === 'dark' ? 'dark_mode' : 'light_mode'\"\n  label=\"Alternar tema\"\n  (click)=\"toggleTheme.emit()\"\n/>\n\n@if (showNotifications()) {\n  <span class=\"s-top-bar__sino\">\n    <s-icon-button\n      icon=\"notifications\"\n      label=\"Notifica\u00E7\u00F5es\"\n      (click)=\"notificationsClick.emit($event)\"\n    />\n\n    @if (notifications() > 0) {\n      <span class=\"s-top-bar__contador\" [attr.aria-label]=\"notifications() + ' n\u00E3o lidas'\">\n        {{ notifications() }}\n      </span>\n    }\n  </span>\n}\n\n<s-icon-button icon=\"person\" label=\"Perfil\" (click)=\"profileClick.emit($event)\" />\n", styles: [":host{display:flex;align-items:center;gap:var(--space-8, 8px);height:var(--topbar-h, 64px);padding:0 var(--space-24, 24px);background:var(--card);border-bottom:1px solid var(--card-border);font-family:var(--font-ui);container:s-top-bar/inline-size}.s-top-bar__marca{display:flex;align-items:center;gap:var(--space-8, 8px);min-width:0;flex-shrink:0}.s-top-bar__marca--link{text-decoration:none;color:inherit;border-radius:var(--radius-control, 8px)}.s-top-bar__marca--link:focus-visible{outline:none;box-shadow:0 0 0 3px var(--focus-ring)}.s-top-bar__nomes{display:flex;flex-direction:column;min-width:0;line-height:1.15}.s-top-bar__nome{font-family:var(--font-display);font-size:var(--text-h6, 16px);font-weight:var(--weight-semibold, 600);color:var(--text-primary);white-space:nowrap}.s-top-bar__subtitulo{font-size:var(--text-caption, 12px);color:var(--text-secondary);white-space:nowrap}.s-top-bar__espaco{flex:1}.s-top-bar__ano{display:inline-flex;align-items:center;gap:var(--space-8, 8px);font-size:var(--text-caption, 12px);color:var(--text-secondary);white-space:nowrap}.s-top-bar__select{--field-h: 36px;width:112px}.s-top-bar__sino{position:relative;display:inline-flex}.s-top-bar__contador{position:absolute;top:0;right:0;display:inline-flex;align-items:center;justify-content:center;min-width:18px;height:18px;padding:0 5px;border-radius:var(--radius-full, 9999px);background:var(--destructive);color:var(--on-filled);font-size:11px;font-weight:var(--weight-medium, 500);pointer-events:none}@container s-top-bar (max-width: 480px){.s-top-bar__nomes{display:none}.s-top-bar__ano-rotulo{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}}@media(max-width:480px){:host{gap:var(--space-4, 4px);padding:0 var(--space-8, 8px)}}@container s-top-bar (max-width: 480px){.s-top-bar__ano{flex:none}.s-top-bar__select{width:88px}.s-top-bar__select ::ng-deep .mat-mdc-select-trigger{padding:0 var(--space-8, 8px)}}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$5.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$5.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }, { kind: "component", type: SSelectComponent, selector: "s-select", inputs: ["options", "compareWith", "clearable", "filterable", "filterPlaceholder", "noResultsText", "emptyText"] }], viewProviders: [{ provide: SFieldContext, useClass: CampoAnoLetivo }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: STopBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-top-bar', imports: [FormsModule, NgTemplateOutlet, SIconButtonComponent, SSelectComponent], changeDetection: ChangeDetectionStrategy.OnPush, viewProviders: [{ provide: SFieldContext, useClass: CampoAnoLetivo }], host: {
                        class: 's-top-bar',
                        role: 'banner',
                    }, template: "@if (showMenuButton()) {\n  <s-icon-button icon=\"menu\" label=\"Expandir ou recolher menu\" (click)=\"toggleMenu.emit()\" />\n}\n\n<ng-template #marca>\n  <ng-content select=\"[brand]\" />\n\n  @if (systemName() || systemSubtitle()) {\n    <span class=\"s-top-bar__nomes\">\n      @if (systemName()) {\n        <span class=\"s-top-bar__nome\">{{ systemName() }}</span>\n      }\n      @if (systemSubtitle()) {\n        <span class=\"s-top-bar__subtitulo\">{{ systemSubtitle() }}</span>\n      }\n    </span>\n  }\n</ng-template>\n\n@if (inicio()) {\n  <a\n    class=\"s-top-bar__marca s-top-bar__marca--link\"\n    [href]=\"inicio()\"\n    title=\"Ir para o in\u00EDcio\"\n    (click)=\"irParaInicio($event)\"\n  >\n    <ng-container [ngTemplateOutlet]=\"marca\" />\n  </a>\n} @else {\n  <div class=\"s-top-bar__marca\">\n    <ng-container [ngTemplateOutlet]=\"marca\" />\n  </div>\n}\n\n<!-- Espacador: empurra o grupo da direita, como no componente do guia. -->\n<div class=\"s-top-bar__espaco\"></div>\n\n<!-- Acoes proprias do sistema, antes do ano letivo: a busca global do\n     Educacional, por exemplo. -->\n<ng-content />\n\n@if (schoolYears().length || schoolYearLoading()) {\n  <div class=\"s-top-bar__ano\" [attr.aria-busy]=\"schoolYearLoading() || null\">\n    <span class=\"s-top-bar__ano-rotulo\" [id]=\"campoAno.labelId()\">Ano letivo</span>\n    <!-- Unico controle com texto na barra: o ano vigente muda o significado de\n         tudo que a tela mostra. E o mesmo <s-select> dos formularios, so mais\n         baixo; o rotulo se liga a ele pelo contexto de campo da barra. -->\n    <s-select\n      class=\"s-top-bar__select\"\n      [options]=\"opcoesAno()\"\n      [clearable]=\"false\"\n      [compareWith]=\"schoolYearCompareWith()\"\n      [disabled]=\"schoolYearLoading() || schoolYearDisabled()\"\n      [placeholder]=\"schoolYearLoading() ? '\u2026' : ''\"\n      [ngModel]=\"schoolYearLoading() ? null : schoolYear()\"\n      (ngModelChange)=\"schoolYearChange.emit($event)\"\n    />\n  </div>\n}\n\n<s-icon-button\n  [icon]=\"theme() === 'dark' ? 'dark_mode' : 'light_mode'\"\n  label=\"Alternar tema\"\n  (click)=\"toggleTheme.emit()\"\n/>\n\n@if (showNotifications()) {\n  <span class=\"s-top-bar__sino\">\n    <s-icon-button\n      icon=\"notifications\"\n      label=\"Notifica\u00E7\u00F5es\"\n      (click)=\"notificationsClick.emit($event)\"\n    />\n\n    @if (notifications() > 0) {\n      <span class=\"s-top-bar__contador\" [attr.aria-label]=\"notifications() + ' n\u00E3o lidas'\">\n        {{ notifications() }}\n      </span>\n    }\n  </span>\n}\n\n<s-icon-button icon=\"person\" label=\"Perfil\" (click)=\"profileClick.emit($event)\" />\n", styles: [":host{display:flex;align-items:center;gap:var(--space-8, 8px);height:var(--topbar-h, 64px);padding:0 var(--space-24, 24px);background:var(--card);border-bottom:1px solid var(--card-border);font-family:var(--font-ui);container:s-top-bar/inline-size}.s-top-bar__marca{display:flex;align-items:center;gap:var(--space-8, 8px);min-width:0;flex-shrink:0}.s-top-bar__marca--link{text-decoration:none;color:inherit;border-radius:var(--radius-control, 8px)}.s-top-bar__marca--link:focus-visible{outline:none;box-shadow:0 0 0 3px var(--focus-ring)}.s-top-bar__nomes{display:flex;flex-direction:column;min-width:0;line-height:1.15}.s-top-bar__nome{font-family:var(--font-display);font-size:var(--text-h6, 16px);font-weight:var(--weight-semibold, 600);color:var(--text-primary);white-space:nowrap}.s-top-bar__subtitulo{font-size:var(--text-caption, 12px);color:var(--text-secondary);white-space:nowrap}.s-top-bar__espaco{flex:1}.s-top-bar__ano{display:inline-flex;align-items:center;gap:var(--space-8, 8px);font-size:var(--text-caption, 12px);color:var(--text-secondary);white-space:nowrap}.s-top-bar__select{--field-h: 36px;width:112px}.s-top-bar__sino{position:relative;display:inline-flex}.s-top-bar__contador{position:absolute;top:0;right:0;display:inline-flex;align-items:center;justify-content:center;min-width:18px;height:18px;padding:0 5px;border-radius:var(--radius-full, 9999px);background:var(--destructive);color:var(--on-filled);font-size:11px;font-weight:var(--weight-medium, 500);pointer-events:none}@container s-top-bar (max-width: 480px){.s-top-bar__nomes{display:none}.s-top-bar__ano-rotulo{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}}@media(max-width:480px){:host{gap:var(--space-4, 4px);padding:0 var(--space-8, 8px)}}@container s-top-bar (max-width: 480px){.s-top-bar__ano{flex:none}.s-top-bar__select{width:88px}.s-top-bar__select ::ng-deep .mat-mdc-select-trigger{padding:0 var(--space-8, 8px)}}\n"] }]
        }], propDecorators: { systemName: [{ type: i0.Input, args: [{ isSignal: true, alias: "systemName", required: false }] }], systemSubtitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "systemSubtitle", required: false }] }], homeLink: [{ type: i0.Input, args: [{ isSignal: true, alias: "homeLink", required: false }] }], showMenuButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "showMenuButton", required: false }] }], schoolYears: [{ type: i0.Input, args: [{ isSignal: true, alias: "schoolYears", required: false }] }], schoolYear: [{ type: i0.Input, args: [{ isSignal: true, alias: "schoolYear", required: false }] }], schoolYearCompareWith: [{ type: i0.Input, args: [{ isSignal: true, alias: "schoolYearCompareWith", required: false }] }], schoolYearLoading: [{ type: i0.Input, args: [{ isSignal: true, alias: "schoolYearLoading", required: false }] }], schoolYearDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "schoolYearDisabled", required: false }] }], showNotifications: [{ type: i0.Input, args: [{ isSignal: true, alias: "showNotifications", required: false }] }], notifications: [{ type: i0.Input, args: [{ isSignal: true, alias: "notifications", required: false }] }], theme: [{ type: i0.Input, args: [{ isSignal: true, alias: "theme", required: false }] }], toggleMenu: [{ type: i0.Output, args: ["toggleMenu"] }], schoolYearChange: [{ type: i0.Output, args: ["schoolYearChange"] }], toggleTheme: [{ type: i0.Output, args: ["toggleTheme"] }], notificationsClick: [{ type: i0.Output, args: ["notificationsClick"] }], profileClick: [{ type: i0.Output, args: ["profileClick"] }] } });

/**
 * Menu lateral da web: 256px expandido, 72px recolhido.
 *
 * ## O gradiente aparece aqui, e so aqui
 *
 * O item ativo usa `--gradient-primary` com rotulo branco. Na web esse
 * gradiente **nao existe em nenhum outro lugar** — e o que faz "onde estou" ser
 * reconhecido de relance, sem ler. Usa-lo num card ou num botao gasta essa
 * distincao.
 *
 * O glifo do item ativo tambem ganha o eixo `FILL`, entao a marcacao nao depende
 * so de cor.
 *
 * ## Recolhido
 *
 * A 72px sobra o icone. O rotulo vira tooltip — sem ele, um menu recolhido e um
 * teste de memoria.
 */
class SSidebarComponent {
    el = inject(ElementRef);
    destroyRef = inject(DestroyRef);
    documento = inject(DOCUMENT);
    instanceId = proximoId('s-sidebar');
    focusBeforeOverlay = null;
    wasOverlayOpen = false;
    /** Destinos do menu, na ordem. */
    items = input([], ...(ngDevMode ? [{ debugName: "items" }] : []));
    /** Id do item ativo. */
    activeId = input('', ...(ngDevMode ? [{ debugName: "activeId" }] : []));
    /**
     * Recolhe para 72px, deixando so os icones.
     *
     * Suporta two-way binding: `[(collapsed)]="sinal"`. Tambem aceita binding
     * unidirecional `[collapsed]="valor"` — retrocompativel com o uso anterior.
     */
    collapsed = model(false, ...(ngDevMode ? [{ debugName: "collapsed" }] : []));
    /**
     * Mostra o botao de recolher/expandir no topo da sidebar.
     *
     * Desligue quando o cabecalho da aplicacao ja tem o proprio botao de menu
     * (o hamburguer do topo), para nao haver dois controles fazendo a mesma
     * coisa. O colapso continua pelo `[(collapsed)]`.
     */
    showToggle = input(true, ...(ngDevMode ? [{ debugName: "showToggle", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Rotulo acessivel do menu, quando a tela tem mais de uma navegacao. */
    label = input('Menu principal', ...(ngDevMode ? [{ debugName: "label" }] : []));
    /**
     * Largura maxima, em px, para tratar a sidebar como sobreposicao.
     *
     * O padrao preserva o contrato anterior da lib. Sistemas que mantem a
     * navegacao lateral ate tablet largo, como o Professor, podem alinhar o
     * corte sem duplicar CSS.
     */
    breakpoint = input(900, ...(ngDevMode ? [{ debugName: "breakpoint", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Item escolhido. A aplicacao decide o que fazer — normalmente, navegar. */
    select = output();
    isNarrowViewport = signal(false, ...(ngDevMode ? [{ debugName: "isNarrowViewport" }] : []));
    groups = computed(() => this.normalizeGroups(this.items()), ...(ngDevMode ? [{ debugName: "groups" }] : []));
    isOverlayOpen = computed(() => this.isNarrowViewport() && !this.collapsed(), ...(ngDevMode ? [{ debugName: "isOverlayOpen" }] : []));
    /** Alterna o estado de colapso. */
    alternarColapso() {
        this.collapsed.update((v) => !v);
    }
    constructor() {
        effect((onCleanup) => {
            const windowRef = this.documento.defaultView;
            if (!windowRef) {
                return;
            }
            const media = windowRef.matchMedia(`(max-width: ${this.breakpoint()}px)`);
            const update = () => this.isNarrowViewport.set(media.matches);
            update();
            media.addEventListener('change', update);
            onCleanup(() => media.removeEventListener('change', update));
        });
        effect(() => this.syncOverlay());
        // So no navegador: no servidor nao ha clique.
        afterNextRender(() => this.fecharAoClicarFora());
    }
    /**
     * No mobile, clicar fora do menu aberto o fecha.
     *
     * A decisao fica para depois que o clique termina de ser tratado. O caso que
     * isso resolve e o botao de menu da top-bar, que fica fora da sidebar: ao
     * fechar por ele, decidir na hora fechava o menu e, em seguida, o
     * `(toggleMenu)` da tela o invertia de novo - o menu nunca fechava. Esperando,
     * o botao age primeiro, e so resta fechar se ninguem mais o fez.
     */
    fecharAoClicarFora() {
        const janela = this.documento.defaultView;
        if (!janela) {
            return;
        }
        const handler = (event) => {
            if (!this.isNarrowViewport())
                return;
            if (this.collapsed())
                return;
            if (this.el.nativeElement.contains(event.target))
                return;
            janela.setTimeout(() => {
                if (!this.collapsed()) {
                    this.collapsed.set(true);
                }
            });
        };
        this.documento.addEventListener('click', handler, true);
        this.destroyRef.onDestroy(() => this.documento.removeEventListener('click', handler, true));
    }
    closeOverlay(event) {
        if (!this.isOverlayOpen()) {
            return;
        }
        event?.preventDefault();
        event?.stopPropagation();
        this.collapsed.set(true);
    }
    ehAtivo(item, routeActive = false) {
        return routeActive || item.id === this.activeId();
    }
    hasRoute(item) {
        return this.itemRoute(item) !== null;
    }
    itemRoute(item) {
        return item.routerLink ?? item.route ?? null;
    }
    badgeText(item) {
        const badge = item.badge;
        return badge === undefined || badge === null ? '' : String(badge);
    }
    normalizeGroups(entries) {
        const groups = [];
        entries.forEach((entry) => {
            if (this.isGroup(entry)) {
                groups.push(this.createGroup(entry.label, entry.items, groups.length));
                return;
            }
            const label = entry.group ?? '';
            const existingGroup = groups.find((group) => group.label === label);
            if (existingGroup) {
                const index = groups.indexOf(existingGroup);
                groups[index] = { ...existingGroup, items: [...existingGroup.items, entry] };
                return;
            }
            groups.push(this.createGroup(label, [entry], groups.length));
        });
        return groups;
    }
    createGroup(label, items, index) {
        return {
            id: `${this.instanceId}-group-${index}`,
            label,
            items,
        };
    }
    isGroup(entry) {
        return 'items' in entry;
    }
    syncOverlay() {
        const open = this.isOverlayOpen();
        if (open && !this.wasOverlayOpen) {
            this.focusBeforeOverlay = this.activeElement();
        }
        if (!open && this.wasOverlayOpen) {
            this.focusBeforeOverlay?.focus();
            this.focusBeforeOverlay = null;
        }
        this.wasOverlayOpen = open;
    }
    activeElement() {
        const active = this.documento.activeElement;
        return active instanceof HTMLElement ? active : null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SSidebarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SSidebarComponent, isStandalone: true, selector: "s-sidebar", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, activeId: { classPropertyName: "activeId", publicName: "activeId", isSignal: true, isRequired: false, transformFunction: null }, collapsed: { classPropertyName: "collapsed", publicName: "collapsed", isSignal: true, isRequired: false, transformFunction: null }, showToggle: { classPropertyName: "showToggle", publicName: "showToggle", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, breakpoint: { classPropertyName: "breakpoint", publicName: "breakpoint", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { collapsed: "collapsedChange", select: "select" }, host: { listeners: { "keydown.escape": "closeOverlay($event)" }, properties: { "class.s-sidebar--recolhido": "collapsed()", "class.s-sidebar--narrow": "isNarrowViewport()", "class.s-sidebar--overlay": "isOverlayOpen()", "attr.aria-modal": "isOverlayOpen() ? \"true\" : null", "attr.role": "isOverlayOpen() ? \"dialog\" : null", "attr.aria-label": "isOverlayOpen() ? label() : null" }, classAttribute: "s-sidebar" }, ngImport: i0, template: "@if (isOverlayOpen()) {\n  <div class=\"s-sidebar__backdrop\" aria-hidden=\"true\" (click)=\"closeOverlay($event)\"></div>\n}\n\n@if (showToggle()) {\n  <s-icon-button\n    class=\"s-sidebar__toggle\"\n    [icon]=\"collapsed() ? 'menu' : 'chevron_left'\"\n    [label]=\"collapsed() ? 'Expandir menu' : 'Recolher menu'\"\n    (click)=\"alternarColapso()\"\n  />\n}\n\n<nav\n  class=\"s-sidebar__lista\"\n  [attr.aria-label]=\"label()\"\n  [cdkTrapFocus]=\"isOverlayOpen()\"\n  [cdkTrapFocusAutoCapture]=\"isOverlayOpen()\"\n>\n  @for (group of groups(); track group.id) {\n    <div\n      class=\"s-sidebar__group\"\n      role=\"group\"\n      [attr.aria-label]=\"group.label && collapsed() ? group.label : null\"\n      [attr.aria-labelledby]=\"group.label && !collapsed() ? group.id : null\"\n    >\n      @if (group.label && !collapsed()) {\n        <h3 class=\"s-sidebar__group-title\" [id]=\"group.id\">{{ group.label }}</h3>\n      }\n\n      @for (item of group.items; track item.id) {\n        @if (hasRoute(item)) {\n          <a\n            class=\"s-sidebar__item\"\n            routerLinkActive=\"s-sidebar__item--ativo\"\n            #activeRoute=\"routerLinkActive\"\n            [routerLink]=\"itemRoute(item)\"\n            [class.s-sidebar__item--ativo]=\"ehAtivo(item, activeRoute.isActive)\"\n            [attr.aria-current]=\"ehAtivo(item, activeRoute.isActive) ? 'page' : null\"\n            [attr.aria-label]=\"collapsed() ? item.label : null\"\n            [sTooltip]=\"collapsed() ? item.label : ''\"\n            sTooltipPosition=\"right\"\n            (click)=\"select.emit(item.id)\"\n          >\n            <!-- FILL no ativo: a marcacao nao depende so de cor. -->\n            <s-icon\n              [name]=\"item.icon\"\n              size=\"md\"\n              [iconFilled]=\"ehAtivo(item, activeRoute.isActive)\"\n            />\n\n            @if (!collapsed()) {\n              <span class=\"s-sidebar__rotulo\">{{ item.label }}</span>\n            }\n\n            @if (badgeText(item)) {\n              <s-badge\n                class=\"s-sidebar__badge\"\n                [tone]=\"item.badgeTone ?? 'info'\"\n                [attr.aria-label]=\"badgeText(item) + ' em ' + item.label\"\n              >\n                {{ badgeText(item) }}\n              </s-badge>\n            }\n          </a>\n        } @else {\n          <button\n            type=\"button\"\n            class=\"s-sidebar__item\"\n            [class.s-sidebar__item--ativo]=\"ehAtivo(item)\"\n            [attr.aria-current]=\"ehAtivo(item) ? 'page' : null\"\n            [attr.aria-label]=\"collapsed() ? item.label : null\"\n            [sTooltip]=\"collapsed() ? item.label : ''\"\n            sTooltipPosition=\"right\"\n            (click)=\"select.emit(item.id)\"\n          >\n            <!-- FILL no ativo: a marcacao nao depende so de cor. -->\n            <s-icon [name]=\"item.icon\" size=\"md\" [iconFilled]=\"ehAtivo(item)\" />\n\n            @if (!collapsed()) {\n              <span class=\"s-sidebar__rotulo\">{{ item.label }}</span>\n            }\n\n            @if (badgeText(item)) {\n              <s-badge\n                class=\"s-sidebar__badge\"\n                [tone]=\"item.badgeTone ?? 'info'\"\n                [attr.aria-label]=\"badgeText(item) + ' em ' + item.label\"\n              >\n                {{ badgeText(item) }}\n              </s-badge>\n            }\n          </button>\n        }\n      }\n    </div>\n  }\n</nav>\n\n<div class=\"s-sidebar__rodape\"><ng-content select=\"[footer]\" /></div>\n", styles: [":host{display:flex;flex-direction:column;width:var(--sidebar-w, 256px);height:100%;padding:var(--space-12, 12px) var(--space-8, 8px);background:var(--card);border-right:1px solid var(--card-border);font-family:var(--font-ui);transition:width .15s ease}:host(.s-sidebar--recolhido){width:var(--sidebar-w-collapsed, 72px)}.s-sidebar__toggle{align-self:flex-end;margin-bottom:var(--space-8, 8px);position:relative;z-index:1}:host(.s-sidebar--recolhido) .s-sidebar__toggle{align-self:center}.s-sidebar__lista{display:flex;flex-direction:column;gap:var(--space-4, 4px);flex:1;min-height:0;overflow-y:auto;position:relative;z-index:1}.s-sidebar__item{display:flex;align-items:center;gap:var(--space-12, 12px);height:44px;padding:0 var(--space-12, 12px);border:none;border-radius:var(--radius-control, 8px);background:transparent;font-family:inherit;font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);color:var(--text-primary);text-align:left;cursor:pointer;transition:background-color .15s ease,color .15s ease;position:relative;text-decoration:none}.s-sidebar__item s-icon{color:var(--text-secondary);flex:0 0 auto}.s-sidebar__item:hover{background:color-mix(in srgb,var(--text-primary) 6%,transparent)}.s-sidebar__item:focus-visible{outline:none;box-shadow:0 0 0 2px var(--card),0 0 0 5px var(--focus-ring)}.s-sidebar__item--ativo,.s-sidebar__item--ativo:hover{background:var(--gradient-primary);color:var(--on-gradient)}.s-sidebar__item--ativo s-icon,.s-sidebar__item--ativo:hover s-icon{color:var(--on-gradient)}:host(.s-sidebar--recolhido) .s-sidebar__item{justify-content:center;padding:0}.s-sidebar__group{display:flex;flex-direction:column;gap:var(--space-4, 4px)}.s-sidebar__group+.s-sidebar__group{margin-top:var(--space-12, 12px)}.s-sidebar__group-title{margin:0;padding:0 var(--space-12, 12px);color:var(--text-secondary);font-family:inherit;font-size:var(--text-badge, 12px);font-weight:var(--weight-semibold, 600);line-height:var(--leading-tight, 1.2);text-transform:uppercase}.s-sidebar__rotulo{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.s-sidebar__badge{flex:0 0 auto;margin-left:auto}:host(.s-sidebar--recolhido) .s-sidebar__badge{position:absolute;inset-block-start:var(--space-4, 4px);inset-inline-end:var(--space-4, 4px);max-width:calc(var(--sidebar-w-collapsed, 72px) / 2);overflow:hidden;padding:0 var(--space-4, 4px)}.s-sidebar__rodape:not(:empty){padding-top:var(--space-12, 12px);margin-top:var(--space-12, 12px);border-top:1px solid var(--card-border);position:relative;z-index:1}:host(.s-sidebar--narrow){position:fixed;inset-block:0;inset-inline-start:0;z-index:var(--z-sidebar, 1000);box-shadow:var(--elevation-3);transform:translate(0);transition:width .15s ease,transform .15s ease}:host(.s-sidebar--narrow.s-sidebar--recolhido){transform:translate(-100%)}:host(.s-sidebar--overlay){width:var(--sidebar-w, 256px)}.s-sidebar__backdrop{position:fixed;inset:0;z-index:0;background:color-mix(in srgb,var(--text-primary) 32%,transparent)}@media(prefers-reduced-motion:reduce){:host{transition:none}}\n"], dependencies: [{ kind: "directive", type: CdkTrapFocus, selector: "[cdkTrapFocus]", inputs: ["cdkTrapFocus", "cdkTrapFocusAutoCapture"], exportAs: ["cdkTrapFocus"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "component", type: SBadgeComponent, selector: "s-badge", inputs: ["tone", "wrap", "icon"] }, { kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }, { kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }, { kind: "directive", type: STooltipDirective, selector: "[sTooltip]", inputs: ["sTooltip", "sTooltipPosition", "sTooltipDisabled", "sTooltipDelay"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SSidebarComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-sidebar', imports: [
                        CdkTrapFocus,
                        RouterLink,
                        RouterLinkActive,
                        SBadgeComponent,
                        SIconComponent,
                        SIconButtonComponent,
                        STooltipDirective,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-sidebar',
                        '[class.s-sidebar--recolhido]': 'collapsed()',
                        '[class.s-sidebar--narrow]': 'isNarrowViewport()',
                        '[class.s-sidebar--overlay]': 'isOverlayOpen()',
                        '[attr.aria-modal]': 'isOverlayOpen() ? "true" : null',
                        '[attr.role]': 'isOverlayOpen() ? "dialog" : null',
                        '[attr.aria-label]': 'isOverlayOpen() ? label() : null',
                        '(keydown.escape)': 'closeOverlay($event)',
                    }, template: "@if (isOverlayOpen()) {\n  <div class=\"s-sidebar__backdrop\" aria-hidden=\"true\" (click)=\"closeOverlay($event)\"></div>\n}\n\n@if (showToggle()) {\n  <s-icon-button\n    class=\"s-sidebar__toggle\"\n    [icon]=\"collapsed() ? 'menu' : 'chevron_left'\"\n    [label]=\"collapsed() ? 'Expandir menu' : 'Recolher menu'\"\n    (click)=\"alternarColapso()\"\n  />\n}\n\n<nav\n  class=\"s-sidebar__lista\"\n  [attr.aria-label]=\"label()\"\n  [cdkTrapFocus]=\"isOverlayOpen()\"\n  [cdkTrapFocusAutoCapture]=\"isOverlayOpen()\"\n>\n  @for (group of groups(); track group.id) {\n    <div\n      class=\"s-sidebar__group\"\n      role=\"group\"\n      [attr.aria-label]=\"group.label && collapsed() ? group.label : null\"\n      [attr.aria-labelledby]=\"group.label && !collapsed() ? group.id : null\"\n    >\n      @if (group.label && !collapsed()) {\n        <h3 class=\"s-sidebar__group-title\" [id]=\"group.id\">{{ group.label }}</h3>\n      }\n\n      @for (item of group.items; track item.id) {\n        @if (hasRoute(item)) {\n          <a\n            class=\"s-sidebar__item\"\n            routerLinkActive=\"s-sidebar__item--ativo\"\n            #activeRoute=\"routerLinkActive\"\n            [routerLink]=\"itemRoute(item)\"\n            [class.s-sidebar__item--ativo]=\"ehAtivo(item, activeRoute.isActive)\"\n            [attr.aria-current]=\"ehAtivo(item, activeRoute.isActive) ? 'page' : null\"\n            [attr.aria-label]=\"collapsed() ? item.label : null\"\n            [sTooltip]=\"collapsed() ? item.label : ''\"\n            sTooltipPosition=\"right\"\n            (click)=\"select.emit(item.id)\"\n          >\n            <!-- FILL no ativo: a marcacao nao depende so de cor. -->\n            <s-icon\n              [name]=\"item.icon\"\n              size=\"md\"\n              [iconFilled]=\"ehAtivo(item, activeRoute.isActive)\"\n            />\n\n            @if (!collapsed()) {\n              <span class=\"s-sidebar__rotulo\">{{ item.label }}</span>\n            }\n\n            @if (badgeText(item)) {\n              <s-badge\n                class=\"s-sidebar__badge\"\n                [tone]=\"item.badgeTone ?? 'info'\"\n                [attr.aria-label]=\"badgeText(item) + ' em ' + item.label\"\n              >\n                {{ badgeText(item) }}\n              </s-badge>\n            }\n          </a>\n        } @else {\n          <button\n            type=\"button\"\n            class=\"s-sidebar__item\"\n            [class.s-sidebar__item--ativo]=\"ehAtivo(item)\"\n            [attr.aria-current]=\"ehAtivo(item) ? 'page' : null\"\n            [attr.aria-label]=\"collapsed() ? item.label : null\"\n            [sTooltip]=\"collapsed() ? item.label : ''\"\n            sTooltipPosition=\"right\"\n            (click)=\"select.emit(item.id)\"\n          >\n            <!-- FILL no ativo: a marcacao nao depende so de cor. -->\n            <s-icon [name]=\"item.icon\" size=\"md\" [iconFilled]=\"ehAtivo(item)\" />\n\n            @if (!collapsed()) {\n              <span class=\"s-sidebar__rotulo\">{{ item.label }}</span>\n            }\n\n            @if (badgeText(item)) {\n              <s-badge\n                class=\"s-sidebar__badge\"\n                [tone]=\"item.badgeTone ?? 'info'\"\n                [attr.aria-label]=\"badgeText(item) + ' em ' + item.label\"\n              >\n                {{ badgeText(item) }}\n              </s-badge>\n            }\n          </button>\n        }\n      }\n    </div>\n  }\n</nav>\n\n<div class=\"s-sidebar__rodape\"><ng-content select=\"[footer]\" /></div>\n", styles: [":host{display:flex;flex-direction:column;width:var(--sidebar-w, 256px);height:100%;padding:var(--space-12, 12px) var(--space-8, 8px);background:var(--card);border-right:1px solid var(--card-border);font-family:var(--font-ui);transition:width .15s ease}:host(.s-sidebar--recolhido){width:var(--sidebar-w-collapsed, 72px)}.s-sidebar__toggle{align-self:flex-end;margin-bottom:var(--space-8, 8px);position:relative;z-index:1}:host(.s-sidebar--recolhido) .s-sidebar__toggle{align-self:center}.s-sidebar__lista{display:flex;flex-direction:column;gap:var(--space-4, 4px);flex:1;min-height:0;overflow-y:auto;position:relative;z-index:1}.s-sidebar__item{display:flex;align-items:center;gap:var(--space-12, 12px);height:44px;padding:0 var(--space-12, 12px);border:none;border-radius:var(--radius-control, 8px);background:transparent;font-family:inherit;font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);color:var(--text-primary);text-align:left;cursor:pointer;transition:background-color .15s ease,color .15s ease;position:relative;text-decoration:none}.s-sidebar__item s-icon{color:var(--text-secondary);flex:0 0 auto}.s-sidebar__item:hover{background:color-mix(in srgb,var(--text-primary) 6%,transparent)}.s-sidebar__item:focus-visible{outline:none;box-shadow:0 0 0 2px var(--card),0 0 0 5px var(--focus-ring)}.s-sidebar__item--ativo,.s-sidebar__item--ativo:hover{background:var(--gradient-primary);color:var(--on-gradient)}.s-sidebar__item--ativo s-icon,.s-sidebar__item--ativo:hover s-icon{color:var(--on-gradient)}:host(.s-sidebar--recolhido) .s-sidebar__item{justify-content:center;padding:0}.s-sidebar__group{display:flex;flex-direction:column;gap:var(--space-4, 4px)}.s-sidebar__group+.s-sidebar__group{margin-top:var(--space-12, 12px)}.s-sidebar__group-title{margin:0;padding:0 var(--space-12, 12px);color:var(--text-secondary);font-family:inherit;font-size:var(--text-badge, 12px);font-weight:var(--weight-semibold, 600);line-height:var(--leading-tight, 1.2);text-transform:uppercase}.s-sidebar__rotulo{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.s-sidebar__badge{flex:0 0 auto;margin-left:auto}:host(.s-sidebar--recolhido) .s-sidebar__badge{position:absolute;inset-block-start:var(--space-4, 4px);inset-inline-end:var(--space-4, 4px);max-width:calc(var(--sidebar-w-collapsed, 72px) / 2);overflow:hidden;padding:0 var(--space-4, 4px)}.s-sidebar__rodape:not(:empty){padding-top:var(--space-12, 12px);margin-top:var(--space-12, 12px);border-top:1px solid var(--card-border);position:relative;z-index:1}:host(.s-sidebar--narrow){position:fixed;inset-block:0;inset-inline-start:0;z-index:var(--z-sidebar, 1000);box-shadow:var(--elevation-3);transform:translate(0);transition:width .15s ease,transform .15s ease}:host(.s-sidebar--narrow.s-sidebar--recolhido){transform:translate(-100%)}:host(.s-sidebar--overlay){width:var(--sidebar-w, 256px)}.s-sidebar__backdrop{position:fixed;inset:0;z-index:0;background:color-mix(in srgb,var(--text-primary) 32%,transparent)}@media(prefers-reduced-motion:reduce){:host{transition:none}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], activeId: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeId", required: false }] }], collapsed: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsed", required: false }] }, { type: i0.Output, args: ["collapsedChange"] }], showToggle: [{ type: i0.Input, args: [{ isSignal: true, alias: "showToggle", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], breakpoint: [{ type: i0.Input, args: [{ isSignal: true, alias: "breakpoint", required: false }] }], select: [{ type: i0.Output, args: ["select"] }] } });

const PARTICLES = new Set(['de', 'da', 'do', 'dos', 'das', 'e']);
const TONES = ['primary', 'success', 'warning', 'info', 'destructive'];
/**
 * Iniciais usadas quando a foto nao existe ou falha.
 *
 * O mesmo criterio da barra superior: nomes compostos usam a primeira e a ultima
 * palavra com sentido, ignorando conectivos comuns do pt-BR para que "Maria da
 * Silva" vire "MS", nao "MD".
 */
function avatarInitials(name) {
    const parts = name
        .trim()
        .split(/\s+/)
        .filter((part) => part && !PARTICLES.has(part.toLocaleLowerCase('pt-BR')));
    if (!parts.length) {
        return '?';
    }
    const first = parts[0]?.[0] ?? '';
    const last = parts.length > 1 ? (parts[parts.length - 1]?.[0] ?? '') : '';
    return `${first}${last}`.toLocaleUpperCase('pt-BR');
}
/** Tom deterministico, restrito aos tokens semanticos do tema. */
function avatarTone(name) {
    const text = name.trim().toLocaleLowerCase('pt-BR');
    let sum = 0;
    for (const character of text) {
        sum += character.codePointAt(0) ?? 0;
    }
    return TONES[sum % TONES.length] ?? 'primary';
}

/**
 * Avatar de pessoa da biblioteca `@siage/siage-ui`.
 *
 * Ele cobre os dois usos atuais: foto quando a aplicacao tem uma URL confiavel,
 * e iniciais quando nao tem. A cor de fundo nao e aleatoria; ela escolhe um dos
 * tokens semanticos do tema a partir do nome, para manter consistencia visual
 * entre telas sem criar cores fora do guia.
 */
class SAvatarComponent {
    /** Nome que identifica a pessoa e gera as iniciais quando a imagem nao aparece. */
    name = input.required(...(ngDevMode ? [{ debugName: "name" }] : []));
    /** URL da foto. Se o carregamento falhar, o componente preserva o contexto com as iniciais. */
    src = input('', ...(ngDevMode ? [{ debugName: "src" }] : []));
    /** Tamanho do avatar dentro da escala visual da biblioteca. */
    size = input('md', ...(ngDevMode ? [{ debugName: "size" }] : []));
    /** Texto alternativo da imagem quando a foto comunica algo mais especifico que o nome. */
    alt = input('', ...(ngDevMode ? [{ debugName: "alt" }] : []));
    imageFailed = signal(false, ...(ngDevMode ? [{ debugName: "imageFailed" }] : []));
    accessibleName = computed(() => this.name().trim() || 'Usuário', ...(ngDevMode ? [{ debugName: "accessibleName" }] : []));
    alternativeText = computed(() => this.alt().trim() || this.accessibleName(), ...(ngDevMode ? [{ debugName: "alternativeText" }] : []));
    initials = computed(() => avatarInitials(this.name()), ...(ngDevMode ? [{ debugName: "initials" }] : []));
    showImage = computed(() => Boolean(this.src().trim()) && !this.imageFailed(), ...(ngDevMode ? [{ debugName: "showImage" }] : []));
    hostClasses = computed(() => `s-avatar--${this.size()} s-avatar--${avatarTone(this.name())}`, ...(ngDevMode ? [{ debugName: "hostClasses" }] : []));
    constructor() {
        effect(() => {
            this.src();
            this.imageFailed.set(false);
        });
    }
    handleImageError() {
        this.imageFailed.set(true);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAvatarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SAvatarComponent, isStandalone: true, selector: "s-avatar", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null }, src: { classPropertyName: "src", publicName: "src", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, alt: { classPropertyName: "alt", publicName: "alt", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" }, classAttribute: "s-avatar" }, ngImport: i0, template: `
    @if (showImage()) {
      <img
        class="s-avatar__image"
        [src]="src()"
        [alt]="alternativeText()"
        (error)="handleImageError()"
      />
    } @else {
      <span class="s-avatar__initials" role="img" [attr.aria-label]="accessibleName()">
        {{ initials() }}
      </span>
    }
  `, isInline: true, styles: [":host{display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;width:var(--s-avatar-size);height:var(--s-avatar-size);border-radius:var(--radius-full, 9999px);overflow:hidden;font-family:var(--font-ui);font-weight:var(--weight-semibold, 600);line-height:1;vertical-align:middle}:host(.s-avatar--sm){--s-avatar-size: calc(var(--icon-sm, 20px) + var(--space-12, 12px));font-size:var(--text-caption, 12px)}:host(.s-avatar--md){--s-avatar-size: calc(var(--icon-md, 24px) + var(--space-16, 16px));font-size:var(--text-body, 14px)}:host(.s-avatar--lg){--s-avatar-size: calc(var(--icon-lg, 48px) + var(--space-16, 16px));font-size:var(--text-h6, 16px)}:host(.s-avatar--primary){background:color-mix(in srgb,var(--primary) calc(var(--tint-container, .12) * 100%),transparent);color:var(--primary-on-surface)}:host(.s-avatar--success){background:color-mix(in srgb,var(--success) calc(var(--tint-container, .12) * 100%),transparent);color:var(--success-on-surface)}:host(.s-avatar--warning){background:color-mix(in srgb,var(--warning) calc(var(--tint-container, .12) * 100%),transparent);color:var(--warning-on-surface)}:host(.s-avatar--info){background:color-mix(in srgb,var(--info) calc(var(--tint-container, .12) * 100%),transparent);color:var(--info-on-surface)}:host(.s-avatar--destructive){background:color-mix(in srgb,var(--destructive) calc(var(--tint-container, .12) * 100%),transparent);color:var(--destructive-on-surface)}.s-avatar__image{width:100%;height:100%;object-fit:cover}.s-avatar__initials{display:inline-flex;align-items:center;justify-content:center;width:100%;height:100%}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAvatarComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-avatar', template: `
    @if (showImage()) {
      <img
        class="s-avatar__image"
        [src]="src()"
        [alt]="alternativeText()"
        (error)="handleImageError()"
      />
    } @else {
      <span class="s-avatar__initials" role="img" [attr.aria-label]="accessibleName()">
        {{ initials() }}
      </span>
    }
  `, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-avatar',
                        '[class]': 'hostClasses()',
                    }, styles: [":host{display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto;width:var(--s-avatar-size);height:var(--s-avatar-size);border-radius:var(--radius-full, 9999px);overflow:hidden;font-family:var(--font-ui);font-weight:var(--weight-semibold, 600);line-height:1;vertical-align:middle}:host(.s-avatar--sm){--s-avatar-size: calc(var(--icon-sm, 20px) + var(--space-12, 12px));font-size:var(--text-caption, 12px)}:host(.s-avatar--md){--s-avatar-size: calc(var(--icon-md, 24px) + var(--space-16, 16px));font-size:var(--text-body, 14px)}:host(.s-avatar--lg){--s-avatar-size: calc(var(--icon-lg, 48px) + var(--space-16, 16px));font-size:var(--text-h6, 16px)}:host(.s-avatar--primary){background:color-mix(in srgb,var(--primary) calc(var(--tint-container, .12) * 100%),transparent);color:var(--primary-on-surface)}:host(.s-avatar--success){background:color-mix(in srgb,var(--success) calc(var(--tint-container, .12) * 100%),transparent);color:var(--success-on-surface)}:host(.s-avatar--warning){background:color-mix(in srgb,var(--warning) calc(var(--tint-container, .12) * 100%),transparent);color:var(--warning-on-surface)}:host(.s-avatar--info){background:color-mix(in srgb,var(--info) calc(var(--tint-container, .12) * 100%),transparent);color:var(--info-on-surface)}:host(.s-avatar--destructive){background:color-mix(in srgb,var(--destructive) calc(var(--tint-container, .12) * 100%),transparent);color:var(--destructive-on-surface)}.s-avatar__image{width:100%;height:100%;object-fit:cover}.s-avatar__initials{display:inline-flex;align-items:center;justify-content:center;width:100%;height:100%}\n"] }]
        }], ctorParameters: () => [], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: true }] }], src: [{ type: i0.Input, args: [{ isSignal: true, alias: "src", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], alt: [{ type: i0.Input, args: [{ isSignal: true, alias: "alt", required: false }] }] } });

const MENU_POSITIONS = [
    { originX: 'end', originY: 'bottom', overlayX: 'end', overlayY: 'top', offsetY: 4 },
    { originX: 'start', originY: 'bottom', overlayX: 'start', overlayY: 'top', offsetY: 4 },
    { originX: 'end', originY: 'top', overlayX: 'end', overlayY: 'bottom', offsetY: -4 },
    { originX: 'start', originY: 'top', overlayX: 'start', overlayY: 'bottom', offsetY: -4 },
];
/**
 * Menu flutuante da biblioteca `@siage/siage-ui`.
 *
 * O painel usa o `CdkMenu` para manter a navegação por teclado esperada de menu:
 * setas, Home/End, Esc e typeahead. A biblioteca desenha só a superfície e os
 * itens; a aplicação ancora o painel em qualquer botão com `[sMenuTriggerFor]`.
 */
class SMenuComponent {
    /** Nome acessivel do painel quando o gatilho sozinho nao descreve o conjunto de opcoes. */
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
    overlay = inject(Overlay);
    viewContainerRef = inject(ViewContainerRef);
    template = viewChild.required('menuTemplate');
    openState = signal(false, ...(ngDevMode ? [{ debugName: "openState" }] : []));
    overlayRef = null;
    origin = null;
    closeSubscription = Subscription.EMPTY;
    isOpen = computed(() => this.openState(), ...(ngDevMode ? [{ debugName: "isOpen" }] : []));
    open(origin) {
        const element = origin instanceof ElementRef ? origin.nativeElement : origin;
        if (this.openState()) {
            return;
        }
        this.origin = element;
        this.overlayRef = this.overlay.create({
            hasBackdrop: true,
            backdropClass: 'cdk-overlay-transparent-backdrop',
            panelClass: 's-menu__overlay',
            positionStrategy: this.overlay
                .position()
                .flexibleConnectedTo(element)
                .withPositions(MENU_POSITIONS)
                .withPush(false),
            scrollStrategy: this.overlay.scrollStrategies.reposition(),
        });
        this.overlayRef.attach(new TemplatePortal(this.template(), this.viewContainerRef));
        this.closeSubscription = new Subscription();
        this.closeSubscription.add(this.overlayRef.backdropClick().subscribe(() => this.close()));
        this.closeSubscription.add(this.overlayRef.detachments().subscribe(() => this.finishClose()));
        this.openState.set(true);
        queueMicrotask(() => this.focusFirstItem());
    }
    openFromEvent(event) {
        if (event.currentTarget instanceof HTMLElement) {
            this.toggle(event.currentTarget);
        }
    }
    toggle(origin) {
        if (this.openState()) {
            this.close();
            return;
        }
        this.open(origin);
    }
    close() {
        this.overlayRef?.detach();
    }
    ariaExpanded() {
        return this.openState() ? 'true' : 'false';
    }
    ngOnDestroy() {
        this.closeSubscription.unsubscribe();
        this.overlayRef?.dispose();
    }
    focusFirstItem() {
        this.focusItem('first');
    }
    handleKeydown(event) {
        if (event.key === 'Escape') {
            event.preventDefault();
            event.stopImmediatePropagation();
            this.close();
            return;
        }
        if (event.key === 'Home') {
            event.preventDefault();
            event.stopImmediatePropagation();
            this.focusItem('first');
            return;
        }
        if (event.key === 'End') {
            event.preventDefault();
            event.stopImmediatePropagation();
            this.focusItem('last');
        }
    }
    focusItem(position) {
        const items = Array.from(this.overlayRef?.overlayElement.querySelectorAll('button[cdkmenuitem]:not(:disabled)') ?? []);
        const item = position === 'first' ? items[0] : items[items.length - 1];
        item?.focus();
    }
    finishClose() {
        if (!this.openState()) {
            return;
        }
        this.openState.set(false);
        this.closeSubscription.unsubscribe();
        this.overlayRef?.dispose();
        this.overlayRef = null;
        this.origin?.focus();
        this.origin = null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "20.3.34", type: SMenuComponent, isStandalone: true, selector: "s-menu", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, providers: [PARENT_OR_NEW_MENU_STACK_PROVIDER], viewQueries: [{ propertyName: "template", first: true, predicate: ["menuTemplate"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <ng-template #menuTemplate>
      <div
        cdkMenu
        class="s-menu__panel"
        [attr.aria-label]="label() || null"
        (closed)="close()"
        (keydown)="handleKeydown($event)"
        (s-menu-item-triggered)="close()"
      >
        <ng-content />
      </div>
    </ng-template>
  `, isInline: true, styles: [".s-menu__panel{min-width:192px;padding:var(--space-4, 4px) 0;border:1px solid var(--card-border);border-radius:var(--radius-container, 12px);background:var(--card);box-shadow:var(--elevation-2);font-family:var(--font-ui);outline:none}\n"], dependencies: [{ kind: "directive", type: CdkMenu, selector: "[cdkMenu]", outputs: ["closed"], exportAs: ["cdkMenu"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-menu', imports: [CdkMenu], template: `
    <ng-template #menuTemplate>
      <div
        cdkMenu
        class="s-menu__panel"
        [attr.aria-label]="label() || null"
        (closed)="close()"
        (keydown)="handleKeydown($event)"
        (s-menu-item-triggered)="close()"
      >
        <ng-content />
      </div>
    </ng-template>
  `, changeDetection: ChangeDetectionStrategy.OnPush, providers: [PARENT_OR_NEW_MENU_STACK_PROVIDER], styles: [".s-menu__panel{min-width:192px;padding:var(--space-4, 4px) 0;border:1px solid var(--card-border);border-radius:var(--radius-container, 12px);background:var(--card);box-shadow:var(--elevation-2);font-family:var(--font-ui);outline:none}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], template: [{ type: i0.ViewChild, args: ['menuTemplate', { isSignal: true }] }] } });

/** Item acionavel do `s-menu`. */
class SMenuItemComponent {
    /** Glifo opcional para ajudar a varrer visualmente uma lista curta de acoes. */
    icon = input('', ...(ngDevMode ? [{ debugName: "icon" }] : []));
    /** Desabilita a opcao sem remove-la do menu, preservando o mapa de acoes. */
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Tom reservado para acoes irreversiveis, como sair ou excluir. */
    destructive = input(false, ...(ngDevMode ? [{ debugName: "destructive", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Emite quando o CDK aciona o item por mouse ou teclado. */
    triggered = output();
    elementRef = inject(ElementRef);
    handleTriggered() {
        if (this.disabled()) {
            return;
        }
        this.triggered.emit();
        this.elementRef.nativeElement.dispatchEvent(new CustomEvent('s-menu-item-triggered', { bubbles: true }));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SMenuItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SMenuItemComponent, isStandalone: true, selector: "s-menu-item", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, destructive: { classPropertyName: "destructive", publicName: "destructive", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { triggered: "triggered" }, host: { classAttribute: "s-menu-item" }, ngImport: i0, template: `
    <button
      cdkMenuItem
      type="button"
      class="s-menu-item__button"
      [class.s-menu-item__button--destructive]="destructive()"
      [disabled]="disabled()"
      [cdkMenuItemDisabled]="disabled()"
      (cdkMenuItemTriggered)="handleTriggered()"
    >
      @if (icon()) {
        <s-icon [name]="icon()" size="sm" />
      }
      <span class="s-menu-item__label"><ng-content /></span>
    </button>
  `, isInline: true, styles: [":host{display:block}.s-menu-item__button{display:flex;align-items:center;gap:var(--space-8, 8px);width:100%;min-height:var(--control-h, 40px);padding:0 var(--space-12, 12px);border:none;background:transparent;color:var(--text-primary);font:inherit;text-align:left;cursor:pointer}.s-menu-item__button:hover:not(:disabled),.s-menu-item__button:focus-visible{outline:none;background:color-mix(in srgb,var(--primary) 8%,transparent)}.s-menu-item__button:disabled{opacity:.4;cursor:default}.s-menu-item__button--destructive{color:var(--destructive-on-surface)}.s-menu-item__button--destructive:hover:not(:disabled),.s-menu-item__button--destructive:focus-visible{background:color-mix(in srgb,var(--destructive) 8%,transparent)}.s-menu-item__label{min-width:0}\n"], dependencies: [{ kind: "directive", type: CdkMenuItem, selector: "[cdkMenuItem]", inputs: ["cdkMenuItemDisabled", "cdkMenuitemTypeaheadLabel"], outputs: ["cdkMenuItemTriggered"], exportAs: ["cdkMenuItem"] }, { kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SMenuItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-menu-item', imports: [CdkMenuItem, SIconComponent], template: `
    <button
      cdkMenuItem
      type="button"
      class="s-menu-item__button"
      [class.s-menu-item__button--destructive]="destructive()"
      [disabled]="disabled()"
      [cdkMenuItemDisabled]="disabled()"
      (cdkMenuItemTriggered)="handleTriggered()"
    >
      @if (icon()) {
        <s-icon [name]="icon()" size="sm" />
      }
      <span class="s-menu-item__label"><ng-content /></span>
    </button>
  `, changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 's-menu-item' }, styles: [":host{display:block}.s-menu-item__button{display:flex;align-items:center;gap:var(--space-8, 8px);width:100%;min-height:var(--control-h, 40px);padding:0 var(--space-12, 12px);border:none;background:transparent;color:var(--text-primary);font:inherit;text-align:left;cursor:pointer}.s-menu-item__button:hover:not(:disabled),.s-menu-item__button:focus-visible{outline:none;background:color-mix(in srgb,var(--primary) 8%,transparent)}.s-menu-item__button:disabled{opacity:.4;cursor:default}.s-menu-item__button--destructive{color:var(--destructive-on-surface)}.s-menu-item__button--destructive:hover:not(:disabled),.s-menu-item__button--destructive:focus-visible{background:color-mix(in srgb,var(--destructive) 8%,transparent)}.s-menu-item__label{min-width:0}\n"] }]
        }], propDecorators: { icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], destructive: [{ type: i0.Input, args: [{ isSignal: true, alias: "destructive", required: false }] }], triggered: [{ type: i0.Output, args: ["triggered"] }] } });

/** Separador visual entre grupos de acoes do `s-menu`. */
class SMenuSeparatorComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SMenuSeparatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.34", type: SMenuSeparatorComponent, isStandalone: true, selector: "s-menu-separator", host: { attributes: { "role": "separator" }, classAttribute: "s-menu-separator" }, ngImport: i0, template: '', isInline: true, styles: [":host{display:block;height:1px;margin:var(--space-4, 4px) 0;background:var(--card-border)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SMenuSeparatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-menu-separator', template: '', changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-menu-separator',
                        role: 'separator',
                    }, styles: [":host{display:block;height:1px;margin:var(--space-4, 4px) 0;background:var(--card-border)}\n"] }]
        }] });

/** Gatilho que ancora um `s-menu` em qualquer botao ou elemento interativo. */
class SMenuTriggerDirective {
    menu = input.required(...(ngDevMode ? [{ debugName: "menu", alias: 'sMenuTriggerFor' }] : [{ alias: 'sMenuTriggerFor' }]));
    elementRef = inject(ElementRef);
    handleClick() {
        this.menu().toggle(this.elementRef);
    }
    handleKeyboardTrigger(event) {
        event.preventDefault();
        this.menu().open(this.elementRef);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SMenuTriggerDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "20.3.34", type: SMenuTriggerDirective, isStandalone: true, selector: "[sMenuTriggerFor]", inputs: { menu: { classPropertyName: "menu", publicName: "sMenuTriggerFor", isSignal: true, isRequired: true, transformFunction: null } }, host: { attributes: { "aria-haspopup": "menu" }, listeners: { "click": "handleClick()", "keydown.arrowDown": "handleKeyboardTrigger($event)", "keydown.enter": "handleKeyboardTrigger($event)", "keydown.space": "handleKeyboardTrigger($event)" }, properties: { "attr.aria-expanded": "menu().ariaExpanded()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SMenuTriggerDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[sMenuTriggerFor]',
                    standalone: true,
                    host: {
                        'aria-haspopup': 'menu',
                        '[attr.aria-expanded]': 'menu().ariaExpanded()',
                        '(click)': 'handleClick()',
                        '(keydown.arrowDown)': 'handleKeyboardTrigger($event)',
                        '(keydown.enter)': 'handleKeyboardTrigger($event)',
                        '(keydown.space)': 'handleKeyboardTrigger($event)',
                    },
                }]
        }], propDecorators: { menu: [{ type: i0.Input, args: [{ isSignal: true, alias: "sMenuTriggerFor", required: true }] }] } });

/**
 * Selecao multipla que vira etiquetas.
 *
 * A diferenca para o `<s-multiselect>` e o que fica visivel: aqui **cada
 * escolha ocupa espaco na tela**, com o proprio botao de remover. Use quando a
 * lista escolhida importa tanto quanto o ato de escolher — disciplinas de um
 * professor, turmas de uma escala. Quando o que importa e so a contagem, o
 * multiselect gasta menos espaco.
 *
 * **Nao esta no guia de design.** Segue a anatomia do campo e o tamanho de
 * badge (12px) nas etiquetas.
 *
 * Como o `<s-autocomplete>`, aceita `options` da tela ou consulta a
 * `SAutocompleteSource` quando recebe `url` — a biblioteca continua sem fazer
 * HTTP.
 */
class SChipsComponent extends SControlBase {
    /** Sugestoes do painel. Ignorado quando ha `url`. */
    options = input([], ...(ngDevMode ? [{ debugName: "options" }] : []));
    /** Recurso consultado a cada digitacao, via `SAutocompleteSource`. */
    url = input('', ...(ngDevMode ? [{ debugName: "url" }] : []));
    /** Filtros enviados junto da busca. So tem efeito com `url`. */
    params = input({}, ...(ngDevMode ? [{ debugName: "params" }] : []));
    /** Caracteres minimos antes de consultar. So tem efeito com `url`. */
    minLength = input(1, ...(ngDevMode ? [{ debugName: "minLength", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /**
     * Compara valores, como no `<s-select>`: decide se uma opcao ja foi escolhida
     * e qual rotulo mostrar para um valor que veio do formulario. O padrao e
     * igualdade estrita; informe uma funcao quando o valor for um objeto.
     */
    compareWith = input((a, b) => a === b, ...(ngDevMode ? [{ debugName: "compareWith" }] : []));
    /** Espera entre a digitacao e a consulta, em ms. */
    debounceTime = input(300, ...(ngDevMode ? [{ debugName: "debounceTime", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Texto exibido no painel quando nao ha sugestoes. */
    noResultsText = input('Nenhum resultado encontrado', ...(ngDevMode ? [{ debugName: "noResultsText" }] : []));
    /** Teto de etiquetas. `0` nao limita. */
    max = input(0, ...(ngDevMode ? [{ debugName: "max", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Etiqueta acrescentada. */
    add = output();
    /** Etiqueta removida. */
    remove = output();
    /** Texto digitado. Use quando a tela alimenta `options` por conta propria. */
    search = output();
    /** Tentativa de repetir uma etiqueta ja escolhida. */
    duplicate = output();
    searchControl = new FormControl('', { nonNullable: true });
    source = inject(SAutocompleteSource, { optional: true });
    fetched = signal([], ...(ngDevMode ? [{ debugName: "fetched" }] : []));
    fetching = signal(false, ...(ngDevMode ? [{ debugName: "fetching" }] : []));
    termo = signal('', ...(ngDevMode ? [{ debugName: "termo" }] : []));
    /** As etiquetas escolhidas, com rotulo — nao so o valor. */
    escolhidas = signal([], ...(ngDevMode ? [{ debugName: "escolhidas" }] : []));
    /** Etiquetas que chegaram do formulario sem rotulo conhecido. */
    provisorias = new WeakSet();
    campo = usarCampo('s-chips');
    controlId = this.campo.id;
    ariaLabel = this.campo.rotuloAvulso(this.label);
    describedBy = this.campo.describedBy;
    required = this.campo.obrigatorio;
    isInvalid = computed(() => this.invalid() || this.campo.invalido(), ...(ngDevMode ? [{ debugName: "isInvalid" }] : []));
    /**
     * As etiquetas, com o rotulo provisorio trocado assim que `options` ou a
     * busca trazem a opcao — o valor costuma chegar antes delas na edicao.
     */
    chips = computed(() => {
        const conhecidas = [...this.options(), ...this.fetched()];
        return this.escolhidas().map((opcao) => this.provisorias.has(opcao)
            ? (conhecidas.find((item) => this.compareWith()(item.value, opcao.value)) ?? opcao)
            : opcao);
    }, ...(ngDevMode ? [{ debugName: "chips" }] : []));
    isLoading = computed(() => this.fetching(), ...(ngDevMode ? [{ debugName: "isLoading" }] : []));
    /**
     * Sugestoes menos o que ja foi escolhido: repetir nao e opcao. Com `options`,
     * o texto digitado filtra aqui mesmo; com `url`, quem filtra e a consulta.
     */
    sugestoes = computed(() => {
        const termo = this.termo();
        const base = this.url()
            ? this.fetched()
            : this.options().filter((opcao) => contemTermo(opcao.label, termo));
        const escolhidas = this.escolhidas();
        const comparar = this.compareWith();
        // Pelo `compareWith`: com `url`, cada resposta traz outras instancias.
        return base.filter((opcao) => !escolhidas.some((item) => comparar(item.value, opcao.value)));
    }, ...(ngDevMode ? [{ debugName: "sugestoes" }] : []));
    noLimite = computed(() => this.max() > 0 && this.escolhidas().length >= this.max(), ...(ngDevMode ? [{ debugName: "noLimite" }] : []));
    constructor() {
        super();
        this.searchControl.valueChanges.pipe(takeUntilDestroyed()).subscribe((texto) => {
            this.termo.set(texto);
            this.search.emit(texto);
        });
        // O campo de digitacao e um FormControl proprio, entao desabilitar o
        // controle de fora nao chega ate ele sozinho.
        effect(() => {
            if (this.isDisabled()) {
                this.searchControl.disable({ emitEvent: false });
            }
            else {
                this.searchControl.enable({ emitEvent: false });
            }
        });
        this.searchControl.valueChanges
            .pipe(filter((valor) => typeof valor === 'string'), debounce(() => timer(this.debounceTime())), switchMap((termo) => {
            const url = this.url();
            if (!url) {
                return EMPTY;
            }
            if (termo.length < this.minLength()) {
                this.fetched.set([]);
                return EMPTY;
            }
            if (!this.source) {
                throw new Error('<s-chips url="..."> exige uma SAutocompleteSource. ' +
                    'Registre provideSiageAutocompleteSource(...) no app.config.ts.');
            }
            this.fetching.set(true);
            return this.source.search({ url, term: termo, params: this.params() }).pipe(catchError(() => of([])), tap(() => this.fetching.set(false)), 
            // Ver `<s-autocomplete>`: cobre a consulta cancelada pelo `switchMap`.
            finalize(() => this.fetching.set(false)));
        }), takeUntilDestroyed())
            .subscribe((opcoes) => this.fetched.set(opcoes));
    }
    onOptionSelected(evento) {
        const opcao = evento.option.value;
        this.acrescentar(opcao);
        this.searchControl.setValue('', { emitEvent: false });
        this.termo.set('');
        this.fetched.set([]);
    }
    remover(opcao) {
        this.escolhidas.update((atuais) => atuais.filter((item) => item.value !== opcao.value));
        this.setValue(this.escolhidas().map((item) => item.value));
        this.remove.emit(opcao);
    }
    /** Backspace no campo vazio remove a ultima etiqueta. */
    onBackspace() {
        const atuais = this.escolhidas();
        if (this.searchControl.value === '' && atuais.length > 0) {
            this.remover(atuais[atuais.length - 1]);
        }
    }
    onBlur() {
        this.onTouched();
    }
    acrescentar(opcao) {
        if (this.escolhidas().some((item) => this.compareWith()(item.value, opcao.value))) {
            this.duplicate.emit(opcao);
            return;
        }
        if (this.noLimite()) {
            return;
        }
        this.escolhidas.update((atuais) => [...atuais, opcao]);
        this.setValue(this.escolhidas().map((item) => item.value));
        this.add.emit(opcao);
    }
    writeValue(valor) {
        super.writeValue(valor);
        const valores = valor ?? [];
        const conhecidas = [...this.options(), ...this.fetched(), ...this.escolhidas()];
        // Um valor que chega do formulario sem rotulo conhecido vira etiqueta com o
        // proprio valor no texto — melhor que uma etiqueta vazia enquanto a tela
        // nao informa `options`.
        this.escolhidas.set(valores.map((item) => {
            const conhecida = conhecidas.find((opcao) => this.compareWith()(opcao.value, item));
            if (conhecida) {
                return conhecida;
            }
            const provisoria = { label: String(item), value: item };
            this.provisorias.add(provisoria);
            return provisoria;
        }));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SChipsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SChipsComponent, isStandalone: true, selector: "s-chips", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, url: { classPropertyName: "url", publicName: "url", isSignal: true, isRequired: false, transformFunction: null }, params: { classPropertyName: "params", publicName: "params", isSignal: true, isRequired: false, transformFunction: null }, minLength: { classPropertyName: "minLength", publicName: "minLength", isSignal: true, isRequired: false, transformFunction: null }, compareWith: { classPropertyName: "compareWith", publicName: "compareWith", isSignal: true, isRequired: false, transformFunction: null }, debounceTime: { classPropertyName: "debounceTime", publicName: "debounceTime", isSignal: true, isRequired: false, transformFunction: null }, noResultsText: { classPropertyName: "noResultsText", publicName: "noResultsText", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { add: "add", remove: "remove", search: "search", duplicate: "duplicate" }, host: { classAttribute: "s-chips" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SChipsComponent),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: "<div\n  class=\"s-chips__campo\"\n  matAutocompleteOrigin\n  #origem=\"matAutocompleteOrigin\"\n  [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n  [attr.data-disabled]=\"isDisabled() ? 'true' : null\"\n  [attr.data-readonly]=\"readOnly() ? 'true' : null\"\n>\n  @for (chip of chips(); track chip.value) {\n    <span class=\"s-chips__chip\">\n      <span class=\"s-chips__texto\" [attr.title]=\"chip.label\">{{ chip.label }}</span>\n\n      @if (!isDisabled() && !readOnly()) {\n        <s-icon-button\n          class=\"s-chips__remover\"\n          icon=\"close\"\n          [label]=\"'Remover ' + chip.label\"\n          size=\"xs\"\n          (click)=\"remover(chip)\"\n        />\n      }\n    </span>\n  }\n\n  @if (!noLimite() && !readOnly()) {\n    <input\n      class=\"s-chips__nativo\"\n      type=\"text\"\n      autocomplete=\"off\"\n      [id]=\"controlId()\"\n      [attr.aria-label]=\"ariaLabel()\"\n      [formControl]=\"searchControl\"\n      [matAutocomplete]=\"auto\"\n      [matAutocompleteConnectedTo]=\"origem\"\n      [placeholder]=\"chips().length ? '' : placeholder()\"\n      [attr.aria-required]=\"required() ? 'true' : null\"\n      [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      [attr.aria-busy]=\"isLoading() ? 'true' : null\"\n      (keydown.backspace)=\"onBackspace()\"\n      (blur)=\"onBlur()\"\n    />\n  }\n\n  <mat-autocomplete #auto (optionSelected)=\"onOptionSelected($event)\">\n    @if (sugestoes().length === 0 && !isLoading()) {\n      <mat-option class=\"s-chips__mensagem\" disabled>{{ noResultsText() }}</mat-option>\n    } @else {\n      @for (opcao of sugestoes(); track opcao.value) {\n        <mat-option [value]=\"opcao\" [disabled]=\"opcao.disabled ?? false\">\n          {{ opcao.label }}\n        </mat-option>\n      }\n    }\n  </mat-autocomplete>\n</div>\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%;--s-field-h: var(--field-h, 48px)}.s-chips__campo{box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;display:flex;flex-wrap:wrap;align-items:center;gap:var(--space-8, 8px);height:auto;min-height:var(--s-field-h);padding:var(--space-8, 8px) var(--field-px, 16px)}.s-chips__campo:hover:not([data-disabled=true]){border-color:var(--border);background:var(--card)}.s-chips__campo:focus-within{border:2px solid var(--primary);background:var(--card);padding:7px 15px}.s-chips__campo[data-invalid=true]{border-color:var(--destructive)}.s-chips__campo[data-disabled=true]{opacity:.4}.s-chips__campo[data-readonly=true]{border-color:transparent;background:color-mix(in srgb,var(--text-primary) 4%,transparent)}.s-chips__chip{display:inline-flex;align-items:center;gap:var(--space-4, 4px);height:var(--badge-h, 24px);padding:0 var(--space-4, 4px) 0 var(--badge-px, 8px);border-radius:var(--radius-control, 8px);background:color-mix(in srgb,var(--primary) calc(var(--tint-container, .12) * 100%),transparent);color:var(--primary-on-surface);font-size:var(--text-badge, 12px);font-weight:var(--weight-medium, 500);line-height:1;white-space:nowrap;max-width:100%;min-width:0}.s-chips__texto{overflow:hidden;text-overflow:ellipsis;min-width:0;line-height:1.3}.s-chips__remover{--s-icon-button-size: 20px;flex:none}.s-chips__nativo{flex:1;min-width:120px;padding:0;border:none;background:transparent;font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary)}.s-chips__nativo::placeholder{color:var(--text-secondary)}.s-chips__nativo:focus{outline:none}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$5.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$5.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$5.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatAutocompleteModule }, { kind: "component", type: i2.MatAutocomplete, selector: "mat-autocomplete", inputs: ["aria-label", "aria-labelledby", "displayWith", "autoActiveFirstOption", "autoSelectActiveOption", "requireSelection", "panelWidth", "disableRipple", "class", "hideSingleSelectionIndicator"], outputs: ["optionSelected", "opened", "closed", "optionActivated"], exportAs: ["matAutocomplete"] }, { kind: "component", type: i1$3.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i2.MatAutocompleteTrigger, selector: "input[matAutocomplete], textarea[matAutocomplete]", inputs: ["matAutocomplete", "matAutocompletePosition", "matAutocompleteConnectedTo", "autocomplete", "matAutocompleteDisabled"], exportAs: ["matAutocompleteTrigger"] }, { kind: "directive", type: i2.MatAutocompleteOrigin, selector: "[matAutocompleteOrigin]", exportAs: ["matAutocompleteOrigin"] }, { kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SChipsComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-chips', imports: [ReactiveFormsModule, MatAutocompleteModule, SIconComponent, SIconButtonComponent], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SChipsComponent),
                            multi: true,
                        },
                    ], host: {
                        class: 's-chips',
                    }, template: "<div\n  class=\"s-chips__campo\"\n  matAutocompleteOrigin\n  #origem=\"matAutocompleteOrigin\"\n  [attr.data-invalid]=\"isInvalid() ? 'true' : null\"\n  [attr.data-disabled]=\"isDisabled() ? 'true' : null\"\n  [attr.data-readonly]=\"readOnly() ? 'true' : null\"\n>\n  @for (chip of chips(); track chip.value) {\n    <span class=\"s-chips__chip\">\n      <span class=\"s-chips__texto\" [attr.title]=\"chip.label\">{{ chip.label }}</span>\n\n      @if (!isDisabled() && !readOnly()) {\n        <s-icon-button\n          class=\"s-chips__remover\"\n          icon=\"close\"\n          [label]=\"'Remover ' + chip.label\"\n          size=\"xs\"\n          (click)=\"remover(chip)\"\n        />\n      }\n    </span>\n  }\n\n  @if (!noLimite() && !readOnly()) {\n    <input\n      class=\"s-chips__nativo\"\n      type=\"text\"\n      autocomplete=\"off\"\n      [id]=\"controlId()\"\n      [attr.aria-label]=\"ariaLabel()\"\n      [formControl]=\"searchControl\"\n      [matAutocomplete]=\"auto\"\n      [matAutocompleteConnectedTo]=\"origem\"\n      [placeholder]=\"chips().length ? '' : placeholder()\"\n      [attr.aria-required]=\"required() ? 'true' : null\"\n      [attr.aria-invalid]=\"isInvalid() ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      [attr.aria-busy]=\"isLoading() ? 'true' : null\"\n      (keydown.backspace)=\"onBackspace()\"\n      (blur)=\"onBlur()\"\n    />\n  }\n\n  <mat-autocomplete #auto (optionSelected)=\"onOptionSelected($event)\">\n    @if (sugestoes().length === 0 && !isLoading()) {\n      <mat-option class=\"s-chips__mensagem\" disabled>{{ noResultsText() }}</mat-option>\n    } @else {\n      @for (opcao of sugestoes(); track opcao.value) {\n        <mat-option [value]=\"opcao\" [disabled]=\"opcao.disabled ?? false\">\n          {{ opcao.label }}\n        </mat-option>\n      }\n    }\n  </mat-autocomplete>\n</div>\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:block;width:100%;--s-field-h: var(--field-h, 48px)}.s-chips__campo{box-sizing:border-box;width:100%;height:var(--s-field-h, var(--field-h, 48px));padding:0 var(--field-px, 16px);font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary);background:var(--background);border:1px solid color-mix(in srgb,var(--border) 45%,transparent);border-radius:var(--radius-control, 8px);transition:border-color .15s ease,background-color .15s ease;display:flex;flex-wrap:wrap;align-items:center;gap:var(--space-8, 8px);height:auto;min-height:var(--s-field-h);padding:var(--space-8, 8px) var(--field-px, 16px)}.s-chips__campo:hover:not([data-disabled=true]){border-color:var(--border);background:var(--card)}.s-chips__campo:focus-within{border:2px solid var(--primary);background:var(--card);padding:7px 15px}.s-chips__campo[data-invalid=true]{border-color:var(--destructive)}.s-chips__campo[data-disabled=true]{opacity:.4}.s-chips__campo[data-readonly=true]{border-color:transparent;background:color-mix(in srgb,var(--text-primary) 4%,transparent)}.s-chips__chip{display:inline-flex;align-items:center;gap:var(--space-4, 4px);height:var(--badge-h, 24px);padding:0 var(--space-4, 4px) 0 var(--badge-px, 8px);border-radius:var(--radius-control, 8px);background:color-mix(in srgb,var(--primary) calc(var(--tint-container, .12) * 100%),transparent);color:var(--primary-on-surface);font-size:var(--text-badge, 12px);font-weight:var(--weight-medium, 500);line-height:1;white-space:nowrap;max-width:100%;min-width:0}.s-chips__texto{overflow:hidden;text-overflow:ellipsis;min-width:0;line-height:1.3}.s-chips__remover{--s-icon-button-size: 20px;flex:none}.s-chips__nativo{flex:1;min-width:120px;padding:0;border:none;background:transparent;font-family:var(--font-ui);font-size:var(--text-body, 14px);color:var(--text-primary)}.s-chips__nativo::placeholder{color:var(--text-secondary)}.s-chips__nativo:focus{outline:none}\n"] }]
        }], ctorParameters: () => [], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], url: [{ type: i0.Input, args: [{ isSignal: true, alias: "url", required: false }] }], params: [{ type: i0.Input, args: [{ isSignal: true, alias: "params", required: false }] }], minLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "minLength", required: false }] }], compareWith: [{ type: i0.Input, args: [{ isSignal: true, alias: "compareWith", required: false }] }], debounceTime: [{ type: i0.Input, args: [{ isSignal: true, alias: "debounceTime", required: false }] }], noResultsText: [{ type: i0.Input, args: [{ isSignal: true, alias: "noResultsText", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], add: [{ type: i0.Output, args: ["add"] }], remove: [{ type: i0.Output, args: ["remove"] }], search: [{ type: i0.Output, args: ["search"] }], duplicate: [{ type: i0.Output, args: ["duplicate"] }] } });

/**
 * Fonte dos arquivos ja enviados do `<s-file-upload>`.
 *
 * A biblioteca **nao faz HTTP** — a mesma regra do `SAutocompleteSource`. O
 * arquivo escolhido agora, ainda no navegador, o componente baixa sozinho; o
 * que esta no servidor so a aplicacao sabe buscar. Com a fonte registrada, a
 * tela informa `fileId` e o botao de baixar funciona sem codigo na tela.
 *
 * @example
 * ```ts
 * @Injectable({ providedIn: 'root' })
 * export class SiageFileSource extends SFileSource {
 *   private readonly arquivos = inject(ArquivoService);
 *
 *   download({ id, fileName }: SFileDownload) {
 *     return this.arquivos.download(id).pipe(map((r) => salvar(r.body, fileName)));
 *   }
 * }
 * ```
 */
class SFileSource {
}
/**
 * Registra a fonte dos arquivos ja enviados.
 *
 * ```ts
 * // app.config.ts
 * providers: [provideSiageFileSource(SiageFileSource)]
 * ```
 */
function provideSiageFileSource(source) {
    return makeEnvironmentProviders([{ provide: SFileSource, useExisting: source }]);
}

/** Converte bytes em algo legivel. */
function formatarTamanho(bytes) {
    if (bytes < 1024) {
        return `${bytes} B`;
    }
    if (bytes < 1024 * 1024) {
        return `${Math.round(bytes / 1024)} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
/** `['pdf', 'jpg', 'png']` vira `PDF, JPG ou PNG`. */
function listarExtensoes(extensoes) {
    const nomes = extensoes.map((extensao) => extensao.toUpperCase());
    return nomes.length > 1
        ? `${nomes.slice(0, -1).join(', ')} ou ${nomes[nomes.length - 1]}`
        : (nomes[0] ?? '');
}
/** Salva no computador um conteudo que ja esta no navegador. */
function salvarNoComputador(conteudo, nome) {
    const url = URL.createObjectURL(conteudo);
    const link = document.createElement('a');
    link.href = url;
    link.download = nome;
    link.click();
    URL.revokeObjectURL(url);
}
/**
 * Selecao de um arquivo, com validacao antes do envio.
 *
 * **Nao faz upload.** Ele valida extensao e tamanho, mostra o que foi
 * escolhido e entrega o `File` para a aplicacao — que decide para onde mandar.
 * E a mesma regra do `<s-autocomplete>`: a biblioteca nao conhece a API.
 *
 * Baixar tambem segue a regra: o arquivo escolhido agora o componente salva
 * sozinho; o ja enviado (`fileName` + `fileId`) e buscado pela `SFileSource`
 * que a aplicacao registra.
 *
 * **Nao esta no guia de design.** Segue a altura de controle dos botoes e a
 * superficie somente-leitura para o arquivo ja escolhido.
 *
 * Validar antes de enviar poupa a viagem: um PDF de 40MB recusado no navegador
 * economiza o upload inteiro e a mensagem de erro que so chegaria depois.
 */
class SFileUploadComponent extends SControlBase {
    /** Extensoes aceitas, sem ponto. Vazio aceita qualquer uma. */
    accept = input(['pdf', 'png', 'jpg', 'jpeg'], ...(ngDevMode ? [{ debugName: "accept" }] : []));
    /** Tamanho maximo em MB. `0` nao limita. */
    maxSizeMb = input(10, ...(ngDevMode ? [{ debugName: "maxSizeMb", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /** Rotulo do botao de escolher. */
    buttonLabel = input('Selecionar Arquivo', ...(ngDevMode ? [{ debugName: "buttonLabel" }] : []));
    /** Glifo do botao de escolher. */
    buttonIcon = input('upload', ...(ngDevMode ? [{ debugName: "buttonIcon" }] : []));
    /** Ver `SFileUploadAppearance`. */
    appearance = input('button', ...(ngDevMode ? [{ debugName: "appearance" }] : []));
    /**
     * Botao na largura toda do container.
     *
     * Para colunas estreitas e formularios de uma coluna, onde um botao curto
     * a esquerda parece solto. `dropzone` ja ocupa a largura toda; `icon` ignora.
     */
    fullWidth = input(false, ...(ngDevMode ? [{ debugName: "fullWidth", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Texto opcional na `dropzone`, abaixo do botao (ex.: "ou arraste para cá"). */
    dropLabel = input('', ...(ngDevMode ? [{ debugName: "dropLabel" }] : []));
    /**
     * Nome de um arquivo ja enviado antes.
     *
     * Numa tela de edicao o arquivo esta no servidor, nao no navegador: nao ha
     * `File` para mostrar. Este input exibe o nome sem exigir que a aplicacao
     * baixe o conteudo so para preencher o campo.
     */
    fileName = input('', ...(ngDevMode ? [{ debugName: "fileName" }] : []));
    /**
     * Id do arquivo ja enviado, entregue a `SFileSource` para baixar.
     *
     * Tambem e o que libera remover um arquivo ja enviado: sem id, o nome e so
     * informativo (a foto atual, por exemplo) e so se troca escolhendo outro.
     */
    fileId = input(null, ...(ngDevMode ? [{ debugName: "fileId" }] : []));
    /** Exibe o botao de baixar. */
    allowDownload = input(false, ...(ngDevMode ? [{ debugName: "allowDownload", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Exibe o botao de remover. */
    allowRemove = input(true, ...(ngDevMode ? [{ debugName: "allowRemove", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Abre um modal quando o arquivo e recusado, com o formato aceito ou o
     * limite de tamanho.
     *
     * Ligado por padrao: sem ele, escolher um arquivo fora da regra nao mudava
     * nada na tela, e a pessoa nao sabia por que. Desligue quando a tela mostrar
     * a recusa por conta propria — `fileError` e emitido nos dois casos.
     */
    showErrorDialog = input(true, ...(ngDevMode ? [{ debugName: "showErrorDialog", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Mensagem de extensao recusada. `{formatos}` vira a lista aceita. */
    invalidFormatMessage = input('Formato inválido. Selecione um arquivo nos formatos {formatos}.', ...(ngDevMode ? [{ debugName: "invalidFormatMessage" }] : []));
    /** Mensagem de tamanho excedido. `{tamanho}` vira o limite (`10MB`). */
    maxSizeMessage = input('Tamanho máximo excedido. O arquivo deve ter no máximo {tamanho}.', ...(ngDevMode ? [{ debugName: "maxSizeMessage" }] : []));
    /**
     * Mostra "Selecione um arquivo." enquanto nao houver arquivo — ligue depois
     * da tentativa de salvar. Num `<s-field>` com `required`, a mensagem do
     * campo ja cobre o caso.
     */
    showRequired = input(false, ...(ngDevMode ? [{ debugName: "showRequired", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Arquivo aceito ou, ao remover, `null`.
     *
     * O `null` deixa a tela tratar escolher e remover num lugar so; `fileRemoved`
     * continua para quem so quer saber da remocao.
     */
    fileSelected = output();
    /** Arquivo removido. */
    fileRemoved = output();
    /** Arquivo recusado, com o motivo. */
    fileError = output();
    /** Pedido de download do arquivo ja enviado (alem da `SFileSource`, se houver). */
    download = output();
    /** O seletor de arquivos do sistema vai abrir. */
    selectorOpened = output();
    campo = usarCampo('s-file-upload');
    modal = inject(SModalService);
    fonte = inject(SFileSource, { optional: true });
    entrada = viewChild.required('entrada');
    controlId = this.campo.id;
    describedBy = this.campo.describedBy;
    required = this.campo.obrigatorio;
    /**
     * Nome do arquivo ja enviado, enquanto ele vale.
     *
     * Segue `fileName`, mas o usuario pode remove-lo: depois de "remover", o
     * campo fica vazio mesmo que a tela nao limpe `fileName`. Antes o nome
     * exibido voltava para o input, e o arquivo removido continuava na tela.
     */
    nomeRemoto = linkedSignal(() => this.fileName() ?? '', ...(ngDevMode ? [{ debugName: "nomeRemoto" }] : []));
    /** Um arquivo esta sendo arrastado sobre a `dropzone`. */
    arrastando = signal(false, ...(ngDevMode ? [{ debugName: "arrastando" }] : []));
    /** O que aparece na tela: o arquivo escolhido agora ou o ja enviado. */
    nomeExibido = computed(() => this.value()?.name ?? this.nomeRemoto(), ...(ngDevMode ? [{ debugName: "nomeExibido" }] : []));
    temArquivo = computed(() => this.nomeExibido().length > 0, ...(ngDevMode ? [{ debugName: "temArquivo" }] : []));
    tamanhoExibido = computed(() => {
        const arquivo = this.value();
        return arquivo ? formatarTamanho(arquivo.size) : '';
    }, ...(ngDevMode ? [{ debugName: "tamanhoExibido" }] : []));
    extensoesTexto = computed(() => listarExtensoes(this.accept()), ...(ngDevMode ? [{ debugName: "extensoesTexto" }] : []));
    limiteTexto = computed(() => this.maxSizeMb() > 0 ? `${this.maxSizeMb()}MB` : '', ...(ngDevMode ? [{ debugName: "limiteTexto" }] : []));
    atributoAccept = computed(() => this.accept()
        .map((extensao) => `.${extensao}`)
        .join(','), ...(ngDevMode ? [{ debugName: "atributoAccept" }] : []));
    /** Baixa o escolhido agora, ou o ja enviado quando ha como buscar. */
    podeBaixar = computed(() => this.allowDownload() && (!!this.value() || !!this.nomeRemoto()), ...(ngDevMode ? [{ debugName: "podeBaixar" }] : []));
    /** O escolhido agora sempre sai; o ja enviado, so com `fileId`. */
    podeRemover = computed(() => this.allowRemove() && !this.isDisabled() && (!!this.value() || !!this.fileId()), ...(ngDevMode ? [{ debugName: "podeRemover" }] : []));
    faltaArquivo = computed(() => this.showRequired() && !this.temArquivo(), ...(ngDevMode ? [{ debugName: "faltaArquivo" }] : []));
    /** Abre o seletor de arquivos do sistema. */
    abrirSeletor() {
        if (this.isDisabled()) {
            return;
        }
        this.selectorOpened.emit();
        this.entrada().nativeElement.click();
    }
    onFileChange(evento) {
        const entrada = evento.target;
        const arquivo = entrada.files?.[0];
        // Permite escolher o mesmo arquivo duas vezes seguidas: sem isto, o
        // `change` nao dispara na segunda.
        entrada.value = '';
        if (arquivo) {
            this.receber(arquivo);
        }
    }
    aoArrastar(evento) {
        if (this.isDisabled()) {
            return;
        }
        // Sem o `preventDefault`, o navegador recusa o `drop` e abre o arquivo na aba.
        evento.preventDefault();
        this.arrastando.set(true);
    }
    aoSoltar(evento) {
        evento.preventDefault();
        this.arrastando.set(false);
        const arquivo = evento.dataTransfer?.files?.[0];
        if (arquivo && !this.isDisabled()) {
            this.receber(arquivo);
        }
    }
    receber(arquivo) {
        const problema = this.validar(arquivo);
        if (problema) {
            this.fileError.emit(problema);
            if (this.showErrorDialog()) {
                void this.modal.confirm({
                    variant: 'result',
                    title: 'Atenção!',
                    description: problema.message,
                    icon: 'error',
                    iconVariant: 'destructive',
                    confirmLabel: 'OK',
                    size: 'sm',
                });
            }
            return;
        }
        this.nomeRemoto.set('');
        this.setValue(arquivo);
        this.fileSelected.emit(arquivo);
    }
    remover() {
        // O botao desabilitado do Material nao recebe clique, mas o clique cai no
        // host do `<s-icon-button>`, que e onde o `(click)` escuta.
        if (this.isDisabled()) {
            return;
        }
        this.nomeRemoto.set('');
        this.setValue(null);
        this.fileSelected.emit(null);
        this.fileRemoved.emit();
    }
    baixar() {
        const local = this.value();
        if (local) {
            salvarNoComputador(local, local.name);
            return;
        }
        this.download.emit();
        const id = this.fileId();
        if (!id || !this.fonte) {
            return;
        }
        const fileName = this.nomeRemoto();
        const resposta = this.fonte.download({
            id,
            fileName,
            extension: fileName.split('.').pop()?.toLowerCase() ?? '',
        });
        if (isObservable(resposta)) {
            resposta.subscribe();
        }
    }
    onBlur() {
        this.onTouched();
    }
    /**
     * Volta ao estado inicial: sem arquivo escolhido, com o nome de `fileName`.
     * Para a tela limpar o campo depois de salvar ou cancelar.
     */
    reset() {
        this.setValue(null);
        this.nomeRemoto.set(this.fileName() ?? '');
        this.entrada().nativeElement.value = '';
    }
    validar(arquivo) {
        const extensoes = this.accept();
        const extensao = arquivo.name.split('.').pop()?.toLowerCase() ?? '';
        if (extensoes.length && !extensoes.includes(extensao)) {
            return {
                kind: 'extension',
                file: arquivo,
                message: this.invalidFormatMessage().replace('{formatos}', this.extensoesTexto()),
            };
        }
        const limite = this.maxSizeMb();
        if (limite > 0 && arquivo.size > limite * 1024 * 1024) {
            return {
                kind: 'size',
                file: arquivo,
                message: this.maxSizeMessage().replace('{tamanho}', this.limiteTexto()),
            };
        }
        return null;
    }
    writeValue(valor) {
        super.writeValue(valor);
        // Sem `File`, o nome do arquivo ja enviado passa a ser o que se mostra.
        if (!valor) {
            this.nomeRemoto.set(this.fileName() ?? '');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SFileUploadComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SFileUploadComponent, isStandalone: true, selector: "s-file-upload", inputs: { accept: { classPropertyName: "accept", publicName: "accept", isSignal: true, isRequired: false, transformFunction: null }, maxSizeMb: { classPropertyName: "maxSizeMb", publicName: "maxSizeMb", isSignal: true, isRequired: false, transformFunction: null }, buttonLabel: { classPropertyName: "buttonLabel", publicName: "buttonLabel", isSignal: true, isRequired: false, transformFunction: null }, buttonIcon: { classPropertyName: "buttonIcon", publicName: "buttonIcon", isSignal: true, isRequired: false, transformFunction: null }, appearance: { classPropertyName: "appearance", publicName: "appearance", isSignal: true, isRequired: false, transformFunction: null }, fullWidth: { classPropertyName: "fullWidth", publicName: "fullWidth", isSignal: true, isRequired: false, transformFunction: null }, dropLabel: { classPropertyName: "dropLabel", publicName: "dropLabel", isSignal: true, isRequired: false, transformFunction: null }, fileName: { classPropertyName: "fileName", publicName: "fileName", isSignal: true, isRequired: false, transformFunction: null }, fileId: { classPropertyName: "fileId", publicName: "fileId", isSignal: true, isRequired: false, transformFunction: null }, allowDownload: { classPropertyName: "allowDownload", publicName: "allowDownload", isSignal: true, isRequired: false, transformFunction: null }, allowRemove: { classPropertyName: "allowRemove", publicName: "allowRemove", isSignal: true, isRequired: false, transformFunction: null }, showErrorDialog: { classPropertyName: "showErrorDialog", publicName: "showErrorDialog", isSignal: true, isRequired: false, transformFunction: null }, invalidFormatMessage: { classPropertyName: "invalidFormatMessage", publicName: "invalidFormatMessage", isSignal: true, isRequired: false, transformFunction: null }, maxSizeMessage: { classPropertyName: "maxSizeMessage", publicName: "maxSizeMessage", isSignal: true, isRequired: false, transformFunction: null }, showRequired: { classPropertyName: "showRequired", publicName: "showRequired", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { fileSelected: "fileSelected", fileRemoved: "fileRemoved", fileError: "fileError", download: "download", selectorOpened: "selectorOpened" }, host: { properties: { "class.s-file-upload--largo": "fullWidth() || appearance() === \"dropzone\"" }, classAttribute: "s-file-upload" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SFileUploadComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "entrada", first: true, predicate: ["entrada"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "@if (temArquivo()) {\n  <div class=\"s-file-upload__arquivo\">\n    <s-icon class=\"s-file-upload__icone\" name=\"description\" size=\"sm\" variant=\"primary\" />\n\n    <span class=\"s-file-upload__nome\" [title]=\"nomeExibido()\">{{ nomeExibido() }}</span>\n\n    @if (tamanhoExibido()) {\n      <span class=\"s-file-upload__tamanho\">{{ tamanhoExibido() }}</span>\n    }\n\n    @if (podeBaixar()) {\n      <s-icon-button\n        icon=\"download\"\n        label=\"Baixar arquivo\"\n        variant=\"info\"\n        text\n        size=\"sm\"\n        sTooltip=\"Baixar arquivo\"\n        [disabled]=\"isDisabled()\"\n        (click)=\"isDisabled() || baixar()\"\n      />\n    }\n\n    @if (podeRemover()) {\n      <s-icon-button\n        icon=\"delete\"\n        label=\"Remover arquivo\"\n        variant=\"destructive\"\n        text\n        size=\"sm\"\n        sTooltip=\"Remover arquivo\"\n        (click)=\"remover()\"\n      />\n    }\n  </div>\n} @else {\n  @switch (appearance()) {\n    @case ('dropzone') {\n      <!-- Quem abre o seletor e o botao: a area so recebe o arquivo arrastado,\n           sem um segundo alvo de clique (e de foco) em volta dele. -->\n      <div\n        class=\"s-file-upload__zona\"\n        [class.s-file-upload__zona--ativa]=\"arrastando()\"\n        [class.s-file-upload__zona--desabilitada]=\"isDisabled()\"\n        (dragover)=\"aoArrastar($event)\"\n        (dragleave)=\"arrastando.set(false)\"\n        (drop)=\"aoSoltar($event)\"\n      >\n        <s-icon class=\"s-file-upload__zona-icone\" name=\"upload\" size=\"md\" />\n        <ng-container *ngTemplateOutlet=\"regras\" />\n        <s-button [icon]=\"buttonIcon()\" [disabled]=\"isDisabled()\" (click)=\"abrirSeletor()\">\n          {{ buttonLabel() }}\n        </s-button>\n        @if (dropLabel()) {\n          <span class=\"s-file-upload__regras\">{{ dropLabel() }}</span>\n        }\n      </div>\n    }\n    @case ('icon') {\n      <s-icon-button\n        variant=\"secondary\"\n        outlined\n        [icon]=\"buttonIcon()\"\n        [label]=\"buttonLabel()\"\n        [disabled]=\"isDisabled()\"\n        (click)=\"abrirSeletor()\"\n      />\n    }\n    @default {\n      <s-button\n        [icon]=\"buttonIcon()\"\n        [fullWidth]=\"fullWidth()\"\n        [disabled]=\"isDisabled()\"\n        (click)=\"abrirSeletor()\"\n      >\n        {{ buttonLabel() }}\n      </s-button>\n    }\n  }\n}\n\n@if (faltaArquivo()) {\n  <small class=\"s-file-upload__erro\" role=\"alert\">Selecione um arquivo.</small>\n}\n\n<ng-template #regras>\n  @if (extensoesTexto()) {\n    <span class=\"s-file-upload__regras\">\n      {{ extensoesTexto() }}\n      @if (limiteTexto()) {\n        - M\u00E1x. {{ limiteTexto() }}\n      }\n    </span>\n  }\n</ng-template>\n\n<!-- O <input type=\"file\"> nativo fica fora da vista: o navegador nao deixa\n     estilizar o botao dele, entao quem aparece e o <s-button>. -->\n<input\n  #entrada\n  class=\"s-file-upload__nativo\"\n  type=\"file\"\n  tabindex=\"-1\"\n  [id]=\"controlId()\"\n  [accept]=\"atributoAccept()\"\n  [disabled]=\"isDisabled()\"\n  [attr.aria-required]=\"required() ? 'true' : null\"\n  [attr.aria-describedby]=\"describedBy()\"\n  (change)=\"onFileChange($event)\"\n  (blur)=\"onBlur()\"\n/>\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:flex;align-items:center;gap:var(--space-12, 12px);flex-wrap:wrap}:host(.s-file-upload--largo){display:flex;flex-direction:column;align-items:stretch;gap:var(--space-4, 4px);width:100%}.s-file-upload__zona{box-sizing:border-box;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:var(--space-8, 8px);width:100%;min-height:120px;padding:var(--space-24, 24px);text-align:center;font-size:var(--text-body, 14px);color:var(--text-secondary);background:var(--background);border:2px dashed var(--border);border-radius:var(--radius-container, 12px);transition:border-color .15s ease,background-color .15s ease}.s-file-upload__zona .s-file-upload__regras{font-size:var(--text-body, 14px)}.s-file-upload__zona.s-file-upload__zona--ativa{border-color:var(--primary);background:var(--card)}.s-file-upload__zona--desabilitada{opacity:.4}.s-file-upload__zona-icone{color:var(--text-secondary)}.s-file-upload__nativo{position:absolute;width:1px;height:1px;opacity:0;margin:0}.s-file-upload__arquivo{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary);gap:var(--space-8, 8px);padding-right:var(--space-4, 4px)}.s-file-upload__icone{flex:0 0 auto;color:var(--text-secondary)}.s-file-upload__nome{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.s-file-upload__tamanho{flex:0 0 auto;font-size:var(--text-caption, 12px);color:var(--text-secondary);font-variant-numeric:tabular-nums}.s-file-upload__regras{font-size:var(--text-caption, 12px);color:var(--text-secondary)}.s-file-upload__erro{flex-basis:100%;font-size:var(--text-caption, 12px);color:var(--destructive-on-surface)}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: SButtonComponent, selector: "s-button", inputs: ["variant", "outlined", "fullWidth", "pressed", "buttonRole", "checked", "focusIndex", "loading", "loadingText", "disabled", "icon", "iconRight", "type", "label"] }, { kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }, { kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }, { kind: "directive", type: STooltipDirective, selector: "[sTooltip]", inputs: ["sTooltip", "sTooltipPosition", "sTooltipDisabled", "sTooltipDelay"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SFileUploadComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-file-upload', imports: [
                        NgTemplateOutlet,
                        SButtonComponent,
                        SIconComponent,
                        SIconButtonComponent,
                        STooltipDirective,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SFileUploadComponent),
                            multi: true,
                        },
                    ], host: {
                        class: 's-file-upload',
                        '[class.s-file-upload--largo]': 'fullWidth() || appearance() === "dropzone"',
                    }, template: "@if (temArquivo()) {\n  <div class=\"s-file-upload__arquivo\">\n    <s-icon class=\"s-file-upload__icone\" name=\"description\" size=\"sm\" variant=\"primary\" />\n\n    <span class=\"s-file-upload__nome\" [title]=\"nomeExibido()\">{{ nomeExibido() }}</span>\n\n    @if (tamanhoExibido()) {\n      <span class=\"s-file-upload__tamanho\">{{ tamanhoExibido() }}</span>\n    }\n\n    @if (podeBaixar()) {\n      <s-icon-button\n        icon=\"download\"\n        label=\"Baixar arquivo\"\n        variant=\"info\"\n        text\n        size=\"sm\"\n        sTooltip=\"Baixar arquivo\"\n        [disabled]=\"isDisabled()\"\n        (click)=\"isDisabled() || baixar()\"\n      />\n    }\n\n    @if (podeRemover()) {\n      <s-icon-button\n        icon=\"delete\"\n        label=\"Remover arquivo\"\n        variant=\"destructive\"\n        text\n        size=\"sm\"\n        sTooltip=\"Remover arquivo\"\n        (click)=\"remover()\"\n      />\n    }\n  </div>\n} @else {\n  @switch (appearance()) {\n    @case ('dropzone') {\n      <!-- Quem abre o seletor e o botao: a area so recebe o arquivo arrastado,\n           sem um segundo alvo de clique (e de foco) em volta dele. -->\n      <div\n        class=\"s-file-upload__zona\"\n        [class.s-file-upload__zona--ativa]=\"arrastando()\"\n        [class.s-file-upload__zona--desabilitada]=\"isDisabled()\"\n        (dragover)=\"aoArrastar($event)\"\n        (dragleave)=\"arrastando.set(false)\"\n        (drop)=\"aoSoltar($event)\"\n      >\n        <s-icon class=\"s-file-upload__zona-icone\" name=\"upload\" size=\"md\" />\n        <ng-container *ngTemplateOutlet=\"regras\" />\n        <s-button [icon]=\"buttonIcon()\" [disabled]=\"isDisabled()\" (click)=\"abrirSeletor()\">\n          {{ buttonLabel() }}\n        </s-button>\n        @if (dropLabel()) {\n          <span class=\"s-file-upload__regras\">{{ dropLabel() }}</span>\n        }\n      </div>\n    }\n    @case ('icon') {\n      <s-icon-button\n        variant=\"secondary\"\n        outlined\n        [icon]=\"buttonIcon()\"\n        [label]=\"buttonLabel()\"\n        [disabled]=\"isDisabled()\"\n        (click)=\"abrirSeletor()\"\n      />\n    }\n    @default {\n      <s-button\n        [icon]=\"buttonIcon()\"\n        [fullWidth]=\"fullWidth()\"\n        [disabled]=\"isDisabled()\"\n        (click)=\"abrirSeletor()\"\n      >\n        {{ buttonLabel() }}\n      </s-button>\n    }\n  }\n}\n\n@if (faltaArquivo()) {\n  <small class=\"s-file-upload__erro\" role=\"alert\">Selecione um arquivo.</small>\n}\n\n<ng-template #regras>\n  @if (extensoesTexto()) {\n    <span class=\"s-file-upload__regras\">\n      {{ extensoesTexto() }}\n      @if (limiteTexto()) {\n        - M\u00E1x. {{ limiteTexto() }}\n      }\n    </span>\n  }\n</ng-template>\n\n<!-- O <input type=\"file\"> nativo fica fora da vista: o navegador nao deixa\n     estilizar o botao dele, entao quem aparece e o <s-button>. -->\n<input\n  #entrada\n  class=\"s-file-upload__nativo\"\n  type=\"file\"\n  tabindex=\"-1\"\n  [id]=\"controlId()\"\n  [accept]=\"atributoAccept()\"\n  [disabled]=\"isDisabled()\"\n  [attr.aria-required]=\"required() ? 'true' : null\"\n  [attr.aria-describedby]=\"describedBy()\"\n  (change)=\"onFileChange($event)\"\n  (blur)=\"onBlur()\"\n/>\n", styles: ["@charset \"UTF-8\";input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus,input:-webkit-autofill:active{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 2px)}input:-webkit-autofill:hover{-webkit-box-shadow:0 0 0 30px #fff inset!important}input:-webkit-autofill:focus{-webkit-box-shadow:0 0 0 30px var(--background) inset!important;height:calc(var(--s-field-h, var(--field-h, 48px)) - 4px)}:host{display:flex;align-items:center;gap:var(--space-12, 12px);flex-wrap:wrap}:host(.s-file-upload--largo){display:flex;flex-direction:column;align-items:stretch;gap:var(--space-4, 4px);width:100%}.s-file-upload__zona{box-sizing:border-box;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:var(--space-8, 8px);width:100%;min-height:120px;padding:var(--space-24, 24px);text-align:center;font-size:var(--text-body, 14px);color:var(--text-secondary);background:var(--background);border:2px dashed var(--border);border-radius:var(--radius-container, 12px);transition:border-color .15s ease,background-color .15s ease}.s-file-upload__zona .s-file-upload__regras{font-size:var(--text-body, 14px)}.s-file-upload__zona.s-file-upload__zona--ativa{border-color:var(--primary);background:var(--card)}.s-file-upload__zona--desabilitada{opacity:.4}.s-file-upload__zona-icone{color:var(--text-secondary)}.s-file-upload__nativo{position:absolute;width:1px;height:1px;opacity:0;margin:0}.s-file-upload__arquivo{box-sizing:border-box;width:100%;min-height:var(--s-field-h, var(--field-h, 48px));display:flex;align-items:center;padding:0 var(--field-px, 16px);background:color-mix(in srgb,var(--text-primary) 4%,transparent);border:none;border-radius:var(--radius-control, 8px);font-size:var(--text-body, 14px);color:var(--text-primary);gap:var(--space-8, 8px);padding-right:var(--space-4, 4px)}.s-file-upload__icone{flex:0 0 auto;color:var(--text-secondary)}.s-file-upload__nome{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.s-file-upload__tamanho{flex:0 0 auto;font-size:var(--text-caption, 12px);color:var(--text-secondary);font-variant-numeric:tabular-nums}.s-file-upload__regras{font-size:var(--text-caption, 12px);color:var(--text-secondary)}.s-file-upload__erro{flex-basis:100%;font-size:var(--text-caption, 12px);color:var(--destructive-on-surface)}\n"] }]
        }], propDecorators: { accept: [{ type: i0.Input, args: [{ isSignal: true, alias: "accept", required: false }] }], maxSizeMb: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxSizeMb", required: false }] }], buttonLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "buttonLabel", required: false }] }], buttonIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "buttonIcon", required: false }] }], appearance: [{ type: i0.Input, args: [{ isSignal: true, alias: "appearance", required: false }] }], fullWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "fullWidth", required: false }] }], dropLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "dropLabel", required: false }] }], fileName: [{ type: i0.Input, args: [{ isSignal: true, alias: "fileName", required: false }] }], fileId: [{ type: i0.Input, args: [{ isSignal: true, alias: "fileId", required: false }] }], allowDownload: [{ type: i0.Input, args: [{ isSignal: true, alias: "allowDownload", required: false }] }], allowRemove: [{ type: i0.Input, args: [{ isSignal: true, alias: "allowRemove", required: false }] }], showErrorDialog: [{ type: i0.Input, args: [{ isSignal: true, alias: "showErrorDialog", required: false }] }], invalidFormatMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalidFormatMessage", required: false }] }], maxSizeMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxSizeMessage", required: false }] }], showRequired: [{ type: i0.Input, args: [{ isSignal: true, alias: "showRequired", required: false }] }], fileSelected: [{ type: i0.Output, args: ["fileSelected"] }], fileRemoved: [{ type: i0.Output, args: ["fileRemoved"] }], fileError: [{ type: i0.Output, args: ["fileError"] }], download: [{ type: i0.Output, args: ["download"] }], selectorOpened: [{ type: i0.Output, args: ["selectorOpened"] }], entrada: [{ type: i0.ViewChild, args: ['entrada', { isSignal: true }] }] } });

/**
 * Escolha unica entre poucas opcoes, todas visiveis.
 *
 * A regra para decidir entre radio e `<s-select>` e a quantidade: ate cinco
 * opcoes curtas, mostrar todas poupa um clique e deixa a comparacao visivel.
 * Acima disso o grupo ocupa mais espaco do que informa, e o select ganha.
 *
 * **Nao esta no guia de design**, que so preve checkbox e switch. Segue a
 * mesma anatomia deles: caixa de 20px, rotulo a direita fazendo parte da area
 * de clique.
 *
 * Encapsula o `mat-radio-group`, que ja resolve o que e chato num grupo de
 * radio: navegacao por setas, um unico ponto de tabulacao e o `role="radiogroup"`.
 */
class SRadioGroupComponent extends SControlBase {
    /** Opcoes exibidas. */
    options = input([], ...(ngDevMode ? [{ debugName: "options" }] : []));
    /** Como as opcoes se distribuem. */
    orientation = input('vertical', ...(ngDevMode ? [{ debugName: "orientation" }] : []));
    /** Nome do grupo no formulario nativo. Gerado quando ausente. */
    name = input('', ...(ngDevMode ? [{ debugName: "name" }] : []));
    /**
     * Emitido quando o usuario escolhe uma opcao, com o valor dela. Nao dispara
     * quando o valor muda pelo formulario (`setValue`, `reset`, `patchValue`).
     */
    selectionChange = output();
    campo = usarCampo('s-radio-group');
    nomeGerado = proximoId('s-radio');
    describedBy = this.campo.describedBy;
    required = this.campo.obrigatorio;
    labelledBy = this.campo.rotuladoPor;
    ariaLabel = this.campo.rotuloAvulso(this.label);
    nome = computed(() => this.name() || this.nomeGerado, ...(ngDevMode ? [{ debugName: "nome" }] : []));
    onSelectionChange(evento) {
        const valor = evento.value ?? null;
        this.setValue(valor);
        this.selectionChange.emit(valor);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SRadioGroupComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SRadioGroupComponent, isStandalone: true, selector: "s-radio-group", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectionChange: "selectionChange" }, host: { properties: { "class.s-radio-group--horizontal": "orientation() === 'horizontal'" }, classAttribute: "s-radio-group" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SRadioGroupComponent),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: "<mat-radio-group\n  class=\"s-radio-group__grupo\"\n  [name]=\"nome()\"\n  [value]=\"value()\"\n  [disabled]=\"isDisabled() || readOnly()\"\n  [attr.aria-labelledby]=\"labelledBy()\"\n  [attr.aria-label]=\"ariaLabel()\"\n  [attr.aria-describedby]=\"describedBy()\"\n  [attr.aria-required]=\"required() ? 'true' : null\"\n  (change)=\"onSelectionChange($event)\"\n  (focusout)=\"onGroupFocusOut($event)\"\n>\n  @for (opcao of options(); track opcao.value) {\n    <mat-radio-button [value]=\"opcao.value\" [disabled]=\"opcao.disabled ?? false\">\n      {{ opcao.label }}\n    </mat-radio-button>\n  }\n</mat-radio-group>\n", styles: [":host{display:block}.s-radio-group__grupo{display:flex;flex-direction:column;gap:var(--space-8, 8px)}:host(.s-radio-group--horizontal) .s-radio-group__grupo{flex-direction:row;flex-wrap:wrap;gap:var(--space-16, 16px)}.s-radio-group__grupo{--mat-radio-label-text-font: var(--font-ui);--mat-radio-label-text-size: var(--text-body, 14px);--mat-radio-label-text-color: var(--text-primary);--mat-radio-disabled-label-color: var(--text-primary);--mat-radio-selected-icon-color: var(--primary);--mat-radio-selected-hover-icon-color: var(--primary-hover);--mat-radio-selected-focus-icon-color: var(--primary);--mat-radio-selected-pressed-icon-color: var(--primary-hover);--mat-radio-unselected-icon-color: var(--border);--mat-radio-unselected-hover-icon-color: var(--text-secondary);--mat-radio-ripple-color: var(--text-primary);--mat-radio-state-layer-size: 36px}::ng-deep .s-radio-group__grupo .mat-mdc-radio-button.mat-mdc-radio-disabled{opacity:.4}\n"], dependencies: [{ kind: "ngmodule", type: MatRadioModule }, { kind: "directive", type: i1$7.MatRadioGroup, selector: "mat-radio-group", inputs: ["color", "name", "labelPosition", "value", "selected", "disabled", "required", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioGroup"] }, { kind: "component", type: i1$7.MatRadioButton, selector: "mat-radio-button", inputs: ["id", "name", "aria-label", "aria-labelledby", "aria-describedby", "disableRipple", "tabIndex", "checked", "value", "labelPosition", "disabled", "required", "color", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioButton"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SRadioGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-radio-group', imports: [MatRadioModule], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SRadioGroupComponent),
                            multi: true,
                        },
                    ], host: {
                        class: 's-radio-group',
                        '[class.s-radio-group--horizontal]': "orientation() === 'horizontal'",
                    }, template: "<mat-radio-group\n  class=\"s-radio-group__grupo\"\n  [name]=\"nome()\"\n  [value]=\"value()\"\n  [disabled]=\"isDisabled() || readOnly()\"\n  [attr.aria-labelledby]=\"labelledBy()\"\n  [attr.aria-label]=\"ariaLabel()\"\n  [attr.aria-describedby]=\"describedBy()\"\n  [attr.aria-required]=\"required() ? 'true' : null\"\n  (change)=\"onSelectionChange($event)\"\n  (focusout)=\"onGroupFocusOut($event)\"\n>\n  @for (opcao of options(); track opcao.value) {\n    <mat-radio-button [value]=\"opcao.value\" [disabled]=\"opcao.disabled ?? false\">\n      {{ opcao.label }}\n    </mat-radio-button>\n  }\n</mat-radio-group>\n", styles: [":host{display:block}.s-radio-group__grupo{display:flex;flex-direction:column;gap:var(--space-8, 8px)}:host(.s-radio-group--horizontal) .s-radio-group__grupo{flex-direction:row;flex-wrap:wrap;gap:var(--space-16, 16px)}.s-radio-group__grupo{--mat-radio-label-text-font: var(--font-ui);--mat-radio-label-text-size: var(--text-body, 14px);--mat-radio-label-text-color: var(--text-primary);--mat-radio-disabled-label-color: var(--text-primary);--mat-radio-selected-icon-color: var(--primary);--mat-radio-selected-hover-icon-color: var(--primary-hover);--mat-radio-selected-focus-icon-color: var(--primary);--mat-radio-selected-pressed-icon-color: var(--primary-hover);--mat-radio-unselected-icon-color: var(--border);--mat-radio-unselected-hover-icon-color: var(--text-secondary);--mat-radio-ripple-color: var(--text-primary);--mat-radio-state-layer-size: 36px}::ng-deep .s-radio-group__grupo .mat-mdc-radio-button.mat-mdc-radio-disabled{opacity:.4}\n"] }]
        }], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], selectionChange: [{ type: i0.Output, args: ["selectionChange"] }] } });

/**
 * Escolha em botoes, unica ou multipla.
 *
 * E o controle dos filtros rapidos e das escalas curtas — turno, dia da
 * semana, situacao. A diferenca para o `<s-radio-group>` nao e visual: aqui
 * cada opcao e um **alvo grande**, feito para ser tocado, e a escolha costuma
 * aplicar na hora.
 *
 * **Nao esta no guia de design.** Cada opcao e um `<s-button>`: o escolhido
 * cheio (`primary`), os demais contornados — a escolha nao depende so da
 * borda. Em tela estreita, os botoes empilham.
 *
 * Cada botao anuncia o proprio estado (`aria-pressed`) e o conjunto e um
 * `role="group"` rotulado pelo `<s-field>`. Na escolha unica, `groupRole="radiogroup"`
 * troca isso por `radiogroup` + `radio` com `aria-checked` e navegacao por setas.
 * Sem rotulo do `<s-field>`, nomeie o grupo com `ariaLabel` ou `ariaLabelledby`.
 */
class SSelectionButtonsComponent extends SControlBase {
    /**
     * Opcoes exibidas: `SSelectionOption`, ou qualquer objeto com as chaves de
     * `optionLabel` e `optionValue` (um enum `{ value, name }`, uma lista da API).
     */
    options = input([], ...(ngDevMode ? [{ debugName: "options" }] : []));
    /** Chave do rotulo em cada opcao. Padrao: `label`. */
    optionLabel = input('label', ...(ngDevMode ? [{ debugName: "optionLabel" }] : []));
    /** Chave do valor em cada opcao. Padrao: `value`. */
    optionValue = input('value', ...(ngDevMode ? [{ debugName: "optionValue" }] : []));
    /** Permite escolher mais de uma. O valor passa a ser um array. */
    multiple = input(false, ...(ngDevMode ? [{ debugName: "multiple", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Permite desmarcar clicando na opcao ja escolhida.
     *
     * So vale na escolha unica — no modo multiplo desmarcar sempre funciona. Sem
     * isto, uma escolha feita por engano so se corrige escolhendo outra. Em
     * `groupRole="radiogroup"` e ignorado: radio nunca desmarca (WAI-ARIA).
     */
    allowDeselection = input(true, ...(ngDevMode ? [{ debugName: "allowDeselection", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Linha de resumo abaixo dos botoes: "Selecionadas: Aula 1, Aula 2", ou
     * "Nenhuma opção selecionada" no modo multiplo.
     */
    showSelectedSummary = input(false, ...(ngDevMode ? [{ debugName: "showSelectedSummary", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Uma opcao foi clicada, com o valor dela. Chega depois do formulario ja ter
     * o valor novo — a tela pode validar aqui.
     */
    optionClick = output();
    /**
     * Nome acessivel do grupo, para quando o `<s-field>` nao da rotulo (`label`
     * vazio ou ausente) e o `label` do proprio controle tambem nao existe. O
     * rotulo do campo, quando existe, prevalece.
     */
    ariaLabel = input('', ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
    /**
     * Id de um elemento externo que nomeia o grupo (o titulo do cartao, por
     * exemplo). O rotulo do `<s-field>`, quando existe, prevalece.
     */
    ariaLabelledby = input('', ...(ngDevMode ? [{ debugName: "ariaLabelledby" }] : []));
    /**
     * Papel do conjunto. `radiogroup` so vale na escolha unica: o container vira
     * `radiogroup`, cada botao vira `radio` com `aria-checked`, so a opcao
     * marcada (ou a primeira) fica no Tab e as setas, Home e End movem foco e
     * escolha. Nesse papel, clicar ou apertar Espaco na opcao marcada nao a
     * desmarca (`allowDeselection` e ignorado). Com `multiple`, ou no padrao
     * `group`, nada disso muda.
     */
    groupRole = input('group', ...(ngDevMode ? [{ debugName: "groupRole" }] : []));
    campo = usarCampo('s-selection-buttons');
    host = inject(ElementRef);
    describedBy = this.campo.describedBy;
    labelledBy = computed(() => this.campo.rotuladoPor() ?? (this.ariaLabelledby() || null), ...(ngDevMode ? [{ debugName: "labelledBy" }] : []));
    rotuloAvulso = this.campo.rotuloAvulso(this.label);
    rotuloGrupo = computed(() => this.rotuloAvulso() ?? (this.labelledBy() ? null : this.ariaLabel() || null), ...(ngDevMode ? [{ debugName: "rotuloGrupo" }] : []));
    required = this.campo.obrigatorio;
    radio = computed(() => this.groupRole() === 'radiogroup' && !this.multiple(), ...(ngDevMode ? [{ debugName: "radio" }] : []));
    /** Valores escolhidos, como lista, nos dois modos. */
    escolhidos = computed(() => {
        const atual = this.value();
        if (Array.isArray(atual)) {
            return this.multiple() ? atual : atual.slice(0, 1);
        }
        return atual === null || atual === undefined ? [] : [atual];
    }, ...(ngDevMode ? [{ debugName: "escolhidos" }] : []));
    opcoes = computed(() => this.options().map((item) => {
        const opcao = item;
        const valor = opcao[this.optionValue()];
        const marcada = this.escolhidos().includes(valor);
        return {
            valor,
            rotulo: String(opcao[this.optionLabel()] ?? ''),
            marcada,
            icone: opcao.icon || (marcada ? 'check' : ''),
            desabilitada: !!opcao.disabled,
        };
    }), ...(ngDevMode ? [{ debugName: "opcoes" }] : []));
    resumo = computed(() => {
        const nomes = this.opcoes()
            .filter((opcao) => opcao.marcada)
            .map((opcao) => opcao.rotulo);
        if (!nomes.length) {
            // Na escolha unica, "nenhuma" e o estado inicial, nao uma informacao.
            return this.multiple() ? 'Nenhuma opção selecionada' : '';
        }
        return this.multiple() ? `Selecionadas: ${nomes.join(', ')}` : `Selecionada: ${nomes[0]}`;
    }, ...(ngDevMode ? [{ debugName: "resumo" }] : []));
    bloqueado(desabilitada) {
        return this.isDisabled() || this.readOnly() || desabilitada;
    }
    /** Opcao que entra no Tab no modo `radiogroup`: a marcada, ou a primeira habilitada. */
    indiceTab = computed(() => {
        const lista = this.opcoes();
        const marcada = lista.findIndex((o) => o.marcada && !o.desabilitada);
        return marcada >= 0 ? marcada : lista.findIndex((o) => !o.desabilitada);
    }, ...(ngDevMode ? [{ debugName: "indiceTab" }] : []));
    tabIndexDe(indice) {
        if (!this.radio()) {
            return null;
        }
        return indice === this.indiceTab() ? 0 : -1;
    }
    /** Setas, Home e End no modo `radiogroup`: movem foco e escolha, pulando desabilitadas. */
    aoTeclar(evento) {
        if (!this.radio() || this.isDisabled() || this.readOnly()) {
            return;
        }
        const botoes = Array.from(this.host.nativeElement.querySelectorAll('button.s-button__native'));
        const atual = botoes.indexOf(evento.target);
        const lista = this.opcoes();
        const habilitadas = lista.map((o, i) => i).filter((i) => !lista[i].desabilitada);
        if (atual < 0 || !habilitadas.length) {
            return;
        }
        const pos = habilitadas.indexOf(atual);
        let destino;
        switch (evento.key) {
            case 'ArrowRight':
            case 'ArrowDown':
                destino = habilitadas[(pos + 1) % habilitadas.length];
                break;
            case 'ArrowLeft':
            case 'ArrowUp':
                destino = habilitadas[(pos - 1 + habilitadas.length) % habilitadas.length];
                break;
            case 'Home':
                destino = habilitadas[0];
                break;
            case 'End':
                destino = habilitadas[habilitadas.length - 1];
                break;
            default:
                return;
        }
        evento.preventDefault();
        botoes[destino]?.focus();
        if (destino !== atual || !lista[destino].marcada) {
            this.setValue(lista[destino].valor);
            this.onTouched();
            this.optionClick.emit(lista[destino].valor);
        }
    }
    alternar(valor, desabilitada) {
        if (this.bloqueado(desabilitada)) {
            return;
        }
        if (this.multiple()) {
            const atuais = this.escolhidos();
            this.setValue(atuais.includes(valor) ? atuais.filter((v) => v !== valor) : [...atuais, valor]);
        }
        else if (this.escolhidos().includes(valor)) {
            if (this.allowDeselection() && !this.radio()) {
                this.setValue(null);
            }
        }
        else {
            this.setValue(valor);
        }
        // Quem escolhe ja tocou no campo: a validacao aparece sem esperar o foco sair.
        this.onTouched();
        this.optionClick.emit(valor);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SSelectionButtonsComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SSelectionButtonsComponent, isStandalone: true, selector: "s-selection-buttons", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, optionLabel: { classPropertyName: "optionLabel", publicName: "optionLabel", isSignal: true, isRequired: false, transformFunction: null }, optionValue: { classPropertyName: "optionValue", publicName: "optionValue", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, allowDeselection: { classPropertyName: "allowDeselection", publicName: "allowDeselection", isSignal: true, isRequired: false, transformFunction: null }, showSelectedSummary: { classPropertyName: "showSelectedSummary", publicName: "showSelectedSummary", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledby: { classPropertyName: "ariaLabelledby", publicName: "ariaLabelledby", isSignal: true, isRequired: false, transformFunction: null }, groupRole: { classPropertyName: "groupRole", publicName: "groupRole", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { optionClick: "optionClick" }, host: { classAttribute: "s-selection-buttons" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SSelectionButtonsComponent),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: "<div\n  class=\"s-selection-buttons__grupo\"\n  [attr.role]=\"radio() ? 'radiogroup' : 'group'\"\n  [class.s-selection-buttons__grupo--readonly]=\"readOnly() && !isDisabled()\"\n  [attr.aria-labelledby]=\"labelledBy()\"\n  [attr.aria-label]=\"rotuloGrupo()\"\n  [attr.aria-describedby]=\"describedBy()\"\n  [attr.aria-required]=\"required() ? 'true' : null\"\n  [attr.aria-readonly]=\"radio() && readOnly() ? 'true' : null\"\n  [attr.aria-disabled]=\"radio() && isDisabled() ? 'true' : null\"\n  (keydown)=\"aoTeclar($event)\"\n  (focusout)=\"onGroupFocusOut($event)\"\n>\n  @for (opcao of opcoes(); track opcao.valor; let i = $index) {\n    <s-button\n      class=\"s-selection-buttons__opcao\"\n      [class.s-selection-buttons__opcao--marcada]=\"opcao.marcada\"\n      [variant]=\"opcao.marcada ? 'primary' : 'secondary'\"\n      [outlined]=\"!opcao.marcada\"\n      [icon]=\"opcao.icone\"\n      [disabled]=\"bloqueado(opcao.desabilitada)\"\n      [pressed]=\"radio() ? null : opcao.marcada\"\n      [buttonRole]=\"radio() ? 'radio' : null\"\n      [checked]=\"radio() ? opcao.marcada : null\"\n      [focusIndex]=\"tabIndexDe(i)\"\n      (click)=\"alternar(opcao.valor, opcao.desabilitada)\"\n    >\n      {{ opcao.rotulo }}\n    </s-button>\n  }\n</div>\n\n@if (showSelectedSummary() && resumo()) {\n  <small class=\"s-selection-buttons__resumo\">{{ resumo() }}</small>\n}\n", styles: [":host{display:flex;flex-direction:column;gap:var(--space-8, 8px)}.s-selection-buttons__grupo{display:flex;flex-wrap:wrap;gap:var(--space-8, 8px)}@media(max-width:575.98px){.s-selection-buttons__grupo{flex-direction:column}}.s-selection-buttons__resumo{font-size:var(--text-caption, 12px);color:var(--text-secondary)}\n"], dependencies: [{ kind: "component", type: SButtonComponent, selector: "s-button", inputs: ["variant", "outlined", "fullWidth", "pressed", "buttonRole", "checked", "focusIndex", "loading", "loadingText", "disabled", "icon", "iconRight", "type", "label"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SSelectionButtonsComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-selection-buttons', imports: [SButtonComponent], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SSelectionButtonsComponent),
                            multi: true,
                        },
                    ], host: {
                        class: 's-selection-buttons',
                    }, template: "<div\n  class=\"s-selection-buttons__grupo\"\n  [attr.role]=\"radio() ? 'radiogroup' : 'group'\"\n  [class.s-selection-buttons__grupo--readonly]=\"readOnly() && !isDisabled()\"\n  [attr.aria-labelledby]=\"labelledBy()\"\n  [attr.aria-label]=\"rotuloGrupo()\"\n  [attr.aria-describedby]=\"describedBy()\"\n  [attr.aria-required]=\"required() ? 'true' : null\"\n  [attr.aria-readonly]=\"radio() && readOnly() ? 'true' : null\"\n  [attr.aria-disabled]=\"radio() && isDisabled() ? 'true' : null\"\n  (keydown)=\"aoTeclar($event)\"\n  (focusout)=\"onGroupFocusOut($event)\"\n>\n  @for (opcao of opcoes(); track opcao.valor; let i = $index) {\n    <s-button\n      class=\"s-selection-buttons__opcao\"\n      [class.s-selection-buttons__opcao--marcada]=\"opcao.marcada\"\n      [variant]=\"opcao.marcada ? 'primary' : 'secondary'\"\n      [outlined]=\"!opcao.marcada\"\n      [icon]=\"opcao.icone\"\n      [disabled]=\"bloqueado(opcao.desabilitada)\"\n      [pressed]=\"radio() ? null : opcao.marcada\"\n      [buttonRole]=\"radio() ? 'radio' : null\"\n      [checked]=\"radio() ? opcao.marcada : null\"\n      [focusIndex]=\"tabIndexDe(i)\"\n      (click)=\"alternar(opcao.valor, opcao.desabilitada)\"\n    >\n      {{ opcao.rotulo }}\n    </s-button>\n  }\n</div>\n\n@if (showSelectedSummary() && resumo()) {\n  <small class=\"s-selection-buttons__resumo\">{{ resumo() }}</small>\n}\n", styles: [":host{display:flex;flex-direction:column;gap:var(--space-8, 8px)}.s-selection-buttons__grupo{display:flex;flex-wrap:wrap;gap:var(--space-8, 8px)}@media(max-width:575.98px){.s-selection-buttons__grupo{flex-direction:column}}.s-selection-buttons__resumo{font-size:var(--text-caption, 12px);color:var(--text-secondary)}\n"] }]
        }], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], optionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionLabel", required: false }] }], optionValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionValue", required: false }] }], multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], allowDeselection: [{ type: i0.Input, args: [{ isSignal: true, alias: "allowDeselection", required: false }] }], showSelectedSummary: [{ type: i0.Input, args: [{ isSignal: true, alias: "showSelectedSummary", required: false }] }], optionClick: [{ type: i0.Output, args: ["optionClick"] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledby: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledby", required: false }] }], groupRole: [{ type: i0.Input, args: [{ isSignal: true, alias: "groupRole", required: false }] }] } });

/**
 * Navegacao por abas dentro de uma tela.
 *
 * **Nao esta no guia de design.** Entrou porque o Professores usa abas para
 * separar secoes de um mesmo registro — frequencia, notas, plano — e sem um
 * componente cada tela desenharia as suas.
 *
 * Nao envolve o `mat-tab-group`: ele gerencia o **conteudo** das abas, com
 * animacao de troca e lazy rendering. Aqui as abas so navegam; o conteudo e da
 * tela, e muitas vezes de uma rota filha. Trazer o grupo do Material
 * significaria adotar o modelo de conteudo dele junto.
 *
 * Sao `<button>` de verdade, com `role="tab"`: setas do teclado e leitor de
 * tela funcionam sem a tela ligar nada.
 */
class STabsComponent {
    /** Abas, na ordem. */
    tabs = input([], ...(ngDevMode ? [{ debugName: "tabs" }] : []));
    /** Id da aba ativa. */
    activeId = input('', ...(ngDevMode ? [{ debugName: "activeId" }] : []));
    /** Rotulo acessivel do grupo, quando a tela tem mais de um. */
    label = input('Seções', ...(ngDevMode ? [{ debugName: "label" }] : []));
    /** Aba escolhida. */
    tabChange = output();
    el = inject(ElementRef);
    prefixo = proximoId('s-tabs');
    /**
     * A aba que fica na ordem do Tab: a ativa, ou a primeira disponivel quando
     * `activeId` nao bate com nenhuma. Sem esse recuo, um `activeId` errado
     * deixava todas com `tabindex=-1` e a lista sumia do teclado.
     */
    focavel = computed(() => {
        const disponiveis = this.tabs().filter((aba) => !aba.disabled);
        return (disponiveis.find((aba) => this.ehAtiva(aba)) ?? disponiveis[0])?.id ?? null;
    }, ...(ngDevMode ? [{ debugName: "focavel" }] : []));
    /**
     * Id do botao da aba. Use no `aria-labelledby` do painel:
     *
     * ```html
     * <s-tabs #abas [tabs]="abas" [activeId]="ativa()" (tabChange)="ativa.set($event)" />
     * <div role="tabpanel" [id]="abas.panelElementId(ativa())"
     *      [attr.aria-labelledby]="abas.tabElementId(ativa())">...</div>
     * ```
     */
    tabElementId(id) {
        return `${this.prefixo}-aba-${id}`;
    }
    /** Id esperado do painel da aba - e para onde o `aria-controls` dela aponta. */
    panelElementId(id) {
        return `${this.prefixo}-painel-${id}`;
    }
    ehAtiva(aba) {
        return aba.id === this.activeId();
    }
    escolher(aba) {
        if (!aba.disabled && !this.ehAtiva(aba)) {
            this.tabChange.emit(aba.id);
        }
    }
    /** Setas navegam entre abas, pulando as desabilitadas. Home/End vao a primeira/ultima. */
    aoTeclar(evento) {
        const disponiveis = this.tabs().filter((aba) => !aba.disabled);
        if (disponiveis.length === 0) {
            return;
        }
        const atual = disponiveis.findIndex((aba) => aba.id === this.focavel());
        if (atual === -1) {
            return;
        }
        let destino;
        switch (evento.key) {
            case 'ArrowRight':
                destino = (atual + 1) % disponiveis.length;
                break;
            case 'ArrowLeft':
                destino = (atual - 1 + disponiveis.length) % disponiveis.length;
                break;
            case 'Home':
                destino = 0;
                break;
            case 'End':
                destino = disponiveis.length - 1;
                break;
            default:
                return;
        }
        evento.preventDefault();
        const abaDestino = disponiveis[destino];
        this.tabChange.emit(abaDestino.id);
        // Roving tabindex: move o foco DOM para o botao da aba de destino.
        const botoes = this.el.nativeElement.querySelectorAll('.s-tabs__aba:not(:disabled)');
        botoes[destino]?.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: STabsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: STabsComponent, isStandalone: true, selector: "s-tabs", inputs: { tabs: { classPropertyName: "tabs", publicName: "tabs", isSignal: true, isRequired: false, transformFunction: null }, activeId: { classPropertyName: "activeId", publicName: "activeId", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { tabChange: "tabChange" }, host: { classAttribute: "s-tabs" }, ngImport: i0, template: "<div class=\"s-tabs__lista\" role=\"tablist\" [attr.aria-label]=\"label()\" (keydown)=\"aoTeclar($event)\">\n  @for (aba of tabs(); track aba.id) {\n    <button\n      type=\"button\"\n      role=\"tab\"\n      class=\"s-tabs__aba\"\n      [class.s-tabs__aba--ativa]=\"ehAtiva(aba)\"\n      [attr.aria-selected]=\"ehAtiva(aba)\"\n      [id]=\"tabElementId(aba.id)\"\n      [attr.aria-controls]=\"panelElementId(aba.id)\"\n      [attr.tabindex]=\"aba.id === focavel() ? 0 : -1\"\n      [disabled]=\"aba.disabled ?? false\"\n      (click)=\"escolher(aba)\"\n    >\n      @if (aba.icon) {\n        <s-icon [name]=\"aba.icon\" size=\"sm\" />\n      }\n\n      <span>{{ aba.label }}</span>\n\n      @if (aba.badge) {\n        <s-badge tone=\"secondary\">{{ aba.badge }}</s-badge>\n      }\n    </button>\n  }\n</div>\n", styles: [":host{display:block;font-family:var(--font-ui)}.s-tabs__lista{display:flex;align-items:stretch;gap:var(--space-4, 4px);border-bottom:1px solid var(--card-border);overflow-x:auto;overflow-y:hidden}.s-tabs__aba{display:inline-flex;align-items:center;gap:var(--space-8, 8px);height:var(--control-h, 40px);padding:0 var(--space-16, 16px);border:none;border-bottom:2px solid transparent;margin-bottom:-1px;background:transparent;font-family:inherit;font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);color:var(--text-secondary);white-space:nowrap;cursor:pointer;transition:color .15s ease,border-color .15s ease}.s-tabs__aba:hover:not(:disabled){color:var(--text-primary)}.s-tabs__aba:disabled{opacity:.4;cursor:default}.s-tabs__aba:focus-visible{outline:none;border-radius:var(--radius-control, 8px) var(--radius-control, 8px) 0 0;box-shadow:0 0 0 2px var(--background),0 0 0 5px var(--focus-ring)}.s-tabs__aba--ativa{color:var(--primary);border-bottom-color:var(--primary)}\n"], dependencies: [{ kind: "component", type: SBadgeComponent, selector: "s-badge", inputs: ["tone", "wrap", "icon"] }, { kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: STabsComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-tabs', imports: [SBadgeComponent, SIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-tabs',
                    }, template: "<div class=\"s-tabs__lista\" role=\"tablist\" [attr.aria-label]=\"label()\" (keydown)=\"aoTeclar($event)\">\n  @for (aba of tabs(); track aba.id) {\n    <button\n      type=\"button\"\n      role=\"tab\"\n      class=\"s-tabs__aba\"\n      [class.s-tabs__aba--ativa]=\"ehAtiva(aba)\"\n      [attr.aria-selected]=\"ehAtiva(aba)\"\n      [id]=\"tabElementId(aba.id)\"\n      [attr.aria-controls]=\"panelElementId(aba.id)\"\n      [attr.tabindex]=\"aba.id === focavel() ? 0 : -1\"\n      [disabled]=\"aba.disabled ?? false\"\n      (click)=\"escolher(aba)\"\n    >\n      @if (aba.icon) {\n        <s-icon [name]=\"aba.icon\" size=\"sm\" />\n      }\n\n      <span>{{ aba.label }}</span>\n\n      @if (aba.badge) {\n        <s-badge tone=\"secondary\">{{ aba.badge }}</s-badge>\n      }\n    </button>\n  }\n</div>\n", styles: [":host{display:block;font-family:var(--font-ui)}.s-tabs__lista{display:flex;align-items:stretch;gap:var(--space-4, 4px);border-bottom:1px solid var(--card-border);overflow-x:auto;overflow-y:hidden}.s-tabs__aba{display:inline-flex;align-items:center;gap:var(--space-8, 8px);height:var(--control-h, 40px);padding:0 var(--space-16, 16px);border:none;border-bottom:2px solid transparent;margin-bottom:-1px;background:transparent;font-family:inherit;font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);color:var(--text-secondary);white-space:nowrap;cursor:pointer;transition:color .15s ease,border-color .15s ease}.s-tabs__aba:hover:not(:disabled){color:var(--text-primary)}.s-tabs__aba:disabled{opacity:.4;cursor:default}.s-tabs__aba:focus-visible{outline:none;border-radius:var(--radius-control, 8px) var(--radius-control, 8px) 0 0;box-shadow:0 0 0 2px var(--background),0 0 0 5px var(--focus-ring)}.s-tabs__aba--ativa{color:var(--primary);border-bottom-color:var(--primary)}\n"] }]
        }], propDecorators: { tabs: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabs", required: false }] }], activeId: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeId", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], tabChange: [{ type: i0.Output, args: ["tabChange"] }] } });

/**
 * Grupo de secoes que abrem e fecham dentro de uma tela.
 *
 * Por padrao abre uma secao por vez: abrir outra fecha a anterior. Com `multi`,
 * cada uma abre e fecha sozinha.
 *
 * As setas do teclado andam entre os cabecalhos (Home e End vao ao primeiro e
 * ao ultimo), pulando os desabilitados.
 *
 * @example
 * ```html
 * <s-accordion>
 *   <s-accordion-item title="Dados gerais" expanded>...</s-accordion-item>
 *   <s-accordion-item title="Historico">...</s-accordion-item>
 * </s-accordion>
 * ```
 */
class SAccordionComponent {
    /** Permite mais de uma secao aberta ao mesmo tempo. */
    multi = input(false, ...(ngDevMode ? [{ debugName: "multi", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    cdk = inject(CdkAccordion);
    host = inject(ElementRef);
    constructor() {
        effect(() => {
            this.cdk.multi = this.multi();
        });
    }
    /** Setas, Home e End entre os cabecalhos deste grupo — nao dos aninhados. */
    aoTeclar(evento) {
        const alvo = evento.target;
        if (!alvo.classList.contains('s-accordion-item__header')) {
            return;
        }
        const cabecalhos = Array.from(this.host.nativeElement.querySelectorAll(':scope > .s-accordion-item > .s-accordion-item__heading > .s-accordion-item__header'));
        const atual = cabecalhos.indexOf(alvo);
        if (atual < 0) {
            return;
        }
        const habilitados = cabecalhos.filter((cabecalho) => !cabecalho.disabled);
        const posicao = habilitados.indexOf(alvo);
        let destino;
        switch (evento.key) {
            case 'ArrowDown':
                destino = habilitados[(posicao + 1) % habilitados.length];
                break;
            case 'ArrowUp':
                destino = habilitados[(posicao - 1 + habilitados.length) % habilitados.length];
                break;
            case 'Home':
                destino = habilitados[0];
                break;
            case 'End':
                destino = habilitados[habilitados.length - 1];
                break;
            default:
                return;
        }
        evento.preventDefault();
        destino?.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAccordionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.34", type: SAccordionComponent, isStandalone: true, selector: "s-accordion", inputs: { multi: { classPropertyName: "multi", publicName: "multi", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "keydown": "aoTeclar($event)" }, classAttribute: "s-accordion" }, hostDirectives: [{ directive: i1$8.CdkAccordion }], ngImport: i0, template: `<ng-content />`, isInline: true, styles: [":host{display:block;overflow:hidden;background:var(--card);border:1px solid var(--card-border);border-radius:var(--radius-container, 12px)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAccordionComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-accordion', template: `<ng-content />`, changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [CdkAccordion], host: {
                        class: 's-accordion',
                        '(keydown)': 'aoTeclar($event)',
                    }, styles: [":host{display:block;overflow:hidden;background:var(--card);border:1px solid var(--card-border);border-radius:var(--radius-container, 12px)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { multi: [{ type: i0.Input, args: [{ isSignal: true, alias: "multi", required: false }] }] } });
/**
 * Conteudo que so e montado quando a secao abre.
 *
 * Para secoes caras — uma tabela que consulta a API, um grafico. Quanto tempo
 * ele fica montado depende do `lazyContent` do item: por padrao (`keep`), fica
 * depois da primeira abertura, e fechar e abrir de novo nao refaz a consulta
 * nem perde o que foi digitado; com `reload`, e desmontado ao fechar e montado
 * de novo a cada abertura, buscando dados frescos.
 *
 * @example
 * ```html
 * <s-accordion-item title="Historico">
 *   <ng-template sAccordionContent>
 *     <app-historico [id]="id" />
 *   </ng-template>
 * </s-accordion-item>
 * ```
 */
class SAccordionContentDirective {
    template = inject(TemplateRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAccordionContentDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.34", type: SAccordionContentDirective, isStandalone: true, selector: "ng-template[sAccordionContent]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAccordionContentDirective, decorators: [{
            type: Directive,
            args: [{ selector: 'ng-template[sAccordionContent]' }]
        }] });
/**
 * Cabecalho proprio no lugar do `title`: um contador, um badge de status, uma
 * segunda linha de texto.
 *
 * O template entra **dentro do botao** que abre a secao. Por isso nao pode ter
 * nada clicavel — botao, link ou campo dentro de botao e HTML invalido e o
 * leitor de tela nao chega neles. O glifo de abrir e fechar continua sendo do
 * componente.
 *
 * Mantenha o `title` mesmo com o template: ele vira o contexto (`let-titulo`).
 *
 * @example
 * ```html
 * <s-accordion-item title="Pendencias">
 *   <ng-template sAccordionHeader let-titulo let-aberto="expanded">
 *     {{ titulo }} <s-badge tone="warning">3</s-badge>
 *   </ng-template>
 *   ...
 * </s-accordion-item>
 * ```
 */
class SAccordionHeaderDirective {
    template = inject(TemplateRef);
    static ngTemplateContextGuard(_diretiva, contexto) {
        return true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAccordionHeaderDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.34", type: SAccordionHeaderDirective, isStandalone: true, selector: "ng-template[sAccordionHeader]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAccordionHeaderDirective, decorators: [{
            type: Directive,
            args: [{ selector: 'ng-template[sAccordionHeader]' }]
        }] });
/**
 * Uma secao do `<s-accordion>`.
 *
 * O cabecalho e um `<button>` dentro de um titulo (`role="heading"`), entao a
 * secao aparece na lista de titulos do leitor de tela. O painel continua no DOM
 * fechado, so escondido: o que foi digitado nele nao se perde ao fechar.
 */
class SAccordionItemComponent {
    /**
     * Texto do cabecalho. Com `<ng-template sAccordionHeader>`, o template ocupa
     * o lugar dele e o recebe no contexto.
     */
    title = input('', ...(ngDevMode ? [{ debugName: "title" }] : []));
    /**
     * Secao aberta. Funciona sozinho, como valor inicial, ou ligado nos dois
     * sentidos: `[(expanded)]="aberto"`.
     */
    expanded = input(false, ...(ngDevMode ? [{ debugName: "expanded", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Mantem a secao na lista, mas sem abrir nem fechar. */
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Nivel do titulo para o leitor de tela. O padrao, 3, serve dentro de uma
     * pagina com `<h1>` no page-header e `<h2>` nas secoes; ajuste se o grupo
     * estiver em outro nivel.
     */
    headingLevel = input(3, ...(ngDevMode ? [{ debugName: "headingLevel", transform: numberAttribute }] : [{ transform: numberAttribute }]));
    /**
     * Quanto tempo o `<ng-template sAccordionContent>` fica montado: `keep`
     * (padrao) mantem depois da primeira abertura; `reload` monta de novo a cada
     * abertura. Nao afeta o conteudo projetado direto no item, que e sempre
     * mantido.
     */
    lazyContent = input('keep', ...(ngDevMode ? [{ debugName: "lazyContent" }] : []));
    /** A secao abriu ou fechou: pelo clique ou porque outra abriu no grupo. */
    expandedChange = output();
    conteudoTardio = contentChild(SAccordionContentDirective, ...(ngDevMode ? [{ debugName: "conteudoTardio" }] : []));
    cabecalho = contentChild(SAccordionHeaderDirective, ...(ngDevMode ? [{ debugName: "cabecalho" }] : []));
    /** Estado que esta na tela, venha do input, do clique ou do grupo. */
    aberto = linkedSignal(() => this.expanded(), ...(ngDevMode ? [{ debugName: "aberto" }] : []));
    /** Ja abriu alguma vez: no modo `keep`, o conteudo tardio fica montado. */
    jaAbriu = signal(false, ...(ngDevMode ? [{ debugName: "jaAbriu" }] : []));
    /** O conteudo tardio esta montado agora. */
    montaTardio = computed(() => this.lazyContent() === 'reload' ? this.aberto() : this.jaAbriu(), ...(ngDevMode ? [{ debugName: "montaTardio" }] : []));
    contextoCabecalho = computed(() => ({
        $implicit: this.title(),
        expanded: this.aberto(),
        disabled: this.disabled(),
    }), ...(ngDevMode ? [{ debugName: "contextoCabecalho" }] : []));
    cdk = inject(CdkAccordionItem);
    prefixo = proximoId('s-accordion-item');
    headerId = `${this.prefixo}-header`;
    panelId = `${this.prefixo}-panel`;
    /** Escrita vinda do input: o CDK avisa, mas a tela nao precisa ouvir de volta. */
    sincronizando = false;
    constructor() {
        effect(() => {
            const valor = this.expanded();
            untracked(() => {
                this.sincronizando = true;
                this.cdk.expanded = valor;
                this.sincronizando = false;
            });
        });
        effect(() => {
            this.cdk.disabled = this.disabled();
        });
        effect(() => {
            if (this.aberto()) {
                untracked(() => this.jaAbriu.set(true));
            }
        });
        this.cdk.expandedChange.pipe(takeUntilDestroyed()).subscribe((valor) => {
            this.aberto.set(valor);
            if (!this.sincronizando) {
                this.expandedChange.emit(valor);
            }
        });
    }
    alternar() {
        if (!this.disabled()) {
            this.cdk.toggle();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAccordionItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SAccordionItemComponent, isStandalone: true, selector: "s-accordion-item", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, expanded: { classPropertyName: "expanded", publicName: "expanded", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, headingLevel: { classPropertyName: "headingLevel", publicName: "headingLevel", isSignal: true, isRequired: false, transformFunction: null }, lazyContent: { classPropertyName: "lazyContent", publicName: "lazyContent", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { expandedChange: "expandedChange" }, host: { properties: { "class.s-accordion-item--expanded": "aberto()", "class.s-accordion-item--disabled": "disabled()" }, classAttribute: "s-accordion-item" }, queries: [{ propertyName: "conteudoTardio", first: true, predicate: SAccordionContentDirective, descendants: true, isSignal: true }, { propertyName: "cabecalho", first: true, predicate: SAccordionHeaderDirective, descendants: true, isSignal: true }], hostDirectives: [{ directive: i1$8.CdkAccordionItem }], ngImport: i0, template: "<div class=\"s-accordion-item__heading\" role=\"heading\" [attr.aria-level]=\"headingLevel()\">\n  <button\n    class=\"s-accordion-item__header\"\n    type=\"button\"\n    [id]=\"headerId\"\n    [disabled]=\"disabled()\"\n    [attr.aria-expanded]=\"aberto()\"\n    [attr.aria-controls]=\"panelId\"\n    (click)=\"alternar()\"\n  >\n    <span class=\"s-accordion-item__title\">\n      @if (cabecalho(); as proprio) {\n        <ng-container\n          [ngTemplateOutlet]=\"proprio.template\"\n          [ngTemplateOutletContext]=\"contextoCabecalho()\"\n        />\n      } @else {\n        {{ title() }}\n      }\n    </span>\n    <s-icon class=\"s-accordion-item__icon\" name=\"expand_more\" />\n  </button>\n</div>\n\n<div\n  class=\"s-accordion-item__panel\"\n  role=\"region\"\n  [id]=\"panelId\"\n  [attr.aria-labelledby]=\"headerId\"\n  [hidden]=\"!aberto()\"\n>\n  <ng-content />\n  @if (montaTardio() && conteudoTardio(); as tardio) {\n    <ng-container [ngTemplateOutlet]=\"tardio.template\" />\n  }\n</div>\n", styles: [":host{display:block}:host(:not(:first-of-type)){border-top:1px solid var(--card-border)}.s-accordion-item__heading{margin:0}.s-accordion-item__header{width:100%;min-height:48px;display:flex;align-items:center;justify-content:space-between;gap:var(--space-16);padding:var(--space-12) var(--space-16);border:0;background:transparent;color:var(--text-primary);font-family:var(--font-ui);font-size:var(--text-body, 14px);font-weight:var(--weight-semibold, 600);text-align:left;cursor:pointer;transition:background-color .15s ease}.s-accordion-item__header:hover:not(:disabled){background:color-mix(in srgb,var(--text-primary) 4%,transparent)}.s-accordion-item__header:focus-visible{outline:none;box-shadow:inset 0 0 0 2px var(--card),inset 0 0 0 4px var(--focus-ring)}.s-accordion-item__header:disabled{opacity:.4;cursor:default}.s-accordion-item__title{flex:1 1 auto;min-width:0;display:flex;flex-wrap:wrap;align-items:center;gap:var(--space-8)}.s-accordion-item__icon{flex:0 0 auto;color:var(--text-secondary);transition:transform .15s ease}:host(.s-accordion-item--expanded) .s-accordion-item__icon{transform:rotate(180deg)}.s-accordion-item__panel{padding:0 var(--space-16) var(--space-16);color:var(--text-primary);font-family:var(--font-ui);font-size:var(--text-body, 14px);line-height:var(--leading-normal, 1.45)}.s-accordion-item__panel[hidden]{display:none}@media(prefers-reduced-motion:reduce){.s-accordion-item__header,.s-accordion-item__icon{transition:none}}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SAccordionItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-accordion-item', imports: [NgTemplateOutlet, SIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [CdkAccordionItem], host: {
                        class: 's-accordion-item',
                        '[class.s-accordion-item--expanded]': 'aberto()',
                        '[class.s-accordion-item--disabled]': 'disabled()',
                    }, template: "<div class=\"s-accordion-item__heading\" role=\"heading\" [attr.aria-level]=\"headingLevel()\">\n  <button\n    class=\"s-accordion-item__header\"\n    type=\"button\"\n    [id]=\"headerId\"\n    [disabled]=\"disabled()\"\n    [attr.aria-expanded]=\"aberto()\"\n    [attr.aria-controls]=\"panelId\"\n    (click)=\"alternar()\"\n  >\n    <span class=\"s-accordion-item__title\">\n      @if (cabecalho(); as proprio) {\n        <ng-container\n          [ngTemplateOutlet]=\"proprio.template\"\n          [ngTemplateOutletContext]=\"contextoCabecalho()\"\n        />\n      } @else {\n        {{ title() }}\n      }\n    </span>\n    <s-icon class=\"s-accordion-item__icon\" name=\"expand_more\" />\n  </button>\n</div>\n\n<div\n  class=\"s-accordion-item__panel\"\n  role=\"region\"\n  [id]=\"panelId\"\n  [attr.aria-labelledby]=\"headerId\"\n  [hidden]=\"!aberto()\"\n>\n  <ng-content />\n  @if (montaTardio() && conteudoTardio(); as tardio) {\n    <ng-container [ngTemplateOutlet]=\"tardio.template\" />\n  }\n</div>\n", styles: [":host{display:block}:host(:not(:first-of-type)){border-top:1px solid var(--card-border)}.s-accordion-item__heading{margin:0}.s-accordion-item__header{width:100%;min-height:48px;display:flex;align-items:center;justify-content:space-between;gap:var(--space-16);padding:var(--space-12) var(--space-16);border:0;background:transparent;color:var(--text-primary);font-family:var(--font-ui);font-size:var(--text-body, 14px);font-weight:var(--weight-semibold, 600);text-align:left;cursor:pointer;transition:background-color .15s ease}.s-accordion-item__header:hover:not(:disabled){background:color-mix(in srgb,var(--text-primary) 4%,transparent)}.s-accordion-item__header:focus-visible{outline:none;box-shadow:inset 0 0 0 2px var(--card),inset 0 0 0 4px var(--focus-ring)}.s-accordion-item__header:disabled{opacity:.4;cursor:default}.s-accordion-item__title{flex:1 1 auto;min-width:0;display:flex;flex-wrap:wrap;align-items:center;gap:var(--space-8)}.s-accordion-item__icon{flex:0 0 auto;color:var(--text-secondary);transition:transform .15s ease}:host(.s-accordion-item--expanded) .s-accordion-item__icon{transform:rotate(180deg)}.s-accordion-item__panel{padding:0 var(--space-16) var(--space-16);color:var(--text-primary);font-family:var(--font-ui);font-size:var(--text-body, 14px);line-height:var(--leading-normal, 1.45)}.s-accordion-item__panel[hidden]{display:none}@media(prefers-reduced-motion:reduce){.s-accordion-item__header,.s-accordion-item__icon{transition:none}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], expanded: [{ type: i0.Input, args: [{ isSignal: true, alias: "expanded", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], headingLevel: [{ type: i0.Input, args: [{ isSignal: true, alias: "headingLevel", required: false }] }], lazyContent: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazyContent", required: false }] }], expandedChange: [{ type: i0.Output, args: ["expandedChange"] }], conteudoTardio: [{ type: i0.ContentChild, args: [i0.forwardRef(() => SAccordionContentDirective), { isSignal: true }] }], cabecalho: [{ type: i0.ContentChild, args: [i0.forwardRef(() => SAccordionHeaderDirective), { isSignal: true }] }] } });

/** Texto para leitor de tela: a cor e o glifo não chegam a quem não vê. */
const ESTADO_TEXTO = {
    done: 'concluída',
    current: 'etapa atual',
    pending: 'pendente',
    error: 'com pendência',
};
/**
 * Indicador de progresso de um fluxo em etapas — cadastro, matrícula,
 * importação.
 *
 * **Não está no guia de design.** Entrou para que cada fluxo em etapas não
 * desenhe o seu. Segue as cores do guia: concluída em `--primary`, atual com
 * anel em `--primary`, pendente neutra e pendência em `--destructive`.
 *
 * **Só indica.** O conteúdo de cada etapa é da tela, como nas abas de
 * `<s-tabs>`: o componente não esconde nem mostra nada, e a tela troca o que
 * renderiza ao ouvir `stepChange`. Não envolve o `mat-stepper` pelo mesmo
 * motivo — ele gerencia o conteúdo das etapas, e trazê-lo seria adotar esse
 * modelo junto.
 *
 * Em container estreito, a disposição horizontal esconde os rótulos das etapas
 * que não são a atual; os marcadores continuam mostrando onde se está.
 *
 * @example
 * ```html
 * <s-steps [steps]="etapas" [activeId]="etapa()" clickable (stepChange)="etapa.set($event)" />
 * ```
 */
class SStepsComponent {
    /** Etapas, na ordem. */
    steps = input([], ...(ngDevMode ? [{ debugName: "steps" }] : []));
    /** Id da etapa atual. As anteriores contam como concluídas. */
    activeId = input('', ...(ngDevMode ? [{ debugName: "activeId" }] : []));
    /**
     * Horizontal por padrão, acima do formulário. Vertical para fluxos longos ou
     * para uma coluna lateral, onde a descrição de cada etapa cabe.
     */
    orientation = input('horizontal', ...(ngDevMode ? [{ debugName: "orientation" }] : []));
    /**
     * As etapas viram botões e emitem `stepChange`.
     *
     * Desligado, o componente é só indicador: a tela avança pelos botões dela.
     */
    clickable = input(false, ...(ngDevMode ? [{ debugName: "clickable", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Com `clickable`, só as etapas anteriores à atual podem ser escolhidas —
     * voltar para corrigir, sim; pular a validação, não. Desligue quando as
     * etapas forem independentes entre si.
     */
    linear = input(true, ...(ngDevMode ? [{ debugName: "linear", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Rótulo acessível da lista. */
    label = input('Etapas', ...(ngDevMode ? [{ debugName: "label" }] : []));
    /** Etapa escolhida pelo usuário. */
    stepChange = output();
    etapas = computed(() => {
        const lista = this.steps();
        const atual = lista.findIndex((etapa) => etapa.id === this.activeId());
        return lista.map((etapa, indice) => {
            const estado = this.estadoDe(etapa, indice, atual);
            return {
                etapa,
                numero: indice + 1,
                estado,
                estadoTexto: ESTADO_TEXTO[estado],
                escolhivel: this.podeEscolher(etapa, indice, atual),
                atual: indice === atual,
            };
        });
    }, ...(ngDevMode ? [{ debugName: "etapas" }] : []));
    escolher(item) {
        if (item.escolhivel) {
            this.stepChange.emit(item.etapa.id);
        }
    }
    estadoDe(etapa, indice, atual) {
        if (etapa.error) {
            return 'error';
        }
        if (indice === atual) {
            return 'current';
        }
        return indice < atual ? 'done' : 'pending';
    }
    podeEscolher(etapa, indice, atual) {
        if (!this.clickable() || etapa.disabled || indice === atual) {
            return false;
        }
        return !this.linear() || indice < atual;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SStepsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SStepsComponent, isStandalone: true, selector: "s-steps", inputs: { steps: { classPropertyName: "steps", publicName: "steps", isSignal: true, isRequired: false, transformFunction: null }, activeId: { classPropertyName: "activeId", publicName: "activeId", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, clickable: { classPropertyName: "clickable", publicName: "clickable", isSignal: true, isRequired: false, transformFunction: null }, linear: { classPropertyName: "linear", publicName: "linear", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { stepChange: "stepChange" }, host: { properties: { "class.s-steps--vertical": "orientation() === \"vertical\"" }, classAttribute: "s-steps" }, ngImport: i0, template: "<ol class=\"s-steps__lista\" [attr.aria-label]=\"label()\">\n  @for (item of etapas(); track item.etapa.id) {\n    <li\n      class=\"s-steps__item\"\n      [class]=\"'s-steps__item--' + item.estado\"\n      [attr.aria-current]=\"item.atual ? 'step' : null\"\n    >\n      @if (item.escolhivel) {\n        <button type=\"button\" class=\"s-steps__etapa\" (click)=\"escolher(item)\">\n          <ng-container *ngTemplateOutlet=\"conteudo; context: { $implicit: item }\" />\n        </button>\n      } @else {\n        <div class=\"s-steps__etapa\">\n          <ng-container *ngTemplateOutlet=\"conteudo; context: { $implicit: item }\" />\n        </div>\n      }\n\n      <span class=\"s-steps__linha\" aria-hidden=\"true\"></span>\n    </li>\n  }\n</ol>\n\n<ng-template #conteudo let-item>\n  <span class=\"s-steps__marcador\" aria-hidden=\"true\">\n    @switch (item.estado) {\n      @case ('done') {\n        <s-icon name=\"check\" size=\"sm\" />\n      }\n      @case ('error') {\n        <s-icon name=\"priority_high\" size=\"sm\" />\n      }\n      @default {\n        {{ item.numero }}\n      }\n    }\n  </span>\n\n  <span class=\"s-steps__textos\">\n    <span class=\"s-steps__rotulo\">{{ item.etapa.label }}</span>\n    @if (item.etapa.description) {\n      <span class=\"s-steps__descricao\">{{ item.etapa.description }}</span>\n    }\n    <span class=\"s-steps__oculto\">, {{ item.estadoTexto }}</span>\n  </span>\n</ng-template>\n", styles: [":host{--s-steps-marcador: calc(var(--icon-md, 24px) + var(--space-8, 8px));display:block;container:s-steps/inline-size;font-family:var(--font-ui)}.s-steps__lista{display:flex;margin:0;padding:0;list-style:none}.s-steps__item{position:relative;flex:1 1 0;min-width:0}.s-steps__etapa{box-sizing:border-box;display:flex;flex-direction:column;align-items:center;gap:var(--space-8, 8px);width:100%;margin:0;padding:0 var(--space-4, 4px);font:inherit;text-align:center;color:inherit;background:none;border:0;border-radius:var(--radius-control, 8px)}button.s-steps__etapa{cursor:pointer}button.s-steps__etapa:hover .s-steps__rotulo{color:var(--primary)}button.s-steps__etapa:focus-visible{outline:none}button.s-steps__etapa:focus-visible .s-steps__marcador{box-shadow:0 0 0 3px var(--primary)}.s-steps__marcador{box-sizing:border-box;display:inline-flex;flex:0 0 auto;align-items:center;justify-content:center;width:var(--s-steps-marcador);height:var(--s-steps-marcador);font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);font-variant-numeric:tabular-nums;color:var(--text-secondary);background:var(--card);border:1px solid var(--border);border-radius:var(--radius-full, 9999px)}.s-steps__textos{display:flex;flex-direction:column;gap:var(--space-4, 4px);min-width:0}.s-steps__rotulo{font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);color:var(--text-secondary);overflow-wrap:anywhere}.s-steps__descricao{font-size:var(--text-caption, 12px);color:var(--text-secondary)}.s-steps__oculto{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}.s-steps__linha{position:absolute;top:calc(var(--s-steps-marcador) / 2);left:calc(50% + var(--s-steps-marcador) / 2 + var(--space-8, 8px));right:calc(-50% + var(--s-steps-marcador) / 2 + var(--space-8, 8px));height:1px;background:var(--border)}.s-steps__item:last-child .s-steps__linha{display:none}.s-steps__item--done .s-steps__marcador{color:var(--on-filled);background:var(--primary);border-color:var(--primary)}.s-steps__item--done .s-steps__rotulo{color:var(--text-primary)}.s-steps__item--done .s-steps__linha{background:var(--primary)}.s-steps__item--current .s-steps__marcador{color:var(--primary);border:2px solid var(--primary)}.s-steps__item--current .s-steps__rotulo{color:var(--text-primary)}.s-steps__item--error .s-steps__marcador{color:var(--on-filled);background:var(--destructive);border-color:var(--destructive)}.s-steps__item--error .s-steps__rotulo{color:var(--destructive)}:host(.s-steps--vertical) .s-steps__lista{flex-direction:column}:host(.s-steps--vertical) .s-steps__item{flex:0 0 auto;padding-bottom:var(--space-24, 24px)}:host(.s-steps--vertical) .s-steps__item:last-child{padding-bottom:0}:host(.s-steps--vertical) .s-steps__etapa{flex-direction:row;align-items:flex-start;gap:var(--space-12, 12px);padding:0;text-align:left}:host(.s-steps--vertical) .s-steps__textos{padding-top:calc((var(--s-steps-marcador) - var(--text-label, 14px) * var(--leading-tight, 1.2)) / 2)}:host(.s-steps--vertical) .s-steps__linha{top:calc(var(--s-steps-marcador) + var(--space-4, 4px));bottom:var(--space-4, 4px);left:calc(var(--s-steps-marcador) / 2);right:auto;width:1px;height:auto}@container s-steps (max-width: 480px){:host(:not(.s-steps--vertical)) .s-steps__descricao{display:none}:host(:not(.s-steps--vertical)) .s-steps__item:not(.s-steps__item--current) .s-steps__textos{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SStepsComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-steps', imports: [NgTemplateOutlet, SIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 's-steps',
                        '[class.s-steps--vertical]': 'orientation() === "vertical"',
                    }, template: "<ol class=\"s-steps__lista\" [attr.aria-label]=\"label()\">\n  @for (item of etapas(); track item.etapa.id) {\n    <li\n      class=\"s-steps__item\"\n      [class]=\"'s-steps__item--' + item.estado\"\n      [attr.aria-current]=\"item.atual ? 'step' : null\"\n    >\n      @if (item.escolhivel) {\n        <button type=\"button\" class=\"s-steps__etapa\" (click)=\"escolher(item)\">\n          <ng-container *ngTemplateOutlet=\"conteudo; context: { $implicit: item }\" />\n        </button>\n      } @else {\n        <div class=\"s-steps__etapa\">\n          <ng-container *ngTemplateOutlet=\"conteudo; context: { $implicit: item }\" />\n        </div>\n      }\n\n      <span class=\"s-steps__linha\" aria-hidden=\"true\"></span>\n    </li>\n  }\n</ol>\n\n<ng-template #conteudo let-item>\n  <span class=\"s-steps__marcador\" aria-hidden=\"true\">\n    @switch (item.estado) {\n      @case ('done') {\n        <s-icon name=\"check\" size=\"sm\" />\n      }\n      @case ('error') {\n        <s-icon name=\"priority_high\" size=\"sm\" />\n      }\n      @default {\n        {{ item.numero }}\n      }\n    }\n  </span>\n\n  <span class=\"s-steps__textos\">\n    <span class=\"s-steps__rotulo\">{{ item.etapa.label }}</span>\n    @if (item.etapa.description) {\n      <span class=\"s-steps__descricao\">{{ item.etapa.description }}</span>\n    }\n    <span class=\"s-steps__oculto\">, {{ item.estadoTexto }}</span>\n  </span>\n</ng-template>\n", styles: [":host{--s-steps-marcador: calc(var(--icon-md, 24px) + var(--space-8, 8px));display:block;container:s-steps/inline-size;font-family:var(--font-ui)}.s-steps__lista{display:flex;margin:0;padding:0;list-style:none}.s-steps__item{position:relative;flex:1 1 0;min-width:0}.s-steps__etapa{box-sizing:border-box;display:flex;flex-direction:column;align-items:center;gap:var(--space-8, 8px);width:100%;margin:0;padding:0 var(--space-4, 4px);font:inherit;text-align:center;color:inherit;background:none;border:0;border-radius:var(--radius-control, 8px)}button.s-steps__etapa{cursor:pointer}button.s-steps__etapa:hover .s-steps__rotulo{color:var(--primary)}button.s-steps__etapa:focus-visible{outline:none}button.s-steps__etapa:focus-visible .s-steps__marcador{box-shadow:0 0 0 3px var(--primary)}.s-steps__marcador{box-sizing:border-box;display:inline-flex;flex:0 0 auto;align-items:center;justify-content:center;width:var(--s-steps-marcador);height:var(--s-steps-marcador);font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);font-variant-numeric:tabular-nums;color:var(--text-secondary);background:var(--card);border:1px solid var(--border);border-radius:var(--radius-full, 9999px)}.s-steps__textos{display:flex;flex-direction:column;gap:var(--space-4, 4px);min-width:0}.s-steps__rotulo{font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);color:var(--text-secondary);overflow-wrap:anywhere}.s-steps__descricao{font-size:var(--text-caption, 12px);color:var(--text-secondary)}.s-steps__oculto{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}.s-steps__linha{position:absolute;top:calc(var(--s-steps-marcador) / 2);left:calc(50% + var(--s-steps-marcador) / 2 + var(--space-8, 8px));right:calc(-50% + var(--s-steps-marcador) / 2 + var(--space-8, 8px));height:1px;background:var(--border)}.s-steps__item:last-child .s-steps__linha{display:none}.s-steps__item--done .s-steps__marcador{color:var(--on-filled);background:var(--primary);border-color:var(--primary)}.s-steps__item--done .s-steps__rotulo{color:var(--text-primary)}.s-steps__item--done .s-steps__linha{background:var(--primary)}.s-steps__item--current .s-steps__marcador{color:var(--primary);border:2px solid var(--primary)}.s-steps__item--current .s-steps__rotulo{color:var(--text-primary)}.s-steps__item--error .s-steps__marcador{color:var(--on-filled);background:var(--destructive);border-color:var(--destructive)}.s-steps__item--error .s-steps__rotulo{color:var(--destructive)}:host(.s-steps--vertical) .s-steps__lista{flex-direction:column}:host(.s-steps--vertical) .s-steps__item{flex:0 0 auto;padding-bottom:var(--space-24, 24px)}:host(.s-steps--vertical) .s-steps__item:last-child{padding-bottom:0}:host(.s-steps--vertical) .s-steps__etapa{flex-direction:row;align-items:flex-start;gap:var(--space-12, 12px);padding:0;text-align:left}:host(.s-steps--vertical) .s-steps__textos{padding-top:calc((var(--s-steps-marcador) - var(--text-label, 14px) * var(--leading-tight, 1.2)) / 2)}:host(.s-steps--vertical) .s-steps__linha{top:calc(var(--s-steps-marcador) + var(--space-4, 4px));bottom:var(--space-4, 4px);left:calc(var(--s-steps-marcador) / 2);right:auto;width:1px;height:auto}@container s-steps (max-width: 480px){:host(:not(.s-steps--vertical)) .s-steps__descricao{display:none}:host(:not(.s-steps--vertical)) .s-steps__item:not(.s-steps__item--current) .s-steps__textos{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}}\n"] }]
        }], propDecorators: { steps: [{ type: i0.Input, args: [{ isSignal: true, alias: "steps", required: false }] }], activeId: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeId", required: false }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], clickable: [{ type: i0.Input, args: [{ isSignal: true, alias: "clickable", required: false }] }], linear: [{ type: i0.Input, args: [{ isSignal: true, alias: "linear", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], stepChange: [{ type: i0.Output, args: ["stepChange"] }] } });

/**
 * Cartao de indicador: um numero grande com o que ele significa.
 *
 * Aparece nos painteis de acompanhamento — frequencia, notas, ponto — onde a
 * pessoa precisa ler tres ou quatro numeros de relance antes de decidir se
 * abre a listagem.
 *
 * **Nao esta no guia de design.** Ele existe nas telas de exemplo do guia, sem
 * ficha de props; as medidas aqui saem dos tokens de card e da escala
 * tipografica.
 *
 * A ordem de leitura e selo → valor → rotulo → tendencia: o selo tintado
 * ancora o olho antes do numero, e a tendencia (ou o `hint`) fecha a leitura
 * dizendo se o numero e bom, ruim ou so contexto. O valor usa `--text-h2`
 * porque e o que a pessoa veio ler; o rotulo fica em `--text-secondary`,
 * porque so faz sentido depois do numero.
 */
class SStatCardComponent {
    /** O que o numero mede. Ex.: "Presenças no mês". */
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
    /** O numero em si. Texto quando a aplicacao ja formatou ("71,2%"); numero entra como esta. */
    value = input('', ...(ngDevMode ? [{ debugName: "value" }] : []));
    /** Uma linha de contexto abaixo do valor. Ex.: "de 180 aulas".
     *
     * Ignorado quando `trend` esta presente — os dois ocupam a mesma linha, e a
     * tendencia e mais especifica.
     */
    hint = input('', ...(ngDevMode ? [{ debugName: "hint" }] : []));
    /** Glifo de 24px dentro do selo tintado, no topo do cartao. */
    icon = input('', ...(ngDevMode ? [{ debugName: "icon" }] : []));
    /**
     * Cor do glifo e do realce.
     *
     * Use tom semantico so quando o numero **for** bom ou ruim. Um total neutro
     * pintado de verde sugere uma avaliacao que ninguem fez.
     */
    tone = input('default', ...(ngDevMode ? [{ debugName: "tone" }] : []));
    /** Comparacao com o periodo anterior, com seta e cor proprias. */
    trend = input(null, ...(ngDevMode ? [{ debugName: "trend" }] : []));
    /** `+12,5%`, `-3%`, `0%` - virgula decimal e sinal, como se le no Brasil. */
    variacao = computed(() => {
        const valor = this.trend()?.value ?? 0;
        return `${PERCENTUAL.format(valor)}%`;
    }, ...(ngDevMode ? [{ debugName: "variacao" }] : []));
    /** O que a seta diz, para quem nao a ve. */
    sentido = computed(() => {
        const valor = this.trend()?.value ?? 0;
        return valor > 0 ? 'Alta de' : valor < 0 ? 'Queda de' : 'Sem variação,';
    }, ...(ngDevMode ? [{ debugName: "sentido" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SStatCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.34", type: SStatCardComponent, isStandalone: true, selector: "s-stat-card", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, hint: { classPropertyName: "hint", publicName: "hint", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, trend: { classPropertyName: "trend", publicName: "trend", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "\"s-stat-card s-stat-card--\" + tone()" } }, ngImport: i0, template: "@if (icon()) {\n  <span class=\"s-stat-card__icone\">\n    <s-icon [name]=\"icon()\" size=\"md\" />\n  </span>\n}\n\n<strong class=\"s-stat-card__valor\">{{ value() }}</strong>\n\n<span class=\"s-stat-card__rotulo\">{{ label() }}</span>\n\n@if (trend(); as tendencia) {\n  <span\n    class=\"s-stat-card__tendencia\"\n    [class.s-stat-card__tendencia--negativa]=\"tendencia.value < 0\"\n    [class.s-stat-card__tendencia--neutra]=\"tendencia.value === 0\"\n  >\n    @if (tendencia.value !== 0) {\n      <s-icon [name]=\"tendencia.value < 0 ? 'arrow_downward' : 'arrow_upward'\" size=\"xs\" />\n    }\n    <span class=\"s-stat-card__sentido\">{{ sentido() }}</span>\n    {{ variacao() }} {{ tendencia.label }}\n  </span>\n} @else if (hint()) {\n  <span class=\"s-stat-card__contexto\">{{ hint() }}</span>\n}\n", styles: [":host{display:flex;flex-direction:column;align-items:flex-start;gap:var(--space-8, 8px);padding:var(--space-16, 16px);background:var(--card);border:1px solid var(--card-border);border-radius:var(--radius-container, 12px);box-shadow:var(--elevation-1);font-family:var(--font-ui)}.s-stat-card__icone{display:inline-flex;align-items:center;justify-content:center;width:calc(var(--icon-md, 24px) + var(--space-16, 16px));height:calc(var(--icon-md, 24px) + var(--space-16, 16px));border-radius:var(--radius-control, 8px);flex:0 0 auto;background:var(--secondary);color:var(--text-secondary)}.s-stat-card__rotulo{font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);color:var(--text-secondary)}.s-stat-card__valor{font-family:var(--font-display);font-size:var(--text-h2, 30px);font-weight:var(--weight-semibold, 600);line-height:var(--leading-tight, 1.2);color:var(--text-primary);font-variant-numeric:tabular-nums}.s-stat-card__contexto{font-size:var(--text-caption, 12px);color:var(--text-secondary)}.s-stat-card__tendencia{display:inline-flex;align-items:center;gap:var(--space-4, 4px);font-size:var(--text-caption, 12px);font-weight:var(--weight-medium, 500);color:var(--success-on-surface)}.s-stat-card__tendencia.s-stat-card__tendencia--negativa{color:var(--destructive-on-surface)}.s-stat-card__tendencia.s-stat-card__tendencia--neutra{color:var(--text-secondary)}.s-stat-card__sentido{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}:host(.s-stat-card--default) .s-stat-card__icone{background:color-mix(in srgb,var(--primary) calc(var(--tint-container, .12) * 100%),transparent);color:var(--primary-on-surface)}:host(.s-stat-card--success) .s-stat-card__icone{background:color-mix(in srgb,var(--success) calc(var(--tint-container, .12) * 100%),transparent);color:var(--success-on-surface)}:host(.s-stat-card--warning) .s-stat-card__icone{background:color-mix(in srgb,var(--warning) calc(var(--tint-container, .12) * 100%),transparent);color:var(--warning-on-surface)}:host(.s-stat-card--destructive) .s-stat-card__icone{background:color-mix(in srgb,var(--destructive) calc(var(--tint-container, .12) * 100%),transparent);color:var(--destructive-on-surface)}:host(.s-stat-card--info) .s-stat-card__icone{background:color-mix(in srgb,var(--info) calc(var(--tint-container, .12) * 100%),transparent);color:var(--info-on-surface)}:host(.s-stat-card--secondary) .s-stat-card__icone{background:var(--secondary);color:var(--text-primary)}:host(.s-stat-card--outline) .s-stat-card__icone{background:transparent;border:1px solid var(--border);color:var(--text-secondary)}\n"], dependencies: [{ kind: "component", type: SIconComponent, selector: "s-icon", inputs: ["name", "size", "iconFilled", "filled", "color", "label", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SStatCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-stat-card', imports: [SIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        '[class]': '"s-stat-card s-stat-card--" + tone()',
                    }, template: "@if (icon()) {\n  <span class=\"s-stat-card__icone\">\n    <s-icon [name]=\"icon()\" size=\"md\" />\n  </span>\n}\n\n<strong class=\"s-stat-card__valor\">{{ value() }}</strong>\n\n<span class=\"s-stat-card__rotulo\">{{ label() }}</span>\n\n@if (trend(); as tendencia) {\n  <span\n    class=\"s-stat-card__tendencia\"\n    [class.s-stat-card__tendencia--negativa]=\"tendencia.value < 0\"\n    [class.s-stat-card__tendencia--neutra]=\"tendencia.value === 0\"\n  >\n    @if (tendencia.value !== 0) {\n      <s-icon [name]=\"tendencia.value < 0 ? 'arrow_downward' : 'arrow_upward'\" size=\"xs\" />\n    }\n    <span class=\"s-stat-card__sentido\">{{ sentido() }}</span>\n    {{ variacao() }} {{ tendencia.label }}\n  </span>\n} @else if (hint()) {\n  <span class=\"s-stat-card__contexto\">{{ hint() }}</span>\n}\n", styles: [":host{display:flex;flex-direction:column;align-items:flex-start;gap:var(--space-8, 8px);padding:var(--space-16, 16px);background:var(--card);border:1px solid var(--card-border);border-radius:var(--radius-container, 12px);box-shadow:var(--elevation-1);font-family:var(--font-ui)}.s-stat-card__icone{display:inline-flex;align-items:center;justify-content:center;width:calc(var(--icon-md, 24px) + var(--space-16, 16px));height:calc(var(--icon-md, 24px) + var(--space-16, 16px));border-radius:var(--radius-control, 8px);flex:0 0 auto;background:var(--secondary);color:var(--text-secondary)}.s-stat-card__rotulo{font-size:var(--text-label, 14px);font-weight:var(--weight-medium, 500);color:var(--text-secondary)}.s-stat-card__valor{font-family:var(--font-display);font-size:var(--text-h2, 30px);font-weight:var(--weight-semibold, 600);line-height:var(--leading-tight, 1.2);color:var(--text-primary);font-variant-numeric:tabular-nums}.s-stat-card__contexto{font-size:var(--text-caption, 12px);color:var(--text-secondary)}.s-stat-card__tendencia{display:inline-flex;align-items:center;gap:var(--space-4, 4px);font-size:var(--text-caption, 12px);font-weight:var(--weight-medium, 500);color:var(--success-on-surface)}.s-stat-card__tendencia.s-stat-card__tendencia--negativa{color:var(--destructive-on-surface)}.s-stat-card__tendencia.s-stat-card__tendencia--neutra{color:var(--text-secondary)}.s-stat-card__sentido{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}:host(.s-stat-card--default) .s-stat-card__icone{background:color-mix(in srgb,var(--primary) calc(var(--tint-container, .12) * 100%),transparent);color:var(--primary-on-surface)}:host(.s-stat-card--success) .s-stat-card__icone{background:color-mix(in srgb,var(--success) calc(var(--tint-container, .12) * 100%),transparent);color:var(--success-on-surface)}:host(.s-stat-card--warning) .s-stat-card__icone{background:color-mix(in srgb,var(--warning) calc(var(--tint-container, .12) * 100%),transparent);color:var(--warning-on-surface)}:host(.s-stat-card--destructive) .s-stat-card__icone{background:color-mix(in srgb,var(--destructive) calc(var(--tint-container, .12) * 100%),transparent);color:var(--destructive-on-surface)}:host(.s-stat-card--info) .s-stat-card__icone{background:color-mix(in srgb,var(--info) calc(var(--tint-container, .12) * 100%),transparent);color:var(--info-on-surface)}:host(.s-stat-card--secondary) .s-stat-card__icone{background:var(--secondary);color:var(--text-primary)}:host(.s-stat-card--outline) .s-stat-card__icone{background:transparent;border:1px solid var(--border);color:var(--text-secondary)}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], hint: [{ type: i0.Input, args: [{ isSignal: true, alias: "hint", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], tone: [{ type: i0.Input, args: [{ isSignal: true, alias: "tone", required: false }] }], trend: [{ type: i0.Input, args: [{ isSignal: true, alias: "trend", required: false }] }] } });
const PERCENTUAL = new Intl.NumberFormat('pt-BR', {
    maximumFractionDigits: 1,
    signDisplay: 'exceptZero',
});

const CHAVE = 'siage-ui:tema';
/**
 * Tema da aplicacao.
 *
 * A biblioteca ja emite os dois temas completos; o que faltava era quem
 * escrevesse `data-theme` no `<html>` — o mesmo atributo que o guia usa, e o
 * que o `styles/_theme.scss` observa.
 *
 * `system` nao escreve atributo nenhum: sem ele, a regra
 * `@media (prefers-color-scheme: dark)` do tema assume, e a tela acompanha o
 * sistema operacional sozinha. E por isso que "seguir o sistema" e um estado de
 * verdade, e nao um terceiro tema.
 *
 * A escolha e guardada em `localStorage`, entao sobrevive ao recarregamento.
 * Se o armazenamento estiver indisponivel — janela anonima, cookies
 * bloqueados — o servico continua funcionando, so nao lembra na proxima visita.
 */
class SThemeService {
    documento = inject(DOCUMENT$1);
    destroyRef = inject(DestroyRef);
    /** Preferencia atual. */
    theme = signal('system', ...(ngDevMode ? [{ debugName: "theme" }] : []));
    /** O sistema operacional esta no escuro. Acompanha a troca em tempo real. */
    sistemaEscuro = signal(false, ...(ngDevMode ? [{ debugName: "sistemaEscuro" }] : []));
    /**
     * O tema que esta valendo na tela, com `system` ja resolvido - e reage
     * quando o sistema operacional troca de tema com a tela aberta.
     */
    resolved = computed(() => {
        const atual = this.theme();
        if (atual !== 'system') {
            return atual;
        }
        return this.sistemaEscuro() ? 'dark' : 'light';
    }, ...(ngDevMode ? [{ debugName: "resolved" }] : []));
    constructor() {
        this.theme.set(this.lerGuardado());
        this.aplicar(this.theme());
        this.acompanharSistema();
    }
    /** Troca a preferencia e aplica na hora. */
    set(theme) {
        this.theme.set(theme);
        this.aplicar(theme);
        this.guardar(theme);
    }
    /**
     * Alterna entre claro e escuro.
     *
     * Partindo de `system`, vai para o oposto do que esta na tela — e o que a
     * pessoa espera de um botao que ela clicou justamente porque nao gostou do
     * que via.
     */
    toggle() {
        this.set(this.resolved() === 'dark' ? 'light' : 'dark');
    }
    /**
     * O tema que esta valendo na tela, com `system` ja resolvido.
     *
     * @deprecated Use o signal `resolved`, que reage a troca de tema do sistema.
     */
    resolvido() {
        return this.resolved();
    }
    acompanharSistema() {
        const consulta = this.documento.defaultView?.matchMedia?.('(prefers-color-scheme: dark)');
        if (!consulta) {
            return;
        }
        this.sistemaEscuro.set(consulta.matches);
        const aoTrocar = (evento) => this.sistemaEscuro.set(evento.matches);
        consulta.addEventListener('change', aoTrocar);
        this.destroyRef.onDestroy(() => consulta.removeEventListener('change', aoTrocar));
    }
    aplicar(theme) {
        const raiz = this.documento.documentElement;
        if (theme === 'system') {
            // Sem atributo, quem decide e o `prefers-color-scheme` do tema.
            raiz.removeAttribute('data-theme');
            return;
        }
        raiz.setAttribute('data-theme', theme);
    }
    lerGuardado() {
        try {
            const guardado = this.documento.defaultView?.localStorage.getItem(CHAVE);
            return guardado === 'light' || guardado === 'dark' ? guardado : 'system';
        }
        catch {
            // Janela anonima ou armazenamento bloqueado: segue o sistema.
            return 'system';
        }
    }
    guardar(theme) {
        try {
            this.documento.defaultView?.localStorage.setItem(CHAVE, theme);
        }
        catch {
            // Sem armazenamento a escolha vale para esta sessao e nao e lembrada.
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SThemeService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SThemeService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SThemeService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

/**
 * Botao que alterna entre claro e escuro.
 *
 * Encapsula o `SThemeService`, que e quem escreve `data-theme` no `<html>` e
 * guarda a escolha. A tela so precisa por o botao onde quiser — normalmente na
 * `<s-top-bar>`.
 *
 * O glifo mostra o tema **que esta valendo**, nao o que o clique vai trazer:
 * um sol quando a tela esta clara. E a convencao que a maioria dos sistemas
 * usa, e trocar isso confunde mais do que informa.
 */
class SThemeToggleComponent {
    /** Rotulo acessivel. Descreve o botao, nao o estado. */
    label = input('Alternar tema', ...(ngDevMode ? [{ debugName: "label" }] : []));
    tema = inject(SThemeService);
    // O tema resolvido, e nao a preferencia: em `system` com o sistema no
    // escuro, a tela esta escura - e o glifo tem de dizer isso.
    glifo = computed(() => this.tema.resolved() === 'dark' ? 'dark_mode' : 'light_mode', ...(ngDevMode ? [{ debugName: "glifo" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SThemeToggleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.34", type: SThemeToggleComponent, isStandalone: true, selector: "s-theme-toggle", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "s-theme-toggle" }, ngImport: i0, template: ` <s-icon-button [icon]="glifo()" [label]="label()" (click)="tema.toggle()" /> `, isInline: true, dependencies: [{ kind: "component", type: SIconButtonComponent, selector: "s-icon-button", inputs: ["icon", "label", "variant", "outlined", "text", "size", "iconFilled", "disabled", "loading", "type"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.34", ngImport: i0, type: SThemeToggleComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 's-theme-toggle',
                    imports: [SIconButtonComponent],
                    template: ` <s-icon-button [icon]="glifo()" [label]="label()" (click)="tema.toggle()" /> `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: {
                        class: 's-theme-toggle',
                    },
                }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

/*
 * API pública de @siage/siage-ui.
 *
 * Exporte aqui apenas o que a aplicação consumidora precisa usar.
 * Detalhes internos (controles, estados, helpers) permanecem privados.
 */
// Tipos compartilhados entre componentes.

/**
 * Generated bundle index. Do not edit.
 */

export { SAccordionComponent, SAccordionContentDirective, SAccordionHeaderDirective, SAccordionItemComponent, SAlertComponent, SAutocompleteComponent, SAutocompleteFooterDirective, SAutocompleteSource, SAvatarComponent, SBadgeComponent, SButtonComponent, SCardComponent, SCardContentDirective, SCardFooterDirective, SCardHeaderDirective, SCardTitleDirective, SCheckboxComponent, SChipsComponent, SDateAdapter, SDatepickerComponent, SDatepickerFooterDirective, SDatepickerHeaderDirective, SDatepickerIntl, SEmptyStateComponent, SFieldComponent, SFileSource, SFileUploadComponent, SFilterCardComponent, SFilterStorage, SIconButtonComponent, SIconComponent, SInputComponent, SInputNumberComponent, SLoadingOverlayComponent, SLoadingService, SMaskDirective, SMenuComponent, SMenuItemComponent, SMenuSeparatorComponent, SMenuTriggerDirective, SModalComponent, SModalFooterDirective, SModalRef, SModalService, SMultiselectComponent, SOnlyDigitsDirective, SOptionTemplateDirective, SPageHeaderComponent, SPageHeaderStatusDirective, SPaginationComponent, SPasswordRequirementsComponent, SPermissionChecker, SProgressBarComponent, SRadioGroupComponent, SRecordCountComponent, SSelectComponent, SSelectionButtonsComponent, SSessionFilterStorage, SSidebarComponent, SSkeletonComponent, SSpinnerComponent, SStatCardComponent, SStepsComponent, SSwitchComponent, STableCellDirective, STableComponent, STableSkeletonComponent, STabsComponent, STextareaComponent, SThemeService, SThemeToggleComponent, SToastService, STooltipDirective, STopBarComponent, S_DATE_CONFIG, S_DATE_FORMATS, S_DATE_PART_LENGTH, S_LOADING_DELAY, S_MENSAGENS_PADRAO, S_PASSWORD_RULES, S_TOAST_DEFAULTS, S_TOAST_DURACAO, S_TOAST_MAXIMO, S_VALIDATION_MESSAGES, adiarCarregamento, avatarInitials, avatarTone, breadcrumbFromRoute, criarConfigData, firstFromPage, formatMask, formatPattern, formatPhone, formatPtBrNumber, injectModalData, injectModalRef, integerDigitCount, mapCellTemplates, mascararData, maskPtBrNumber, pageFromFirst, parsePtBrNumber, pixelsDoTamanho, positionAfterRaw, primeiraMensagem, provideSiageAutocompleteSource, provideSiageDateAdapter, provideSiageFileSource, provideSiageFilterStorage, provideSiageLoadingDelay, provideSiagePermissionChecker, provideSiageToast, provideSiageValidationMessages, rawCountBeforeCursor, severityTone, siageLoadingInterceptor, tamanhoDeIcone, todasAsMensagens, validateMinMax, variavelDoTamanho };
//# sourceMappingURL=siage-siage-ui.mjs.map
