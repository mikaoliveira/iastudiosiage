import { Observable } from 'rxjs';
import * as _siage_siage_ui from '@siage/siage-ui';
import { STableSort, STableColumn, STableAction, SBreadcrumb, STableEmpty, SOption, SFilterValueFormatter, STableActionEvent, SListPermissionConfig } from '@siage/siage-ui';
import * as _angular_forms from '@angular/forms';
import { FormGroup } from '@angular/forms';
import * as _angular_core from '@angular/core';

/**
 * O pedido de uma pagina de listagem, como a fonte de dados o recebe.
 *
 * E deliberadamente pobre: pagina, tamanho, ordenacao e os filtros da tela, sem
 * nada de HTTP. Traduzir isto em `URLSearchParams`, corpo de POST ou consulta
 * GraphQL e trabalho da aplicacao — a biblioteca nao conhece a API de nenhum
 * sistema.
 */
interface SCrudQuery {
    /** Pagina pedida, comecando em **1**. */
    page: number;
    /** Registros por pagina. */
    pageSize: number;
    /** Ordenacao atual, ou `null` para a ordem que o backend devolver. */
    sort: STableSort | null;
    /**
     * Filtros ja aplicados — o valor do formulario no momento em que a pessoa
     * clicou em **Buscar**, sem os campos vazios.
     *
     * Nao e o valor corrente do formulario: digitar nao dispara consulta.
     */
    filters: Readonly<Record<string, unknown>>;
}
/** Uma pagina de resultado. */
interface SCrudPage<T> {
    /** As linhas desta pagina. */
    items: readonly T[];
    /** Total do resultado **filtrado**, nao da tabela inteira. */
    total: number;
}
/**
 * Fonte de dados de uma listagem de CRUD.
 *
 * A biblioteca **nao faz HTTP** — mesma regra do `SAutocompleteSource`. Ela
 * descreve o pedido (`SCrudQuery`) e espera uma pagina de volta; quem sabe
 * chamar a API e o service do sistema.
 *
 * Para o contrato que os sistemas do SIAGE ja usam hoje
 * (`getByFilterPaginated`, `PagedResult`) existe o adaptador pronto
 * `siageCrudDataSource()` — nao e preciso escrever esta classe a mao.
 *
 * @example
 * ```ts
 * @Injectable({ providedIn: 'root' })
 * export class TipoFaltaDataSource extends SCrudDataSource<TipoFaltaListDto> {
 *   private readonly api = inject(TipoFaltaService);
 *
 *   list({ page, pageSize, sort, filters }: SCrudQuery) {
 *     return this.api.buscar({ page, pageSize, sort, ...filters }).pipe(
 *       map((r) => ({ items: r.items, total: r.totalCount })),
 *     );
 *   }
 *
 *   remove(row: TipoFaltaListDto) {
 *     return this.api.excluir(row.id);
 *   }
 * }
 * ```
 */
declare abstract class SCrudDataSource<T> {
    /**
     * Devolve uma pagina do resultado.
     *
     * A consulta anterior e cancelada quando um novo pedido chega — trocar de
     * pagina duas vezes seguidas nao deixa a primeira resposta sobrescrever a
     * segunda.
     */
    abstract list(query: SCrudQuery): Observable<SCrudPage<T>>;
}
/**
 * As operacoes **opcionais** da fonte de dados.
 *
 * Ficam numa interface de mesmo nome, e nao na classe, porque um metodo
 * abstrato opcional continua obrigando cada implementacao a escrever `remove()`
 * — nem que seja para lancar erro. Aqui o cadastro que nao exclui simplesmente
 * nao implementa, e a lixeira nao aparece na tabela.
 */
interface SCrudDataSource<T> {
    /**
     * Exclui um registro.
     *
     * O modal de confirmacao e o aviso de sucesso ficam com a biblioteca; aqui so
     * a chamada.
     */
    remove?(row: T): Observable<unknown>;
    /**
     * Ativa ou inativa um registro.
     *
     * `active` e o estado **desejado** — `false` quando a pessoa pediu para
     * inativar —, e nao o estado atual da linha.
     */
    setActive?(row: T, active: boolean): Observable<unknown>;
}

/**
 * Nome da entidade, no singular e no plural, com genero.
 *
 * O genero nao e enfeite gramatical: e o que faz a biblioteca escrever "Novo
 * Tipo de Falta" e "Tipo de Falta excluido" sem que cada tela repita as
 * mensagens — e sem a tela ter que escreve-las erradas.
 */
interface SCrudEntity {
    /** Singular, como aparece no botao e nas mensagens: `'Tipo de Falta'`. */
    name: string;
    /** Plural, usado no titulo da tela quando `title` nao e informado. */
    namePlural?: string;
    /** `'masculine'` → "o/Novo/excluido"; `'feminine'` → "a/Nova/excluida". */
    gender: 'masculine' | 'feminine';
}
/**
 * Rotas do CRUD.
 *
 * Informando `routes`, a navegacao de cadastrar/editar/visualizar acontece
 * sozinha. Sem `routes`, nada e navegado e a tela decide o que fazer nos
 * outputs do `<s-crud-list>` — e o caso de quem abre formulario em modal.
 */
interface SCrudRoutes {
    /** Rota da listagem: `'/configuracoes-ponto/tipos-falta'`. */
    base: string;
    /** Segmento de cadastro. Padrao `'cadastrar'`. */
    create?: string;
    /** Segmento de edicao, antes do id. Padrao `'editar'`. */
    edit?: string;
    /** Segmento de visualizacao, antes do id. Padrao `'visualizar'`. */
    detail?: string;
}
/**
 * Quais das quatro acoes padrao aparecem na ultima coluna.
 *
 * Uma acao so aparece se a fonte de dados souber executa-la: configurar
 * `remove: true` numa fonte sem `remove()` nao mostra o botao, porque um botao
 * que nao faz nada e pior que um botao ausente.
 */
interface SCrudActions {
    /** Olho — abre a tela de visualizacao. */
    view?: boolean;
    /** Lapis — abre a tela de edicao. */
    edit?: boolean;
    /** Lixeira — confirma e exclui. */
    remove?: boolean;
    /** Alterna ativo/inativo, com confirmacao. */
    inactivate?: boolean;
}
/**
 * Tudo o que uma listagem de CRUD precisa saber.
 *
 * E o unico arquivo que uma tela nova escreve: colunas, entidade, rotas,
 * acoes e a fonte de dados. O comportamento — carregar, filtrar, paginar,
 * ordenar, confirmar exclusao, avisar — vem de `injectCrudList()`.
 */
interface SCrudConfig<T extends Record<string, unknown>> {
    /** Ver `SCrudEntity`. */
    entity: SCrudEntity;
    /** De onde vem os dados. Ver `SCrudDataSource`. */
    dataSource: SCrudDataSource<T>;
    /** Colunas da tabela, na ordem. Mesmo tipo do `<s-table>`. */
    columns: readonly STableColumn<T>[];
    /**
     * Formulario dos filtros.
     *
     * Os campos sao projetados no slot `[filters]` do `<s-crud-list>`; a
     * biblioteca so le o valor quando a pessoa busca. Sem formulario, o card de
     * filtros nao aparece.
     */
    filters?: FormGroup;
    /** Ver `SCrudRoutes`. Sem isto, nenhuma navegacao automatica acontece. */
    routes?: SCrudRoutes;
    /** Ver `SCrudActions`. O padrao e visualizar, editar e excluir. */
    actions?: SCrudActions;
    /**
     * Acoes alem das quatro padrao — "duplicar", "exportar", "ver usos".
     *
     * Chegam no output `action` do `<s-crud-list>`, com o id declarado aqui.
     */
    extraActions?: readonly STableAction<T>[];
    /** Titulo da tela. Padrao: `entity.namePlural ?? entity.name`. */
    title?: string;
    /** Uma ou duas linhas dizendo para que serve a tela. */
    description?: string;
    /** Trilha de navegacao do `<s-page-header>`. */
    breadcrumbs?: readonly SBreadcrumb[];
    /** Exibe a seta de voltar. A tela responde no output `back`. */
    showBack?: boolean;
    /** Exibe o botao de cadastrar. Padrao `true`. */
    showCreate?: boolean;
    /** Rotulo do botao de cadastrar. Padrao: `Novo`/`Nova` + `entity.name`. */
    createLabel?: string;
    /** Campo que identifica a linha, usado ao montar as rotas. Padrao `'id'`. */
    idKey?: keyof T & string;
    /** Campo booleano de ativo/inativo. Padrao `'ativo'`. */
    activeKey?: keyof T & string;
    /**
     * Como chamar uma linha nas mensagens de confirmacao.
     *
     * Padrao: `nome`, `descricao` ou `titulo`, o primeiro que existir. Uma
     * confirmacao que diz **qual** registro vai sumir e a diferenca entre
     * confirmar e torcer.
     */
    rowLabel?: (row: T) => string;
    /** Registros por pagina. Padrao `10`. */
    pageSize?: number;
    /** Opcoes do seletor de tamanho de pagina. */
    pageSizeOptions?: readonly number[];
    /** Substantivo da contagem do rodape. Padrao: o plural da entidade. */
    itemsLabel?: string;
    /** Ordenacao inicial. */
    sort?: STableSort | null;
    /**
     * Consulta ja na abertura da tela. Padrao `true`.
     *
     * Desligue quando buscar sem filtro for caro ou nao fizer sentido — a tela
     * abre no estado vazio ate a primeira busca.
     */
    autoLoad?: boolean;
    /**
     * Traduz uma falha da fonte de dados em mensagem para quem esta na tela.
     *
     * A biblioteca nao conhece a API: ela sabe que a exclusao falhou, mas nao
     * sabe que 409 quer dizer "esta em uso em 3 tabelas". Devolva a frase, e ela
     * vira a segunda linha do aviso; devolva `undefined` e o aviso fica so com o
     * titulo, que ja diz o que nao aconteceu.
     *
     * @example
     * ```ts
     * errorMessage: (erro) =>
     *   erro instanceof HttpErrorResponse && erro.status === 409
     *     ? 'O registro está em uso e não pode ser excluído.'
     *     : undefined,
     * ```
     */
    errorMessage?: (error: unknown, action: 'list' | 'remove' | 'active') => string | undefined;
}

/** Ids das acoes que a propria biblioteca executa. */
declare const ACOES_PADRAO: readonly ["view", "edit", "remove", "inactivate", "activate"];
/** Ver `ACOES_PADRAO`. */
type SCrudActionId = (typeof ACOES_PADRAO)[number];
/**
 * O estado e o comportamento de uma listagem de CRUD, sem template nenhum.
 *
 * ## O que isto resolve
 *
 * Antes desta camada, cada sistema reescrevia a mesma listagem: um recurso
 * paginado, o formulario de filtro virando parametro, a ordenacao, o modal de
 * confirmacao, o aviso de sucesso e a navegacao para o formulario. Era muito
 * codigo para algo que nao muda de tela para tela — e cada copia envelhecia
 * sozinha, num sistema de cada vez.
 *
 * Aqui isso e uma funcao: `injectCrudList(config)`. A tela escreve o que e
 * dela — colunas, filtros, rotas, fonte de dados — e mais nada.
 *
 * ## Por que funcao, e nao classe base
 *
 * Herdar de um componente base obriga a tela a ser filha de alguem, amarra o
 * construtor e transforma qualquer ajuste em `override`. Uma funcao devolve um
 * objeto: a tela guarda numa propriedade, o template usa, e ela continua livre
 * para herdar de quem quiser — ou de ninguem.
 *
 * ## O que dispara consulta
 *
 * Trocar de pagina, de tamanho de pagina ou de ordenacao consulta na hora.
 * **Digitar num filtro nao consulta**: os filtros so entram na consulta quando
 * a pessoa clica em Buscar (ou tecla Enter no card de filtros). E o que evita
 * uma chamada por tecla e mantem a lista parada enquanto alguem preenche tres
 * campos.
 *
 * @example
 * ```ts
 * export class TipoFaltaListComponent {
 *   protected readonly crud = injectCrudList<TipoFaltaListDto>({
 *     entity: { name: 'Tipo de Falta', namePlural: 'Tipos de Falta', gender: 'masculine' },
 *     dataSource: siageCrudDataSource(inject(TipoFaltaService)),
 *     routes: { base: '/configuracoes-ponto/tipos-falta' },
 *     filters: inject(FormBuilder).group({ nome: [''], ativo: [null] }),
 *     columns: COLUNAS,
 *     actions: { view: true, edit: true, remove: true, inactivate: true },
 *   });
 * }
 * ```
 */
declare class SCrudList<T extends Record<string, unknown>> {
    #private;
    /** Pagina atual, comecando em 1. */
    readonly page: _angular_core.WritableSignal<number>;
    /** Registros por pagina. */
    readonly pageSize: _angular_core.WritableSignal<number>;
    /** Ordenacao atual, ou `null` para a ordem que o backend devolver. */
    readonly sort: _angular_core.WritableSignal<STableSort | null>;
    /** Filtros **aplicados** — o que foi para a consulta, nao o que esta digitado. */
    readonly filters: _angular_core.WritableSignal<Readonly<Record<string, unknown>>>;
    constructor(config: SCrudConfig<T>);
    /** Linhas da pagina atual. */
    readonly rows: _angular_core.Signal<readonly T[]>;
    /** Total do resultado ja filtrado. */
    readonly total: _angular_core.Signal<number>;
    /** Consulta em andamento. */
    readonly loading: _angular_core.Signal<boolean>;
    /** Erro da ultima consulta, quando houve. */
    readonly error: _angular_core.Signal<Error | undefined>;
    /** Formulario de filtros, quando a tela declarou um. */
    get filterForm(): _angular_forms.FormGroup<any> | undefined;
    /** Colunas configuradas, na ordem. */
    get columns(): readonly _siage_siage_ui.STableColumn<T>[];
    /** Titulo da tela. */
    readonly title: _angular_core.Signal<string>;
    /** Descricao sob o titulo. */
    readonly description: _angular_core.Signal<string>;
    /** Trilha do cabecalho. */
    readonly breadcrumbs: _angular_core.Signal<readonly _siage_siage_ui.SBreadcrumb[]>;
    /** Exibe a seta de voltar. */
    readonly showBack: _angular_core.Signal<boolean>;
    /** Exibe o botao de cadastrar. */
    readonly showCreate: _angular_core.Signal<boolean>;
    /** Rotulo do botao de cadastrar — "Novo Tipo de Falta". */
    readonly createLabel: _angular_core.Signal<string>;
    /** Substantivo da contagem do rodape. */
    readonly itemsLabel: _angular_core.Signal<string>;
    /** Opcoes do seletor de tamanho de pagina. */
    readonly pageSizeOptions: _angular_core.Signal<readonly number[]>;
    /** Colunas da grade de filtros. */
    /**
     * As acoes da ultima coluna.
     *
     * Uma acao so entra se houver como executa-la: sem `remove()` na fonte de
     * dados a lixeira nao aparece, ainda que a configuracao peca — um botao que
     * nao faz nada e pior que um botao ausente. Ativar e inativar sao duas acoes
     * que se escondem uma a outra, porque o icone muda conforme a linha.
     */
    readonly actions: _angular_core.Signal<readonly STableAction<T>[]>;
    /**
     * O que a tabela mostra quando nao ha linhas.
     *
     * Sao tres situacoes diferentes, e trata-las igual e o erro classico: erro de
     * carga nao e lista vazia, e filtro sem resultado nao e cadastro vazio —
     * oferecer "cadastrar" no primeiro caso responde a pergunta errada.
     */
    readonly empty: _angular_core.Signal<STableEmpty>;
    /** Como a linha e chamada nas mensagens. Ver `SCrudConfig.rowLabel`. */
    rowLabel(row: T): string;
    /** Aplica os filtros do formulario e volta para a primeira pagina. */
    search(): void;
    /** Limpa formulario, filtros e ordenacao, e busca de novo. */
    clear(): void;
    /** Troca de pagina. */
    goToPage(page: number): void;
    /** Troca o tamanho da pagina — sempre voltando para a primeira. */
    setPageSize(pageSize: number): void;
    /**
     * Troca a ordenacao.
     *
     * Volta para a primeira pagina: seguir na pagina 7 de uma ordem que acabou de
     * mudar mostra um recorte que nao quer dizer nada.
     */
    setSort(sort: STableSort | null): void;
    /** Refaz a consulta atual, sem mexer em filtro, pagina ou ordem. */
    reload(): void;
    /**
     * O botao do estado vazio, que faz uma coisa diferente em cada situacao -
     * ver `empty`: tentar de novo apos erro, limpar o filtro sem resultado, ou
     * cadastrar o primeiro registro.
     */
    emptyAction(): void;
    /** Vai para a tela de cadastro, quando ha `routes`. */
    create(): void;
    /** Vai para a tela de visualizacao, quando ha `routes`. */
    view(row: T): void;
    /** Vai para a tela de edicao, quando ha `routes`. */
    edit(row: T): void;
    /**
     * Confirma e exclui.
     *
     * A confirmacao nomeia o registro e a acao — "Sim, excluir" —, porque quem le
     * so o botao precisa entender a consequencia.
     */
    remove(row: T): Promise<void>;
    /** Confirma e alterna ativo/inativo. */
    toggleActive(row: T): Promise<void>;
    /**
     * Executa a acao padrao correspondente ao id.
     *
     * Devolve `false` para id que nao e da biblioteca — o sinal de que a acao e
     * da tela, e o `<s-crud-list>` a repassa no output `action`.
     */
    run(action: string, row: T): boolean;
}
/**
 * Cria a listagem a partir da configuracao. Chame no campo de uma classe de
 * componente, como qualquer `inject()`.
 *
 * @see SCrudList
 */
declare function injectCrudList<T extends Record<string, unknown>>(config: SCrudConfig<T>): SCrudList<T>;

/**
 * A tela de listagem inteira: cabecalho, filtros, tabela e rodape.
 *
 * ## O que ele e — e o que nao e
 *
 * E **composicao**, nao um componente novo de dados: por dentro sao os mesmos
 * `<s-page-header>`, `<s-filter-card>` e `<s-table>` que qualquer tela pode
 * montar a mao. Ele existe porque essa montagem e sempre igual, e repeti-la em
 * cada CRUD e onde a moldura de uma tela comeca a divergir da moldura da outra
 * — titulo em lugar diferente, botao com outro rotulo, tabela sem estado vazio.
 *
 * Quem precisa de um arranjo diferente continua livre para montar as tres
 * pecas na mao e usar so `injectCrudList()` — o comportamento nao depende deste
 * componente.
 *
 * ## Os dois slots
 *
 * - `[filters]` — os campos do card de filtros, com o `formGroup` da tela.
 * - `<ng-template sTableCell="chave">` — a celula que foge do texto: um botao,
 *   um link, um icone. Vai direto para a coluna correspondente da tabela.
 *
 * ## Outputs e comportamento padrao
 *
 * Os outputs sao **avisos**, e nao substituicoes: excluir sempre pede
 * confirmacao e chama a fonte de dados; visualizar e editar navegam **quando ha
 * `routes` na configuracao**. Sem `routes`, nada e navegado — e ai os outputs
 * `view`/`edit` sao o caminho da tela, que pode abrir um modal em vez de mudar
 * de rota.
 *
 * @example
 * ```html
 * <s-crud-list [crud]="crud">
 *   <form filters [formGroup]="filtros">
 *     <s-field label="Nome"><s-input icon="search" formControlName="nome" /></s-field>
 *     <s-field label="Status"><s-select [options]="status" formControlName="ativo" /></s-field>
 *   </form>
 *
 *   <ng-template sTableCell="emUso" let-linha>
 *     <s-button variant="ghost" size="sm" (click)="verUsos(linha)">Ver usos</s-button>
 *   </ng-template>
 * </s-crud-list>
 * ```
 */
declare class SCrudListComponent<T extends Record<string, unknown> = Record<string, unknown>> {
    /** A listagem criada por `injectCrudList()`. */
    readonly crud: _angular_core.InputSignal<SCrudList<T>>;
    /**
     * Repassado ao `<s-filter-card>`: com ele os filtros sobrevivem a ida ao
     * cadastro e a volta, e a listagem reconsulta com eles ao reabrir.
     */
    readonly filterId: _angular_core.InputSignal<string>;
    /** Rotulos dos chips de filtro ativo, por chave do formulario de filtros. */
    readonly filterLabels: _angular_core.InputSignal<Record<string, string>>;
    /** Opcoes por chave, para o chip mostrar o rotulo e nao o id do select. */
    readonly filterOptions: _angular_core.InputSignal<Record<string, readonly SOption<unknown>[]>>;
    /** Formatador dos valores de chip que as opcoes nao resolvem. */
    readonly filterValueFormatter: _angular_core.InputSignal<SFilterValueFormatter | null>;
    /** Botao de cadastrar acionado — inclusive o do estado vazio. */
    readonly create: _angular_core.OutputEmitterRef<void>;
    /** Acao de visualizar acionada numa linha. */
    readonly view: _angular_core.OutputEmitterRef<T>;
    /** Acao de editar acionada numa linha. */
    readonly edit: _angular_core.OutputEmitterRef<T>;
    /**
     * Acao de excluir acionada numa linha.
     *
     * O aviso sai **antes** da confirmacao: o modal e a chamada a fonte de dados
     * continuam sendo da biblioteca.
     */
    readonly remove: _angular_core.OutputEmitterRef<T>;
    /** Ativar ou inativar acionado numa linha. */
    readonly inactivate: _angular_core.OutputEmitterRef<T>;
    /** Acao declarada em `extraActions`, que a biblioteca nao executa. */
    readonly action: _angular_core.OutputEmitterRef<STableActionEvent<T>>;
    /** Seta de voltar do cabecalho. */
    readonly back: _angular_core.OutputEmitterRef<void>;
    /**
     * Os templates de celula projetados na tela, repassados a tabela.
     *
     * A tabela e propriedade deste componente, entao os templates precisam
     * atravessa-lo: quem escreve `<ng-template sTableCell>` esta dentro do
     * `<s-crud-list>`, nao dentro da `<s-table>`.
     */
    private readonly templatesProjetados;
    protected readonly templates: _angular_core.Signal<Record<string, _angular_core.TemplateRef<_siage_siage_ui.STableCellContext<T>>>>;
    protected criar(): void;
    /**
     * Botao do estado vazio. So "sem dados" cadastra - e passa por `criar` para
     * emitir `create` como o botao do cabecalho. Erro tenta de novo e filtro sem
     * resultado limpa a busca: ver `SCrudList.emptyAction`.
     */
    protected aoAcaoDoVazio(): void;
    protected aoAcionar(evento: STableActionEvent<T>): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SCrudListComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SCrudListComponent<any>, "s-crud-list", never, { "crud": { "alias": "crud"; "required": true; "isSignal": true; }; "filterId": { "alias": "filterId"; "required": false; "isSignal": true; }; "filterLabels": { "alias": "filterLabels"; "required": false; "isSignal": true; }; "filterOptions": { "alias": "filterOptions"; "required": false; "isSignal": true; }; "filterValueFormatter": { "alias": "filterValueFormatter"; "required": false; "isSignal": true; }; }, { "create": "create"; "view": "view"; "edit": "edit"; "remove": "remove"; "inactivate": "inactivate"; "action": "action"; "back": "back"; }, ["templatesProjetados"], ["[filters]"], true, never>;
}

/** Modo operacional da casca de formulario de CRUD. */
type SCrudFormMode = 'create' | 'edit' | 'view';

/**
 * Casca padrao para formulario de cadastro, edicao e visualizacao de CRUD.
 *
 * ## Por que a casca desabilita o `FormGroup` em visualizacao
 *
 * O guia diferencia `readOnly` de `disabled`, mas esta casca recebe conteudo
 * projetado: pode haver `s-input`, `s-select`, componentes da aplicacao ou ate
 * controles nativos. Nao ha como propagar `readOnly` de forma confiavel para
 * todos sem impor uma API nova a cada controle. Por isso, em `mode="view"` a
 * casca desabilita o `FormGroup` com `emitEvent: false`: e uma trava
 * operacional para impedir edicao acidental. Se uma tela precisa da aparencia
 * de somente-leitura do guia, ela pode repassar `[readOnly]="mode === 'view'"`
 * aos controles projetados; o bloqueio do grupo continua protegendo o submit.
 *
 * ## Metadados por slot
 *
 * A ultima edicao entra pelo slot `[sCrudFormMeta]`, e nao por um input
 * formatado, porque autoria e auditoria variam por sistema. A biblioteca
 * reserva o lugar visual; a aplicacao decide texto, fuso, link ou badge.
 *
 * @example
 * ```html
 * <s-crud-form
 *   title="Nova Escola"
 *   description="Informe os dados cadastrais da escola."
 *   mode="create"
 *   [form]="form"
 *   (save)="save()"
 *   (cancelRequest)="goBack()"
 * >
 *   <s-field label="Nome" required>
 *     <s-input formControlName="schoolName" />
 *   </s-field>
 * </s-crud-form>
 * ```
 */
declare class SCrudFormComponent {
    private readonly formSignal;
    /**
     * Formulario reativo da tela.
     *
     * A casca marca como tocado no submit invalido, consulta `dirty` no cancelar
     * e bloqueia o grupo em `view`. A estrutura dos controles continua sendo da
     * aplicacao.
     *
     * Setter em vez de `input()`: o `FormGroupDirective` provido pela casca
     * precisa receber o grupo antes de os `formControlName` projetados se
     * registrarem, e um `effect()` chegaria tarde demais.
     */
    set form(form: FormGroup | null);
    get form(): FormGroup | null;
    /** Titulo do cabecalho da tela. */
    readonly title: _angular_core.InputSignal<string>;
    /** Subtitulo que explica o objetivo do cadastro. */
    readonly description: _angular_core.InputSignal<string>;
    /** Trilha de navegacao repassada ao `<s-page-header>`. */
    readonly breadcrumbs: _angular_core.InputSignal<readonly SBreadcrumb[]>;
    /** Exibe a seta de voltar do cabecalho. */
    readonly showBack: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Estado da tela.
     *
     * `create` e `edit` exibem Salvar. `view` bloqueia o `FormGroup` e troca
     * Salvar por Editar, para a tela decidir se navega ou muda o modo.
     */
    readonly mode: _angular_core.InputSignal<SCrudFormMode>;
    /**
     * Indica salvamento em andamento.
     *
     * O botao permanece focavel pelo componente de botao, mas o submit e barrado
     * aqui tambem para cobrir envio por Enter.
     */
    readonly saving: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Permissoes no mesmo formato das listagens.
     *
     * `create` controla Salvar em cadastro, `edit` controla Salvar/Editar em
     * edicao ou visualizacao, e `remove` controla Excluir.
     *
     * So esconde botoes: nao e controle de acesso, e o backend precisa autorizar
     * cada operacao. Sem `provideSiagePermissionChecker`, todos aparecem.
     */
    readonly permissions: _angular_core.InputSignal<SListPermissionConfig | null>;
    /** Rotulo do botao de salvar. */
    readonly submitLabel: _angular_core.InputSignal<string>;
    /** Rotulo do botao de cancelar. */
    readonly cancelLabel: _angular_core.InputSignal<string>;
    /** Rotulo do botao que pede edicao em modo visualizacao. */
    readonly editLabel: _angular_core.InputSignal<string>;
    /** Rotulo do botao de exclusao. */
    readonly deleteLabel: _angular_core.InputSignal<string>;
    /** Nome do registro usado nas confirmacoes. */
    readonly entityName: _angular_core.InputSignal<string>;
    /** Seta de voltar do cabecalho. */
    readonly back: _angular_core.OutputEmitterRef<void>;
    /** Salvar acionado com formulario valido. */
    readonly save: _angular_core.OutputEmitterRef<void>;
    /** Cancelamento confirmado ou sem alteracoes pendentes. */
    readonly cancelRequest: _angular_core.OutputEmitterRef<void>;
    /** Pedido de troca para edicao em `mode="view"`. */
    readonly editRequest: _angular_core.OutputEmitterRef<void>;
    /** Exclusao confirmada. O alias preserva a API `(delete)`. */
    readonly remove: _angular_core.OutputEmitterRef<void>;
    private readonly modal;
    private readonly permissionChecker;
    private readonly host;
    private readonly destroyRef;
    private readonly formDirective;
    private disabledForm;
    private originallyDisabledControls;
    protected readonly viewing: _angular_core.Signal<boolean>;
    protected readonly canSave: _angular_core.Signal<boolean>;
    protected readonly canEdit: _angular_core.Signal<boolean>;
    protected readonly canDelete: _angular_core.Signal<boolean>;
    protected readonly cardTitle: _angular_core.Signal<"Dados do cadastro" | "Dados para edição" | "Dados para visualização">;
    constructor();
    protected onSubmit(): void;
    protected onCancel(): Promise<void>;
    protected onDelete(): Promise<void>;
    protected onEditRequest(): void;
    private hasPermission;
    protected currentForm(): FormGroup | null;
    private syncFormDirective;
    private syncViewMode;
    private disableForView;
    private restoreDisabledForm;
    private disabledControls;
    private childrenOf;
    private focusFirstInvalid;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SCrudFormComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SCrudFormComponent, "s-crud-form", never, { "form": { "alias": "form"; "required": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "breadcrumbs": { "alias": "breadcrumbs"; "required": false; "isSignal": true; }; "showBack": { "alias": "showBack"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "saving": { "alias": "saving"; "required": false; "isSignal": true; }; "permissions": { "alias": "permissions"; "required": false; "isSignal": true; }; "submitLabel": { "alias": "submitLabel"; "required": false; "isSignal": true; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; "isSignal": true; }; "editLabel": { "alias": "editLabel"; "required": false; "isSignal": true; }; "deleteLabel": { "alias": "deleteLabel"; "required": false; "isSignal": true; }; "entityName": { "alias": "entityName"; "required": false; "isSignal": true; }; }, { "back": "back"; "save": "save"; "cancelRequest": "cancelRequest"; "editRequest": "editRequest"; "remove": "delete"; }, never, ["[sCrudFormMeta]", "*"], true, never>;
}

/**
 * Marca o conteudo de metadados do formulario.
 *
 * A ultima edicao fica como slot, e nao como input formatado, porque cada
 * sistema tem regras diferentes de autoria, fuso e auditoria. A casca so
 * reserva o lugar visual; a aplicacao decide o texto exato e pode incluir link,
 * badge ou data ja formatada em pt-BR.
 *
 * @example
 * ```html
 * <span sCrudFormMeta>Ultima edicao por Ana, em 02/10/2026.</span>
 * ```
 */
declare class SCrudFormMetaDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SCrudFormMetaDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SCrudFormMetaDirective, "[sCrudFormMeta]", never, {}, {}, never, never, true, never>;
}

/** O envelope paginado que as APIs do SIAGE devolvem hoje. */
interface SSiagePagedResult<T> {
    items?: readonly T[];
    totalCount?: number;
}
/**
 * O contrato que os services de listagem do SIAGE ja seguem.
 *
 * Todo metodo e opcional: um cadastro sem exclusao simplesmente nao implementa
 * `delete`, e a lixeira nao aparece na tabela.
 */
interface SSiageCrudService<T> {
    getByFilterPaginated?(params?: URLSearchParams): Observable<SSiagePagedResult<T>>;
    getByFilter?(params?: URLSearchParams): Observable<readonly T[]>;
    delete?(id: string): Observable<unknown>;
    activate?(row: T): Observable<unknown>;
    inactivate?(row: T): Observable<unknown>;
}
/** Ajustes do adaptador, para as APIs que fogem do padrao. */
interface SSiageDataSourceOptions<T> {
    /** Campo do identificador, usado na exclusao. Padrao `'id'`. */
    idKey?: keyof T & string;
    /** Nome do parametro de pagina. Padrao `'page'`. */
    pageParam?: string;
    /** Nome do parametro de tamanho de pagina. Padrao `'pageSize'`. */
    pageSizeParam?: string;
    /** Nome do parametro de ordenacao. Padrao `'sort'`. */
    sortParam?: string;
    /** Nome do parametro de direcao. Padrao `'sortDirection'`. */
    sortDirectionParam?: string;
}
/**
 * Adapta um service de listagem do SIAGE a `SCrudDataSource`, sem escrever a
 * classe a mao.
 *
 * E o caminho para as telas que estao migrando: o service continua o mesmo —
 * `getByFilterPaginated`, `delete`, `activate`/`inactivate` —, e o adaptador
 * traduz `SCrudQuery` em `URLSearchParams` e `PagedResult` em `SCrudPage`.
 *
 * Quando a API de um sistema novo nao seguir esse contrato, escreva a fonte
 * estendendo `SCrudDataSource` — este adaptador e conveniencia, nao regra.
 *
 * Sem `getByFilterPaginated`, cai em `getByFilter`: a API devolve a lista
 * inteira, o total passa a ser o tamanho dela e a pagina e recortada aqui, em
 * memoria. Serve para cadastros pequenos; lista grande pede o endpoint
 * paginado.
 *
 * @example
 * ```ts
 * protected readonly crud = injectCrudList<TipoFaltaListDto>({
 *   dataSource: siageCrudDataSource(inject(TipoFaltaService)),
 *   // ...
 * });
 * ```
 */
declare function siageCrudDataSource<T extends Record<string, unknown>>(service: SSiageCrudService<T>, options?: SSiageDataSourceOptions<T>): SCrudDataSource<T>;

export { SCrudDataSource, SCrudFormComponent, SCrudFormMetaDirective, SCrudList, SCrudListComponent, injectCrudList, siageCrudDataSource };
export type { SCrudActionId, SCrudActions, SCrudConfig, SCrudEntity, SCrudFormMode, SCrudPage, SCrudQuery, SCrudRoutes, SSiageCrudService, SSiageDataSourceOptions, SSiagePagedResult };
